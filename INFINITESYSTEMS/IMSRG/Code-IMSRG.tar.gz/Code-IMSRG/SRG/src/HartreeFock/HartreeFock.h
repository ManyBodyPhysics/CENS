
#ifndef HARTREEFOCK_H
#define	HARTREEFOCK_H

#include "../System/System.h"
#include <vector>
#include <iomanip>

#define MAX_IT 100
#define HF_TOL 1.0e-8

////////////////////////////////////////////////////////////////////////////////
//                          class HartreeFock

/** @brief Class for performing a Hartree-Fock calculation and transforming
 * a given basis to Hartree-Fock basis
    @author Sarah Reimann
    @date 28 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

class HartreeFock{
    
private:
    
    System* Sys; 
    mat C; /// coefficient matrix
    mat C_inner; /// simplified coefficient matrix
    std::vector<arma::mat> tr_elems; /// transformed matrix elements
    std::vector<int>* cCombs; /// index combinations where coefficient matrix is non-zero
    
public:   
    
    /**
     * Constructor
     * @param Sys - system to be treated
     */
    HartreeFock(System* Sys);
    
    ~HartreeFock();
    
    /**
     * Main Hartree-Fock algorithm
     * @param R - number of shells
     * @return transformed Hartree-Fock energy
     */
    double hf_algo(int R);
    
    /**
     * Compute Hartree-Fock energy
     * @return Hartree-Fock energy
     */
    double HFenergy();
    
    /**
     * Transform the basis of the System
     * @param E_HF - Hartree-Fock energy
     */
    void basis_transformation(double E_HF);
    
    /**
     * Extract those index combinations where coefficient matrix is non-zero
     * @param C_mat
     */
    void create_Ccombs(mat& C_mat);
    
    /**
     * Set one-body element in Hamiltonian
     * @param p - first index
     * @param q - second index
     * @param elem - value of element
     */
    void set_f_elem(int p, int q, double elem);
    
    /**
     * Compute the "rho"-matrix to speed up convergence
     * @param rhon
     */
    void mkrho(mat& rhon);
    
    /**
     * Transform two-body elements of type v_hhhh
     */
    void transform_vhhhh();
    
    /**
     * Transform two-body elements of type v_phhh
     */
    void transform_vphhh();
    
    /**
     * Transform two-body elements of type v_pphh
     */
    void transform_vpphh();
    
    /**
     * Transform two-body elements of type v_phph
     */
    void transform_vphph();
    
    /**
     * Transform two-body elements of type v_ppph
     */
    void transform_vppph();
    
    /**
     * Transform two-body elements of type v_pppp
     */
    void transform_vpppp();
    
    
};

#endif	/* HARTREEFOCK_H */

