
#include "HartreeFock.h"
 
////////////////////////////////////////////////////////////////////////////////
//                          class HartreeFock

/** @brief Class for performing a Hartree-Fock calculation and transforming
 * a given basis to Hartree-Fock basis
    @author Sarah Reimann
    @date 28 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

  
HartreeFock::HartreeFock(System* Sys) {

    this->Sys = Sys;
}

HartreeFock::~HartreeFock(){
    cCombs->clear();
}


double HartreeFock::hf_algo(int R) {

    mat eigvec, tmp;
    vec eigval;
    
    double E_old, E_new;
    int alpha, gamma, bsize, a;
    int mvalue, msvalue, map1, map2;
    
    std::vector<arma::mat> hHF2;

    int iterations = 0;
    bool check = true;
    int Mmax_single = R - 1;
    int alphadim_single = 4 * Mmax_single + 2;

    ivec bc_single(alphadim_single);
    bc_single.fill(0);

    C = zeros(Sys->Bas->sp_states, Sys->Bas->sp_states); // coefficient matrix
    
    E_old = Sys->H->mat_elems[0](0, 0); // start value for E_HF
    
    cCombs = new std::vector<int>[Sys->H->Bas->sp_states];
    mat hf_full = zeros(Sys->H->Bas->sp_states, Sys->H->Bas->sp_states); // full Hf-matrix

    // Initialize the coefficient matrix
    for (int i = 0; i < Sys->Bas->sp_states; i++)
        C(i, i) = 1.0;

    alpha = 0;

    // Creating number of blocks in HF-matrix
    for (int l = -Mmax_single; l <= Mmax_single; l++) {
        mvalue = l;
        for (msvalue = -1; msvalue <= 1; msvalue += 2) {
            bsize = 0;
            for (int i = 0; i < Sys->H->Bas->sp_states; i++) {
                if (mvalue == Sys->H->Bas->singPart[i].qnumbers[1] && 
                        msvalue == Sys->H->Bas->singPart[i].qnumbers[2])
                    bsize += 1;
            }
            bc_single(alpha) = bsize;
            alpha += 1;
        }
    }

    int **sc = new int*[alphadim_single]; 
    for (int i = 0; i < alphadim_single; i++) {
        sc[i] = new int[bc_single(i)];
        for (int j = 0; j < bc_single(i); j++)
            sc[i][j] = 0;
    }

    alpha = 0;

    for (int l = -Mmax_single; l <= Mmax_single; l++) {
        mvalue = l;
        for (msvalue = -1; msvalue <= 1; msvalue += 2) {
            bsize = 0;
            for (int i = 0; i < Sys->H->Bas->sp_states; i++) {
                if (mvalue == Sys->H->Bas->singPart[i].qnumbers[1] && msvalue 
                        == Sys->H->Bas->singPart[i].qnumbers[2]) {
                    sc[alpha][bsize] = i;
                    bsize += 1;
                }
            }
            alpha += 1;
        }
    }

    
    // Matrices rhon and rho as computational trick to fasten convergence
    mat rhon = zeros(Sys->H->Bas->sp_states, Sys->H->Bas->sp_states);
    mat rho = zeros(Sys->H->Bas->sp_states, Sys->H->Bas->sp_states);
    
    for (int x = 0; x < alphadim_single; x++) {
        tmp = zeros(bc_single(x), bc_single(x));
        hHF2.push_back(tmp);
    }

    // Main HF loop, performed until convergence
    while (check) {

        iterations++;
        
        // In case of no convergence
        if (iterations > MAX_IT) {
            cout << "No HF convergence" << endl;
            ofstream logfile;
            logfile.open("../Outputs/FullResults/log.dat", ios::app);
            logfile << "- No convergence HF for " << Sys->H->Bas->hole_states 
                    << " " << R << " " << Sys->H->omega << endl;
            logfile.close();
            exit(0);
        }

        
        mkrho(rhon);
        rho = 0.8 * rho + 0.2 * rhon;
       
        // Computing HF-matrix
#pragma omp parallel for private(a,map1,alpha,map2,gamma) schedule(dynamic)
        for (int x = 0; x < alphadim_single; x++) {

            for (a = 0; a < bc_single(x); a++) {
                map1 = a;
                alpha = sc[x][a];
                map2 = 0;
                for (int g = 0; g < bc_single(x); g++) {
                    map2 = g;
                    gamma = sc[x][g];
                    if (alpha == gamma)
                        hf_full(alpha, gamma) = Sys->H->Bas->singPart[gamma].eps;
                    else
                        hf_full(alpha, gamma) = 0;

                    for (int b = 0; b < Sys->H->Bas->sp_states; b++)
                        for (int d = 0; d < Sys->H->Bas->sp_states; d++)
                            hf_full(alpha, gamma) += rho(b, d) * Sys->H->get_v_elem(
                                    alpha, b, gamma, d, Sys->H->mat_elems);

                    hHF2[x](map1, map2) = hf_full(alpha, gamma);
                }
            }

        } // end x-loop

        // Diagonalize Hartree-Fock matrices
        for (int x = 0; x < alphadim_single; x++) {
            eig_sym(eigval, eigvec, hHF2[x]);

            // Updating C
            for (int i = 0; i < bc_single(x); i++)
                for (int j = 0; j < bc_single(x); j++)
                    C(sc[x][i], sc[x][j]) = eigvec(i, j);
        }

        // energy check
        E_new = HFenergy();
        if (abs(E_old - E_new) < HF_TOL)
            check = false;

        /*cout << "Iteration:  " << iterations <<  ", E_HF: " 
         * << setprecision(8)<< setw(15) << E_new << endl;*/
        
        E_old = E_new;

    }

    // cout << "HF successful, begin transformation elements" << endl;
 
    for (int i = 0; i < alphadim_single; i++)
        delete[] sc[i];
    delete[] sc;

    eigvec.clear();
    eigval.clear();
    hf_full.clear();
    bc_single.clear();
    rhon.clear();
    rho.clear();
    hHF2.clear();

    return E_old;
}


double HartreeFock::HFenergy() {

    double hf_ret = 0;
    int alpha, beta, gamma, delta;
    int nsp = Sys->Bas->sp_states;
      
    mat C_holeXall = C.submat(span::all,span(0,Sys->Bas->hole_states-1));
    C_inner = C_holeXall*C_holeXall.t();
            
    create_Ccombs(C_inner);
   
     // Two-body contribution
#pragma omp parallel for private(alpha, gamma, beta, delta) reduction(+:hf_ret)
    for (alpha = 0; alpha < nsp; alpha++)
        for (int c = 0; c < cCombs[alpha].size(); c++) {
            gamma = cCombs[alpha][c];
            for (beta = 0; beta < nsp; beta++)
                for (int d = 0; d < cCombs[beta].size(); d++) {
                    delta = cCombs[beta][d];
                    hf_ret +=  C_inner(alpha, gamma) * C_inner(beta, delta)
                            * Sys->H->get_v_elem(alpha, beta, gamma, delta, Sys->H->mat_elems);
                }
        }
    
    hf_ret *= 0.5;
    
    // One-body contribution
     for(alpha = 0; alpha < Sys->Bas->sp_states; alpha++)           
            hf_ret += C_inner(alpha,alpha)*Sys->Bas->singPart[alpha].eps;
            
    return hf_ret;

}


void HartreeFock::basis_transformation(double E_HF) {

    int p_ind, q_ind;
    double sp_HF;
    mat elms;
    wall_clock timerTr;
    //timerTr.tic();

    tr_elems = Sys->H->mat_elems;
    tr_elems[0](0, 0) = E_HF;

    create_Ccombs(C); // extract non-zero elements of C-matrix

    //**************************************************************************
    //                 Transformation of two-body elements

    transform_vhhhh();
    transform_vphhh();
    transform_vpphh();
    transform_vphph();
    transform_vppph();
    transform_vpppp();

    //**************************************************************************
    //                Transformation of one-body elements


    imat lbd_limits = Sys->H->Bas->lbd_limits();

    for (int i = 1; i <= 3; i++)
        tr_elems[i].zeros();

    // Contribution from single-particle energies
#pragma omp parallel for private(sp_HF) schedule(dynamic)
    for (int a = 0; a < Sys->H->Bas->sp_states; a++) {
        for (int b = a; b < Sys->H->Bas->sp_states; b++) {
            sp_HF = 0.0;
            for (int i = 0; i < Sys->H->Bas->sp_states; i++)
                sp_HF += C(i, a) * C(i, b) * Sys->H->Bas->singPart[i].eps;

            set_f_elem(a, b, sp_HF);
        }
    }

    int hole_states = Sys->H->Bas->hole_states;
    int part_states = Sys->H->Bas->sp_states - hole_states;
    
    // Transformation of f_hh 
    elms = zeros(hole_states, hole_states);

    for (int p = 0; p < hole_states; p++)
        for (int q = p; q < hole_states; q++) { 
            for (int i = 0; i < hole_states; i++)
                if (Sys->H->Bas->singPart[p].qnumbers[1] +
                        Sys->H->Bas->singPart[i].qnumbers[1]
                        == Sys->H->Bas->singPart[q].qnumbers[1] +
                        Sys->H->Bas->singPart[i].qnumbers[1])
                    if (Sys->H->Bas->singPart[p].qnumbers[2] +
                            Sys->H->Bas->singPart[i].qnumbers[2]
                            == Sys->H->Bas->singPart[q].qnumbers[2] +
                            Sys->H->Bas->singPart[i].qnumbers[2]) 
                        elms(p, q) += Sys->H->get_v_elem(p, i, q, i, tr_elems);
                elms(q,p) = elms(p,q);
        }

    tr_elems[1] += elms;

    // Transformation of f_pp
    elms = zeros(part_states, part_states);

    for (int p = hole_states; p < Sys->H->Bas->sp_states; p++){
        p_ind = p-hole_states;
        for (int q = p; q < Sys->H->Bas->sp_states; q++) {
            q_ind = q-hole_states;
            for (int i = 0; i < hole_states; i++)
                if (Sys->H->Bas->singPart[p].qnumbers[1] + 
                        Sys->H->Bas->singPart[i].qnumbers[1]
                        == Sys->H->Bas->singPart[q].qnumbers[1] +
                        Sys->H->Bas->singPart[i].qnumbers[1])
                    if (Sys->H->Bas->singPart[p].qnumbers[2] + 
                            Sys->H->Bas->singPart[i].qnumbers[2] 
                            == Sys->H->Bas->singPart[q].qnumbers[2] 
                            + Sys->H->Bas->singPart[i].qnumbers[2]) 
                        elms(p_ind, q_ind) += Sys->H->get_v_elem(p, i, q, i, tr_elems); 
        
                elms(q_ind, p_ind) = elms(p_ind, q_ind);
        }
    }

    tr_elems[3] += elms;

    //  Transformation of f_ph
    elms = zeros(part_states, hole_states);

    for (int p = hole_states; p < Sys->H->Bas->sp_states; p++)
        for (int q = 0; q < Sys->H->Bas->hole_states; q++) {
            for (int i = 0; i < hole_states; i++)
                if (Sys->H->Bas->singPart[p].qnumbers[1] + 
                        Sys->H->Bas->singPart[i].qnumbers[1] == 
                        Sys->H->Bas->singPart[q].qnumbers[1]
                        + Sys->H->Bas->singPart[i].qnumbers[1])
                    if (Sys->H->Bas->singPart[p].qnumbers[2] + 
                            Sys->H->Bas->singPart[i].qnumbers[2] 
                            == Sys->H->Bas->singPart[q].qnumbers[2] +
                            Sys->H->Bas->singPart[i].qnumbers[2])
                        elms(p - hole_states, q) += Sys->H->get_v_elem(p, i, q, i, tr_elems); 
        }

    tr_elems[2] += elms;

    //cout << "Transformation of HF basis finished" << endl;
    
    Sys->H->mat_elems = tr_elems;
    
    //double elapsed_timeTr = timerTr.toc();
    //cout << "Elapsed time HF transformation: " << elapsed_timeTr << endl;

    C.clear();
    tr_elems.clear();
    cCombs->clear();

}


void HartreeFock::create_Ccombs(mat& C_mat) {

#pragma omp parallel for
    for (int i = 0; i < Sys->Bas->sp_states; i++) {
        cCombs[i].clear();
        for (int j = 0; j < Sys->Bas->sp_states; j++)
            if (abs(C_mat(i, j)) > 10e-16) cCombs[i].push_back(j);
    }

}


void HartreeFock::set_f_elem(int p, int q, double element) {

    // f_hh
    if ((p < Sys->H->Bas->hole_states) && (q < Sys->H->Bas->hole_states)) {
        tr_elems[1](p, q) = element;
        tr_elems[1](q, p) = element;
        return;
    }

    // f_ph
    if ((p >= Sys->H->Bas->hole_states) && (q < Sys->H->Bas->hole_states)) {
        tr_elems[2](p - Sys->H->Bas->hole_states, q) = element;
        return;
    }

    // f_hp
    if ((p < Sys->H->Bas->hole_states) && (q >= Sys->H->Bas->hole_states)) {
        tr_elems[2](q - Sys->H->Bas->hole_states, p) = element;
        return;
    }

    // f_pp
    tr_elems[3](p - Sys->H->Bas->hole_states, q - Sys->H->Bas->hole_states) = element;
    tr_elems[3](q - Sys->H->Bas->hole_states, p - Sys->H->Bas->hole_states) = element;
    return;

}

void HartreeFock::mkrho(mat& rhon) {
   
    mat CHolesXAll = C.submat(span::all, span(0,Sys->Bas->hole_states-1));   
    rhon = CHolesXAll*CHolesXAll.t();

}


void HartreeFock::transform_vhhhh() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
        tr_elems[4 + 6 * lbd].zeros();
        for (int ab = 0; ab < Sys->H->Bas->hh_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->hh_basis[lbd][ab](1);
            b = Sys->H->Bas->hh_basis[lbd][ab](0);

            for (int cd = 0; cd < Sys->H->Bas->hh_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->hh_basis[lbd][cd](1);
                d = Sys->H->Bas->hh_basis[lbd][cd](0);
                tp_HF = 0.0;

                // Inner loop        
                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];
            
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c)
                                        * C(delta, d) * Sys->H->get_v_elem(alpha, 
                                        beta, gamma, delta, Sys->H->mat_elems); 
                            }
                        }
                    }
                }
                tr_elems[4 + 6 * lbd](ab, cd) = tp_HF;
            }

        }
    }
}


void HartreeFock::transform_vphhh() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ab = 0; ab < Sys->H->Bas->ph_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->ph_basis[lbd][ab](1);
            b = Sys->H->Bas->ph_basis[lbd][ab](0);
            for (int cd = 0; cd < Sys->H->Bas->hh_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->hh_basis[lbd][cd](1);
                d = Sys->H->Bas->hh_basis[lbd][cd](0);
                tp_HF = 0.0;

                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];
                             
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c)
                                        * C(delta, d) * Sys->H->get_v_elem(alpha, 
                                        beta, gamma, delta, Sys->H->mat_elems); 
                            }
                        }
                    }
                }

                tr_elems[5 + 6 * lbd](ab, cd) = tp_HF;                
            }
        }
}


void HartreeFock::transform_vpphh() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->pp_basis[lbd][ab](1);
            b = Sys->H->Bas->pp_basis[lbd][ab](0);
            for (int cd = 0; cd < Sys->H->Bas->hh_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->hh_basis[lbd][cd](1);
                d = Sys->H->Bas->hh_basis[lbd][cd](0);
                tp_HF = 0.0;

                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];
        
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c) 
                                        * C(delta, d) * Sys->H->get_v_elem(alpha,
                                        beta, gamma, delta, Sys->H->mat_elems); 
                            }
                        }
                    }
                }
                tr_elems[6 + 6 * lbd](ab, cd) = tp_HF;
            }
        }
}


void HartreeFock::transform_vphph() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++)
        for (int ab = 0; ab < Sys->H->Bas->ph_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->ph_basis[lbd][ab](1);
            b = Sys->H->Bas->ph_basis[lbd][ab](0);
            for (int cd = 0; cd < Sys->H->Bas->ph_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->ph_basis[lbd][cd](1);
                d = Sys->H->Bas->ph_basis[lbd][cd](0);
                tp_HF = 0.0;

                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];          
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c)
                                        * C(delta, d) * Sys->H->get_v_elem(alpha,
                                        beta, gamma, delta, Sys->H->mat_elems); 
                            }
                        }
                    }
                }
                tr_elems[7 + 6 * lbd](ab, cd) = tp_HF;   
            }
        }
}


void HartreeFock::transform_vppph() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++)
        for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->pp_basis[lbd][ab](1);
            b = Sys->H->Bas->pp_basis[lbd][ab](0);
            for (int cd = 0; cd < Sys->H->Bas->ph_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->ph_basis[lbd][cd](1);
                d = Sys->H->Bas->ph_basis[lbd][cd](0);
                tp_HF = 0.0;

                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];
            
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c)
                                        * C(delta, d) * Sys->H->get_v_elem(alpha,
                                        beta, gamma, delta, Sys->H->mat_elems); 
                            }
                        }
                    }
                }

                tr_elems[8 + 6 * lbd](ab, cd) = tp_HF;
            }
        }
}


void HartreeFock::transform_vpppp() {

    double tp_HF;
    int a, b, c, d;
    int alpha, beta, gamma, delta;
    imat lbd_limits = Sys->H->Bas->lbd_limits();
    ivec tmp;

#pragma omp parallel for private(tp_HF, a,b,c,d,alpha,beta,gamma,delta,tmp) schedule(dynamic)
    for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++)
        for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
            a = Sys->H->Bas->pp_basis[lbd][ab](1);
            b = Sys->H->Bas->pp_basis[lbd][ab](0);
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {
                c = Sys->H->Bas->pp_basis[lbd][cd](1);
                d = Sys->H->Bas->pp_basis[lbd][cd](0);
                tp_HF = 0.0;

                for (int p = 0; p < cCombs[a].size(); p++) {
                    alpha = cCombs[a][p];
                    for (int q = 0; q < cCombs[b].size(); q++) {
                        beta = cCombs[b][q];
          
                        for (int r = 0; r < cCombs[c].size(); r++) {
                            gamma = cCombs[c][r];
                            for (int s = 0; s < cCombs[d].size(); s++) {
                                delta = cCombs[d][s];
                                tp_HF += C(alpha, a) * C(beta, b) * C(gamma, c) * C(delta, d) * Sys->H->get_v_elem(alpha, beta, gamma, delta, Sys->H->mat_elems); // TODO: optimize
                            }
                        }
                    }
                }
                tr_elems[9 + 6 * lbd](ab, cd) = tp_HF;
            }
        }
}


