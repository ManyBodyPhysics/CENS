
#ifndef SYSTEM_H
#define	SYSTEM_H

#include "../../lib/ARMADILLO_LAPACK.h"
#include <cstdlib>
#include <bitset>
#include "../Basis/Basis.h"
#include "../Hamiltonian/Hamiltonian.h"


using namespace std;
using namespace arma;

////////////////////////////////////////////////////////////////////////////////
//                          class System

/** @brief Class for holding all data structures and methods of a specific system,
           serves as interface for solvers
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


class System {
protected:
    int R; /// number of shells
    int numpart; /// number of particles
    int sp_states; /// number of single-particle states

public:
    
    System(){};
    
    ~System();
    
    /**
     * Assign each single-particle state its quantum numbers
     * @param omega - oscilllator frequency
     */
    virtual void mapping(double omega) = 0;
    
    /**
     * Set up the System and initialise it, e.g. create tp-basis and
     * set up the Hamiltonian
     * @param hfbasis - specify if Hartree-Fock basis is used
     * @param omega - oscillator frequency
     * @param label - label for input files
     */
    void setup(bool hfbasis, double omega, int label);
    
    Hamiltonian* H; /// Hamiltonian of the system
    Basis* Bas;  /// basis in which the system is set up
};
    

////////////////////////////////////////////////////////////////////////////////
//                          class System_2DQdot

/** @brief Subclass of "System", used for parabolic two-dimensional quantum dots
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


class System_2DQdot: public System{ 
    
public:
    
    /**
     * Constructor
     * @param numpart - number of particles
     * @param R - number of shells
     */
    System_2DQdot(int numpart, int R);
    
    ~System_2DQdot();
    
    /**
     * Assign each single-particle state its quantum numbers
     * @param omega - oscillator frequency
     */
    void mapping(double omega);
};


#endif	/* SYSTEM_H */

