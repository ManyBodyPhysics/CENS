
#include "System.h"

////////////////////////////////////////////////////////////////////////////////
//                          class System

/** @brief Class for holding all data structures and methods of a specific system,
           serves as interface for solvers
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

 
System::~System(){
    
    delete H;
    delete Bas;
}

void System::setup(bool hfbasis, double omega, int label) {
    
    // Set up the basis
    mapping(omega); 
    Bas->establish_basis(R);
    
    // Set up the Hamiltonian
    H = new Hamiltonian(Bas);  
    H->setup_Hamiltonian(omega, label);

   // cout << "Finished setup of Hamiltonian" << endl;
  
}


////////////////////////////////////////////////////////////////////////////////
//                          class System_2DQdot

/** @brief Subclass of "System", used for parabolic two-dimensional quantum dots
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


System_2DQdot::System_2DQdot(int numpart, int R){
    
    this->numpart = numpart;
    this->R = R;
    
    sp_states = R*(R+1);

    Bas = new Basis(sp_states,numpart, 3);
         
}


void System_2DQdot::mapping(double omega){
    
    int state = 0;
    
    for(int shell = 1; shell <=R; shell ++){
        
        for( int i = 0; i< shell; i++){
            
            Bas->singPart[state].qnumbers[0]  = 
                    Bas->singPart[state+1].qnumbers[0] = i/2; // q-number "n"
            
            if(i%2 == 0){
                 Bas->singPart[state].qnumbers[1] 
                         =  Bas->singPart[state+1].qnumbers[1] 
                         = -(shell-1-2* Bas->singPart[state].qnumbers[0]); // q-number "m"
            }   
            else{
                 Bas->singPart[state].qnumbers[1] 
                         =  Bas->singPart[state+1].qnumbers[1] 
                         =  shell-1-2*Bas->singPart[state].qnumbers[0];
            }
            
            Bas->singPart[state].qnumbers[2] = -1; // q-number "m_s"
            Bas->singPart[state].eps = Bas->singPart[state+1].eps = shell*omega; 
            state++;
            
            Bas->singPart[state].qnumbers[2] = +1; // q-number "m_s"
            state++;
        }       
    }
    
    return;
    
}

