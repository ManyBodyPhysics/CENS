
#include "Hamiltonian.h"  
 
#define DEBUG 0
 
//////////////////////////////// ///////////////////////////////////////////////
//                          class Hamiltonian

/** @brief Class for handling the Hamiltonian matrix in a given basis
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

Hamiltonian::Hamiltonian(Basis* Bas) {

    this->Bas = Bas;

}


void Hamiltonian::setup_Hamiltonian(double omega, int label) {

    this->omega = omega;
    mat tmp = zeros(0, 0);

    // Allocate memory for all needed elements
    for (int i = 0; i < 4; i++)
        mat_elems.push_back(tmp);

    for (int lbd = 0; lbd < Bas->lbd_dim; lbd++)
        for (int i = 0; i < 6; i++)
            mat_elems.push_back(tmp);

    // Compute all elements
    setup_v(label);
    setup_f();
    E0_contr();

    return;
}


void Hamiltonian::E0_contr() {

    mat_elems[0] = zeros(1, 1); 
    
    // Single-particle contribution
    for (int i = 0; i < Bas->hole_states; i++)
        mat_elems[0](0, 0) += Bas->singPart[i].eps;

    double tb_contr = 0.0;

    // Two-body contribution
    for (int lbd = 0; lbd < Bas->lbd_dim; lbd++)
        for (int i = 0; i < Bas->hh_basis[lbd].size(); i++)
            tb_contr += mat_elems[4 + lbd * 6](i, i);
    
    mat_elems[0](0, 0) += tb_contr;

    return;
    
}


void Hamiltonian::setup_f() { 

    int indx;
    mat elms;
    
    int part_states = Bas->sp_states - Bas->hole_states;
    int hole_states = Bas->hole_states;
    
    ///////////////////////////////////////////////////////////////////////////
    // Allocate correct amount of memory

    //f_hh 
    elms = zeros(hole_states, hole_states);
    mat_elems[1] = elms;

    //f_pp  
    elms = zeros(part_states, part_states);
    mat_elems[3] = elms;

    //f_ph
    elms = zeros(part_states, hole_states);
    mat_elems[2] = elms;

    
    ////////////////////////////////////////////////////////////////////////////
    // Compute the f-elements
    
    //f_hh 
    elms = zeros(hole_states, hole_states);
    for (int i = 0; i < hole_states; i++)
        elms(i, i) += Bas->singPart[i].eps;

    for (int p = 0; p < hole_states; p++)
        for (int q = p; q < hole_states; q++) { 
            for (int i = 0; i < hole_states; i++)
                if (Bas->singPart[p].qnumbers[1] + Bas->singPart[i].qnumbers[1] 
                        == Bas->singPart[q].qnumbers[1] + Bas->singPart[i].qnumbers[1])
                    if (Bas->singPart[p].qnumbers[2] + Bas->singPart[i].qnumbers[2]
                            == Bas->singPart[q].qnumbers[2] + Bas->singPart[i].qnumbers[2])
                        elms(p, q) += get_v_elem(p, i, q, i, mat_elems);
        }
    
    for(int p = 0; p < hole_states; p++) 
        for(int q = p; q < hole_states; q++)
            elms(q,p) = elms(p,q);

    mat_elems[1] = elms;

    
    //f_pp  
    elms = zeros(part_states, part_states);
    for (int i = hole_states; i < Bas->sp_states; i++) {
        indx = i - hole_states;
        elms(indx, indx) += Bas->singPart[i].eps;
    }


    for (int p = hole_states; p < Bas->sp_states; p++)
        for (int q = p; q < Bas->sp_states; q++) { 
            for (int i = 0; i < hole_states; i++)
                if (Bas->singPart[p].qnumbers[1] + Bas->singPart[i].qnumbers[1]
                        == Bas->singPart[q].qnumbers[1] + Bas->singPart[i].qnumbers[1])
                    if (Bas->singPart[p].qnumbers[2] + Bas->singPart[i].qnumbers[2]
                            == Bas->singPart[q].qnumbers[2] + Bas->singPart[i].qnumbers[2])
                        elms(p - hole_states, q - hole_states) += get_v_elem(p, i, q, i, mat_elems); 
        }


    for(int p = 0; p < Bas->sp_states-hole_states; p++) 
        for(int q = p; q < Bas->sp_states-hole_states; q++)
            elms(q,p) = elms(p,q);
    
    mat_elems[3] = elms;

    

    //f_ph
    elms = zeros(part_states, hole_states);

    for (int p = hole_states; p < Bas->sp_states; p++)
        for (int q = 0; q < Bas->hole_states; q++) { 
            for (int i = 0; i < hole_states; i++)
                if (Bas->singPart[p].qnumbers[1] + Bas->singPart[i].qnumbers[1] == Bas->singPart[q].qnumbers[1] + Bas->singPart[i].qnumbers[1])
                    if (Bas->singPart[p].qnumbers[2] + Bas->singPart[i].qnumbers[2] == Bas->singPart[q].qnumbers[2] + Bas->singPart[i].qnumbers[2]) elms(p - hole_states, q) += get_v_elem(p, i, q, i, mat_elems); // Optimize
        }

    mat_elems[2] = elms;

}


void Hamiltonian::setup_v(int label) {

    ifstream infile;
    mat elms;
    double element;
    int qnumP, qnumQ, qnumR, qnumS;
    int hhmax, phmax, ppmax;
   
    for (int lbd = 0; lbd < Bas->lbd_dim; lbd++) {

        hhmax = Bas->hh_basis[lbd].size();
        phmax = Bas->ph_basis[lbd].size();
        ppmax = Bas->pp_basis[lbd].size();

        ///////////////////////////////////////////////////////////////////////
        // Allocate the correct amount of memory for the interaction elements
        
        //v_hhhh 
        elms = zeros(hhmax, hhmax);
        mat_elems[4 + lbd * 6] = elms;

        // v_phhh
        elms = zeros(phmax, hhmax);
        mat_elems[5 + lbd * 6] = elms;

        // v_pphh 
        elms = zeros(ppmax, hhmax);
        mat_elems[6 + lbd * 6] = elms;

        // v_phph 
        elms = zeros(phmax, phmax);
        mat_elems[7 + lbd * 6] = elms;

        // v_ppph  
        elms = zeros(ppmax, phmax);
        mat_elems[8 + lbd * 6] = elms;

        // v_pppp 
        elms = zeros(ppmax, ppmax);
        mat_elems[9 + lbd * 6] = elms;

    }
    
    ///////////////////////////////////////////////////////////////////////////
    // Read in the two-body elements from file

    ostringstream filename(ostringstream::app);
    filename << "tpelements.dat";
    filename << label;
    infile.open(filename.str().c_str(), ios::in);

    while (true) {

        element = 0;

        if (infile.eof())
            break;

        infile >> qnumP;
        infile >> qnumQ;
        infile >> qnumR;
        infile >> qnumS;
        infile >> element;
        if (infile.eof())
            break;

        set_v_elem(qnumP, qnumQ, qnumR, qnumS, element * omega);

    }

    infile.close(); 

}


double Hamiltonian::get_f_elem(int p, int q, std::vector<arma::mat>& mat_elems) const {

    // f_hh
    if ((p < Bas->hole_states) && (q < Bas->hole_states))
        return mat_elems[1](p, q);

    // f_ph
    if ((p >= Bas->hole_states) && (q < Bas->hole_states))
        return mat_elems[2](p - Bas->hole_states, q);

    // f_hp
    if ((p < Bas->hole_states) && (q >= Bas->hole_states))
        return mat_elems[2](q - Bas->hole_states, p);

    // f_pp
    return mat_elems[3](p - Bas->hole_states, q - Bas->hole_states);

}


double Hamiltonian::get_v_elem(int p, int q, int r, int s, std::vector<arma::mat>& mat_elems) const {

    int tmp;
    int comb1, comb2;
    
    int sign = 1;

    int M1 = Bas->singPart[p].qnumbers[1] + Bas->singPart[q].qnumbers[1];
    int M2 = Bas->singPart[r].qnumbers[1] + Bas->singPart[s].qnumbers[1];

    // Check conservation of momentum
    if (M1 != M2) return 0;

    int Ms1 = Bas->singPart[p].qnumbers[2] + Bas->singPart[q].qnumbers[2];
    int Ms2 = Bas->singPart[r].qnumbers[2] + Bas->singPart[s].qnumbers[2];

    // Check conservation of spin
    if (Ms1 != Ms2) return 0;

    
    // Bring the indices into the right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    
    // Extract correct channel
    int lbd = Bas->get_lbd(M1, Ms1);

    if (p < Bas->hole_states) {
        if (q < Bas->hole_states) {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_hhhh
                    comb1 = Bas->map_hh(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[4 + 6 * lbd](comb1, comb2);

                } else {

                    // v_hhhp -> v_phhh
                    comb1 = Bas->map_ph(s, r, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Bas->hole_states) {

                    // v_hhph ->v_phhh
                    comb1 = Bas->map_ph(r, s, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                } else {

                    // v_hhpp -> v_pphh
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[6 + 6 * lbd](comb1, comb2);
                }
            }

        } else {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_hphh -> v_phhh
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[5 + 6 * lbd](comb1, comb2);
                } else {

                    // v_hphp -> v_phph
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Bas->hole_states) {

                    // v_hpph -> v_phph
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                } else {
                    // v_hppp -> v_ppph
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_ph(q, p, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[8 + 6 * lbd](comb1, comb2);
                }
            }
        }
    } else {
        if (q < Bas->hole_states) {

            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_phhh
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                } else {

                    // v_phhp -> v_phph
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Bas->hole_states) {

                    // v_phph
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[7 + 6 * lbd](comb1, comb2);

                } else {

                    // v_phpp -> v_ppph
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_ph(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                }
            }
        } else {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_pphh
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[6 + 6 * lbd](comb1, comb2);

                } else {

                    // v_pphp -> v_ppph
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Bas->hole_states) {

                    // v_ppph
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                } else {

                    // v_pppp
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_pp(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * mat_elems[9 + 6 * lbd](comb1, comb2);
                }
            }
        }
    }
}


void Hamiltonian::set_v_elem(int p, int q, int r, int s, double elem) {

    int tmp;
    int comb1, comb2;
    int sign = 1;
    
    int M1 = Bas->singPart[p].qnumbers[1] + Bas->singPart[q].qnumbers[1];

#if DEBUG
    // Check for conservation of angular momentum
    int M2 = Bas->singPart[r].qnumbers[1] + Bas->singPart[s].qnumbers[1];
    if (M1 != M2) {
        cout << "Error: M1 != M2 " << endl;
        exit(1);
    }
#endif

    int Ms1 = Bas->singPart[p].qnumbers[2] + Bas->singPart[q].qnumbers[2];

#if DEBUG
    // Check for conservation of spin
    int Ms2 = Bas->singPart[r].qnumbers[2] + Bas->singPart[s].qnumbers[2];
    if (Ms1 != Ms2) {
        cout << "Error: Ms1 != Ms2 " << endl;
        exit(0);
    }
#endif

    // Bring the indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Get the correct channel
    int lbd = Bas->get_lbd(M1, Ms1);

    if (p < Bas->hole_states) {
        if (q < Bas->hole_states) {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_hhhh
                    comb1 = Bas->map_hh(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[4 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_hhhp -> v_phhh
                    comb1 = Bas->map_ph(s, r, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[5 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;

                }
            } else {
                if (s < Bas->hole_states) {

                    // v_hhph ->v_phhh
                    comb1 = Bas->map_ph(r, s, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[5 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_hhpp -> v_pphh
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[6 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;
                }
            }

        } else {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_hphh -> v_phhh
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[5 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;
                } else {

                    // v_hphp -> v_phph
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[7 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;
                }
            } else {
                if (s < Bas->hole_states) {

                    // v_hpph -> v_phph
                    comb1 = Bas->map_ph(q, p, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[7 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;
                } else {
                    // v_hppp -> v_ppph
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_ph(q, p, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[8 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;
                }
            }
        }
    } else {
        if (q < Bas->hole_states) {

            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_phhh
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[5 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_phhp -> v_phph
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[7 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;
                }
            } else {
                if (s < Bas->hole_states) {

                    // v_phph
                    comb1 = Bas->map_ph(p, q, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[7 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_phpp -> v_ppph
                    comb1 = Bas->map_pp(r, s, lbd);
                    comb2 = Bas->map_ph(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[8 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                }
            }
        } else {
            if (r < Bas->hole_states) {
                if (s < Bas->hole_states) {

                    // v_pphh
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[6 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_pphp -> v_ppph
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[8 + 6 * lbd](comb1, comb2) = -sign*elem;
                    return;

                }
            } else {
                if (s < Bas->hole_states) {

                    // v_ppph
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[8 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;

                } else {

                    // v_pppp
                    comb1 = Bas->map_pp(p, q, lbd);
                    comb2 = Bas->map_pp(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return;
                    mat_elems[9 + 6 * lbd](comb1, comb2) = sign*elem;
                    return;
                }
            }
        }
    }
}

