
#ifndef HAMILTONIAN_H
#define	HAMILTONIAN_H

#include "../../lib/ARMADILLO_LAPACK.h"
#include "../Basis/Basis.h" 
#include <omp.h>
#include <vector>
#include <fstream>

using namespace arma;

//////////////////////////////// ///////////////////////////////////////////////
//                          class Hamiltonian

/** @brief Class for handling the Hamiltonian matrix in a given basis
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

class Hamiltonian{
    
private:
    Basis* Bas; /// basis in which the Hamiltonian is set up
    double omega; /// oscillator frequency
    std::vector<arma::mat> mat_elems; /// array with matrix elements
    
public:
    friend class SRG;
    friend class Wegner;
    friend class White;
    friend class HartreeFock;
   
    /**
     * Constructor
     * @param Bas - basis in which the Hamiltonian is to set up
     */
    Hamiltonian(Basis* Bas);
    
    /**
     * Set up the Hamiltonian in second quantization 
     * @param omega - oscillator frequency
     * @param label - label of the input files
     */
    void setup_Hamiltonian(double omega, int label);
    
    /**
     * Compute ground state energy
     */
    void E0_contr();
    
    /**
     * Compute f-elements of the Hamiltonian and save them in array mat_elems
     */
    void setup_f();
    
    /**
     * Compute v-elements of the Hamiltonian and save them in array mat_elems
     * @param label - label of the input files containing two-body elements 
     * in the form: int1 int2 int3 int4 <1 2|| 3 4>, where the integer int_ 
     * denotes the index of single-particle states and <1 2|| 3 4> is the
     * corresponding element
     */
    void setup_v(int label);
    
    /**
     * Extract f-element f_pq from the array mat_elems
     * @param p - first index
     * @param q - second index
     * @param mat_elems - array containing all elements of the Hamiltonian
     * @return f-element with indices p,q
     */
    double get_f_elem(int p, int q, std::vector<arma::mat>& mat_elems) const;
    

    /**
     * Extract v-element v_pqrs from the array mat_elems
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param mat_elems - - array containing all elements of the Hamiltonian
     * @return v-element with nidices p,q,r,s,
     */
    double get_v_elem(int p, int q, int r, int s, std::vector<arma::mat>& mat_elems) const;
    
    /**
     * Set v-element v_pqrs to value 'elem'
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param elem - value of v_pqrs
     */
    void set_v_elem(int p, int q, int r, int s, double elem);
    
};


#endif	/* HAMILTONIAN_H */

