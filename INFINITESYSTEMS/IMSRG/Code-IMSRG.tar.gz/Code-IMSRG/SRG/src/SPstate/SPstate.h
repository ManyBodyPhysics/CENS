
#ifndef SPSTATE_H
#define	SPSTATE_H

////////////////////////////////////////////////////////////////////////////////
//                          class SPstate

/** @brief Class for holding single-particle states
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

class SPstate{
    
private:
    int index;
    
public:

    SPstate(){};
    
    /**
     * Create array holding the quantum numbers
     * @param i_qn - number of quantum numbers to be contained
     */
    void create(int i_qn);
    
     ~SPstate();
    
    double eps; // single-particle energy
    short* qnumbers; // array with quantum numbers
};

#endif	/* SPSTATE_H */

