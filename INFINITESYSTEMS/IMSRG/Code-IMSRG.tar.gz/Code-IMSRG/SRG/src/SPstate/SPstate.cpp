
#include "SPstate.h"

////////////////////////////////////////////////////////////////////////////////
//                          class SPstate

/** @brief Class for holding single-particle states
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

 
void SPstate::create(int i_qn){
    
     qnumbers = new short[i_qn]; 
    
}


SPstate::~SPstate(){
    
    delete[] qnumbers;
}

