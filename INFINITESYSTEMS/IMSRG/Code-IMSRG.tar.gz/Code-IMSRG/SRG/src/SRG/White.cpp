 
#include "SRG.h"

////////////////////////////////////////////////////////////////////////////////
//                          class White

/** @brief Subclass of SRG, for White's generator
    @author Sarah Reimann
    @date 23 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

#define TEST 0 // Code validation with N=2 particles
#define DEBUG 0
#define TOL 1e-16 // tolerance v_pqrs in update_eta


White::White(System* Sys) {
    
    this->Sys = Sys;
    this->all_states = Sys->H->Bas->sp_states;

    this->hole_states = Sys->H->Bas->hole_states;
    this->part_states = all_states - hole_states;

    this->lbd_dim = Sys->H->Bas->lbd_dim;

    mat tmp;
    int tmp_row, tmp_col;

    // Allocate memory for eta_ph
    tmp_row = Sys->H->mat_elems[2].n_rows;
    tmp_col = Sys->H->mat_elems[2].n_cols;
    tmp.set_size(tmp_row, tmp_col);
    eta.push_back(tmp); // eta_ph

    // Allocate memory for eta_pphh
    for (int i = 6; i < Sys->H->mat_elems.size(); i += 6) {
        tmp_row = Sys->H->mat_elems[i].n_rows;
        tmp_col = Sys->H->mat_elems[i].n_cols;
        tmp.set_size(tmp_row, tmp_col);
        eta.push_back(tmp);
    }

    lbd_limits = Sys->H->Bas->lbd_limits();

}



void White::update_eta(std::vector<arma::mat>& mat_elems) {

    int p;
    
    for (int i = 0; i < eta.size(); i++)
        eta[i].zeros();
  
    ///////////////////////////////////////////////////////////////////////////
    //                      Update eta_ph 
  
    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        p = p_ind + hole_states;
        for (int q = 0; q < hole_states; q++) {
            eta[0](p_ind, q) = mat_elems[2](p_ind,q) /
                    (mat_elems[3](p_ind,p_ind) - mat_elems[1](q,q)
                    - Sys->H->get_v_elem(p, q, p, q, mat_elems));
        }
    }


    
#if TEST
    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        p = p_ind + hole_states;
        for (int q = 0; q < hole_states; q++) {
                 for (int lbd = lbd_limits(0,0); lbd <= lbd_limits(0,1); lbd++)
                    for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                        int i = Sys->H->Bas->hh_basis[lbd][ij](0);
                        int j = Sys->H->Bas->hh_basis[lbd][ij](1);
                        eta[0](p_ind, q) -= get_eta3(p, i, j, q, i, j, mat_elems);
                    } 
        }
    }
#endif

    ///////////////////////////////////////////////////////////////////////////
    //                 Update eta_pphh
    int q, r, s;
    double A;
  
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        
        for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
            
            p = Sys->H->Bas->pp_basis[lbd][ab](0);
            q = Sys->H->Bas->pp_basis[lbd][ab](1);
            
            for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {
                
                r = Sys->H->Bas->hh_basis[lbd][kl](0);
                s = Sys->H->Bas->hh_basis[lbd][kl](1);

                A = mat_elems[9+6*lbd](ab,ab)  // v_pqpq
                        + mat_elems[4+6*lbd](kl,kl) // v_rsrs
                        - Sys->H->get_v_elem(p, r, p, r, mat_elems) // v_prpr
                        - Sys->H->get_v_elem(q, r, q, r, mat_elems) // v_qrqr
                        - Sys->H->get_v_elem(p, s, p, s, mat_elems) // v_psps
                        - Sys->H->get_v_elem(q, s, q, s, mat_elems); // v_qsqs

                eta[1 + lbd](ab, kl) += mat_elems[6+6*lbd](ab,kl) / // v_pqrs
                        ( mat_elems[3](p-hole_states,p-hole_states) // f_pp
                        + mat_elems[3](q-hole_states,q-hole_states) // f_qq
                        - mat_elems[1](r,r) // f_rr
                        - mat_elems[1](s,s) + A); // f_ss


#if TEST
                for (int i = 0; i < hole_states; i++)
                    eta[1+lbd](ab,kl) -= get_eta3(p, q, i, r, s, i, mat_elems);

#endif    
            }
        }
}


double White::get_eta1(int p, int q) const {

    if (p < hole_states) {
        if (q < hole_states)
            return 0;
        else return -eta[0](q - hole_states, p);
    } else if (q < hole_states)
        return eta[0](p - hole_states, q);
    return 0;

}


double White::get_eta2(int p, int q, int r, int s) const {

#if DEBUG
    if (!((p < Sys->H->Bas->hole_states && q < Sys->H->Bas->hole_states && r >=
            Sys->H->Bas->hole_states
            && s >= Sys->H->Bas->hole_states) || (p >= Sys->H->Bas->hole_states
            && q >= Sys->H->Bas->hole_states && r < Sys->H->Bas->hole_states
            && s < Sys->H->Bas->hole_states))) {
        cout << "Error: wrong combination of indices in eta " << endl;
        exit(1);
    }
#endif


    int tmp;
    int comb1, comb2;
    int sign = 1;

    // Check conservation of M
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_S
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    
    if (p < Sys->H->Bas->hole_states) {
        // eta_hhpp -> -eta_pphh
        comb1 = Sys->H->Bas->map_pp(r, s, lbd);
        comb2 = Sys->H->Bas->map_hh(p, q, lbd);
        if (comb1 < 0 || comb2 < 0) return 0;
        return -sign * eta[1 + lbd](comb1, comb2);
    }

    // eta_pphh
    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
    if (comb1 < 0 || comb2 < 0) return 0;
    return sign * eta[1 + lbd](comb1, comb2);

}


double White::E0_deriv(std::vector<arma::mat>& mat_elems) {

    double d_ret = 0.0;
    double contr = 0.0;

    for (int i = 0; i < hole_states; i++)
        for (int a = hole_states; a < all_states; a++) {
            d_ret += -eta[0](a - hole_states, i) * mat_elems[2](a - hole_states, i);
        }

    d_ret *= 2;
    
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++)
            for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++)
                contr += -eta[1 + lbd](ab, ij) * mat_elems[6 + 6 * lbd](ab, ij);

    d_ret += 2 * contr;

    contr = 0.0;
    int i, j;

#if TEST    
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
            i = Sys->H->Bas->hh_basis[lbd][ij](0);
            j = Sys->H->Bas->hh_basis[lbd][ij](1);
            for (int k = 0; k < hole_states; k++)
                contr -= get_dv3(i, j, k, i, j, k, mat_elems);
        }

    d_ret += (1.0 / 3.0) * contr; 
    
#endif

    return d_ret;

}


void White::f_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv) {

    int comb1, comb2, v_ind, v_sign, v_comb1, v_comb2;
    int a_p, i_p, a_q, i_q, pp, qq;

    for (int i = 1; i <= 3; i++) {
        dv[i].zeros();
    }

    ///////////////////////////////////////////////////////////////////////////
    //                   Compute f_hh
 
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
        
        for (int ip = 0; ip < Sys->H->Bas->hh_basis[lbd].size(); ip++) {
            
            i_p = Sys->H->Bas->hh_basis[lbd][ip](0);
            pp = Sys->H->Bas->hh_basis[lbd][ip](1);
            
            for (int iq = 0; iq < Sys->H->Bas->hh_basis[lbd].size(); iq++) {
                
                i_q = Sys->H->Bas->hh_basis[lbd][iq](0);
                qq = Sys->H->Bas->hh_basis[lbd][iq](1);

                if (i_p == i_q) dv[1](pp, qq) += dot(-eta[1 + lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[1 + lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));

                if (pp == qq) dv[1](i_p, i_q) += dot(-eta[1 + lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[1 + lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));

                if (pp == i_q) dv[1](i_p, qq) -= dot(-eta[1 + lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[1 + lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));

                if (i_p == qq) dv[1](pp, i_q) -= dot(-eta[1 + lbd].col(ip), 
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[1 + lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));

            }
        }
    }

    dv[1] += -strans(eta[0]) * mat_elems[2] - strans(mat_elems[2]) * eta[0];

    for (int p = 0; p < hole_states; p++)
        for (int q = p; q < hole_states; q++) {
            for (int i = 0; i < hole_states; i++)
                for (int a = hole_states; a < all_states; a++) {
                    
                    dv[1](p, q) -= eta[0](a - hole_states, i)
                            * Sys->H->get_v_elem(a, p, i, q, mat_elems);
                    dv[1](p, q) -= eta[0](a - hole_states, i) 
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems);
               
                }

#if TEST             
            int i, j; 
            
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    dv[1](p, q) -= get_dv3(p, i, j, q, i, j, mat_elems); 
                }
            
#endif
            dv[1](q, p) = dv[1](p, q);
        }

    ///////////////////////////////////////////////////////////////////////////   
    //                          Compute f_ph 
    
    int p;
   
    dv[2] += eta[0] * mat_elems[1];
    dv[2] -= strans(mat_elems[3]) * eta[0];

    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
        for (int ap = 0; ap < Sys->H->Bas->pp_basis[lbd].size(); ap++) {
            
            a_p = Sys->H->Bas->pp_basis[lbd][ap](0);
            pp = Sys->H->Bas->pp_basis[lbd][ap](1);
            
            for (int aq = 0; aq < Sys->H->Bas->ph_basis[lbd].size(); aq++) {
                
                a_q = Sys->H->Bas->ph_basis[lbd][aq](0);
                qq = Sys->H->Bas->ph_basis[lbd][aq](1);
                if (a_p == a_q) dv[2](pp - hole_states, qq) += 
                        dot(eta[1 + lbd].row(ap), mat_elems[5 + 6 * lbd].row(aq));
                if (pp == a_q) dv[2](a_p - hole_states, qq) -= 
                        dot(eta[1 + lbd].row(ap), mat_elems[5 + 6 * lbd].row(aq));
            }
        }
    }

    
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
        for (int ip = 0; ip < Sys->H->Bas->ph_basis[lbd].size(); ip++) {
            
            i_p = Sys->H->Bas->ph_basis[lbd][ip](1);
            pp = Sys->H->Bas->ph_basis[lbd][ip](0);
            
            for (int iq = 0; iq < Sys->H->Bas->hh_basis[lbd].size(); iq++) {
                
                i_q = Sys->H->Bas->hh_basis[lbd][iq](0);
                qq = Sys->H->Bas->hh_basis[lbd][iq](1);
                
                if (i_p == i_q) dv[2](pp - hole_states, qq) += 
                        dot(eta[1 + lbd].col(iq), mat_elems[8 + 6 * lbd].col(ip));
                if (i_p == qq) dv[2](pp - hole_states, i_q) -= 
                        dot(eta[1 + lbd].col(iq), mat_elems[8 + 6 * lbd].col(ip));
            }
        }
    }

   
    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        
        p = p_ind + hole_states;
        
        for (int q = 0; q < hole_states; q++) {
            for (int i = 0; i < hole_states; i++)
                for (int a = hole_states; a < all_states; a++) {
                    
                    dv[2](p_ind, q) += -Sys->H->get_f_elem(i, a, mat_elems) 
                            * get_eta2_comb(a, p, i, q, v_comb1, v_comb2, v_ind, v_sign);
                    
                    if (abs(v_sign) > 0)
                        dv[2](p_ind, q) -= eta[0](a - hole_states, i) * 
                                v_sign * mat_elems[v_ind](v_comb1, v_comb2);
                    
                    dv[2](p_ind, q) -= eta[0](a - hole_states, i) 
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems);
                }

            
#if TEST
            int i, j;
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    dv[2](p_ind, q) -= get_dv3(p, i, j, q, i, j, mat_elems); 
                }
#endif
        }
    }


    ///////////////////////////////////////////////////////////////////////////
    //                         Compute f_pp
    
    int q;
    
    dv[3] += eta[0] * strans(mat_elems[2]) + mat_elems[2] * strans(eta[0]);

    for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++) {
        for (int ap = 0; ap < Sys->H->Bas->pp_basis[lbd].size(); ap++) {
            
            a_p = Sys->H->Bas->pp_basis[lbd][ap](0);
            pp = Sys->H->Bas->pp_basis[lbd][ap](1);
            
            for (int aq = 0; aq < Sys->H->Bas->pp_basis[lbd].size(); aq++) {
                
                a_q = Sys->H->Bas->pp_basis[lbd][aq](0);
                qq = Sys->H->Bas->pp_basis[lbd][aq](1);
                
                if (a_p == a_q) dv[3](pp - hole_states, qq - hole_states) +=
                        dot(eta[1 + lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[1 + lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                
                if (pp == qq) dv[3](a_p - hole_states, a_q - hole_states) += 
                        dot(eta[1 + lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[1 + lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                
                if (pp == a_q) dv[3](a_p - hole_states, qq - hole_states) -= 
                        dot(eta[1 + lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[1 + lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                
                if (a_p == qq) dv[3](pp - hole_states, a_q - hole_states) -= 
                        dot(eta[1 + lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[1 + lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
            }
        }
    }

    for (int p_ind = 0; p_ind < part_states; p_ind++) {        
        p = p_ind + hole_states;
        
        for (int q_ind = p_ind; q_ind < part_states; q_ind++) {            
            q = q_ind + hole_states;

            for (int i = 0; i < hole_states; i++)
                for (int a = hole_states; a < all_states; a++) {
                    
                    dv[3](p_ind, q_ind) -= eta[0](a - hole_states, i) 
                            * Sys->H->get_v_elem(a, p, i, q, mat_elems);
                    dv[3](p_ind, q_ind) -= eta[0](a - hole_states, i) 
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems);
                }


#if TEST
            int i, j; 
            
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    
                    dv[3](p_ind, q_ind) -= get_dv3(p, i, j, q, i, j, mat_elems); 
                }
#endif

            dv[3](q_ind, p_ind) = dv[3](p_ind, q_ind);
        }
    }

}


void White::v_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv) {


    int p, q, r, s;
    int v_comb1, eta_comb1, v_comb2, eta_comb2, eta_sign, eta_ind, v_sign, v_ind;

    for (int lbd = 0; lbd < lbd_dim; lbd++)
        for (int i = 4; i <= 9; i++)
            dv[i + 6 * lbd].zeros();

#pragma omp parallel private(p,q,r,s,v_comb1, eta_comb1, v_comb2, eta_comb2, eta_sign, eta_ind, v_sign, v_ind)
    {

        ///////////////////////////////////////////////////////////////////////
        //          Compute derivative of v_hhhh dv[4] 
        
#pragma  omp  for   schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {

            for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {

                p = Sys->H->Bas->hh_basis[lbd][ij](0);
                q = Sys->H->Bas->hh_basis[lbd][ij](1);

                for (int kl = ij; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    for (int t = hole_states; t < all_states; t++) {

                        dv[4 + 6 * lbd](ij, kl) -= eta[0](t - hole_states, p)
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - eta[0](t - hole_states, q) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems);

                        dv[4 + 6 * lbd](ij, kl) -= eta[0](t - hole_states, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - eta[0](t - hole_states, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);
                    }


                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {

                        dv[4 + 6 * lbd](ij, kl) -= eta[1 + lbd](ab, ij) 
                                * mat_elems[6 + 6 * lbd](ab, kl)
                                + eta[1 + lbd](ab, kl) * mat_elems[6 + 6 * lbd](ab, ij);
                        
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[4 + 6 * lbd](ij, kl) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif
                    
                    dv[4 + 6 * lbd](kl, ij) = dv[4 + 6 * lbd](ij, kl);
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        //          Compute derivative of v_phhh -> dv[5]
        
#pragma  omp  for  schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);


                    for (int t = 0; t < hole_states; t++) {
                        dv[5 + 6 * lbd](ai, kl) += eta[0](p - hole_states, t)
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems);
                    }

                    for (int t = hole_states; t < all_states; t++) {

                        dv[5 + 6 * lbd](ai, kl) += Sys->H->get_f_elem(q, t, mat_elems)
                                * get_eta2_comb(t, p, r, s, v_comb1, v_comb2, v_ind, v_sign);
                        
                        if (abs(v_sign) > 0)
                            dv[5 + 6 * lbd](ai, kl) += eta[0](t - hole_states, q)
                                    * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                        dv[5 + 6 * lbd](ai, kl) -= eta[0](t - hole_states, r)
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - eta[0](t - hole_states, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);
                    }


                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[5 + 6 * lbd](ai, kl) -= eta[1 + lbd](ab, kl) 
                                * mat_elems[8 + 6 * lbd](ab, ai);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            dv[5 + 6 * lbd](ai, kl) += get_eta2(a, p, i, s) 
                                    * Sys->H->get_v_elem(i, q, a, r, mat_elems)
                                    - get_eta2(a, p, i, r) 
                                    * Sys->H->get_v_elem(i, q, a, s, mat_elems);
                        }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[5 + 6 * lbd](ai, kl) -= get_dv3(p, q, i, r, s, i, mat_elems); 
                    }
#endif

                }
            }
        }


        ///////////////////////////////////////////////////////////////////////
        //         Compute derivative of v_pphh -> dv[6]
        
#pragma  omp for  schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {

            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    for (int t = 0; t < hole_states; t++) {

                        dv[6 + 6 * lbd](cd, kl) += eta[0](p - hole_states, t)
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - eta[0](q - hole_states, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems);

                        dv[6 + 6 * lbd](cd, kl) += Sys->H->get_f_elem(t, r, mat_elems)
                                * get_eta2(p, q, t, s)
                                - Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int t = hole_states; t < all_states; t++) {

                        dv[6 + 6 * lbd](cd, kl) -= Sys->H->get_f_elem(p, t, mat_elems)
                                * get_eta2(t, q, r, s)
                                - Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[6 + 6 * lbd](cd, kl) -= eta[0](t - hole_states, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - eta[0](t - hole_states, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);

                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[6 + 6 * lbd](cd, kl) -= eta[1 + lbd](ab, kl) 
                                * mat_elems[9 + 6 * lbd](ab, cd);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[6 + 6 * lbd](cd, kl) -= eta[1 + lbd](cd, ij_)
                                * mat_elems[4 + 6 * lbd](ij_, kl);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {

                            dv[6 + 6 * lbd](cd, kl) -= get_eta2(a, q, i, s) 
                                    * Sys->H->get_v_elem(i, p, a, r, mat_elems)
                                    - get_eta2(a, p, i, s)
                                    * Sys->H->get_v_elem(i, q, a, r, mat_elems)
                                    - get_eta2(a, q, i, r)
                                    * Sys->H->get_v_elem(i, p, a, s, mat_elems)
                                    + get_eta2(a, p, i, r)
                                    * Sys->H->get_v_elem(i, q, a, s, mat_elems);
                        }

#if TEST                
                    for (int i = 0; i < hole_states; i++) {
                        dv[6 + 6 * lbd](cd, kl) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        //  Compute derivative of v_phph -> dv[7]
        
#pragma  omp for  schedule(dynamic)
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int bj = ai; bj < Sys->H->Bas->ph_basis[lbd].size(); bj++) {

                    r = Sys->H->Bas->ph_basis[lbd][bj](0);
                    s = Sys->H->Bas->ph_basis[lbd][bj](1);


                    for (int t = 0; t < hole_states; t++) {

                        dv[7 + 6 * lbd](ai, bj) += eta[0](p - hole_states, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems);

                        dv[7 + 6 * lbd](ai, bj) += eta[0](r - hole_states, t) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems);

                    }

                    for (int t = hole_states; t < all_states; t++) {

                        dv[7 + 6 * lbd](ai, bj) += eta[0](t - hole_states, q)
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems);

                        dv[7 + 6 * lbd](ai, bj) += eta[0](t - hole_states, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);
                    }


                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {

                            dv[7 + 6 * lbd](ai, bj) += get_eta2_comb(a, 
                                    p, i, s, v_comb1, v_comb2, v_ind, v_sign)
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[7 + 6 * lbd](ai, bj) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);
                        }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[7 + 6 * lbd](ai, bj) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }

#endif
                    dv[7 + 6 * lbd](bj, ai) = dv[7 + 6 * lbd](ai, bj);
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        // Compute derivative of v_ppph -> dv[8]
#pragma  omp  for schedule(dynamic)    
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
          
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int ei = 0; ei < Sys->H->Bas->ph_basis[lbd].size(); ei++) {

                    r = Sys->H->Bas->ph_basis[lbd][ei](0);
                    s = Sys->H->Bas->ph_basis[lbd][ei](1);


                    for (int t = 0; t < hole_states; t++) {

                        dv[8 + 6 * lbd](cd, ei) += eta[0](p - hole_states, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - eta[0](q - hole_states, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems);


                        dv[8 + 6 * lbd](cd, ei) += eta[0](r - hole_states, t) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                + Sys->H->get_f_elem(t, r, mat_elems)
                                * get_eta2(p, q, t, s);
                    }

                    for (int t = hole_states; t < all_states; t++) {
                        dv[8 + 6 * lbd](cd, ei) += 
                                 eta[0](t - hole_states, s)
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[8 + 6 * lbd](cd, ei) -= eta[1 + lbd](cd, ij_) 
                                * mat_elems[5 + 6 * lbd](ei, ij_);

                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {

                            dv[8 + 6 * lbd](cd, ei) -= get_eta2(a, q, i, s)
                                    * Sys->H->get_v_elem(i, p, a, r, mat_elems)
                                    - get_eta2(a, p, i, s) 
                                    * Sys->H->get_v_elem(i, q, a, r, mat_elems);
                        }


#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[8 + 6 * lbd](cd, ei) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif

                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        // v_pppp dv[9]
        
#pragma  omp  for  schedule(dynamic) 
        for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++) {
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int ef = cd; ef < Sys->H->Bas->pp_basis[lbd].size(); ef++) {

                    r = Sys->H->Bas->pp_basis[lbd][ef](0);
                    s = Sys->H->Bas->pp_basis[lbd][ef](1);

                    for (int t = 0; t < hole_states; t++) {

                        dv[9 + 6 * lbd](cd, ef) += eta[0](p - hole_states, t)
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - eta[0](q - hole_states, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems);

                        dv[9 + 6 * lbd](cd, ef) += eta[0](r - hole_states, t) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - eta[0](s - hole_states, t) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems);

                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {

                        dv[9 + 6 * lbd](cd, ef) -= eta[1 + lbd](cd, ij_) 
                                * mat_elems[6 + 6 * lbd](ef, ij_)
                                + eta[1 + lbd](ef, ij_) 
                                * mat_elems[6 + 6 * lbd](cd, ij_);

                    }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[9 + 6 * lbd](cd, ef) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }

#endif
                    dv[9 + 6 * lbd](ef, cd) = dv[9 + 6 * lbd](cd, ef);

                }
            }
        }

    }
}


double White::get_v_elem_comb(int p, int q, int r, int s, std::vector<arma::mat>& mat_elems,
        int& comb1, int& comb2, int& eta_ind, int& eta_sign) {

    int tmp;
    int sign = 1;
    eta_sign = 0;

    // Check conservation of M    
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_s
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    if (p < Sys->H->Bas->hole_states) {
        
        // v_hhpp -> v_pphh
        comb1 = Sys->H->Bas->map_pp(r, s, lbd);
        comb2 = Sys->H->Bas->map_hh(p, q, lbd);
        if (comb1 < 0 || comb2 < 0) return 0;
        eta_ind = 1 + lbd;
        eta_sign = -sign;
        return sign * mat_elems[6 + 6 * lbd](comb1, comb2);
    }

    // v_pphh
    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
    if (comb1 < 0 || comb2 < 0) return 0;
    eta_ind = 1 + lbd;
    eta_sign = sign;
    return sign * mat_elems[6 + 6 * lbd](comb1, comb2);

}


double White::get_eta2_comb(int p, int q, int r, int s, int& comb1, int& comb2,
        int& v_ind, int& v_sign) {

#if DEBUG
    if (!((p < Sys->H->Bas->hole_states && q < Sys->H->Bas->hole_states && 
            r >= Sys->H->Bas->hole_states
            && s >= Sys->H->Bas->hole_states) || (p >= Sys->H->Bas->hole_states &&
            q >= Sys->H->Bas->hole_states && r < Sys->H->Bas->hole_states
            && s < Sys->H->Bas->hole_states))) {
        cout << "Error: Wrong combination of indices in eta_pphh" << endl;
        exit(1);
    }
#endif


    int tmp;
    int sign = 1;
    v_sign = 0;

    // Check conservation of M
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_s
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    
    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    if (p < Sys->H->Bas->hole_states) {
        
        // eta_hhpp -> -eta_pphh
        comb1 = Sys->H->Bas->map_pp(r, s, lbd);
        comb2 = Sys->H->Bas->map_hh(p, q, lbd);
        
        if (comb1 < 0 || comb2 < 0) return 0;
        v_ind = 6 + 6 * lbd;
        v_sign = sign;
        return -sign * eta[1 + lbd](comb1, comb2);
    }

    // eta_pphh
    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
    
    if (comb1 < 0 || comb2 < 0) return 0;
    v_ind = 6 + 6 * lbd;
    v_sign = sign;
    return sign * eta[1 + lbd](comb1, comb2);

}


