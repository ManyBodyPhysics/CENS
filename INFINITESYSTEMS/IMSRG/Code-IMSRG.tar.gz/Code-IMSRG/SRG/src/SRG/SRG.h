
#ifndef SRG_H
#define	SRG_H

#include "../SRG/ode.hpp"
#include "../System/System.h"
#include <iomanip>
#include <iostream>
#include <omp.h>

////////////////////////////////////////////////////////////////////////////////
//                          class SRG

/** @brief Class for the Similarity Renormalization Group (SRG) method
    @author Sarah Reimann
    @date 23 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

class SRG {
protected:
    System* Sys;
    int all_states; /// number of single-particle states
    int hole_states; /// number of hole_states
    int part_states; /// number of particle states
    int lbd_dim; /// maximal number of channels
    double E0; /// ground state energy
    imat lbd_limits; /// holds occupied channels in hh_, ph_ and pp_basis
    std::vector<arma::mat> eta; /// storage of generator

public:

    SRG(){};
    
    /**
     * Main function for integrating the flow equations
     * @param relerr - limit for relative error
     * @param abserr - limit for absolute error
     * @param iflag - flag for information given by the ODE solver
     * @param lambda1 - first integration point to check for convergence
     * @param lambda2 - last integration point until which convergence is checked
     * with initial step length
     * @param step - initial step length to check for convergence
     * @return - final ground state energy
     */
    double run_algo(double relerr, double abserr, int iflag, double lambda1,
    double lambda2, double step);
    
    /**
     * Computes the derivatives of the Hamiltonian
     * @param k_lambda - current integration point
     * @param v - current matrix elements of Hamiltonian
     * @param dv - contains on output the derivatives, same structure as "v"
     */
    void derivative(double k_lambda, std::vector<arma::mat>& v, 
    std::vector<arma::mat>& dv);

    /**
     * Function encoding the delta_function
     * @param p - first index
     * @param q - second index
     * @return Return 1 if p=q, otherwise 0
     */
    int delta(int p, int q);
    
   /**
    * Permute parameters p and q:
    * On output "p" holds the previous value of "q", and "q" the previous one
    *  of "p"
    * @param p
    * @param q
    */
    void permute(int& p, int& q);
    
    
    /**
     * Optional function for code validation with N=2 particles
     * Derivative for preventing the inclusion of three-body interactions w_pqrstu
     * in the test case for N=2 particles
     * Attention: This function gives not the general derivative as for IM-SRG(3)
     * but only those contributions needed for testing N=2 particles
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param t - fifth index
     * @param u - sixth index 
     * @param mat_elems - matrix elements of Hamiltonian
     * @return  the derivative of w_pqrstu
     */
    double get_dv3(int p, int q, int r, int s, int t, int u, std::vector<arma::mat>& mat_elems);
    
    /**
     * Computes three-body terms of generator eta, assuming that the Hamiltonian 
     * itself maximally contains two-body interactions
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param t - fifth index
     * @param u - sixth index
     * @param mat_elems - matrix elements of Hamiltonian
     * @return 
     */
    double get_eta3(int p, int q, int r, int s, int t, int u, std::vector<arma::mat>& mat_elems);
   
    ////////////////////////////////////////////////////////////////////////////
    // Pure virtual functions to be implemented in the derived subclasses

    /**
     * Update all elements of generator, they are stored in the class variable "eta"
     * @param mat_elems - matrix elements of Hamiltonian
     */
    virtual void update_eta(std::vector<arma::mat>& mat_elems) = 0;
    
    /**
     * Get one-body elements of generator
     * @param p - first index
     * @param q - second index
     * @return one-body element eta_pq
     */
    virtual double get_eta1(int p, int q) const = 0;
    
    /**
     * Get two-body elements of generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @return two-body element eta_pqrs
     */
    virtual double get_eta2(int p, int q, int r, int s) const = 0;
  
    /**
     * Compute derivative of ground state energy
     * @param mat_elems - matrix elements of Hamiltonian
     * @return derivative of E_0
     */
    virtual double E0_deriv(std::vector<arma::mat>& mat_elems)=0;
    
    /**
     * Compute derivative of all f-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only f-element part is updated
     */
    virtual void f_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv)=0;
    
    /**
     * Compute derivative of all v-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only v-element part is updated
     */
    virtual void v_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv) = 0;
    
    /**
     * Get v-element v_pqrs of the Hamiltonian as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element eta_pqrs of the generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param eta_ind - index of eta_pqrs in array eta
     * @param eta_sign - sign the element eta_pqrs has to be multiplied with
     * @return v-element v_pqrs
     */
    virtual double get_v_elem_comb(int p, int q, int r, int s, 
    std::vector<arma::mat>& mat_elems, int& comb1, int& comb2, int& eta_ind, int& eta_sign)=0;
    
    /**
     * Get generator-element eta_pqrs exactly as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element v_pqrs of the Hamiltonian
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param v_ind - index of v_pqrs in array mat_elems
     * @param v_sign - sign the element v_pqrs has to be multiplied with
     * @return generator-element eta_pqrs
     */
    virtual double get_eta2_comb(int p, int q, int r, int s, int& comb1, int& comb2,
    int& v_ind, int& v_sign) = 0; 

    ////////////////////////////////////////////////////////////////////////////
    // Adjusted files from ode.cpp 

    /**
     * User interface to the ODE solver
     * @param n - number of matrices
     * @param y - current solution
     * @param t - current integration point
     * @param tout - desired integration point on output
     * @param relerr - tolerance for relative error
     * @param abserr - tolerance for absolute error
     * @param iflag - indicator for the status of integration
     * @param work - workspace for ODE solver , 22 arrays of the form of "y"
     * @param iwork - workspace for ODE solver, dim=5
     * @param work_array - workspace for ODE solver, dim=100
     */
    void ode(int n, std::vector<arma::mat>& y, double &t, double tout, double relerr,
            double abserr, int &iflag, std::vector<arma::mat>* work, int iwork[],
            double* work_array);

    /**
     * Carry out the ODE solution algorithm.
     * @param neqn - number of matrices to be considered
     * @param y - current solution
     * @param t - current integration point
     * @param tout - desired integration point on output
     * @param relerr - tolerance for relative error
     * @param abserr - tolerance for absolute error
     * @param iflag - indicator for the status of integration
     * @param yy - used to hold solution data, same structure as "yy"
     * @param wt - error weight vector,  same structure as "yy"
     * @param p - workspace,  same structure as "yy"
     * @param yp  - solution derivatives,  same structure as "yy"
     * @param ypout - solution derivatives,  same structure as "yy"
     * @param phi - workspace for interpolation, structure equals 16 times the one of "yy"
     * @param alpha - workspace for ODE solver, dim=12
     * @param beta - workspace for ODE solver, dim=12
     * @param sig - workspace for ODE solver, dim=13
     * @param v - workspace for ODE solver, dim=12
     * @param w - workspace for ODE solver, dim=12
     * @param g - workspace for ODE solver, dim=13
     * @param phase1 - internal parameter for ODE solver
     * @param psi - workspace for interpolation, dim=12
     * @param x - working copy of integration point
     * @param h - current step size
     * @param hold - last successive step size
     * @param start - boolean for the first step
     * @param told - previous integration point
     * @param delsgn - sign of (tout-t)
     * @param ns - number of steps taken with stepsize "h"
     * @param nornd - internal parameter for ODE solver
     * @param k - order of the current ODE method
     * @param kold - order of the ODE method on the previous step
     * @param isnold - previous sign of "iflag"
     */
    void de(int neqn, std::vector<arma::mat>& y, double &t, double tout, double relerr,
            double abserr, int &iflag, std::vector<arma::mat>& yy, std::vector<arma::mat>& wt, 
            std::vector<arma::mat>& p, std::vector<arma::mat>& yp, std::vector<arma::mat>& ypout, 
            std::vector<arma::mat>* phi,  double* alpha, double* beta, double* sig,
            double* v, double* w, double* g, bool &phase1, double* psi, double &x,
            double &h, double &hold,bool &start, double &told, double &delsgn, 
            int &ns, bool &nornd, int &k, int &kold, int &isnold);

    /**
     * Integrate the system of ODEs one step
     * @param x - current integration point
     * @param y - approximate solution at current integration point
     * @param n - number of matrices in solution
     * @param h - suggested stepsize
     * @param eps - local error tolerance
     * @param wt - error weights, same structure as "y"
     * @param start - boolean for first step
     * @param hold - step size used on the last successful step
     * @param k - appropriate order for the next step
     * @param kold - order used on the last successful step
     * @param crash - set to TRUE if no step can be taken
     * @param phi - workspace for interpolation, structure equals 16 times the one of "y"
     * @param p - workspace,  same structure as "y"
     * @param yp - solution derivatives,  same structure as "y"
     * @param psi - workspace for interpolation, dim=12
     * @param alpha - workspace for ODE solver, dim=12
     * @param beta - workspace for ODE solver, dim=12
     * @param sig - workspace for ODE solver, dim=13
     * @param v - workspace for ODE solver, dim=12
     * @param w - workspace for ODE solver, dim=12
     * @param g - workspace for ODE solver, dim=13
     * @param phase1 - internal parameter for ODE solver
     * @param ns - number of steps taken with stepsize "h"
     * @param nornd - internal parameter for ODE solver
     */
    void step(double &x, std::vector<arma::mat>& y, int n, double &h, double &eps,
            std::vector<arma::mat>& wt, bool &start, double &hold, int &k, int &kold,
            bool &crash, std::vector<arma::mat>* phi, std::vector<arma::mat>& p,
            std::vector<arma::mat>& yp, double psi[], double alpha[], double beta[],
            double sig[], double v[], double w[], double g[], bool &phase1, int &ns,
            bool &nornd);
    
};


////////////////////////////////////////////////////////////////////////////////
//                          class Wegner

/** @brief Subclass of SRG, for Wegner's canonical generator
    @author sarahrei
    @date 23 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


class Wegner : public SRG {
    
public:
        
    /**
     * Constructor
     * @param Sys - the system to be solved
     */
    Wegner(System* Sys);
    
    /**
     * Update all elements of generator, they are stored in the class variable "eta"
     * @param mat_elems - matrix elements of Hamiltonian
     */
    void update_eta(std::vector<arma::mat>& mat_elems);
    
    /**
     * Get one-body elements of generator
     * @param p - first index
     * @param q - second index
     * @return one-body element eta_pq
     */
    double get_eta1(int p, int q) const;
   
    /**
     * Get two-body elements of generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @return two-body element eta_pqrs
     */
    double get_eta2(int p, int q, int r, int s) const;
    
    /**
     * Compute derivative of ground state energy
     * @param mat_elems - matrix elements of Hamiltonian
     * @return derivative of E_0
     */
    double E0_deriv(std::vector<arma::mat>& all_elm);
    
    /**
     * Compute derivative of all f-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only f-element part is updated
     */
    void f_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv);
    
    /**
     * Compute derivative of all v-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only v-element part is updated
     */
    void v_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv);
    
    /**
     * Get v-element v_pqrs of the Hamiltonian as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element eta_pqrs of the generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param eta_ind - index of eta_pqrs in array eta
     * @param eta_sign - sign the element eta_pqrs has to be multiplied with
     * @return v-element v_pqrs
     */
    double get_v_elem_comb(int p, int q, int r, int s, std::vector<arma::mat>& mat_elems, int& comb1, int& comb2,
            int& eta_ind, int& eta_sign);
    
    /**
     * Get generator-element eta_pqrs exactly as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element v_pqrs of the Hamiltonian
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param v_ind - index of v_pqrs in array mat_elems
     * @param v_sign - sign the element v_pqrs has to be multiplied with
     * @return generator-element eta_pqrs
     */
    double get_eta2_comb(int p, int q, int r, int s, int& comb1, int& comb2, int& v_ind, int& v_sign); 
  
    ~Wegner() {};
};



////////////////////////////////////////////////////////////////////////////////
//                          class White

/** @brief Subclass of SRG, for White's generator
    @author sarahrei
    @date 23 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


class White : public SRG {
public:
    
    /**
     * Constructor
     * @param Sys - the system to be solved
     */
    White(System* Sys);
    
    /**
     * Update all elements of generator, they are stored in the class variable "eta"
     * @param mat_elems - matrix elements of Hamiltonian
     */
    void update_eta(std::vector<arma::mat>& mat_elems);
    
    /**
     * Get one-body elements of generator
     * @param p - first index
     * @param q - second index
     * @return one-body element eta_pq
     */
    double get_eta1(int p, int q) const;
    
    /**
     * Get two-body elements of generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @return two-body element eta_pqrs
     */
    double get_eta2(int p, int q, int r, int s) const;
    
    /**
     * Compute derivative of ground state energy
     * @param mat_elems - matrix elements of Hamiltonian
     * @return derivative of E_0
     */
    double E0_deriv(std::vector<arma::mat>& all_elm);
    
    /**
     * Compute derivative of all f-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only f-element part is updated
     */
    void f_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv);
    
    /**
     * Compute derivative of all v-elements of the Hamiltonian
     * @param mat_elems - matrix elements of Hamiltonian
     * @param dv - array for holding the derivatives; must have same structure
     * as "mat_elems", but only v-element part is updated
     */
    void v_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv);
    
    /**
     * Get v-element v_pqrs of the Hamiltonian as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element eta_pqrs of the generator
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param eta_ind - index of eta_pqrs in array eta
     * @param eta_sign - sign the element eta_pqrs has to be multiplied with
     * @return v-element v_pqrs
     */
    double get_v_elem_comb(int p, int q, int r, int s, std::vector<arma::mat>& mat_elems,
    int& comb1, int& comb2,int& eta_ind, int& eta_sign);
    
    /**
     * Get generator-element eta_pqrs exactly as a normal getter function, 
     * save at the time all information needed to access successively the 
     * element v_pqrs of the Hamiltonian
     * @param p - first index
     * @param q - second index
     * @param r - third index
     * @param s - fourth index
     * @param comb1 - index of tp-state |pq>
     * @param comb2 - index of tp-state |rs>
     * @param v_ind - index of v_pqrs in array mat_elems
     * @param v_sign - sign the element v_pqrs has to be multiplied with
     * @return generator-element eta_pqrs
     */
    double get_eta2_comb(int p, int q, int r, int s, int& comb1, int& comb2, 
    int& v_ind, int& v_sign);
    
    ~White() {};
};



#endif	/* SRG_H */

