
#ifndef ODE_HPP
#define	ODE_HPP

//******************************************************************************
// The original file can be found at:
// http://people.sc.fsu.edu/~jburkardt/cpp_src/ode/ode.html
//******************************************************************************

#include<vector>
#include "../../lib/ARMADILLO_LAPACK.h"


int i4_sign ( int i );
void intrp (double x, std::vector<arma::mat>& y, double xout, 
        std::vector<arma::mat>& yout, std::vector<arma::mat>& ypout, int n,
        int kold, std::vector<arma::mat>* phi, double* psi  );

double r8_abs ( double x );
double r8_add ( double x, double y );
double r8_epsilon ( );
double r8_max ( double x, double y );
double r8_min ( double x, double y );
double r8_sign ( double x );

void timestamp ( );



#endif	/* ODE_HPP */

