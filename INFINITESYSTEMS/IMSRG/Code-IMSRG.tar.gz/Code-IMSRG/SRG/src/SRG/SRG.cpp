
#include "SRG.h"
 

////////////////////////////////////////////////////////////////////////////////
//                          class SRG

/** @brief Class for the Similarity Renormalization Group (SRG) method
    @author Sarah Reimann
    @date 23 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

#define EN_TOL 1e-8

double SRG::run_algo(double relerr, double abserr, int iflag, double lambda1,
        double lambda2, double step) {

    double start_point = 0.0;

    int lev = Sys->H->Bas->sp_states - 1;

    // Model space limit
    for (int i = 0; i < hole_states; i++) {
        start_point += Sys->H->Bas->singPart[lev].eps;
        lev--;
    }

    // Allocations for the ODE solver
    std::vector<arma::mat>* work = new std::vector<arma::mat>[22];

    for (int i = 0; i < 22; i++)
        work[i] = Sys->H->mat_elems;
    double* work_array = new double[100];

    for (int i = 0; i < 100; i++)
        work_array[i] = 0.0;

    int *iwork = new int[5];
    for (int i = 0; i < 5; i++)
        iwork[i] = 0;

    double E0_old;
    double diff = 1.0;

    wall_clock timer;
    double elapsed_time;

    E0_old = 0.1;
    double k = lambda1;
    int counter = 0;
    timer.tic();

    while (diff > EN_TOL) {

        ode(Sys->H->mat_elems.size(), Sys->H->mat_elems, start_point, k, relerr,
                abserr, iflag, work, iwork, work_array);

        elapsed_time = timer.toc();

        E0 = Sys->H->mat_elems[0](0, 0);

        //cout << k << " " << setw(15) << setprecision(10) << E0 << " "<< elapsed_time << endl;


        // Terminate in cases of non-convergence
        if (E0_old - E0 > 1.0 && counter > 0) {
            cout << "No convergence: Radical E0 drop to " << E0 << endl << endl;
            exit(1);
        }

        if (E0_old - E0 < 0 && counter > 0) {
            cout << "No convergence, E0 increasing again" << endl << endl;
            exit(1);
        }

        diff = abs((E0_old - E0) / E0_old);
        E0_old = E0;

        start_point = k;
        k -= step;
        counter++;

        // Adapt the integration limits in the case of late convergence
        if (k < lambda2) {
            lambda2 *= 0.3;
            k += step;
            step *= 0.2;
            k -= step;
            if (step < 0.001) {
                cout << "Integration too short for convergence" << endl << endl;
                exit(3);
            }
        }

    }

    //cout << iflag << endl;

    delete[] work;
    delete[] work_array;
    delete[] iwork;

    return E0;

}


void SRG::derivative(double k_lambda, std::vector<arma::mat>& v,
        std::vector<arma::mat>& dv) {

    double k3 = k_lambda * k_lambda*k_lambda;

    update_eta(v);

    // E0 derivative
    dv[0](0, 0) = E0_deriv(v);

    // v derivative  
    v_drv(v, dv);

    // f derivative 
    f_drv(v, dv);

    for (int i = 0; i <= 3; i++)
        dv[i] *= -2.0 / k3;

    for (int lbd = 0; lbd < lbd_dim; lbd++)
        for (int i = 4; i <= 9; i++)
            dv[i + 6 * lbd] *= -2.0 / k3;

    return;

}


int SRG::delta(int p, int q) {

    if (p == q) return 1;
    return 0;
}


void SRG::permute(int& p, int& q) {

    int tmp;

    tmp = p;
    p = q;
    q = tmp;

}


double SRG::get_dv3(int p, int q, int r, int s, int t, int u,
        std::vector<arma::mat>& mat_elems) {

    double d_ret = 0.0;

    for (int tt = 0; tt < all_states; tt++) {

        d_ret += get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);

        d_ret -= get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);
        permute(s, u);

        d_ret -= get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, u);
        permute(p, r);

        d_ret -= get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);

        d_ret += get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);
        permute(s, u);

        d_ret += get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, u);
        permute(p, r);
        permute(q, r);

        d_ret -= get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);

        d_ret += get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, t);
        permute(s, u);

        d_ret += get_eta2(p, q, s, tt) * Sys->H->get_v_elem(tt, r, t, u, mat_elems)
                - get_eta2(tt, r, t, u) * Sys->H->get_v_elem(p, q, s, tt, mat_elems);

        permute(s, u);
        permute(q, r);

    }

    return d_ret;

}

double SRG::get_eta3(int p, int q, int r, int s, int t, int u,
        std::vector<arma::mat>& mat_elems) {

    double d_ret = 0.0;

    d_ret += Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    // - P_lm
    permute(s, t);
    d_ret -= Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);
    permute(s, t);

    // -P_ln
    permute(s, u);

    d_ret -= Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);
    permute(s, u);

    // -P_pr
    permute(p, r);
    d_ret -= Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);
    permute(p, r);

    // +P_pr P_lm
    permute(p, r);
    permute(s, t);
    d_ret += Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    permute(p, r);
    permute(s, t);

    // +P_pr P_ln
    permute(p, r);
    permute(s, u);

    d_ret += Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    permute(p, r);
    permute(s, u);

    // -P_qr
    permute(q, r);

    d_ret -= Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    permute(q, r);

    // +P_qr P_lm
    permute(q, r);
    permute(s, t);

    d_ret += Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    permute(q, r);
    permute(s, t);

    // +P_qr P_ln
    permute(q, r);
    permute(s, u);

    d_ret += Sys->H->get_v_elem(p, q, s, q, mat_elems)
            * Sys->H->get_v_elem(q, r, t, u, mat_elems) * delta(p, s)
            + Sys->H->get_v_elem(p, q, s, p, mat_elems)
            * Sys->H->get_v_elem(p, r, t, u, mat_elems) * delta(q, s)
            - Sys->H->get_v_elem(p, q, s, t, mat_elems)
            * Sys->H->get_v_elem(t, r, t, u, mat_elems) * delta(r, u)
            - Sys->H->get_v_elem(p, q, s, u, mat_elems)
            * Sys->H->get_v_elem(u, r, t, u, mat_elems) * delta(r, t);

    permute(q, r);
    permute(s, u);

    return d_ret;

}

