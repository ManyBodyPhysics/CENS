
#include "SRG.h"

////////////////////////////////////////////////////////////////////////////////
//                          class Wegner

/** @brief Subclass of SRG, for Wegner's canonical generator
    @author Sarah Reimann
    @date 23 January 2013
 */ 
////////////////////////////////////////////////////////////////////////////////

#define TEST 0 // Code validation with N=2 particles
#define TOL 1e-16 // tolerance v_pqrs

Wegner::Wegner(System* Sys) {
    this->Sys = Sys;
    this->all_states = Sys->H->Bas->sp_states;

    this->hole_states = Sys->H->Bas->hole_states;
    this->part_states = all_states - hole_states;

    this->lbd_dim = Sys->H->Bas->lbd_dim;

    mat tmp;
    int tmp_row, tmp_col;

    for (int i = 0; i < Sys->H->mat_elems.size(); i++) {
        tmp_row = Sys->H->mat_elems[i].n_rows;
        tmp_col = Sys->H->mat_elems[i].n_cols;
        tmp.set_size(tmp_row, tmp_col);
        eta.push_back(tmp);
    }

    lbd_limits = Sys->H->Bas->lbd_limits();

}


void Wegner::update_eta(std::vector<arma::mat>& mat_elems) {

    for (int i = 0; i < eta.size(); i++)
        eta[i].zeros();

    //--------------------------------------------------------------------------
    //               One-body part of eta
    //--------------------------------------------------------------------------

    ////////////////////////////////////////////////////////////////////////////
    //               Update eta_hh

    int i, j;
    eta[1] = mat_elems[1];

    for (int p = 0; p < hole_states; p++)
        for (int q = p; q < hole_states; q++) {
            eta[1](p, q) *= Sys->H->get_f_elem(p, p, mat_elems)
                    - Sys->H->get_f_elem(q, q, mat_elems);

#if TEST  
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    eta[1](p, q) -= get_eta3(p, i, j, q, i, j, mat_elems);
                }
#endif

            eta[1](q, p) = -eta[1](p, q); // Symmetry relation
        }


    ///////////////////////////////////////////////////////////////////////////
    //                   Update eta_ph
    int p;

    eta[2] = mat_elems[2];

    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        p = p_ind + hole_states;
        for (int q = 0; q < hole_states; q++) {
            eta[2](p_ind, q) *= Sys->H->get_f_elem(p, p, mat_elems)
                    - Sys->H->get_f_elem(q, q, mat_elems)
                    + Sys->H->get_v_elem(q, p, p, q, mat_elems);

#if TEST
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    eta[2](p_ind, q) -= get_eta3(p, i, j, q, i, j, mat_elems);
                }
#endif
        }
    }


    ////////////////////////////////////////////////////////////////////////////
    //                    Update eta_pp

    int q;

    eta[3] = mat_elems[3];

    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        p = p_ind + hole_states;
        for (int q_ind = p_ind; q_ind < part_states; q_ind++) {
            q = q_ind + hole_states;
            eta[3](p_ind, q_ind) *= Sys->H->get_f_elem(p, p, mat_elems)
                    - Sys->H->get_f_elem(q, q, mat_elems);

#if TEST
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    eta[3](p_ind, q_ind) -= get_eta3(p, i, j, q, i, j, mat_elems);
                }
#endif
            eta[3](q_ind, p_ind) = -eta[3](p_ind, q_ind); // Symmetry relation
        }
    }


    //-------------------------------------------------------------------------
    //               Two-body part of eta
    //-------------------------------------------------------------------------


    int r, s;
    double v_rqrq, v_sqsq, v_rprp, v_spsp, v_pqpq, v_pqrs;

#pragma omp parallel private(v_rqrq,v_sqsq,v_rprp,v_spsp,v_pqpq,v_pqrs,p,q,r,s,i,j)
    {

        ///////////////////////////////////////////////////////////////////////////
        //                     Update eta_hhhh

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
            for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {

                p = Sys->H->Bas->hh_basis[lbd][ij](0);
                q = Sys->H->Bas->hh_basis[lbd][ij](1);

                for (int kl = ij; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {
                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    v_rqrq = Sys->H->get_v_elem(r, q, r, q, mat_elems);
                    v_sqsq = -Sys->H->get_v_elem(s, q, q, s, mat_elems);
                    v_rprp = Sys->H->get_v_elem(r, p, r, p, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    eta[4 + 6 * lbd](ij, kl) -= Sys->H->get_f_elem(p, r, mat_elems)
                            * v_rqrq * delta(q, s)
                            - Sys->H->get_f_elem(p, s, mat_elems) * v_sqsq * delta(q, r)
                            - Sys->H->get_f_elem(q, r, mat_elems) * v_rprp * delta(p, s)
                            + Sys->H->get_f_elem(q, s, mat_elems) * v_spsp * delta(p, r)
                            + v_pqpq * (
                            -Sys->H->get_f_elem(p, r, mat_elems) * delta(q, s)
                            + Sys->H->get_f_elem(q, r, mat_elems) * delta(p, s)
                            + Sys->H->get_f_elem(p, s, mat_elems) * delta(q, r)
                            - Sys->H->get_f_elem(q, s, mat_elems) * delta(p, r)
                            );

                    v_pqrs = mat_elems[4 + 6 * lbd](ij, kl);

                    if (abs(v_pqrs) > TOL) {

                        eta[4 + 6 * lbd](ij, kl) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[4 + 6 * lbd](ij, kl) -= (v_pqpq -
                                Sys->H->get_v_elem(r, s, r, s, mat_elems)
                                ) * v_pqrs;
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[4 + 6 * lbd](ij, kl) -= get_eta3(p, q, i, r, s, i, mat_elems);
#endif

                    eta[4 + 6 * lbd](kl, ij) = -eta[4 + 6 * lbd](ij, kl);
                }
            }


        //////////////////////////////////////////////////////////////////////////
        //                       Update eta_phhh 

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)

            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    v_rqrq = Sys->H->get_v_elem(r, q, r, q, mat_elems);
                    v_sqsq = -Sys->H->get_v_elem(s, q, q, s, mat_elems);
                    v_rprp = Sys->H->get_v_elem(r, p, r, p, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    eta[5 + 6 * lbd](ai, kl) -= Sys->H->get_f_elem(p, r, mat_elems)
                            * v_rqrq * delta(q, s)
                            - Sys->H->get_f_elem(p, s, mat_elems) * v_sqsq * delta(q, r)
                            + v_pqpq * (
                            -Sys->H->get_f_elem(p, r, mat_elems) * delta(q, s)
                            + Sys->H->get_f_elem(p, s, mat_elems) * delta(q, r)
                            );

                    v_pqrs = mat_elems[5 + 6 * lbd](ai, kl);

                    if (abs(v_pqrs) > TOL) {

                        eta[5 + 6 * lbd](ai, kl) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[5 + 6 * lbd](ai, kl) += (
                                Sys->H->get_v_elem(r, s, r, s, mat_elems)
                                ) * v_pqrs;

                        eta[5 + 6 * lbd](ai, kl) -= (
                                Sys->H->get_v_elem(r, p, r, p, mat_elems) + v_spsp
                                ) * v_pqrs;
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[5 + 6 * lbd](ai, kl) -= get_eta3(p, q, i, r, s, i, mat_elems);

#endif
                }
            }


        ///////////////////////////////////////////////////////////////////////////
        //                       Update eta_pphh

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)

            for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                p = Sys->H->Bas->pp_basis[lbd][ab](0);
                q = Sys->H->Bas->pp_basis[lbd][ab](1);
                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    v_rqrq = Sys->H->get_v_elem(r, q, r, q, mat_elems);
                    v_sqsq = -Sys->H->get_v_elem(s, q, q, s, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    v_pqrs = mat_elems[6 + 6 * lbd](ab, kl);

                    if (abs(v_pqrs) > TOL) {

                        eta[6 + 6 * lbd](ab, kl) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[6 + 6 * lbd](ab, kl) += (
                                v_pqpq +
                                Sys->H->get_v_elem(r, s, r, s, mat_elems)
                                ) * v_pqrs;

                        eta[6 + 6 * lbd](ab, kl) -= (
                                Sys->H->get_v_elem(r, p, r, p, mat_elems)
                                + v_rqrq + v_spsp + v_sqsq
                                ) * v_pqrs;
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[6 + 6 * lbd](ab, kl) -= get_eta3(p, q, i, r, s, i, mat_elems);
#endif

                }
            }


        //////////////////////////////////////////////////////////////////////////////
        //                          Update eta_phph

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++)

            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int bj = ai; bj < Sys->H->Bas->ph_basis[lbd].size(); bj++) {

                    r = Sys->H->Bas->ph_basis[lbd][bj](0);
                    s = Sys->H->Bas->ph_basis[lbd][bj](1);

                    v_rqrq = Sys->H->get_v_elem(r, q, r, q, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    eta[7 + 6 * lbd](ai, bj) -= Sys->H->get_f_elem(p, r, mat_elems)
                            * v_rqrq * delta(q, s)
                            + Sys->H->get_f_elem(q, s, mat_elems) * v_spsp * delta(p, r)
                            + v_pqpq * (
                            -Sys->H->get_f_elem(p, r, mat_elems) * delta(q, s)
                            - Sys->H->get_f_elem(q, s, mat_elems) * delta(p, r)
                            );

                    v_pqrs = mat_elems[7 + 6 * lbd](ai, bj);

                    if (abs(v_pqrs) > TOL) {

                        eta[7 + 6 * lbd](ai, bj) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[7 + 6 * lbd](ai, bj) -= (-v_rqrq + v_spsp
                                ) * v_pqrs;

                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[7 + 6 * lbd](ai, bj) -= get_eta3(p, q, i, r, s, i, mat_elems);
#endif

                    eta[7 + 6 * lbd](bj, ai) = -eta[7 + 6 * lbd](ai, bj);
                }
            }


        ///////////////////////////////////////////////////////////////////////////
        //                           Update eta_ppph

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++)

            for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {

                p = Sys->H->Bas->pp_basis[lbd][ab](0);
                q = Sys->H->Bas->pp_basis[lbd][ab](1);

                for (int ci = 0; ci < Sys->H->Bas->ph_basis[lbd].size(); ci++) {

                    r = Sys->H->Bas->ph_basis[lbd][ci](0);
                    s = Sys->H->Bas->ph_basis[lbd][ci](1);

                    v_sqsq = -Sys->H->get_v_elem(s, q, q, s, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    eta[8 + 6 * lbd](ab, ci) -=
                            -Sys->H->get_f_elem(p, s, mat_elems) * v_sqsq * delta(q, r)
                            + Sys->H->get_f_elem(q, s, mat_elems) * v_spsp * delta(p, r)
                            + v_pqpq * (
                            +Sys->H->get_f_elem(p, s, mat_elems) * delta(q, r)
                            - Sys->H->get_f_elem(q, s, mat_elems) * delta(p, r)
                            );

                    v_pqrs = mat_elems[8 + 6 * lbd](ab, ci);

                    if (abs(v_pqrs) > TOL) {

                        eta[8 + 6 * lbd](ab, ci) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[8 + 6 * lbd](ab, ci) += (
                                v_pqpq
                                ) * v_pqrs;


                        eta[8 + 6 * lbd](ab, ci) -= (
                                +v_spsp
                                + v_sqsq
                                ) * v_pqrs;

                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[8 + 6 * lbd](ab, ci) -= get_eta3(p, q, i, r, s, i, mat_elems);

#endif
                }
            }


        ///////////////////////////////////////////////////////////////////////
        //                     Update eta_pppp

#pragma omp for schedule(dynamic)
        for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++)

            for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {

                p = Sys->H->Bas->pp_basis[lbd][ab](0);
                q = Sys->H->Bas->pp_basis[lbd][ab](1);

                for (int cd = ab; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                    r = Sys->H->Bas->pp_basis[lbd][cd](0);
                    s = Sys->H->Bas->pp_basis[lbd][cd](1);

                    v_rqrq = Sys->H->get_v_elem(r, q, r, q, mat_elems);
                    v_sqsq = -Sys->H->get_v_elem(s, q, q, s, mat_elems);
                    v_rprp = Sys->H->get_v_elem(r, p, r, p, mat_elems);
                    v_spsp = -Sys->H->get_v_elem(s, p, p, s, mat_elems);
                    v_pqpq = Sys->H->get_v_elem(p, q, p, q, mat_elems);

                    eta[9 + 6 * lbd](ab, cd) -= Sys->H->get_f_elem(p, r, mat_elems)
                            * v_rqrq * delta(q, s)
                            - Sys->H->get_f_elem(p, s, mat_elems) * v_sqsq * delta(q, r)
                            - Sys->H->get_f_elem(q, r, mat_elems) * v_rprp * delta(p, s)
                            + Sys->H->get_f_elem(q, s, mat_elems) * v_spsp * delta(p, r)
                            + v_pqpq * (
                            -Sys->H->get_f_elem(p, r, mat_elems) * delta(q, s)
                            + Sys->H->get_f_elem(q, r, mat_elems) * delta(p, s)
                            + Sys->H->get_f_elem(p, s, mat_elems) * delta(q, r)
                            - Sys->H->get_f_elem(q, s, mat_elems) * delta(p, r)
                            );

                    v_pqrs = mat_elems[9 + 6 * lbd](ab, cd);

                    if (abs(v_pqrs) > TOL) {

                        eta[9 + 6 * lbd](ab, cd) += (Sys->H->get_f_elem(p, p, mat_elems)
                                + Sys->H->get_f_elem(q, q, mat_elems)
                                - Sys->H->get_f_elem(r, r, mat_elems)
                                - Sys->H->get_f_elem(s, s, mat_elems)) * v_pqrs;

                        eta[9 + 6 * lbd](ab, cd) += (
                                v_pqpq - Sys->H->get_v_elem(r, s, r, s, mat_elems)
                                ) * v_pqrs;
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++)
                        eta[9 + 6 * lbd](ab, cd) -= get_eta3(p, q, i, r, s, i, mat_elems);
#endif

                    eta[9 + 6 * lbd](cd, ab) = -eta[9 + 6 * lbd](ab, cd);
                }
            }
    }
}


double Wegner::get_eta1(int p, int q) const {

    if (p < hole_states) {
        if (q < hole_states)
            return eta[1](p, q);
        else return -eta[2](q - hole_states, p);
    } else if (q < hole_states)
        return eta[2](p - hole_states, q);
    return eta[3](p - hole_states, q - hole_states);


}


double Wegner::get_eta2(int p, int q, int r, int s) const {

    int tmp;
    int sign = 1;
    int comb1, comb2;

    // Check conservation of M
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_s
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    if (p < Sys->H->Bas->hole_states) {
        if (q < Sys->H->Bas->hole_states) {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hhhh
                    comb1 = Sys->H->Bas->map_hh(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[4 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_hhhp -> eta_phhh
                    comb1 = Sys->H->Bas->map_ph(s, r, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[5 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hhph -> -eta_phhh
                    comb1 = Sys->H->Bas->map_ph(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[5 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_hhpp -> -eta_pphh
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[6 + 6 * lbd](comb1, comb2);
                }
            }

        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hphh -> eta_phhh
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[5 + 6 * lbd](comb1, comb2);
                } else {

                    // eta_hphp -> eta_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hpph -> -eta_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[7 + 6 * lbd](comb1, comb2);
                } else {
                    // eta_hppp -> eta_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(q, p, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[8 + 6 * lbd](comb1, comb2);
                }
            }
        }
    } else {
        if (q < Sys->H->Bas->hole_states) {

            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_phhh
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[5 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_phhp -> eta_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[7 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_phpp -> -eta_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[8 + 6 * lbd](comb1, comb2);

                }
            }
        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_pphh
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[6 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_pphp -> -eta_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return -sign * eta[8 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[8 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_pppp
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_pp(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    return sign * eta[9 + 6 * lbd](comb1, comb2);
                }
            }
        }
    }

}


double Wegner::E0_deriv(std::vector<arma::mat>& mat_elems) {


    double d_ret = 0.0;
    double contr = 0.0;

    for (int i = 0; i < hole_states; i++)
        for (int a = hole_states; a < all_states; a++) {
            d_ret += get_eta1(i, a) * Sys->H->get_f_elem(a, i, mat_elems);
        }

    d_ret *= 2;

    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++)
            for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++)
                contr += -eta[6 + 6 * lbd](ab, ij) * mat_elems[6 + 6 * lbd](ab, ij);

    d_ret += 2 * contr;

    contr = 0.0;

#if TEST
    int i, j;
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
        for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
            i = Sys->H->Bas->hh_basis[lbd][ij](0);
            j = Sys->H->Bas->hh_basis[lbd][ij](1);
            for (int k = 0; k < hole_states; k++)
                contr += get_dv3(i, j, k, i, j, k, mat_elems);
        }

    d_ret += (1.0 / 3.0) * contr;

#endif

    return d_ret;

}


void Wegner::f_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv) {

    int a_p, i_p, a_q, i_q, pp, qq;

    for (int i = 1; i <= 3; i++) {
        dv[i].zeros();
    }

    ///////////////////////////////////////////////////////////////////////////
    //                         Compute f_hh

    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
        for (int ap = 0; ap < Sys->H->Bas->ph_basis[lbd].size(); ap++) {

            a_p = Sys->H->Bas->ph_basis[lbd][ap](0);
            pp = Sys->H->Bas->ph_basis[lbd][ap](1);

            for (int aq = ap; aq < Sys->H->Bas->ph_basis[lbd].size(); aq++) {

                a_q = Sys->H->Bas->ph_basis[lbd][aq](0);
                qq = Sys->H->Bas->ph_basis[lbd][aq](1);

                if (a_p == a_q) dv[1](pp, qq) += dot(eta[5 + 6 * lbd].row(ap),
                        mat_elems[5 + 6 * lbd].row(aq))
                    + dot(eta[5 + 6 * lbd].row(aq), mat_elems[5 + 6 * lbd].row(ap));
            }
        }
    }


    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
        for (int ip = 0; ip < Sys->H->Bas->hh_basis[lbd].size(); ip++) {

            i_p = Sys->H->Bas->hh_basis[lbd][ip](0);
            pp = Sys->H->Bas->hh_basis[lbd][ip](1);

            for (int iq = 0; iq < Sys->H->Bas->hh_basis[lbd].size(); iq++) {

                i_q = Sys->H->Bas->hh_basis[lbd][iq](0);
                qq = Sys->H->Bas->hh_basis[lbd][iq](1);

                if (i_p == i_q) dv[1](pp, qq) += dot(-eta[6 + 6 * lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[6 + 6 * lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));
                if (pp == qq) dv[1](i_p, i_q) += dot(-eta[6 + 6 * lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[6 + 6 * lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));
                if (pp == i_q) dv[1](i_p, qq) -= dot(-eta[6 + 6 * lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[6 + 6 * lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));
                if (i_p == qq) dv[1](pp, i_q) -= dot(-eta[6 + 6 * lbd].col(ip),
                        mat_elems[6 + 6 * lbd].col(iq))
                    + dot(-eta[6 + 6 * lbd].col(iq), mat_elems[6 + 6 * lbd].col(ip));
            }
        }

    }


    dv[1] += eta[1] * mat_elems[1] + strans(eta[1] * mat_elems[1]);
    dv[1] += -strans(eta[2]) * mat_elems[2] - strans(mat_elems[2]) * eta[2];

    for (int p = 0; p < hole_states; p++)
        for (int q = p; q < hole_states; q++) {

            for (int i = 0; i < hole_states; i++)
                for (int a = hole_states; a < all_states; a++) {
                    dv[1](p, q) += get_eta1(i, a)
                            * Sys->H->get_v_elem(a, p, i, q, mat_elems)
                            - Sys->H->get_f_elem(i, a, mat_elems) * get_eta2(a, p, i, q);
                    dv[1](p, q) -= get_eta1(a, i)
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems)
                            - Sys->H->get_f_elem(a, i, mat_elems) * get_eta2(i, p, a, q);
                }

#if TEST          
            int i, j;
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    dv[1](p, q) -= get_dv3(p, i, j, q, i, j, mat_elems);

                }
#endif

            dv[1](q, p) = dv[1](p, q);
        }


    ///////////////////////////////////////////////////////////////////////////
    //                       Compute f_ph
    
    int p;

    dv[2] += eta[2] * mat_elems[1] + mat_elems[2] * strans(eta[1]);
    dv[2] += eta[3] * mat_elems[2] - strans(mat_elems[3]) * eta[2];

    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
        for (int ap = 0; ap < Sys->H->Bas->pp_basis[lbd].size(); ap++) {
            
            a_p = Sys->H->Bas->pp_basis[lbd][ap](0);
            pp = Sys->H->Bas->pp_basis[lbd][ap](1);
            
            for (int aq = 0; aq < Sys->H->Bas->ph_basis[lbd].size(); aq++) {
                
                a_q = Sys->H->Bas->ph_basis[lbd][aq](0);
                qq = Sys->H->Bas->ph_basis[lbd][aq](1);
                
                if (a_p == a_q) dv[2](pp - hole_states, qq) += 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[5 + 6 * lbd].row(aq))
                    + dot(eta[5 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                if (pp == a_q) dv[2](a_p - hole_states, qq) -= 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[5 + 6 * lbd].row(aq))
                    + dot(eta[5 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
            }
        }
    }

    
    for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
        for (int ip = 0; ip < Sys->H->Bas->ph_basis[lbd].size(); ip++) {
            
            i_p = Sys->H->Bas->ph_basis[lbd][ip](1);
            pp = Sys->H->Bas->ph_basis[lbd][ip](0);
            
            for (int iq = 0; iq < Sys->H->Bas->hh_basis[lbd].size(); iq++) {
                
                i_q = Sys->H->Bas->hh_basis[lbd][iq](0);
                qq = Sys->H->Bas->hh_basis[lbd][iq](1);
                
                if (i_p == i_q) dv[2](pp - hole_states, qq) += 
                        dot(eta[8 + 6 * lbd].col(ip), mat_elems[6 + 6 * lbd].col(iq))
                    + dot(eta[6 + 6 * lbd].col(iq), mat_elems[8 + 6 * lbd].col(ip));
                if (i_p == qq) dv[2](pp - hole_states, i_q) -= 
                        dot(eta[8 + 6 * lbd].col(ip), mat_elems[6 + 6 * lbd].col(iq))
                    + dot(eta[6 + 6 * lbd].col(iq), mat_elems[8 + 6 * lbd].col(ip));
            }
        }
    }

    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        
        p = p_ind + hole_states;
        
        for (int q = 0; q < hole_states; q++) {
            for (int i = 0; i < hole_states; i++)
                
                for (int a = hole_states; a < all_states; a++) {
                    dv[2](p_ind, q) += get_eta1(i, a) 
                            * Sys->H->get_v_elem(a, p, i, q, mat_elems)
                            - Sys->H->get_f_elem(i, a, mat_elems) * get_eta2(a, p, i, q);
                    dv[2](p_ind, q) -= get_eta1(a, i) 
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems)
                            - Sys->H->get_f_elem(a, i, mat_elems) * get_eta2(i, p, a, q);
                }

#if TEST
            int i, j;
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    dv[2](p_ind, q) -= get_dv3(p, i, j, q, i, j, mat_elems); 
                }
#endif
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //                         Compute f_pp
    
    int q;
    
    dv[3] += eta[2] * strans(mat_elems[2]) + mat_elems[2] * strans(eta[2]);
    dv[3] += eta[3] * mat_elems[3] - strans(mat_elems[3]) * eta[3];

    for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++) {
        for (int ap = 0; ap < Sys->H->Bas->pp_basis[lbd].size(); ap++) {
            
            a_p = Sys->H->Bas->pp_basis[lbd][ap](0);
            pp = Sys->H->Bas->pp_basis[lbd][ap](1);
            
            for (int aq = 0; aq < Sys->H->Bas->pp_basis[lbd].size(); aq++) {
                
                a_q = Sys->H->Bas->pp_basis[lbd][aq](0);
                qq = Sys->H->Bas->pp_basis[lbd][aq](1);
                
                if (a_p == a_q) dv[3](pp - hole_states, qq - hole_states) += 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[6 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                if (pp == qq) dv[3](a_p - hole_states, a_q - hole_states) += 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[6 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                if (pp == a_q) dv[3](a_p - hole_states, qq - hole_states) -= 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[6 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
                if (a_p == qq) dv[3](pp - hole_states, a_q - hole_states) -= 
                        dot(eta[6 + 6 * lbd].row(ap), mat_elems[6 + 6 * lbd].row(aq))
                    + dot(eta[6 + 6 * lbd].row(aq), mat_elems[6 + 6 * lbd].row(ap));
            }
        }
    }

    for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
        for (int ip = 0; ip < Sys->H->Bas->ph_basis[lbd].size(); ip++) {
            
            i_p = Sys->H->Bas->ph_basis[lbd][ip](1);
            pp = Sys->H->Bas->ph_basis[lbd][ip](0);
            
            for (int iq = 0; iq < Sys->H->Bas->ph_basis[lbd].size(); iq++) {
                
                i_q = Sys->H->Bas->ph_basis[lbd][iq](1);
                qq = Sys->H->Bas->ph_basis[lbd][iq](0); // hppp -> ppph
                
                if (i_p == i_q) dv[3](pp - hole_states, qq - hole_states) += 
                        dot(-eta[8 + 6 * lbd].col(ip), mat_elems[8 + 6 * lbd].col(iq))
                    + dot(-eta[8 + 6 * lbd].col(iq), mat_elems[8 + 6 * lbd].col(ip));
            }
        }
    }
    
    
    for (int p_ind = 0; p_ind < part_states; p_ind++) {
        p = p_ind + hole_states;
        for (int q_ind = p_ind; q_ind < part_states; q_ind++) {
            q = q_ind + hole_states;

            for (int i = 0; i < hole_states; i++)
                for (int a = hole_states; a < all_states; a++) {
                    dv[3](p_ind, q_ind) += get_eta1(i, a) 
                            * Sys->H->get_v_elem(a, p, i, q, mat_elems)
                            - Sys->H->get_f_elem(i, a, mat_elems) * get_eta2(a, p, i, q);
                    dv[3](p_ind, q_ind) -= get_eta1(a, i)
                            * Sys->H->get_v_elem(i, p, a, q, mat_elems)
                            - Sys->H->get_f_elem(a, i, mat_elems) * get_eta2(i, p, a, q);
                }

#if TEST
            int i, j; 
            for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++)
                for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {
                    i = Sys->H->Bas->hh_basis[lbd][ij](0);
                    j = Sys->H->Bas->hh_basis[lbd][ij](1);
                    dv[3](p_ind, q_ind) -= get_dv3(p, i, j, q, i, j, mat_elems);
                }
#endif
            dv[3](q_ind, p_ind) = dv[3](p_ind, q_ind);
        }
    }
}


void Wegner::v_drv(std::vector<arma::mat>& mat_elems, std::vector<arma::mat>& dv) {

    for (int lbd = 0; lbd < lbd_dim; lbd++)
        for (int i = 4; i <= 9; i++)
            dv[i + 6 * lbd].zeros();

#pragma omp parallel 
    {
        int p, q, r, s;
        int v_comb1, eta_comb1, v_comb2, eta_comb2;
        int eta_sign, eta_ind, v_sign, v_ind, dv_ind;
        
        ////////////////////////////////////////////////////////////////////////
        //         Compute derivative of v_hhhh -> dv[4] 
        
#pragma  omp  for   schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {

            dv_ind = 4+6*lbd;
            
            for (int ij = 0; ij < Sys->H->Bas->hh_basis[lbd].size(); ij++) {

                p = Sys->H->Bas->hh_basis[lbd][ij](0);
                q = Sys->H->Bas->hh_basis[lbd][ij](1);

                for (int kl = ij; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](ij, kl) += get_eta1(p, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](ij, kl) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems) 
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {

                        dv[dv_ind](ij, kl) += -eta[6 + 6 * lbd](ab, ij) 
                                * mat_elems[6 + 6 * lbd](ab, kl)
                                - eta[6 + 6 * lbd](ab, kl) 
                                * mat_elems[6 + 6 * lbd](ab, ij);

                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {

                        dv[dv_ind](ij, kl) -= eta[4 + 6 * lbd](ij, ij_) 
                                * mat_elems[4 + 6 * lbd](ij_, kl)
                                - eta[4 + 6 * lbd](ij_, kl) 
                                * mat_elems[4 + 6 * lbd](ij_, ij);

                    }
   
                    for (int i = 0; i < hole_states; i++) {
                         for (int a = hole_states; a < all_states; a++) {

                            dv[dv_ind](ij, kl) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ij, kl) += eta_sign
                                        * eta[eta_ind](eta_comb1, eta_comb2)
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ij, kl) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ij, kl) -= eta_sign
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ij, kl) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign)
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ij, kl) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ij, kl) -= get_eta2_comb(a, p, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ij, kl) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);
                        }
                    }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[dv_ind](ij, kl) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }

#endif
                    dv[dv_ind](kl, ij) = dv[4 + 6 * lbd](ij, kl);
                }
            }
        }


        ///////////////////////////////////////////////////////////////////////
        //         Compute derivative of v_phhh -> dv[5]
        
#pragma  omp  for  schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {
            
            dv_ind = 5+6*lbd;
            
            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](ai, kl) += get_eta1(p, t)
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](ai, kl) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems) 
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                       dv[dv_ind](ai, kl) += -eta[8 + 6 * lbd](ab, ai) 
                               * mat_elems[6 + 6 * lbd](ab, kl)
                                - eta[6 + 6 * lbd](ab, kl) 
                               * mat_elems[8 + 6 * lbd](ab, ai);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[dv_ind](ai, kl) -= eta[5 + 6 * lbd](ai, ij_) 
                                * mat_elems[4 + 6 * lbd](ij_, kl)
                                - eta[4 + 6 * lbd](ij_, kl) 
                                * mat_elems[5 + 6 * lbd](ai, ij_);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            
                            dv[dv_ind](ai, kl) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, kl) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, kl) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, kl) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2)
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, kl) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, kl) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, kl) -= get_eta2_comb(a, p, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, kl) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);
    
                        }
           
#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[dv_ind](ai, kl) -= get_dv3(p, q, i, r, s, i, mat_elems); 
                    }
#endif
                }
            }
        }

        ////////////////////////////////////////////////////////////////////////
        //                Compute derivative of v_pphh -> dv[6]
        
#pragma  omp for  schedule(dynamic)
        for (int lbd = lbd_limits(0, 0); lbd <= lbd_limits(0, 1); lbd++) {

            dv_ind = 6+6*lbd;
            
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int kl = 0; kl < Sys->H->Bas->hh_basis[lbd].size(); kl++) {

                    r = Sys->H->Bas->hh_basis[lbd][kl](0);
                    s = Sys->H->Bas->hh_basis[lbd][kl](1);

                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](cd, kl) += get_eta1(p, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](cd, kl) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems) 
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[dv_ind](cd, kl) += eta[9 + 6 * lbd](cd, ab) 
                                * mat_elems[6 + 6 * lbd](ab, kl)
                                - eta[6 + 6 * lbd](ab, kl) 
                                * mat_elems[9 + 6 * lbd](ab, cd);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[dv_ind](cd, kl) -= eta[6 + 6 * lbd](cd, ij_) 
                                * mat_elems[4 + 6 * lbd](ij_, kl)
                                - eta[4 + 6 * lbd](ij_, kl) 
                                * mat_elems[6 + 6 * lbd](cd, ij_);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            
                            dv[dv_ind](cd, kl) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, kl) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, kl) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, kl) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, kl) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, kl) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, kl) -= get_eta2_comb(a, p, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, kl) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);
                        }

#if TEST                
                    for (int i = 0; i < hole_states; i++) {
                       dv[dv_ind](cd, kl) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif
                }
            }
        }

        
        ////////////////////////////////////////////////////////////////////////
        //       Compute derivative of v_phph -> dv[7]
        
#pragma  omp for  schedule(dynamic)
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
            
            dv_ind = 7+6*lbd;
            
            for (int ai = 0; ai < Sys->H->Bas->ph_basis[lbd].size(); ai++) {

                p = Sys->H->Bas->ph_basis[lbd][ai](0);
                q = Sys->H->Bas->ph_basis[lbd][ai](1);

                for (int bj = ai; bj < Sys->H->Bas->ph_basis[lbd].size(); bj++) {

                    r = Sys->H->Bas->ph_basis[lbd][bj](0);
                    s = Sys->H->Bas->ph_basis[lbd][bj](1);


                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](ai, bj) += get_eta1(p, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](ai, bj) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems) 
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }


                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[dv_ind](ai, bj) += -eta[8 + 6 * lbd](ab, ai) 
                                * mat_elems[8 + 6 * lbd](ab, bj)
                                - eta[8 + 6 * lbd](ab, bj) 
                                * mat_elems[8 + 6 * lbd](ab, ai);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[dv_ind](ai, bj) -= eta[5 + 6 * lbd](ai, ij_) 
                                * mat_elems[5 + 6 * lbd](bj, ij_)
                                + eta[5 + 6 * lbd](bj, ij_) 
                                * mat_elems[5 + 6 * lbd](ai, ij_);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            
                            dv[dv_ind](ai, bj) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, bj) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, bj) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, bj) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, bj) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, bj) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](ai, bj) -= get_eta2_comb(a, p, i, r,
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](ai, bj) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);             
                        }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                       dv[dv_ind](ai, bj) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }             
#endif
                    dv[dv_ind](bj, ai) = dv[dv_ind](ai, bj);
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        //             Compute derivative of v_ppph -> dv[8]
        
#pragma  omp  for schedule(dynamic)    
        for (int lbd = lbd_limits(1, 0); lbd <= lbd_limits(1, 1); lbd++) {
           
            dv_ind = 8+6*lbd;
            
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int ei = 0; ei < Sys->H->Bas->ph_basis[lbd].size(); ei++) {

                    r = Sys->H->Bas->ph_basis[lbd][ei](0);
                    s = Sys->H->Bas->ph_basis[lbd][ei](1);

                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](cd, ei) += get_eta1(p, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](cd, ei) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems) 
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s) 
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[dv_ind](cd, ei) += eta[9 + 6 * lbd](cd, ab) 
                                * mat_elems[8 + 6 * lbd](ab, ei)
                                - eta[8 + 6 * lbd](ab, ei) 
                                * mat_elems[9 + 6 * lbd](ab, cd);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[dv_ind](cd, ei) -= eta[6 + 6 * lbd](cd, ij_) 
                                * mat_elems[5 + 6 * lbd](ei, ij_)
                                + eta[5 + 6 * lbd](ei, ij_) 
                                * mat_elems[6 + 6 * lbd](cd, ij_);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            
                            dv[dv_ind](cd, ei) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ei) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ei) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ei) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ei) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ei) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ei) -= get_eta2_comb(a, p, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ei) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);                        
                        }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                       dv[dv_ind](cd, ei) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif
                }
            }
        }

        ///////////////////////////////////////////////////////////////////////
        //          Compute derivative of v_pppp -> dv[9]
        
#pragma  omp  for  schedule(dynamic) 
        for (int lbd = lbd_limits(2, 0); lbd <= lbd_limits(2, 1); lbd++) {
            
            dv_ind = 9+6*lbd;
            
            for (int cd = 0; cd < Sys->H->Bas->pp_basis[lbd].size(); cd++) {

                p = Sys->H->Bas->pp_basis[lbd][cd](0);
                q = Sys->H->Bas->pp_basis[lbd][cd](1);

                for (int ef = cd; ef < Sys->H->Bas->pp_basis[lbd].size(); ef++) {

                    r = Sys->H->Bas->pp_basis[lbd][ef](0);
                    s = Sys->H->Bas->pp_basis[lbd][ef](1);

                    for (int t = 0; t < all_states; t++) {

                        dv[dv_ind](cd, ef) += get_eta1(p, t) 
                                * Sys->H->get_v_elem(t, q, r, s, mat_elems)
                                - Sys->H->get_f_elem(p, t, mat_elems) 
                                * get_eta2(t, q, r, s)
                                - get_eta1(q, t) 
                                * Sys->H->get_v_elem(t, p, r, s, mat_elems)
                                + Sys->H->get_f_elem(q, t, mat_elems) 
                                * get_eta2(t, p, r, s);

                        dv[dv_ind](cd, ef) -= get_eta1(t, r) 
                                * Sys->H->get_v_elem(p, q, t, s, mat_elems)
                                - Sys->H->get_f_elem(t, r, mat_elems)
                                * get_eta2(p, q, t, s)
                                - get_eta1(t, s)
                                * Sys->H->get_v_elem(p, q, t, r, mat_elems)
                                + Sys->H->get_f_elem(t, s, mat_elems) 
                                * get_eta2(p, q, t, r);
                    }

                    for (int ab = 0; ab < Sys->H->Bas->pp_basis[lbd].size(); ab++) {
                        dv[dv_ind](cd, ef) += eta[9 + 6 * lbd](cd, ab) 
                                * mat_elems[9 + 6 * lbd](ab, ef)
                                - eta[9 + 6 * lbd](ab, ef) 
                                * mat_elems[9 + 6 * lbd](ab, cd);
                    }

                    for (int ij_ = 0; ij_ < Sys->H->Bas->hh_basis[lbd].size(); ij_++) {
                        dv[dv_ind](cd, ef) -= eta[6 + 6 * lbd](cd, ij_) 
                                * mat_elems[6 + 6 * lbd](ef, ij_)
                                + eta[6 + 6 * lbd](ef, ij_) 
                                * mat_elems[6 + 6 * lbd](cd, ij_);
                    }

                    for (int i = 0; i < hole_states; i++)
                        for (int a = hole_states; a < all_states; a++) {
                            
                            dv[dv_ind](cd, ef) -= get_eta2_comb(a, q, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, r, mat_elems,
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                            dv[dv_ind](cd, ef) += eta_sign 
                                    * eta[eta_ind](eta_comb1, eta_comb2) 
                                    * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ef) += get_eta2_comb(a, p, i, s, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, r, mat_elems,
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ef) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ef) += get_eta2_comb(a, q, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, p, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ef) -= eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);

                            dv[dv_ind](cd, ef) -= get_eta2_comb(a, p, i, r, 
                                    v_comb1, v_comb2, v_ind, v_sign) 
                                    * get_v_elem_comb(i, q, a, s, mat_elems, 
                                    eta_comb1, eta_comb2, eta_ind, eta_sign);
                            
                            if (abs(v_sign) > 0 && abs(eta_sign) > 0)
                                dv[dv_ind](cd, ef) += eta_sign 
                                        * eta[eta_ind](eta_comb1, eta_comb2) 
                                        * v_sign * mat_elems[v_ind](v_comb1, v_comb2);
                        }

#if TEST
                    for (int i = 0; i < hole_states; i++) {
                        dv[dv_ind](cd, ef) -= get_dv3(p, q, i, r, s, i, mat_elems);
                    }
#endif
                    dv[dv_ind](ef, cd) = dv[dv_ind](cd, ef);
                }
            }
        }
    }
}


double Wegner::get_v_elem_comb(int p, int q, int r, int s,  
        std::vector<arma::mat>& mat_elems, int& comb1, int& comb2, int& eta_ind,
        int& eta_sign) {

    int tmp;
    int sign = 1;
    eta_sign = 0;

    // Check conservation of M
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_s
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    if (p < Sys->H->Bas->hole_states) {
        if (q < Sys->H->Bas->hole_states) {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // v_hhhh
                    comb1 = Sys->H->Bas->map_hh(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 4 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[4 + 6 * lbd](comb1, comb2);

                } else {

                    // v_hhhp -> v_phhh
                    comb1 = Sys->H->Bas->map_ph(s, r, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 5 + 6 * lbd;
                    eta_sign = sign;
                    return -sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // v_hhph ->v_phhh
                    comb1 = Sys->H->Bas->map_ph(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 5 + 6 * lbd;
                    eta_sign = -sign;
                    return sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                } else {

                    // v_hhpp -> v_pphh
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 6 + 6 * lbd;
                    eta_sign = -sign;
                    return sign * mat_elems[6 + 6 * lbd](comb1, comb2);
                }
            }

        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // v_hphh -> v_phhh
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 5 + 6 * lbd;
                    eta_sign = -sign;
                    return -sign * mat_elems[5 + 6 * lbd](comb1, comb2);
                } else {

                    // v_hphp -> v_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 7 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // v_hpph -> v_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 7 + 6 * lbd;
                    eta_sign = -sign;
                    return -sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                } else {
                    // v_hppp -> v_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(q, p, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 8 + 6 * lbd;
                    eta_sign = sign;
                    return -sign * mat_elems[8 + 6 * lbd](comb1, comb2);
                }
            }
        }
    } else {
        if (q < Sys->H->Bas->hole_states) {

            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // v_phhh
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 5 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[5 + 6 * lbd](comb1, comb2);

                } else {

                    // v_phhp -> v_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 7 + 6 * lbd;
                    eta_sign = -sign;
                    return -sign * mat_elems[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // v_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 7 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[7 + 6 * lbd](comb1, comb2);

                } else {

                    // v_phpp -> v_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 8 + 6 * lbd;
                    eta_sign = -sign;
                    return sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                }
            }
        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // v_pphh
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 6 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[6 + 6 * lbd](comb1, comb2);

                } else {

                    // v_pphp -> v_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 8 + 6 * lbd;
                    eta_sign = -sign;
                    return -sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // v_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 8 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[8 + 6 * lbd](comb1, comb2);

                } else {

                    // v_pppp
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_pp(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    eta_ind = 9 + 6 * lbd;
                    eta_sign = sign;
                    return sign * mat_elems[9 + 6 * lbd](comb1, comb2);
                }
            }
        }
    }
}


double Wegner::get_eta2_comb(int p, int q, int r, int s, int& comb1, int& comb2,
        int& v_ind, int& v_sign) {

    int tmp;
    int sign = 1;
    v_sign = 0;

    // Check conservation of M
    int M1 = Sys->H->Bas->singPart[p].qnumbers[1] + Sys->H->Bas->singPart[q].qnumbers[1];
    int M2 = Sys->H->Bas->singPart[r].qnumbers[1] + Sys->H->Bas->singPart[s].qnumbers[1];

    if (M1 != M2) return 0;

    // Check conservation of M_s
    int Ms1 = Sys->H->Bas->singPart[p].qnumbers[2] + Sys->H->Bas->singPart[q].qnumbers[2];
    int Ms2 = Sys->H->Bas->singPart[r].qnumbers[2] + Sys->H->Bas->singPart[s].qnumbers[2];

    if (Ms1 != Ms2) return 0;

    // Bring indices into right order
    if (p < q) {
        tmp = p;
        p = q;
        q = tmp;
        sign *= -1;
    }

    if (r < s) {
        tmp = r;
        r = s;
        s = tmp;
        sign *= -1;
    }

    // Extract right channel
    int lbd = Sys->H->Bas->get_lbd(M1, Ms1);

    if (p < Sys->H->Bas->hole_states) {
        if (q < Sys->H->Bas->hole_states) {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hhhh
                    comb1 = Sys->H->Bas->map_hh(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 4 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[4 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_hhhp -> eta_phhh
                    comb1 = Sys->H->Bas->map_ph(s, r, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 5 + 6 * lbd;
                    v_sign = -sign;
                    return sign * eta[5 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hhph -> -eta_phhh
                    comb1 = Sys->H->Bas->map_ph(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 5 + 6 * lbd;
                    v_sign = sign;
                    return -sign * eta[5 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_hhpp -> -eta_pphh
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_hh(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 6 + 6 * lbd;
                    v_sign = sign;
                    return -sign * eta[6 + 6 * lbd](comb1, comb2);
                }
            }

        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hphh -> -eta_phhh
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 5 + 6 * lbd;
                    v_sign = -sign;
                    return -sign * eta[5 + 6 * lbd](comb1, comb2);
                } else {

                    // eta_hphp -> eta_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 7 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_hpph -> -eta_phph
                    comb1 = Sys->H->Bas->map_ph(q, p, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 7 + 6 * lbd;
                    v_sign = -sign;
                    return -sign * eta[7 + 6 * lbd](comb1, comb2);
                } else {
                    // eta_hppp -> eta_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(q, p, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 8 + 6 * lbd;
                    v_sign = -sign;
                    return sign * eta[8 + 6 * lbd](comb1, comb2);
                }
            }
        }
    } else {
        if (q < Sys->H->Bas->hole_states) {

            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_phhh
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 5 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[5 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_phhp -> -eta_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 7 + 6 * lbd;
                    v_sign = -sign;
                    return -sign * eta[7 + 6 * lbd](comb1, comb2);
                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_phph
                    comb1 = Sys->H->Bas->map_ph(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 7 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[7 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_phpp -> -eta_ppph
                    comb1 = Sys->H->Bas->map_pp(r, s, lbd);
                    comb2 = Sys->H->Bas->map_ph(p, q, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 8 + 6 * lbd;
                    v_sign = sign;
                    return -sign * eta[8 + 6 * lbd](comb1, comb2);

                }
            }
        } else {
            if (r < Sys->H->Bas->hole_states) {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_pphh
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_hh(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 6 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[6 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_pphp -> -eta_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(s, r, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 8 + 6 * lbd;
                    v_sign = -sign;
                    return -sign * eta[8 + 6 * lbd](comb1, comb2);

                }
            } else {
                if (s < Sys->H->Bas->hole_states) {

                    // eta_ppph
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_ph(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 8 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[8 + 6 * lbd](comb1, comb2);

                } else {

                    // eta_pppp
                    comb1 = Sys->H->Bas->map_pp(p, q, lbd);
                    comb2 = Sys->H->Bas->map_pp(r, s, lbd);
                    if (comb1 < 0 || comb2 < 0) return 0;
                    v_ind = 9 + 6 * lbd;
                    v_sign = sign;
                    return sign * eta[9 + 6 * lbd](comb1, comb2);
                }
            }
        }
    }

}



     

