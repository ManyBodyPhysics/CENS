
#ifndef BASIS_H
#define	BASIS_H


#include "../../lib/ARMADILLO_LAPACK.h"
#include "../SPstate/SPstate.h"
#include <vector>


using namespace std;
using namespace arma;

////////////////////////////////////////////////////////////////////////////////
//                          class Basis

/** @brief Class for creating and administering a two-particle basis
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////

class Basis{
    
private:
    int sp_states; /// number of single-particle states
    int hole_states; /// number hole states = number particles
    int lbd_dim; /// number of channels
    int Mmax; 
    imat lbd_lims; /// holds occupied channels in hh_, ph_ and pp_basis
    std::vector<arma::ivec2> *hh_basis, *pp_basis, *ph_basis; /// tp-basis
       
public:

    friend class Hamiltonian;
    friend class HartreeFock;
    friend class SRG;
    friend class Wegner;
    friend class White;  
    
    Basis(){};
    
    /**
     * Constructor
     * @param sp_states - number single-particle states
     * @param hole_states - number hole states
     * @param i_qn - number of quantum numbers to be stored in the single-particle
     * basis
     */
    Basis(int sp_states, int hole_states, int i_qn);
    
    /**
     * Destructor
     */
    ~Basis();
    
    /**
     * Create the complete tp-basis
     * @param R - number of shells
     */
    void establish_basis(int R);
    
    /**
     * Create tp-basis for indices corresponding to hole states
     */
    void create_hh();
    
    /**
     * Create tp-basis for indices corresponding to particle states
     */
    void create_pp();
    
    /**
     * Create tp-basis with the first index corresponding to a particle, the
     * second one to a hole state
     */
    void create_ph(); 
      
    /**
     * Translate indices p and h to an index in the ph_basis
     * @param p - first index, must correspond to particle state
     * @param h - second index, must correspond to hole state
     * @param lbd - channel
     * @return - index in ph_basis of channel lbd
     */
    int map_ph(int p, int h, int lbd);
    
    /**
     * Translate indices p1 and p2 to an index in the pp_basis
     * @param p1 - first index, must correspond to particle state
     * @param p2 - second index, must correspond to particle state
     * @param lbd - channel
     * @return - index in pp_basis of channel lbd
     */
    int map_pp(int p1, int p2, int lbd);
    
    /**
     * Translate indices h1 and h2 to an index in the hh_basis
     * @param h1 - first index, must correspond to hole state
     * @param h2 - second index, must correspond to hole state
     * @param lbd - channel
     * @return - index in hh_basis of channel lbd
     */
    int map_hh(int h1, int h2, int lbd);
    
    /**
     * Determine which channels are really occupied in the tp-basis
     * @return matrix with limits of lambda for hh_,ph_ and pp_basis
     */
    imat lbd_limits(); 
    
    /**
     * Determine channel from quantum numbers M and M_s
     * @param M - magnetic quantum number
     * @param Ms - spin quantum number
     * @return channel corresponding to the two given quantum numbers
     */
    int get_lbd(int M, int Ms);
    
    SPstate* singPart;
    
};


#endif	/* BASIS_H */

