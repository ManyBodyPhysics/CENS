
#include "Basis.h"
  
////////////////////////////////////////////////////////////////////////////////
//                          class Basis

/** @brief Class for creating and administering a two-particle basis
    @author Sarah Reimann
    @date 08 January 2013
 */
////////////////////////////////////////////////////////////////////////////////


Basis::Basis(int sp_states, int hole_states, int i_qn) {

    this->sp_states = sp_states;
    this->hole_states = hole_states;

    // Create the array with single-particle states
    singPart = new SPstate[sp_states];
    for (int i = 0; i < sp_states; i++)
        singPart[i].create(i_qn);
    
}


Basis::~Basis(){
    
    delete[] singPart;
    delete[] hh_basis;
    delete[] ph_basis;
    delete[] pp_basis;
}


void Basis::establish_basis(int R) {

    // Get the maximal number of "M" and number of channels
    Mmax = (R-1)*2;
    lbd_dim = 6*Mmax + 3;
    
    // Establish the two-particle basis
    create_hh();
    create_pp();
    create_ph();
    
    // Get the boundaries of lambda
    lbd_lims = lbd_limits();

}


void Basis::create_hh() {

    int M, Ms; 
    ivec2 contr, channel;
    int lbd = 0;
    
    // Allocating space for each channel
    hh_basis = new std::vector<arma::ivec2>[lbd_dim];
      
   // Loop over all possible values of M
    for (int l = -Mmax; l <= Mmax; l++) {
        channel(0) = l;
        
        // Loop over all possible values of M_s
        for (channel(1) = -2; channel(1) <= 2; channel(1)+=2) {

            for (int i = 0; i < hole_states; i++) // i = hole
                for (int j = 0; j < i; j++) { // j = hole

                    M = singPart[i].qnumbers[1] + singPart[j].qnumbers[1];
                    Ms = singPart[i].qnumbers[2] + singPart[j].qnumbers[2];

                    // If channel is correct, add hole-hole combination
                    if (M == channel(0) && Ms == channel(1)) {
                        contr << i << j << endr;
                        hh_basis[lbd].push_back(contr);
                    }
                }
            lbd++;
        }
    }  
}


void Basis::create_pp() { 

    int M, Ms; 
    ivec2 contr, channel;
    int lbd = 0;
    
    // Allocating space for each channel
    pp_basis = new std::vector<arma::ivec2>[lbd_dim];
     
    // Loop over all possible values of M
    for (int l = -Mmax; l <= Mmax; l++) {
        channel(0) = l;
        
        // Loop over all possible values of M_s
        for (channel(1) = -2; channel(1) <= 2; channel(1)+=2) {

            for (int i = hole_states; i < sp_states; i++)  // i = particle
                for (int j = hole_states; j < i; j++) { // j = particle

                    M = singPart[i].qnumbers[1] + singPart[j].qnumbers[1];
                    Ms = singPart[i].qnumbers[2] + singPart[j].qnumbers[2];

                    // If channel is correct, add particle-particle combination
                    if (M == channel(0) && Ms == channel(1)) {
                        contr << i << j << endr;
                        pp_basis[lbd].push_back(contr);
                    }
                }            
            lbd++;
        }
    }
}


void Basis::create_ph() { 

    int M, Ms; 
    ivec2 contr, channel;
    int lbd = 0;
    
    // Allocating space for each channel
    ph_basis = new std::vector<arma::ivec2>[lbd_dim];
     
    // Loop over all possible values of M
    for (int l = -Mmax; l <= Mmax; l++) {
        channel(0) = l;
        
        // Loop over all possible values of M_s
        for (channel(1) = -2; channel(1) <= 2; channel(1)+=2) {

            for (int i = hole_states; i < sp_states; i++)  // i = particle
                for (int j = 0; j < hole_states; j++) {  // j = hole

                    M = singPart[i].qnumbers[1] + singPart[j].qnumbers[1];
                    Ms = singPart[i].qnumbers[2] + singPart[j].qnumbers[2];

                    // If channel is correct, add particle-hole combination
                    if (M == channel(0) && Ms == channel(1)) {
                        contr << i << j << endr;
                        ph_basis[lbd].push_back(contr);
                    }
                }           
            lbd++;
        }
    }
}


int Basis::map_ph(int p, int h, int lbd){ 
    
    for(int i = 0; i< ph_basis[lbd].size(); i++)
        if( (p == ph_basis[lbd][i](0)) && (h == ph_basis[lbd][i](1))){
            return i;
        }
    
    return -1;
    
}


int Basis::map_pp(int p1, int p2, int lbd){
  
    int tmp;
    
    // Bring indices into right order
    if(p1 < p2){
        tmp = p1;
        p1 = p2;
        p2 = tmp;
    }
    
    for(int i = 0; i< pp_basis[lbd].size(); i++)
        if( (p1 == pp_basis[lbd][i](0)) && (p2  == pp_basis[lbd][i](1))){
            return i;
        }
    
    return -1;
    
}


int Basis::map_hh(int h1, int h2, int lbd){ 
    
    int tmp;
    
    // Bring indices into right order
    if(h1 < h2){
        tmp = h1;
        h1 = h2;
        h2 = tmp;
    }

    for(int i = 0; i< hh_basis[lbd].size(); i++)
        if( (h1 == hh_basis[lbd][i](0)) && (h2 == hh_basis[lbd][i](1))){
            return i;
        }
    
    return -1;
    
}


imat Basis::lbd_limits(){
    
    int lbd = 0;
    imat mat_ret(3,2);
    
    // Lower bound hh_basis
    lbd = 0;    
    while(hh_basis[lbd].size() == 0)
        lbd++;   
    mat_ret(0,0) = lbd;
    
    // Lower bound ph_basis
    lbd = 0;
    while(ph_basis[lbd].size() == 0)
        lbd++;   
    mat_ret(1,0) = lbd;
    
    // Lower bound pp_basis
    lbd = 0;  
    while(pp_basis[lbd].size() == 0)
        lbd++;
    mat_ret(2,0) = lbd;
    
    // Upper bound hh_basis
    lbd = lbd_dim-1;
    while(hh_basis[lbd].size() == 0)
        lbd--; 
    mat_ret(0,1) = lbd;
    
    // Upper bound ph_basis
    lbd = lbd_dim-1;
    while(ph_basis[lbd].size() == 0)
        lbd--; 
    mat_ret(1,1) = lbd;
    
    // Upper bound pp_basis
    lbd = lbd_dim-1; 
    while(pp_basis[lbd].size() == 0)
        lbd--;  
    mat_ret(2,1) = lbd;
    
    return mat_ret;
         
}


int Basis::get_lbd(int M, int Ms){ 
    
    return (M+Mmax)*3+(Ms/2)+1; // Note: in our case Ms/2= {-1,0,1} 
    
}

