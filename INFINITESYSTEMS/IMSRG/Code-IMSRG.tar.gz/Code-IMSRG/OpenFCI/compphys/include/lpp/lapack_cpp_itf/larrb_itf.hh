#ifndef __PROJECT__LPP__FILE__LARRB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARRB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larrb_itf.hh C++ interface to LAPACK (s,d,c,z)larrb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larrb_itf.hh
    (excerpt adapted from xlarrb.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  given the relatively robust representation(rrr) l d l^t, xlarrb
    **  does ``limited'' bisection to locate the eigenvalues of l d l^t,
    **  w( ifirst ) thru' w( ilast ), to more accuracy. intervals
    **  [left, right] are maintained by storing their mid-points and
    **  semi-widths in the arrays w and werr respectively.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d.
    **
    **  l       (input) BASE DATA TYPE array, dimension (n-1)
    **          the n-1 subdiagonal elements of the unit bidiagonal matrix l.
    **
    **  ld      (input) BASE DATA TYPE array, dimension (n-1)
    **          the n-1 elements l(i)*d(i).
    **
    **  lld     (input) BASE DATA TYPE array, dimension (n-1)
    **          the n-1 elements l(i)*l(i)*d(i).
    **
    **  ifirst  (input) long int
    **          the index of the first eigenvalue in the cluster.
    **
    **  ilast   (input) long int
    **          the index of the last eigenvalue in the cluster.
    **
    **  sigma   (input) BASE DATA TYPE
    **          the shift used to form l d l^t (see dlarrf).
    **
    **  reltol  (input) BASE DATA TYPE
    **          the relative tolerance.
    **
    **  w       (input/output) BASE DATA TYPE array, dimension (n)
    **          on input, w( ifirst ) thru' w( ilast ) are estimates of the
    **          corresponding eigenvalues of l d l^t.
    **          on output, these estimates are ``refined''.
    **
    **  wgap    (input/output) BASE DATA TYPE array, dimension (n)
    **          the gaps between the eigenvalues of l d l^t. very small
    **          gaps are changed on output.
    **
    **  werr    (input/output) BASE DATA TYPE array, dimension (n)
    **          on input, werr( ifirst ) thru' werr( ilast ) are the errors
    **          in the estimates w( ifirst ) thru' w( ilast ).
    **          on output, these are the ``refined'' errors.
    **
    ******reminder to inder --- info is never set in this subroutine ******
    **  info    (output) long int
    **          error flag.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larrb(
        const long int* n,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const long int* ifirst,
        const long int* ilast,
        const float* sigma,
        const float* reltol,
        float* ws,
        float* wgap,
        float* werr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void larrb(
        const long int* n,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const long int* ifirst,
        const long int* ilast,
        const float* sigma,
        const float* reltol,
        float* ws,
        float* wgap,
        float* werr,
        long int* info)
  */
  /*! fn
   inline void larrb(
        const long int* n,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const long int* ifirst,
        const long int* ilast,
        const double* sigma,
        const double* reltol,
        double* ws,
        double* wgap,
        double* werr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void larrb(
        const long int* n,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const long int* ifirst,
        const long int* ilast,
        const double* sigma,
        const double* reltol,
        double* ws,
        double* wgap,
        double* werr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarrb.f)
  //     ******reminder to inder --- WORK is never used in this subroutine *****
  //     **  WORK    (input) BASE DATA TYPE array, dimension (???)
  //     **          WORKspace.
  //     **
  //     **  IWORK   (input) long int array, dimension (2*n)
  //     **          WORKspace.
  //     **
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARRB(NAME, T)\
inline void larrb(\
    const long int* n,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const long int* ifirst,\
    const long int* ilast,\
    const T* sigma,\
    const T* reltol,\
    T* ws,\
    T* wgap,\
    T* werr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(2**n);\
    F77NAME( NAME )(n, d, l, ld, lld, ifirst, ilast, sigma, reltol, ws, wgap, werr, w.getw(), w.getiw(), info);\
}\
inline void larrb(\
    const long int* n,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const long int* ifirst,\
    const long int* ilast,\
    const T* sigma,\
    const T* reltol,\
    T* ws,\
    T* wgap,\
    T* werr,\
    long int* info)\
{\
   workspace<T> w;\
   larrb(n, d, l, ld, lld, ifirst, ilast, sigma, reltol, ws, wgap, werr, info, w);\
}\

    LPP_LARRB(slarrb, float)
    LPP_LARRB(dlarrb, double)

#undef LPP_LARRB



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larrb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
