#ifndef __PROJECT__LPP__FILE__HSEQR_HH__INCLUDED
#define __PROJECT__LPP__FILE__HSEQR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hseqr_itf.hh C++ interface to LAPACK (c,d,c,z)hseqr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hseqr_itf.hh
    (excerpt adapted from xhseqr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhseqr computes the eigenvalues of a DATA TYPE upper hessenberg
    **  matrix h, and, optionally, the matrices t and z from the schur
    **  decomposition h = z t z**h, where t is an upper triangular matrix
    **  (the schur form), and z is the unitary matrix of schur vectors.
    **
    **  optionally z may be postmultiplied into an input unitary matrix q,
    **  so that this routine can give the schur factorization of a matrix a
    **  which has been reduced to the hessenberg form h by the unitary
    **  matrix q:  a = q*h*q**h = (qz)*t*(qz)**h.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          = 'e': compute eigenvalues only;
    **          = 's': compute eigenvalues and the schur form t.
    **
    **  compz   (input) char
    **          = 'n': no schur vectors are computed;
    **          = 'i': z is initialized to the unit matrix and the matrix z
    **                 of schur vectors of h is returned;
    **          = 'v': z must contain an unitary matrix q on entry, and
    **                 the product q*z is returned.
    **
    **  n       (input) long int
    **          the order of the matrix h.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          it is assumed that h is already upper triangular in rows
    **          and columns 1:ilo-1 and ihi+1:n. ilo and ihi are normally
    **          set by a previous call to cgebal, and then passed to cgehrd
    **          when the matrix output by cgebal is reduced to hessenberg
    **          form. otherwise ilo and ihi should be set to 1 and n
    **          respectively.
    **          1 <= ilo <= ihi <= n, if n > 0; ilo=1 and ihi=0, if n=0.
    **
    **  h       (input/output) DATA TYPE array, dimension (ldh,n)
    **          on entry, the upper hessenberg matrix h.
    **          on exit, if job = 's', h contains the upper triangular matrix
    **          t from the schur decomposition (the schur form). if
    **          job = 'e', the contents of h are unspecified on exit.
    **
    **  ldh     (input) long int
    **          the leading dimension of the array h. ldh >= max(1,n).
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          the computed eigenvalues. if job = 's', the eigenvalues are
    **          stored in the same order as on the diagonal of the schur form
    **          returned in h, with w(i) = h(i,i).
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          if compz = 'n': z is not referenced.
    **          if compz = 'i': on entry, z need not be set, and on exit, z
    **          contains the unitary matrix z of the schur vectors of h.
    **          if compz = 'v': on entry z must contain an n-by-n matrix q,
    **          which is assumed to be equal to the unit matrix except for
    **          the submatrix z(ilo:ihi,ilo:ihi); on exit z contains q*z.
    **          normally q is the unitary matrix generated by cunghr after
    **          the call to cgehrd which formed the hessenberg matrix h.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.
    **          ldz >= max(1,n) if compz = 'i' or 'v'; ldz >= 1 otherwise.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, xhseqr failed to compute all the
    **                eigenvalues in a total of 30*(ihi-ilo+1) iterations;
    **                elements 1:ilo-1 and i+1:n of w contain those
    **                eigenvalues which have been successfully computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hseqr(
        const char* job,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* wr,
        float* wi,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void hseqr(
        const char* job,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* wr,
        float* wi,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void hseqr(
        const char* job,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* wr,
        double* wi,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void hseqr(
        const char* job,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* wr,
        double* wi,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from shseqr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,N).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HSEQR(NAME, T)\
inline void hseqr(\
    const char* job,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    T* wi,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, compz, n, ilo, ihi, h, ldh, wr, wi, z, ldz, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compz, n, ilo, ihi, h, ldh, wr, wi, z, ldz, w.getw(), &w.neededsize(), info);\
}\
inline void hseqr(\
    const char* job,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    T* wi,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   hseqr(job, compz, n, ilo, ihi, h, ldh, wr, wi, z, ldz, info, w);\
}\

    LPP_HSEQR(shseqr, float)
    LPP_HSEQR(dhseqr, double)

#undef LPP_HSEQR


  // The following macro provides the 4 functions 
  /*! fn
   inline void hseqr(
       const char* job,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* ws,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hseqr(
       const char* job,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* ws,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void hseqr(
       const char* job,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* ws,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hseqr(
       const char* job,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* ws,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chseqr.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,N).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HSEQR(NAME, T, TBASE)\
inline void hseqr(\
    const char* job,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, compz, n, ilo, ihi, h, ldh, ws, z, ldz, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compz, n, ilo, ihi, h, ldh, ws, z, ldz, w.getw(), &w.neededsize(), info);\
}\
inline void hseqr(\
    const char* job,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   hseqr(job, compz, n, ilo, ihi, h, ldh, ws, z, ldz, info, w);\
}\

    LPP_HSEQR(chseqr, std::complex<float>,  float)
    LPP_HSEQR(zhseqr, std::complex<double>, double)

#undef LPP_HSEQR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hseqr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
