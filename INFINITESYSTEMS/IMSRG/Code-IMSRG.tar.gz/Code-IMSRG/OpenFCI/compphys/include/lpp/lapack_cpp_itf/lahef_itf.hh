#ifndef __PROJECT__LPP__FILE__LAHEF_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAHEF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lahef_itf.hh C++ interface to LAPACK (c,d,c,z)lahef
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lahef_itf.hh
    (excerpt adapted from xlahef.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlahef computes a partial factorization of a DATA TYPE hermitian
    **  matrix a using the bunch-kaufman diagonal pivoting method. the
    **  partial factorization has the form:
    **
    **  a  =  ( i  u12 ) ( a11  0  ) (  i    0   )  if uplo = 'u', or:
    **        ( 0  u22 ) (  0   d  ) ( u12' u22' )
    **
    **  a  =  ( l11  0 ) (  d   0  ) ( l11' l21' )  if uplo = 'l'
    **        ( l21  i ) (  0  a22 ) (  0    i   )
    **
    **  where the order of d is at most nb. the actual order is returned in
    **  the argument kb, and is either nb or nb-1, or n if n <= nb.
    **  note that u' denotes the conjugate transpose of u.
    **
    **  xlahef is an auxiliary routine called by chetrf. it uses blocked code
    **  (calling level 3 blas) to update the submatrix a11 (if uplo = 'u') or
    **  a22 (if uplo = 'l').
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is stored:
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nb      (input) long int
    **          the maximum number of columns of the matrix a that should be
    **          factored.  nb should be at least 2 to allow for 2-by-2 pivot
    **          blocks.
    **
    **  kb      (output) long int
    **          the number of columns of a that were actually factored.
    **          kb is either nb-1 or nb, or n if n <= nb.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **          on exit, a contains details of the partial factorization.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  ipiv    (output) long int array, dimension (n)
    **          details of the interchanges and the block structure of d.
    **          if uplo = 'u', only the last kb elements of ipiv are set;
    **          if uplo = 'l', only the first kb elements are set.
    **
    **          if ipiv(k) > 0, then rows and columns k and ipiv(k) were
    **          interchanged and d(k,k) is a 1-by-1 diagonal block.
    **          if uplo = 'u' and ipiv(k) = ipiv(k-1) < 0, then rows and
    **          columns k-1 and -ipiv(k) were interchanged and d(k-1:k,k-1:k)
    **          is a 2-by-2 diagonal block.  if uplo = 'l' and ipiv(k) =
    **          ipiv(k+1) < 0, then rows and columns k+1 and -ipiv(k) were
    **          interchanged and d(k:k+1,k:k+1) is a 2-by-2 diagonal block.
    **
    **
    **  ldw     (input) long int
    **          the leading dimension of the array w.  ldw >= max(1,n).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          > 0: if info = k, d(k,k) is exactly zero.  the factorization
    **               has been completed, but the block diagonal matrix d is
    **               exactly singular.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lahef(
       const char* uplo,
       const long int* n,
       const long int* nb,
       long int* kb,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<float>* ws,
       const long int* ldw,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lahef(
       const char* uplo,
       const long int* n,
       const long int* nb,
       long int* kb,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<float>* ws,
       const long int* ldw,
       long int* info)
  */
  /*! fn
   inline void lahef(
       const char* uplo,
       const long int* n,
       const long int* nb,
       long int* kb,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<double>* ws,
       const long int* ldw,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lahef(
       const char* uplo,
       const long int* n,
       const long int* nb,
       long int* kb,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<double>* ws,
       const long int* ldw,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clahef.f)
  //    *  W       (workspace) std::complex<float> array, dimension (LDW,NB)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAHEF(NAME, T, TBASE)\
inline void lahef(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* ws,\
    const long int* ldw,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nb, kb, a, lda, ipiv, ws, ldw, info);\
}\
inline void lahef(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* ws,\
    const long int* ldw,\
    long int* info)\
{\
   workspace<T> w;\
   lahef(uplo, n, nb, kb, a, lda, ipiv, ws, ldw, info, w);\
}\

    LPP_LAHEF(clahef, std::complex<float>,  float)
    LPP_LAHEF(zlahef, std::complex<double>, double)

#undef LPP_LAHEF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lahef_itf.hh
// /////////////////////////////////////////////////////////////////////////////
