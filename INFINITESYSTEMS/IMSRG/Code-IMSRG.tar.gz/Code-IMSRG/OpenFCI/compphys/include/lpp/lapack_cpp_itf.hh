#ifndef __PROJECT__LPP__MON_JAN_16_10_29_29_2006__FILE__LAPACK_CPP_ITF_HH__INCLUDED
#define __PROJECT__LPP__MON_JAN_16_10_29_29_2006__FILE__LAPACK_CPP_ITF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2006 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lapack_cpp_itf.hh                                      
//  who         : contributed by Joel FALCOU and Jean-Thierry LAPRESTE 
//  when        : Mon Jan 16 10:29:29 2006                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
#include <string>

// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////

namespace lpp
{
  ////////////////////////////////////////////////////////////////////////////
  // utility
  ////////////////////////////////////////////////////////////////////////////
  inline int EnvBlockSize(int ispec,
                   const std::string & fname,
                   const std::string & opts,
                   int n1 = -1, 
                   int n2 = -1,
                   int n3 = -1,
                   int n4 = -1)
  {
    int i = ispec;
    int N1 = n1;
    int N2 = n2;
    int N3 = n3;
    int N4 = n4; 
    return F77NAME(ilaenv)(&i, fname.c_str(), opts.c_str(), &N1, &N2, &N3, &N4,
                           fname.size(), opts.size());
  }
}

// /////////////////////////////////////////////////////////////////////////////
//  End of lpp namespace
// /////////////////////////////////////////////////////////////////////////////

#include "lapackworkspace.hh"

////////////////////////////////////////////////////////////////
// csrot  rotation plane � deux vecteurs complexes ??
// zdrot  rotation plane � deux vecteurs complexes ??
// csrscl multiplication vecteur 1/a,  inutile
// zdrscl multiplication vecteur 1/a,  inutile
// xerbla gestion d'erreurs
// second temps en seconde,  inutile
// ladiv  � faire
////////////////////////////////////////////////////////////////
// interfacer lamch avec les constantes
////////////////////////////////////////////////////////////////

namespace lpp
{
  inline char lower(const char c){
    return (c >= 'A' && c <= 'Z') ? c +('a'-'A') : c; 
  }
  inline char upper(const char c){
    return (c >= 'a' && c <= 'z') ? c -('a'-'A') : c; 
  }

}

#include "lapack_cpp_itf/bdsdc_itf.hh"
#include "lapack_cpp_itf/bdsqr_itf.hh"
#include "lapack_cpp_itf/disna_itf.hh"
#include "lapack_cpp_itf/gbbrd_itf.hh"
#include "lapack_cpp_itf/gbcon_itf.hh"
#include "lapack_cpp_itf/gbequ_itf.hh"
#include "lapack_cpp_itf/gbrfs_itf.hh"
#include "lapack_cpp_itf/gbsv_itf.hh"
#include "lapack_cpp_itf/gbsvx_itf.hh"
#include "lapack_cpp_itf/gbtf2_itf.hh"
#include "lapack_cpp_itf/gbtrf_itf.hh"
#include "lapack_cpp_itf/gbtrs_itf.hh"
#include "lapack_cpp_itf/gebak_itf.hh"
#include "lapack_cpp_itf/gebal_itf.hh"
#include "lapack_cpp_itf/gebd2_itf.hh"
#include "lapack_cpp_itf/gebrd_itf.hh"
#include "lapack_cpp_itf/gecon_itf.hh"
#include "lapack_cpp_itf/geequ_itf.hh"
#include "lapack_cpp_itf/gees_itf.hh"
#include "lapack_cpp_itf/geesx_itf.hh"
#include "lapack_cpp_itf/geev_itf.hh"
#include "lapack_cpp_itf/geevx_itf.hh"
#include "lapack_cpp_itf/gegs_itf.hh"
#include "lapack_cpp_itf/gegv_itf.hh"
#include "lapack_cpp_itf/gehd2_itf.hh"
#include "lapack_cpp_itf/gehrd_itf.hh"
#include "lapack_cpp_itf/gelq2_itf.hh"
#include "lapack_cpp_itf/gelqf_itf.hh"
#include "lapack_cpp_itf/gelsd_itf.hh"
#include "lapack_cpp_itf/gels_itf.hh"
#include "lapack_cpp_itf/gelss_itf.hh"
#include "lapack_cpp_itf/gelsx_itf.hh"
#include "lapack_cpp_itf/gelsy_itf.hh"
#include "lapack_cpp_itf/geql2_itf.hh"
#include "lapack_cpp_itf/geqlf_itf.hh"
#include "lapack_cpp_itf/geqp3_itf.hh"
#include "lapack_cpp_itf/geqpf_itf.hh"
#include "lapack_cpp_itf/geqr2_itf.hh"
#include "lapack_cpp_itf/geqrf_itf.hh"
#include "lapack_cpp_itf/gerfs_itf.hh"
#include "lapack_cpp_itf/gerq2_itf.hh"
#include "lapack_cpp_itf/gerqf_itf.hh"
#include "lapack_cpp_itf/gesc2_itf.hh"
#include "lapack_cpp_itf/gesdd_itf.hh"
#include "lapack_cpp_itf/gesvd_itf.hh"
#include "lapack_cpp_itf/gesv_itf.hh"
#include "lapack_cpp_itf/gesvx_itf.hh"
#include "lapack_cpp_itf/getc2_itf.hh"
#include "lapack_cpp_itf/getf2_itf.hh"
#include "lapack_cpp_itf/getrf_itf.hh"
#include "lapack_cpp_itf/getri_itf.hh"
#include "lapack_cpp_itf/getrs_itf.hh"
#include "lapack_cpp_itf/ggbak_itf.hh"
#include "lapack_cpp_itf/ggbal_itf.hh"
#include "lapack_cpp_itf/gges_itf.hh"
#include "lapack_cpp_itf/ggesx_itf.hh"
#include "lapack_cpp_itf/ggev_itf.hh"
#include "lapack_cpp_itf/ggevx_itf.hh"
#include "lapack_cpp_itf/ggglm_itf.hh"
#include "lapack_cpp_itf/gghrd_itf.hh"
#include "lapack_cpp_itf/gglse_itf.hh"
#include "lapack_cpp_itf/ggqrf_itf.hh"
#include "lapack_cpp_itf/ggrqf_itf.hh"
#include "lapack_cpp_itf/ggsvd_itf.hh"
#include "lapack_cpp_itf/gtcon_itf.hh"
#include "lapack_cpp_itf/gtrfs_itf.hh"
#include "lapack_cpp_itf/gtsv_itf.hh"
#include "lapack_cpp_itf/gtsvx_itf.hh"
#include "lapack_cpp_itf/gttrf_itf.hh"
#include "lapack_cpp_itf/gttrs_itf.hh"
#include "lapack_cpp_itf/gtts2_itf.hh"
#include "lapack_cpp_itf/hbevd_itf.hh"
#include "lapack_cpp_itf/hbev_itf.hh"
#include "lapack_cpp_itf/hbevx_itf.hh"
#include "lapack_cpp_itf/hbgst_itf.hh"
#include "lapack_cpp_itf/hbgvd_itf.hh"
#include "lapack_cpp_itf/hbgv_itf.hh"
#include "lapack_cpp_itf/hbgvx_itf.hh"
#include "lapack_cpp_itf/hbtrd_itf.hh"
#include "lapack_cpp_itf/hecon_itf.hh"
#include "lapack_cpp_itf/heevd_itf.hh"
#include "lapack_cpp_itf/heev_itf.hh"
#include "lapack_cpp_itf/heevr_itf.hh"
#include "lapack_cpp_itf/heevx_itf.hh"
#include "lapack_cpp_itf/hegs2_itf.hh"
#include "lapack_cpp_itf/hegst_itf.hh"
#include "lapack_cpp_itf/hegvd_itf.hh"
#include "lapack_cpp_itf/hegv_itf.hh"
#include "lapack_cpp_itf/hegvx_itf.hh"
#include "lapack_cpp_itf/herfs_itf.hh"
#include "lapack_cpp_itf/hesv_itf.hh"
#include "lapack_cpp_itf/hesvx_itf.hh"
#include "lapack_cpp_itf/hetd2_itf.hh"
#include "lapack_cpp_itf/hetf2_itf.hh"
#include "lapack_cpp_itf/hetrd_itf.hh"
#include "lapack_cpp_itf/hetrf_itf.hh"
#include "lapack_cpp_itf/hetri_itf.hh"
#include "lapack_cpp_itf/hetrs_itf.hh"
#include "lapack_cpp_itf/hgeqz_itf.hh"
#include "lapack_cpp_itf/hpcon_itf.hh"
#include "lapack_cpp_itf/hpevd_itf.hh"
#include "lapack_cpp_itf/hpev_itf.hh"
#include "lapack_cpp_itf/hpevx_itf.hh"
#include "lapack_cpp_itf/hpgst_itf.hh"
#include "lapack_cpp_itf/hpgvd_itf.hh"
#include "lapack_cpp_itf/hpgv_itf.hh"
#include "lapack_cpp_itf/hpgvx_itf.hh"
#include "lapack_cpp_itf/hprfs_itf.hh"
#include "lapack_cpp_itf/hpsv_itf.hh"
#include "lapack_cpp_itf/hpsvx_itf.hh"
#include "lapack_cpp_itf/hptrd_itf.hh"
#include "lapack_cpp_itf/hptrf_itf.hh"
#include "lapack_cpp_itf/hptri_itf.hh"
#include "lapack_cpp_itf/hptrs_itf.hh"
#include "lapack_cpp_itf/hsein_itf.hh"
#include "lapack_cpp_itf/hseqr_itf.hh"
#include "lapack_cpp_itf/labad_itf.hh"
#include "lapack_cpp_itf/labrd_itf.hh"
#include "lapack_cpp_itf/lacgv_itf.hh"
#include "lapack_cpp_itf/lacon_itf.hh"
#include "lapack_cpp_itf/lacp2_itf.hh"
#include "lapack_cpp_itf/lacpy_itf.hh"
#include "lapack_cpp_itf/lacrm_itf.hh"
#include "lapack_cpp_itf/lacrt_itf.hh"
#include "lapack_cpp_itf/ladiv_itf.hh"
#include "lapack_cpp_itf/lae2_itf.hh"
#include "lapack_cpp_itf/laebz_itf.hh"
#include "lapack_cpp_itf/laed0_itf.hh"
#include "lapack_cpp_itf/laed1_itf.hh"
#include "lapack_cpp_itf/laed2_itf.hh"
#include "lapack_cpp_itf/laed3_itf.hh"
#include "lapack_cpp_itf/laed4_itf.hh"
#include "lapack_cpp_itf/laed5_itf.hh"
#include "lapack_cpp_itf/laed6_itf.hh"
#include "lapack_cpp_itf/laed7_itf.hh"
#include "lapack_cpp_itf/laed8_itf.hh"
#include "lapack_cpp_itf/laed9_itf.hh"
#include "lapack_cpp_itf/laeda_itf.hh"
#include "lapack_cpp_itf/laein_itf.hh"
#include "lapack_cpp_itf/laesy_itf.hh"
#include "lapack_cpp_itf/laev2_itf.hh"
#include "lapack_cpp_itf/laexc_itf.hh"
#include "lapack_cpp_itf/lag2_itf.hh"
#include "lapack_cpp_itf/lags2_itf.hh"
#include "lapack_cpp_itf/lagtf_itf.hh"
#include "lapack_cpp_itf/lagtm_itf.hh"
#include "lapack_cpp_itf/lagts_itf.hh"
#include "lapack_cpp_itf/lagv2_itf.hh"
#include "lapack_cpp_itf/lahef_itf.hh"
#include "lapack_cpp_itf/lahqr_itf.hh"
#include "lapack_cpp_itf/lahrd_itf.hh"
#include "lapack_cpp_itf/laic1_itf.hh"
#include "lapack_cpp_itf/laln2_itf.hh"
#include "lapack_cpp_itf/lals0_itf.hh"
#include "lapack_cpp_itf/lalsa_itf.hh"
#include "lapack_cpp_itf/lalsd_itf.hh"
#include "lapack_cpp_itf/lamrg_itf.hh"
#include "lapack_cpp_itf/lanv2_itf.hh"
#include "lapack_cpp_itf/lapll_itf.hh"
#include "lapack_cpp_itf/lapmt_itf.hh"
#include "lapack_cpp_itf/laqgb_itf.hh"
#include "lapack_cpp_itf/laqge_itf.hh"
#include "lapack_cpp_itf/laqhb_itf.hh"
#include "lapack_cpp_itf/laqhe_itf.hh"
#include "lapack_cpp_itf/laqhp_itf.hh"
#include "lapack_cpp_itf/laqp2_itf.hh"
#include "lapack_cpp_itf/laqps_itf.hh"
#include "lapack_cpp_itf/laqsb_itf.hh"
#include "lapack_cpp_itf/laqsp_itf.hh"
#include "lapack_cpp_itf/laqsy_itf.hh"
#include "lapack_cpp_itf/laqtr_itf.hh"
#include "lapack_cpp_itf/lar1v_itf.hh"
#include "lapack_cpp_itf/lar2v_itf.hh"
#include "lapack_cpp_itf/larcm_itf.hh"
#include "lapack_cpp_itf/larfb_itf.hh"
#include "lapack_cpp_itf/larfg_itf.hh"
#include "lapack_cpp_itf/larf_itf.hh"
#include "lapack_cpp_itf/larft_itf.hh"
#include "lapack_cpp_itf/larfx_itf.hh"
#include "lapack_cpp_itf/largv_itf.hh"
#include "lapack_cpp_itf/larnv_itf.hh"
#include "lapack_cpp_itf/larrb_itf.hh"
#include "lapack_cpp_itf/larre_itf.hh"
#include "lapack_cpp_itf/larrf_itf.hh"
#include "lapack_cpp_itf/larrv_itf.hh"
#include "lapack_cpp_itf/lartg_itf.hh"
#include "lapack_cpp_itf/lartv_itf.hh"
#include "lapack_cpp_itf/laruv_itf.hh"
#include "lapack_cpp_itf/larzb_itf.hh"
#include "lapack_cpp_itf/larz_itf.hh"
#include "lapack_cpp_itf/larzt_itf.hh"
#include "lapack_cpp_itf/las2_itf.hh"
#include "lapack_cpp_itf/lascl_itf.hh"
#include "lapack_cpp_itf/lasd0_itf.hh"
#include "lapack_cpp_itf/lasd1_itf.hh"
#include "lapack_cpp_itf/lasd2_itf.hh"
#include "lapack_cpp_itf/lasd3_itf.hh"
#include "lapack_cpp_itf/lasd4_itf.hh"
#include "lapack_cpp_itf/lasd5_itf.hh"
#include "lapack_cpp_itf/lasd6_itf.hh"
#include "lapack_cpp_itf/lasd7_itf.hh"
#include "lapack_cpp_itf/lasd8_itf.hh"
#include "lapack_cpp_itf/lasd9_itf.hh"
#include "lapack_cpp_itf/lasda_itf.hh"
#include "lapack_cpp_itf/lasdq_itf.hh"
#include "lapack_cpp_itf/lasdt_itf.hh"
#include "lapack_cpp_itf/laset_itf.hh"
#include "lapack_cpp_itf/lasq1_itf.hh"
#include "lapack_cpp_itf/lasq2_itf.hh"
#include "lapack_cpp_itf/lasq3_itf.hh"
#include "lapack_cpp_itf/lasq4_itf.hh"
#include "lapack_cpp_itf/lasq5_itf.hh"
#include "lapack_cpp_itf/lasq6_itf.hh"
#include "lapack_cpp_itf/lasr_itf.hh"
#include "lapack_cpp_itf/lasrt_itf.hh"
#include "lapack_cpp_itf/lassq_itf.hh"
#include "lapack_cpp_itf/lasv2_itf.hh"
#include "lapack_cpp_itf/laswp_itf.hh"
#include "lapack_cpp_itf/lasy2_itf.hh"
#include "lapack_cpp_itf/lasyf_itf.hh"
#include "lapack_cpp_itf/latbs_itf.hh"
#include "lapack_cpp_itf/latdf_itf.hh"
#include "lapack_cpp_itf/latps_itf.hh"
#include "lapack_cpp_itf/latrd_itf.hh"
#include "lapack_cpp_itf/latrs_itf.hh"
#include "lapack_cpp_itf/latrz_itf.hh"
#include "lapack_cpp_itf/latzm_itf.hh"
#include "lapack_cpp_itf/lauu2_itf.hh"
#include "lapack_cpp_itf/lauum_itf.hh"
#include "lapack_cpp_itf/opgtr_itf.hh"
#include "lapack_cpp_itf/opmtr_itf.hh"
#include "lapack_cpp_itf/org2l_itf.hh"
#include "lapack_cpp_itf/org2r_itf.hh"
#include "lapack_cpp_itf/orgbr_itf.hh"
#include "lapack_cpp_itf/orghr_itf.hh"
#include "lapack_cpp_itf/orgl2_itf.hh"
#include "lapack_cpp_itf/orglq_itf.hh"
#include "lapack_cpp_itf/orgql_itf.hh"
#include "lapack_cpp_itf/orgqr_itf.hh"
#include "lapack_cpp_itf/orgr2_itf.hh"
#include "lapack_cpp_itf/orgrq_itf.hh"
#include "lapack_cpp_itf/orgtr_itf.hh"
#include "lapack_cpp_itf/orm2l_itf.hh"
#include "lapack_cpp_itf/orm2r_itf.hh"
#include "lapack_cpp_itf/ormbr_itf.hh"
#include "lapack_cpp_itf/ormhr_itf.hh"
#include "lapack_cpp_itf/orml2_itf.hh"
#include "lapack_cpp_itf/ormlq_itf.hh"
#include "lapack_cpp_itf/ormql_itf.hh"
#include "lapack_cpp_itf/ormqr_itf.hh"
#include "lapack_cpp_itf/ormr2_itf.hh"
#include "lapack_cpp_itf/ormr3_itf.hh"
#include "lapack_cpp_itf/ormrq_itf.hh"
#include "lapack_cpp_itf/ormrz_itf.hh"
#include "lapack_cpp_itf/ormtr_itf.hh"
#include "lapack_cpp_itf/pbcon_itf.hh"
#include "lapack_cpp_itf/pbequ_itf.hh"
#include "lapack_cpp_itf/pbrfs_itf.hh"
#include "lapack_cpp_itf/pbstf_itf.hh"
#include "lapack_cpp_itf/pbsv_itf.hh"
#include "lapack_cpp_itf/pbsvx_itf.hh"
#include "lapack_cpp_itf/pbtf2_itf.hh"
#include "lapack_cpp_itf/pbtrf_itf.hh"
#include "lapack_cpp_itf/pbtrs_itf.hh"
#include "lapack_cpp_itf/pocon_itf.hh"
#include "lapack_cpp_itf/poequ_itf.hh"
#include "lapack_cpp_itf/porfs_itf.hh"
#include "lapack_cpp_itf/posv_itf.hh"
#include "lapack_cpp_itf/posvx_itf.hh"
#include "lapack_cpp_itf/potf2_itf.hh"
#include "lapack_cpp_itf/potrf_itf.hh"
#include "lapack_cpp_itf/potri_itf.hh"
#include "lapack_cpp_itf/potrs_itf.hh"
#include "lapack_cpp_itf/ppcon_itf.hh"
#include "lapack_cpp_itf/ppequ_itf.hh"
#include "lapack_cpp_itf/pprfs_itf.hh"
#include "lapack_cpp_itf/ppsv_itf.hh"
#include "lapack_cpp_itf/ppsvx_itf.hh"
#include "lapack_cpp_itf/pptrf_itf.hh"
#include "lapack_cpp_itf/pptri_itf.hh"
#include "lapack_cpp_itf/pptrs_itf.hh"
#include "lapack_cpp_itf/ptcon_itf.hh"
#include "lapack_cpp_itf/pteqr_itf.hh"
#include "lapack_cpp_itf/ptrfs_itf.hh"
#include "lapack_cpp_itf/ptsv_itf.hh"
#include "lapack_cpp_itf/ptsvx_itf.hh"
#include "lapack_cpp_itf/pttrf_itf.hh"
#include "lapack_cpp_itf/pttrs_itf.hh"
#include "lapack_cpp_itf/ptts2_itf.hh"
#include "lapack_cpp_itf/rot_itf.hh"
#include "lapack_cpp_itf/rscl_itf.hh"
#include "lapack_cpp_itf/sbevd_itf.hh"
#include "lapack_cpp_itf/sbev_itf.hh"
#include "lapack_cpp_itf/sbevx_itf.hh"
#include "lapack_cpp_itf/sbgst_itf.hh"
#include "lapack_cpp_itf/sbgvd_itf.hh"
#include "lapack_cpp_itf/sbgv_itf.hh"
#include "lapack_cpp_itf/sbgvx_itf.hh"
#include "lapack_cpp_itf/sbtrd_itf.hh"
#include "lapack_cpp_itf/spcon_itf.hh"
#include "lapack_cpp_itf/spevd_itf.hh"
#include "lapack_cpp_itf/spev_itf.hh"
#include "lapack_cpp_itf/spevx_itf.hh"
#include "lapack_cpp_itf/spgst_itf.hh"
#include "lapack_cpp_itf/spgvd_itf.hh"
#include "lapack_cpp_itf/spgv_itf.hh"
#include "lapack_cpp_itf/spgvx_itf.hh"
#include "lapack_cpp_itf/spmv_itf.hh"
#include "lapack_cpp_itf/sprfs_itf.hh"
#include "lapack_cpp_itf/spr_itf.hh"
#include "lapack_cpp_itf/spsv_itf.hh"
#include "lapack_cpp_itf/spsvx_itf.hh"
#include "lapack_cpp_itf/sptrd_itf.hh"
#include "lapack_cpp_itf/sptrf_itf.hh"
#include "lapack_cpp_itf/sptri_itf.hh"
#include "lapack_cpp_itf/sptrs_itf.hh"
#include "lapack_cpp_itf/stebz_itf.hh"
#include "lapack_cpp_itf/stedc_itf.hh"
#include "lapack_cpp_itf/stegr_itf.hh"
#include "lapack_cpp_itf/stein_itf.hh"
#include "lapack_cpp_itf/steqr_itf.hh"
#include "lapack_cpp_itf/sterf_itf.hh"
#include "lapack_cpp_itf/stevd_itf.hh"
#include "lapack_cpp_itf/stev_itf.hh"
#include "lapack_cpp_itf/stevr_itf.hh"
#include "lapack_cpp_itf/stevx_itf.hh"
#include "lapack_cpp_itf/sycon_itf.hh"
#include "lapack_cpp_itf/syevd_itf.hh"
#include "lapack_cpp_itf/syev_itf.hh"
#include "lapack_cpp_itf/syevr_itf.hh"
#include "lapack_cpp_itf/syevx_itf.hh"
#include "lapack_cpp_itf/sygs2_itf.hh"
#include "lapack_cpp_itf/sygst_itf.hh"
#include "lapack_cpp_itf/sygvd_itf.hh"
#include "lapack_cpp_itf/sygv_itf.hh"
#include "lapack_cpp_itf/sygvx_itf.hh"
#include "lapack_cpp_itf/symv_itf.hh"
#include "lapack_cpp_itf/syrfs_itf.hh"
#include "lapack_cpp_itf/syr_itf.hh"
#include "lapack_cpp_itf/sysv_itf.hh"
#include "lapack_cpp_itf/sysvx_itf.hh"
#include "lapack_cpp_itf/sytd2_itf.hh"
#include "lapack_cpp_itf/sytf2_itf.hh"
#include "lapack_cpp_itf/sytrd_itf.hh"
#include "lapack_cpp_itf/sytrf_itf.hh"
#include "lapack_cpp_itf/sytri_itf.hh"
#include "lapack_cpp_itf/sytrs_itf.hh"
#include "lapack_cpp_itf/tbcon_itf.hh"
#include "lapack_cpp_itf/tbrfs_itf.hh"
#include "lapack_cpp_itf/tbtrs_itf.hh"
#include "lapack_cpp_itf/tgevc_itf.hh"
#include "lapack_cpp_itf/tgex2_itf.hh"
#include "lapack_cpp_itf/tgexc_itf.hh"
#include "lapack_cpp_itf/tgsen_itf.hh"
#include "lapack_cpp_itf/tgsja_itf.hh"
#include "lapack_cpp_itf/tgsna_itf.hh"
#include "lapack_cpp_itf/tgsy2_itf.hh"
#include "lapack_cpp_itf/tgsyl_itf.hh"
#include "lapack_cpp_itf/tpcon_itf.hh"
#include "lapack_cpp_itf/tprfs_itf.hh"
#include "lapack_cpp_itf/tptri_itf.hh"
#include "lapack_cpp_itf/tptrs_itf.hh"
#include "lapack_cpp_itf/trcon_itf.hh"
#include "lapack_cpp_itf/trevc_itf.hh"
#include "lapack_cpp_itf/trexc_itf.hh"
#include "lapack_cpp_itf/trrfs_itf.hh"
#include "lapack_cpp_itf/trsen_itf.hh"
#include "lapack_cpp_itf/trsna_itf.hh"
#include "lapack_cpp_itf/trsyl_itf.hh"
#include "lapack_cpp_itf/trti2_itf.hh"
#include "lapack_cpp_itf/trtri_itf.hh"
#include "lapack_cpp_itf/trtrs_itf.hh"
#include "lapack_cpp_itf/tzrqf_itf.hh"
#include "lapack_cpp_itf/tzrzf_itf.hh"
#include "lapack_cpp_itf/ung2l_itf.hh"
#include "lapack_cpp_itf/ung2r_itf.hh"
#include "lapack_cpp_itf/ungbr_itf.hh"
#include "lapack_cpp_itf/unghr_itf.hh"
#include "lapack_cpp_itf/ungl2_itf.hh"
#include "lapack_cpp_itf/unglq_itf.hh"
#include "lapack_cpp_itf/ungql_itf.hh"
#include "lapack_cpp_itf/ungqr_itf.hh"
#include "lapack_cpp_itf/ungr2_itf.hh"
#include "lapack_cpp_itf/ungrq_itf.hh"
#include "lapack_cpp_itf/ungtr_itf.hh"
#include "lapack_cpp_itf/unm2l_itf.hh"
#include "lapack_cpp_itf/unm2r_itf.hh"
#include "lapack_cpp_itf/unmbr_itf.hh"
#include "lapack_cpp_itf/unmhr_itf.hh"
#include "lapack_cpp_itf/unml2_itf.hh"
#include "lapack_cpp_itf/unmlq_itf.hh"
#include "lapack_cpp_itf/unmql_itf.hh"
#include "lapack_cpp_itf/unmqr_itf.hh"
#include "lapack_cpp_itf/unmr2_itf.hh"
#include "lapack_cpp_itf/unmr3_itf.hh"
#include "lapack_cpp_itf/unmrq_itf.hh"
#include "lapack_cpp_itf/unmrz_itf.hh"
#include "lapack_cpp_itf/unmtr_itf.hh"
#include "lapack_cpp_itf/upgtr_itf.hh"
#include "lapack_cpp_itf/upmtr_itf.hh"
#include "lapack_cpp_itf/lamch_itf.hh"
#include "lapack_cpp_itf/langb_itf.hh"
#include "lapack_cpp_itf/lange_itf.hh"
#include "lapack_cpp_itf/langt_itf.hh"
#include "lapack_cpp_itf/lanhb_itf.hh"
#include "lapack_cpp_itf/lanhe_itf.hh"
#include "lapack_cpp_itf/lanhp_itf.hh"
#include "lapack_cpp_itf/lanhs_itf.hh"
#include "lapack_cpp_itf/lanht_itf.hh"
#include "lapack_cpp_itf/lansb_itf.hh"
#include "lapack_cpp_itf/lansp_itf.hh"
#include "lapack_cpp_itf/lanst_itf.hh"
#include "lapack_cpp_itf/lansy_itf.hh"
#include "lapack_cpp_itf/lantb_itf.hh"
#include "lapack_cpp_itf/lantp_itf.hh"
#include "lapack_cpp_itf/lantr_itf.hh"
#include "lapack_cpp_itf/lapy2_itf.hh"
#include "lapack_cpp_itf/lapy3_itf.hh"
#include "lapack_cpp_itf/sum1_itf.hh"

////////////////////////////////////////////
// supplementary grouping interfaces
////////////////////////////////////////////
#include "lapack_cpp_itf/gqr_itf.hh"
#include "lapack_cpp_itf/mqr_itf.hh"



#endif    

// End of lapack_cp0_itf.hh"
