#ifndef __PROJECT__LPP__FILE__GEBRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEBRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gebrd_itf.hh C++ interface to LAPACK (c,d,c,z)gebrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gebrd_itf.hh
    (excerpt adapted from xgebrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgebrd reduces a general DATA TYPE m-by-n matrix a to upper or lower
    **  bidiagonal form b by a unitary transformation: q**h * a * p = b.
    **
    **  if m >= n, b is upper bidiagonal; if m < n, b is lower bidiagonal.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows in the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns in the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n general matrix to be reduced.
    **          on exit,
    **          if m >= n, the diagonal and the first superdiagonal are
    **            overwritten with the upper bidiagonal matrix b; the
    **            elements below the diagonal, with the array tauq, represent
    **            the unitary matrix q as a product of elementary
    **            reflectors, and the elements above the first superdiagonal,
    **            with the array taup, represent the unitary matrix p as
    **            a product of elementary reflectors;
    **          if m < n, the diagonal and the first subdiagonal are
    **            overwritten with the lower bidiagonal matrix b; the
    **            elements below the first subdiagonal, with the array tauq,
    **            represent the unitary matrix q as a product of
    **            elementary reflectors, and the elements above the diagonal,
    **            with the array taup, represent the unitary matrix p as
    **            a product of elementary reflectors.
    **          see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  d       (output) BASE DATA TYPE array, dimension (min(m,n))
    **          the diagonal elements of the bidiagonal matrix b:
    **          d(i) = a(i,i).
    **
    **  e       (output) BASE DATA TYPE array, dimension (min(m,n)-1)
    **          the off-diagonal elements of the bidiagonal matrix b:
    **          if m >= n, e(i) = a(i,i+1) for i = 1,2,...,n-1;
    **          if m < n, e(i) = a(i+1,i) for i = 1,2,...,m-1.
    **
    **  tauq    (output) DATA TYPE array dimension (min(m,n))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix q. see further details.
    **
    **  taup    (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix p. see further details.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  the matrices q and p are represented as products of elementary
    **  reflectors:
    **
    **  if m >= n,
    **
    **     q = h(1) h(2) . . . h(n)  and  p = g(1) g(2) . . . g(n-1)
    **
    **  each h(i) and g(i) has the form:
    **
    **     h(i) = i - tauq * v * v'  and g(i) = i - taup * u * u'
    **
    **  where tauq and taup are DATA TYPE scalars, and v and u are DATA TYPE
    **  vectors; v(1:i-1) = 0, v(i) = 1, and v(i+1:m) is stored on exit in
    **  a(i+1:m,i); u(1:i) = 0, u(i+1) = 1, and u(i+2:n) is stored on exit in
    **  a(i,i+2:n); tauq is stored in tauq(i) and taup in taup(i).
    **
    **  if m < n,
    **
    **     q = h(1) h(2) . . . h(m-1)  and  p = g(1) g(2) . . . g(m)
    **
    **  each h(i) and g(i) has the form:
    **
    **     h(i) = i - tauq * v * v'  and g(i) = i - taup * u * u'
    **
    **  where tauq and taup are DATA TYPE scalars, and v and u are DATA TYPE
    **  vectors; v(1:i) = 0, v(i+1) = 1, and v(i+2:m) is stored on exit in
    **  a(i+2:m,i); u(1:i-1) = 0, u(i) = 1, and u(i+1:n) is stored on exit in
    **  a(i,i+1:n); tauq is stored in tauq(i) and taup in taup(i).
    **
    **  the contents of a on exit are illustrated by the following examples:
    **
    **  m = 6 and n = 5 (m > n):          m = 5 and n = 6 (m < n):
    **
    **    (  d   e   u1  u1  u1 )           (  d   u1  u1  u1  u1  u1 )
    **    (  v1  d   e   u2  u2 )           (  e   d   u2  u2  u2  u2 )
    **    (  v1  v2  d   e   u3 )           (  v1  e   d   u3  u3  u3 )
    **    (  v1  v2  v3  d   e  )           (  v1  v2  e   d   u4  u4 )
    **    (  v1  v2  v3  v4  d  )           (  v1  v2  v3  e   d   u5 )
    **    (  v1  v2  v3  v4  v5 )
    **
    **  where d and e denote diagonal and off-diagonal elements of b, vi
    **  denotes an element of the vector defining h(i), and ui an element of
    **  the vector defining g(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gebrd(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tauq,
        float* taup,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gebrd(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tauq,
        float* taup,
        long int* info)
  */
  /*! fn
   inline void gebrd(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tauq,
        double* taup,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gebrd(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tauq,
        double* taup,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgebrd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of the array WORK.  LWORK >= max(1,M,N).
  //    *          For optimum performance LWORK >= (M+N)*NB, where NB
  //    *          is the optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEBRD(NAME, T)\
inline void gebrd(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tauq,\
    T* taup,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, d, e, tauq, taup, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, a, lda, d, e, tauq, taup, w.getw(), &w.neededsize(), info);\
}\
inline void gebrd(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tauq,\
    T* taup,\
    long int* info)\
{\
   workspace<T> w;\
   gebrd(m, n, a, lda, d, e, tauq, taup, info, w);\
}\

    LPP_GEBRD(sgebrd, float)
    LPP_GEBRD(dgebrd, double)

#undef LPP_GEBRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gebrd(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const float* d,
       float* e,
       std::complex<float>* tauq,
       std::complex<float>* taup,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gebrd(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const float* d,
       float* e,
       std::complex<float>* tauq,
       std::complex<float>* taup,
       long int* info)
  */
  /*! fn
   inline void gebrd(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const double* d,
       double* e,
       std::complex<double>* tauq,
       std::complex<double>* taup,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gebrd(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const double* d,
       double* e,
       std::complex<double>* tauq,
       std::complex<double>* taup,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgebrd.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of the array WORK.  LWORK >= max(1,M,N).
  //    *          For optimum performance LWORK >= (M+N)*NB, where NB
  //    *          is the optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEBRD(NAME, T, TBASE)\
inline void gebrd(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const TBASE* d,\
    TBASE* e,\
    T* tauq,\
    T* taup,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, d, e, tauq, taup, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, a, lda, d, e, tauq, taup, w.getw(), &w.neededsize(), info);\
}\
inline void gebrd(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const TBASE* d,\
    TBASE* e,\
    T* tauq,\
    T* taup,\
    long int* info)\
{\
   workspace<T> w;\
   gebrd(m, n, a, lda, d, e, tauq, taup, info, w);\
}\

    LPP_GEBRD(cgebrd, std::complex<float>, float)
    LPP_GEBRD(zgebrd, std::complex<double>, double)

#undef LPP_GEBRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gebrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
