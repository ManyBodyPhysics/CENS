#ifndef __PROJECT__LPP__FILE__GETF2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GETF2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : getf2_itf.hh C++ interface to LAPACK (c,d,c,z)getf2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file getf2_itf.hh
    (excerpt adapted from xgetf2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgetf2 computes an lu factorization of a general m-by-n matrix a
    **  using partial pivoting with row interchanges.
    **
    **  the factorization has the form
    **     a = p * l * u
    **  where p is a permutation matrix, l is lower triangular with unit
    **  diagonal elements (lower trapezoidal if m > n), and u is upper
    **  triangular (upper trapezoidal if m < n).
    **
    **  this is the right-looking level 2 blas version of the algorithm.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m by n matrix to be factored.
    **          on exit, the factors l and u from the factorization
    **          a = p*l*u; the unit diagonal elements of l are not stored.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  ipiv    (output) long int array, dimension (min(m,n))
    **          the pivot indices; for 1 <= i <= min(m,n), row i of the
    **          matrix was interchanged with row ipiv(i).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **          > 0: if info = k, u(k,k) is exactly zero. the factorization
    **               has been completed, but the factor u is exactly
    **               singular, and division by zero will occur if it is used
    **               to solve a system of equations.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void getf2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void getf2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* info)
  */
  /*! fn
   inline void getf2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void getf2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgetf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GETF2(NAME, T)\
inline void getf2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, ipiv, info);\
}\
inline void getf2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   getf2(m, n, a, lda, ipiv, info, w);\
}\

    LPP_GETF2(sgetf2, float)
    LPP_GETF2(dgetf2, double)

#undef LPP_GETF2


  // The following macro provides the 4 functions 
  /*! fn
   inline void getf2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void getf2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* info)
  */
  /*! fn
   inline void getf2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void getf2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgetf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GETF2(NAME, T, TBASE)\
inline void getf2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, ipiv, info);\
}\
inline void getf2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   getf2(m, n, a, lda, ipiv, info, w);\
}\

      LPP_GETF2(cgetf2, std::complex<float>,  float)
        LPP_GETF2(zgetf2, std::complex<double>,  double)

#undef LPP_GETF2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of getf2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
