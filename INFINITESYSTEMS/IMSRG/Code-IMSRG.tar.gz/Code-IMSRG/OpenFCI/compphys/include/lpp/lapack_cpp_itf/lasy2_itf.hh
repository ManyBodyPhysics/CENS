#ifndef __PROJECT__LPP__FILE__LASY2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASY2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasy2_itf.hh C++ interface to LAPACK (s,d,c,z)lasy2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasy2_itf.hh
    (excerpt adapted from xlasy2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasy2 solves for the n1 by n2 matrix x, 1 <= n1,n2 <= 2, in
    **
    **         op(tl)*x + isgn*x*op(tr) = scale*b,
    **
    **  where tl is n1 by n1, tr is n2 by n2, b is n1 by n2, and isgn = 1 or
    **  -1.  op(t) = t or t', where t' denotes the transpose of t.
    **
    **  arguments
    **  =========
    **
    **  ltranl  (input) logical
    **          on entry, ltranl specifies the op(tl):
    **             = .false., op(tl) = tl,
    **             = .true., op(tl) = tl'.
    **
    **  ltranr  (input) logical
    **          on entry, ltranr specifies the op(tr):
    **            = .false., op(tr) = tr,
    **            = .true., op(tr) = tr'.
    **
    **  isgn    (input) long int
    **          on entry, isgn specifies the sign of the equation
    **          as described before. isgn may only be 1 or -1.
    **
    **  n1      (input) long int
    **          on entry, n1 specifies the order of matrix tl.
    **          n1 may only be 0, 1 or 2.
    **
    **  n2      (input) long int
    **          on entry, n2 specifies the order of matrix tr.
    **          n2 may only be 0, 1 or 2.
    **
    **  tl      (input) BASE DATA TYPE array, dimension (ldtl,2)
    **          on entry, tl contains an n1 by n1 matrix.
    **
    **  ldtl    (input) long int
    **          the leading dimension of the matrix tl. ldtl >= max(1,n1).
    **
    **  tr      (input) BASE DATA TYPE array, dimension (ldtr,2)
    **          on entry, tr contains an n2 by n2 matrix.
    **
    **  ldtr    (input) long int
    **          the leading dimension of the matrix tr. ldtr >= max(1,n2).
    **
    **  b       (input) BASE DATA TYPE array, dimension (ldb,2)
    **          on entry, the n1 by n2 matrix b contains the right-hand
    **          side of the equation.
    **
    **  ldb     (input) long int
    **          the leading dimension of the matrix b. ldb >= max(1,n1).
    **
    **  scale   (output) BASE DATA TYPE
    **          on exit, scale contains the scale factor. scale is chosen
    **          less than or equal to 1 to prevent the solution overflowing.
    **
    **  x       (output) BASE DATA TYPE array, dimension (ldx,2)
    **          on exit, x contains the n1 by n2 solution.
    **
    **  ldx     (input) long int
    **          the leading dimension of the matrix x. ldx >= max(1,n1).
    **
    **  xnorm   (output) BASE DATA TYPE
    **          on exit, xnorm is the infinity-norm of the solution.
    **
    **  info    (output) long int
    **          on exit, info is set to
    **             0: successful exit.
    **             1: tl and tr have too close eigenvalues, so tl or
    **                tr is perturbed to get a nonsingular equation.
    **          note: in the interests of speed, this routine does not
    **                check the inputs for errors.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasy2(
        const long int* ltranl,
        const long int* ltranr,
        const long int* isgn,
        const long int* n1,
        const long int* n2,
        const float* tl,
        const long int* ldtl,
        const float* tr,
        const long int* ldtr,
        const float* b,
        const long int* ldb,
        float* scale,
        float* x,
        const long int* ldx,
        float* xnorm,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasy2(
        const long int* ltranl,
        const long int* ltranr,
        const long int* isgn,
        const long int* n1,
        const long int* n2,
        const float* tl,
        const long int* ldtl,
        const float* tr,
        const long int* ldtr,
        const float* b,
        const long int* ldb,
        float* scale,
        float* x,
        const long int* ldx,
        float* xnorm,
        long int* info)
  */
  /*! fn
   inline void lasy2(
        const long int* ltranl,
        const long int* ltranr,
        const long int* isgn,
        const long int* n1,
        const long int* n2,
        const double* tl,
        const long int* ldtl,
        const double* tr,
        const long int* ldtr,
        const double* b,
        const long int* ldb,
        double* scale,
        double* x,
        const long int* ldx,
        double* xnorm,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasy2(
        const long int* ltranl,
        const long int* ltranr,
        const long int* isgn,
        const long int* n1,
        const long int* n2,
        const double* tl,
        const long int* ldtl,
        const double* tr,
        const long int* ldtr,
        const double* b,
        const long int* ldb,
        double* scale,
        double* x,
        const long int* ldx,
        double* xnorm,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasy2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASY2(NAME, T)\
inline void lasy2(\
    const long int* ltranl,\
    const long int* ltranr,\
    const long int* isgn,\
    const long int* n1,\
    const long int* n2,\
    const T* tl,\
    const long int* ldtl,\
    const T* tr,\
    const long int* ldtr,\
    const T* b,\
    const long int* ldb,\
    T* scale,\
    T* x,\
    const long int* ldx,\
    T* xnorm,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ltranl, ltranr, isgn, n1, n2, tl, ldtl, tr, ldtr, b, ldb, scale, x, ldx, xnorm, info);\
}\
inline void lasy2(\
    const long int* ltranl,\
    const long int* ltranr,\
    const long int* isgn,\
    const long int* n1,\
    const long int* n2,\
    const T* tl,\
    const long int* ldtl,\
    const T* tr,\
    const long int* ldtr,\
    const T* b,\
    const long int* ldb,\
    T* scale,\
    T* x,\
    const long int* ldx,\
    T* xnorm,\
    long int* info)\
{\
   workspace<T> w;\
   lasy2(ltranl, ltranr, isgn, n1, n2, tl, ldtl, tr, ldtr, b, ldb, scale, x, ldx, xnorm, info, w);\
}\

    LPP_LASY2(slasy2, float)
    LPP_LASY2(dlasy2, double)

#undef LPP_LASY2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasy2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
