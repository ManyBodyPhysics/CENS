#ifndef __PROJECT__LPP__FILE__LASQ4_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASQ4_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasq4_itf.hh C++ interface to LAPACK (s,d,c,z)lasq4
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasq4_itf.hh
    (excerpt adapted from xlasq4.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasq4 computes an approximation tau to the smallest eigenvalue 
    **  using values of d from the previous transform.
    **
    **  i0    (input) long int
    **        first index.
    **
    **  n0    (input) long int
    **        last index.
    **
    **  z     (input) BASE DATA TYPE array, dimension ( 4*n )
    **        z holds the qd array.
    **
    **  pp    (input) long int
    **        pp=0 for ping, pp=1 for pong.
    **
    **  n0in  (input) long int (jtl)
    **        the value of n0 at start of eigtest.
    **
    **  dmin  (input) BASE DATA TYPE
    **        minimum value of d.
    **
    **  dmin1 (input) BASE DATA TYPE
    **        minimum value of d, excluding d( n0 ).
    **
    **  dmin2 (input) BASE DATA TYPE
    **        minimum value of d, excluding d( n0 ) and d( n0-1 ).
    **
    **  dn    (input) BASE DATA TYPE
    **        d(n)
    **
    **  dn1   (input) BASE DATA TYPE
    **        d(n-1)
    **
    **  dn2   (input) BASE DATA TYPE
    **        d(n-2)
    **
    **  tau   (output) BASE DATA TYPE
    **        this is the shift.
    **
    **  ttype (output) long int
    **        shift type.
    **
    **  further details
    **  ===============
    **  cnst1 = 9/16
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasq4(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        const long int* n0in,
        const float* dmin,
        const float* dmin1,
        const float* dmin2,
        const float* dn,
        const float* dn1,
        const float* dn2,
        float* tau,
        long int* ttype,
        workspace<float> & w)
  */
  /*! fn
   inline void lasq4(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        const long int* n0in,
        const float* dmin,
        const float* dmin1,
        const float* dmin2,
        const float* dn,
        const float* dn1,
        const float* dn2,
        float* tau,
        long int* ttype)
  */
  /*! fn
   inline void lasq4(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        const long int* n0in,
        const double* dmin,
        const double* dmin1,
        const double* dmin2,
        const double* dn,
        const double* dn1,
        const double* dn2,
        double* tau,
        long int* ttype,
        workspace<double> & w)
  */
  /*! fn
   inline void lasq4(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        const long int* n0in,
        const double* dmin,
        const double* dmin1,
        const double* dmin2,
        const double* dn,
        const double* dn1,
        const double* dn2,
        double* tau,
        long int* ttype)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasq4.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASQ4(NAME, T)\
inline void lasq4(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    const long int* n0in,\
    const T* dmin,\
    const T* dmin1,\
    const T* dmin2,\
    const T* dn,\
    const T* dn1,\
    const T* dn2,\
    T* tau,\
    long int* ttype,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(i0, n0, z, pp, n0in, dmin, dmin1, dmin2, dn, dn1, dn2, tau, ttype);\
}\
inline void lasq4(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    const long int* n0in,\
    const T* dmin,\
    const T* dmin1,\
    const T* dmin2,\
    const T* dn,\
    const T* dn1,\
    const T* dn2,\
    T* tau,\
    long int* ttype)\
{\
   workspace<T> w;\
   lasq4(i0, n0, z, pp, n0in, dmin, dmin1, dmin2, dn, dn1, dn2, tau, ttype, w);\
}\

    LPP_LASQ4(slasq4, float)
    LPP_LASQ4(dlasq4, double)

#undef LPP_LASQ4



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasq4_itf.hh
// /////////////////////////////////////////////////////////////////////////////
