#ifndef __PROJECT__LPP__FILE__STERF_HH__INCLUDED
#define __PROJECT__LPP__FILE__STERF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sterf_itf.hh C++ interface to LAPACK (s,d,c,z)sterf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sterf_itf.hh
    (excerpt adapted from xsterf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsterf computes all eigenvalues of a symmetric tridiagonal matrix
    **  using the pal-walker-kahan variant of the ql or qr algorithm.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal matrix.
    **          on exit, if info = 0, the eigenvalues in ascending order.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix.
    **          on exit, e has been destroyed.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  the algorithm failed to find all of the eigenvalues in
    **                a total of 30*n iterations; if info = i, then i
    **                elements of e have not converged to zero.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sterf(
        const long int* n,
        float* d,
        float* e,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sterf(
        const long int* n,
        float* d,
        float* e,
        long int* info)
  */
  /*! fn
   inline void sterf(
        const long int* n,
        double* d,
        double* e,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sterf(
        const long int* n,
        double* d,
        double* e,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssterf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_STERF(NAME, T)\
inline void sterf(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, d, e, info);\
}\
inline void sterf(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info)\
{\
   workspace<T> w;\
   sterf(n, d, e, info, w);\
}\

    LPP_STERF(ssterf, float)
    LPP_STERF(dsterf, double)

#undef LPP_STERF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sterf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
