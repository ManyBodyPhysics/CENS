#ifndef __PROJECT__LPP__FILE__LAQP2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQP2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqp2_itf.hh C++ interface to LAPACK (s,d,c,z)laqp2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqp2_itf.hh
    (excerpt adapted from xlaqp2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqp2 computes a qr factorization with column pivoting of
    **  the block a(offset+1:m,1:n).
    **  the block a(1:offset,1:n) is accordingly pivoted, but not factorized.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a. n >= 0.
    **
    **  offset  (input) long int
    **          the number of rows of the matrix a that must be pivoted
    **          but no factorized. offset >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, the upper triangle of block a(offset+1:m,1:n) is 
    **          the triangular factor obtained; the elements in block 
    **          a(offset+1:m,1:n) below the diagonal, together with the 
    **          array tau, represent the orthogonal matrix q as a product of
    **          elementary reflectors. block a(1:offset,1:n) has been 
    **          accordingly pivoted, but no factorized.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  jpvt    (input/output) long int array, dimension (n)
    **          on entry, if jpvt(i) .ne. 0, the i-th column of a is permuted
    **          to the front of a*p (a leading column); if jpvt(i) = 0,
    **          the i-th column of a is a free column.
    **          on exit, if jpvt(i) = k, then the i-th column of a*p
    **          was the k-th column of a.
    **
    **  tau     (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors.
    **
    **  vn1     (input/output) BASE DATA TYPE array, dimension (n)
    **          the vector with the partial column norms.
    **
    **  vn2     (input/output) BASE DATA TYPE array, dimension (n)
    **          the vector with the exact column norms.
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    g. quintana-orti, depto. de informatica, universidad jaime i, spain
    **    x. sun, computer science dept., duke university, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqp2(
        const long int* m,
        const long int* n,
        const long int* offset,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        float* vn1,
        float* vn2,
        workspace<float> & w)
  */
  /*! fn
   inline void laqp2(
        const long int* m,
        const long int* n,
        const long int* offset,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        float* vn1,
        float* vn2)
  */
  /*! fn
   inline void laqp2(
        const long int* m,
        const long int* n,
        const long int* offset,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        double* vn1,
        double* vn2,
        workspace<double> & w)
  */
  /*! fn
   inline void laqp2(
        const long int* m,
        const long int* n,
        const long int* offset,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        double* vn1,
        double* vn2)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaqp2.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQP2(NAME, T)\
inline void laqp2(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    T* vn1,\
    T* vn2,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(m, n, offset, a, lda, jpvt, tau, vn1, vn2, w.getw());\
}\
inline void laqp2(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    T* vn1,\
    T* vn2)                                     \
{\
   workspace<T> w;\
   laqp2(m, n, offset, a, lda, jpvt, tau, vn1, vn2, w);\
}\

    LPP_LAQP2(slaqp2, float)
    LPP_LAQP2(dlaqp2, double)

#undef LPP_LAQP2


  // The following macro provides the 4 functions 
  /*! fn
   inline void laqp2(
       const long int* m,
       const long int* n,
       const long int* offset,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       float* vn1,
       float* vn2,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laqp2(
       const long int* m,
       const long int* n,
       const long int* offset,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       float* vn1,
       float* vn2)
  */
  /*! fn
   inline void laqp2(
       const long int* m,
       const long int* n,
       const long int* offset,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       double* vn1,
       double* vn2,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laqp2(
       const long int* m,
       const long int* n,
       const long int* offset,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       double* vn1,
       double* vn2)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claqp2.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQP2(NAME, T, TBASE)\
inline void laqp2(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    TBASE* vn1,\
    TBASE* vn2,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(m, n, offset, a, lda, jpvt, tau, vn1, vn2, w.getw());\
}\
inline void laqp2(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    TBASE* vn1,\
    TBASE* vn2)                                 \
{\
   workspace<T> w;\
   laqp2(m, n, offset, a, lda, jpvt, tau, vn1, vn2, w);\
}\

    LPP_LAQP2(claqp2, std::complex<float>, float)
    LPP_LAQP2(zlaqp2, std::complex<double>, double)

#undef LPP_LAQP2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqp2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
