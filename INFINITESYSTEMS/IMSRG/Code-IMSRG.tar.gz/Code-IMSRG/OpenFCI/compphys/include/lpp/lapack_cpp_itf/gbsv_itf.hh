#ifndef __PROJECT__LPP__FILE__GBSV_HH__INCLUDED
#define __PROJECT__LPP__FILE__GBSV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gbsv_itf.hh C++ interface to LAPACK (c,d,c,z)gbsv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gbsv_itf.hh
    (excerpt adapted from xgbsv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgbsv computes the solution to a DATA TYPE system of linear equations
    **  a * x = b, where a is a band matrix of order n with kl subdiagonals
    **  and ku superdiagonals, and x and b are n-by-nrhs matrices.
    **
    **  the lu decomposition with partial pivoting and row interchanges is
    **  used to factor a as a = l * u, where l is a product of permutation
    **  and unit lower triangular matrices with kl subdiagonals, and u is
    **  upper triangular with kl+ku superdiagonals.  the factored form of a
    **  is then used to solve the system of equations a * x = b.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  kl      (input) long int
    **          the number of subdiagonals within the band of a.  kl >= 0.
    **
    **  ku      (input) long int
    **          the number of superdiagonals within the band of a.  ku >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the matrix a in band storage, in rows kl+1 to
    **          2*kl+ku+1; rows 1 to kl of the array need not be set.
    **          the j-th column of a is stored in the j-th column of the
    **          array ab as follows:
    **          ab(kl+ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(n,j+kl)
    **          on exit, details of the factorization: u is stored as an
    **          upper triangular band matrix with kl+ku superdiagonals in
    **          rows 1 to kl+ku+1, and the multipliers used during the
    **          factorization are stored in rows kl+ku+2 to 2*kl+ku+1.
    **          see below for further details.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= 2*kl+ku+1.
    **
    **  ipiv    (output) long int array, dimension (n)
    **          the pivot indices that define the permutation matrix p;
    **          row i of the matrix was interchanged with row ipiv(i).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if info = 0, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, u(i,i) is exactly zero.  the factorization
    **                has been completed, but the factor u is exactly
    **                singular, and the solution has not been computed.
    **
    **  further details
    **  ===============
    **
    **  the band storage scheme is illustrated by the following example, when
    **  m = n = 6, kl = 2, ku = 1:
    **
    **  on entry:                       on exit:
    **
    **      *    *    *    +    +    +       *    *    *   u14  u25  u36
    **      *    *    +    +    +    +       *    *   u13  u24  u35  u46
    **      *   a12  a23  a34  a45  a56      *   u12  u23  u34  u45  u56
    **     a11  a22  a33  a44  a55  a66     u11  u22  u33  u44  u55  u66
    **     a21  a32  a43  a54  a65   *      m21  m32  m43  m54  m65   *
    **     a31  a42  a53  a64   *    *      m31  m42  m53  m64   *    *
    **
    **  array elements marked * are not used by the routine; elements marked
    **  + need not be set on entry, but are required by the routine to store
    **  elements of u because of fill-in resulting from the row interchanges.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gbsv(
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gbsv(
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void gbsv(
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gbsv(
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgbsv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBSV(NAME, T)\
inline void gbsv(\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, kl, ku, nrhs, ab, ldab, ipiv, b, ldb, info);\
}\
inline void gbsv(\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gbsv(n, kl, ku, nrhs, ab, ldab, ipiv, b, ldb, info, w);\
}\

    LPP_GBSV(sgbsv, float)
    LPP_GBSV(dgbsv, double)

#undef LPP_GBSV


  // The following macro provides the 4 functions 
  /*! fn
   inline void gbsv(
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gbsv(
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void gbsv(
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gbsv(
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgbsv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBSV(NAME, T, TBASE)\
inline void gbsv(\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, kl, ku, nrhs, ab, ldab, ipiv, b, ldb, info);\
}\
inline void gbsv(\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gbsv(n, kl, ku, nrhs, ab, ldab, ipiv, b, ldb, info, w);\
}\

    LPP_GBSV(cgbsv, std::complex<float>, float)
    LPP_GBSV(zgbsv, std::complex<double>, double)

#undef LPP_GBSV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gbsv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
