#ifndef __PROJECT__LPP__FILE__PBTF2_HH__INCLUDED
#define __PROJECT__LPP__FILE__PBTF2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pbtf2_itf.hh C++ interface to LAPACK (c,d,c,z)pbtf2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pbtf2_itf.hh
    (excerpt adapted from xpbtf2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpbtf2 computes the cholesky factorization of a DATA TYPE hermitian
    **  positive definite band matrix a.
    **
    **  the factorization has the form
    **     a = u' * u ,  if uplo = 'u', or
    **     a = l  * l',  if uplo = 'l',
    **  where u is an upper triangular matrix, u' is the conjugate transpose
    **  of u, and l is lower triangular.
    **
    **  this is the unblocked version of the algorithm, calling level 2 blas.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is stored:
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of super-diagonals of the matrix a if uplo = 'u',
    **          or the number of sub-diagonals if uplo = 'l'.  kd >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the upper or lower triangle of the hermitian band
    **          matrix a, stored in the first kd+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **
    **          on exit, if info = 0, the triangular factor u or l from the
    **          cholesky factorization a = u'*u or a = l*l' of the band
    **          matrix a, in the same storage format as a.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **          > 0: if info = k, the leading minor of order k is not
    **               positive definite, and the factorization could not be
    **               completed.
    **
    **  further details
    **  ===============
    **
    **  the band storage scheme is illustrated by the following example, when
    **  n = 6, kd = 2, and uplo = 'u':
    **
    **  on entry:                       on exit:
    **
    **      *    *   a13  a24  a35  a46      *    *   u13  u24  u35  u46
    **      *   a12  a23  a34  a45  a56      *   u12  u23  u34  u45  u56
    **     a11  a22  a33  a44  a55  a66     u11  u22  u33  u44  u55  u66
    **
    **  similarly, if uplo = 'l' the format of a is as follows:
    **
    **  on entry:                       on exit:
    **
    **     a11  a22  a33  a44  a55  a66     l11  l22  l33  l44  l55  l66
    **     a21  a32  a43  a54  a65   *      l21  l32  l43  l54  l65   *
    **     a31  a42  a53  a64   *    *      l31  l42  l53  l64   *    *
    **
    **  array elements marked * are not used by the routine.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pbtf2(
        const char* uplo,
        const long int* n,
        const long int* kd,
        float* ab,
        const long int* ldab,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pbtf2(
        const char* uplo,
        const long int* n,
        const long int* kd,
        float* ab,
        const long int* ldab,
        long int* info)
  */
  /*! fn
   inline void pbtf2(
        const char* uplo,
        const long int* n,
        const long int* kd,
        double* ab,
        const long int* ldab,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pbtf2(
        const char* uplo,
        const long int* n,
        const long int* kd,
        double* ab,
        const long int* ldab,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spbtf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBTF2(NAME, T)\
inline void pbtf2(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, info);\
}\
inline void pbtf2(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info)\
{\
   workspace<T> w;\
   pbtf2(uplo, n, kd, ab, ldab, info, w);\
}\

    LPP_PBTF2(spbtf2, float)
    LPP_PBTF2(dpbtf2, double)

#undef LPP_PBTF2


  // The following macro provides the 4 functions 
  /*! fn
   inline void pbtf2(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pbtf2(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       long int* info)
  */
  /*! fn
   inline void pbtf2(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pbtf2(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpbtf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBTF2(NAME, T, TBASE)\
inline void pbtf2(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, info);\
}\
inline void pbtf2(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info)\
{\
   workspace<T> w;\
   pbtf2(uplo, n, kd, ab, ldab, info, w);\
}\

    LPP_PBTF2(cpbtf2, std::complex<float>,  float)
    LPP_PBTF2(zpbtf2, std::complex<double>, double)

#undef LPP_PBTF2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pbtf2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
