#ifndef __PROJECT__LPP__FILE__LAGTF_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAGTF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lagtf_itf.hh C++ interface to LAPACK (s,d,c,z)lagtf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lagtf_itf.hh
    (excerpt adapted from xlagtf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlagtf factorizes the matrix (t - lambda*i), where t is an n by n
    **  tridiagonal matrix and lambda is a scalar, as
    **
    **     t - lambda*i = plu,
    **
    **  where p is a permutation matrix, l is a unit lower tridiagonal matrix
    **  with at most one non-zero sub-diagonal elements per column and u is
    **  an upper triangular matrix with at most two non-zero super-diagonal
    **  elements per column.
    **
    **  the factorization is obtained by gaussian elimination with partial
    **  pivoting and implicit row scaling.
    **
    **  the parameter lambda is included in the routine so that xlagtf may
    **  be used, in conjunction with dlagts, to obtain eigenvectors of t by
    **  inverse iteration.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix t.
    **
    **  a       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, a must contain the diagonal elements of t.
    **
    **          on exit, a is overwritten by the n diagonal elements of the
    **          upper triangular matrix u of the factorization of t.
    **
    **  lambda  (input) BASE DATA TYPE
    **          on entry, the scalar lambda.
    **
    **  b       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, b must contain the (n-1) super-diagonal elements of
    **          t.
    **
    **          on exit, b is overwritten by the (n-1) super-diagonal
    **          elements of the matrix u of the factorization of t.
    **
    **  c       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, c must contain the (n-1) sub-diagonal elements of
    **          t.
    **
    **          on exit, c is overwritten by the (n-1) sub-diagonal elements
    **          of the matrix l of the factorization of t.
    **
    **  tol     (input) BASE DATA TYPE
    **          on entry, a relative tolerance used to indicate whether or
    **          not the matrix (t - lambda*i) is nearly singular. tol should
    **          normally be chose as approximately the largest relative error
    **          in the elements of t. for example, if the elements of t are
    **          correct to about 4 significant figures, then tol should be
    **          set to about 5*10**(-4). if tol is supplied as less than eps,
    **          where eps is the relative machine precision, then the value
    **          eps is used in place of tol.
    **
    **  d       (output) BASE DATA TYPE array, dimension (n-2)
    **          on exit, d is overwritten by the (n-2) second super-diagonal
    **          elements of the matrix u of the factorization of t.
    **
    **  in      (output) long int array, dimension (n)
    **          on exit, in contains details of the permutation matrix p. if
    **          an interchange occurred at the kth step of the elimination,
    **          then in(k) = 1, otherwise in(k) = 0. the element in(n)
    **          returns the smallest positive integer j such that
    **
    **             abs( u(j,j) ).le. norm( (t - lambda*i)(j) )*tol,
    **
    **          where norm( a(j) ) denotes the sum of the absolute values of
    **          the jth row of the matrix a. if no such j exists then in(n)
    **          is returned as zero. if in(n) is returned as positive, then a
    **          diagonal element of u is small, indicating that
    **          (t - lambda*i) is singular or nearly singular,
    **
    **  info    (output) long int
    **          = 0   : successful exit
    **          .lt. 0: if info = -k, the kth argument had an illegal value
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lagtf(
        const long int* n,
        float* a,
        const float* lambda,
        const float* b,
        float* c,
        const float* tol,
        const float* d,
        long int* in,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lagtf(
        const long int* n,
        float* a,
        const float* lambda,
        const float* b,
        float* c,
        const float* tol,
        const float* d,
        long int* in,
        long int* info)
  */
  /*! fn
   inline void lagtf(
        const long int* n,
        double* a,
        const double* lambda,
        const double* b,
        double* c,
        const double* tol,
        const double* d,
        long int* in,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lagtf(
        const long int* n,
        double* a,
        const double* lambda,
        const double* b,
        double* c,
        const double* tol,
        const double* d,
        long int* in,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slagtf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGTF(NAME, T)\
inline void lagtf(\
    const long int* n,\
    T* a,\
    const T* lambda,\
    const T* b,\
    T* c,\
    const T* tol,\
    const T* d,\
    long int* in,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lambda, b, c, tol, d, in, info);\
}\
inline void lagtf(\
    const long int* n,\
    T* a,\
    const T* lambda,\
    const T* b,\
    T* c,\
    const T* tol,\
    const T* d,\
    long int* in,\
    long int* info)\
{\
   workspace<T> w;\
   lagtf(n, a, lambda, b, c, tol, d, in, info, w);\
}\

    LPP_LAGTF(slagtf, float)
    LPP_LAGTF(dlagtf, double)

#undef LPP_LAGTF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lagtf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
