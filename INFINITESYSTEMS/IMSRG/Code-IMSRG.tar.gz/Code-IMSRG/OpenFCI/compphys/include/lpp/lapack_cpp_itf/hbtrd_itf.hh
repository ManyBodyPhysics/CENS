#ifndef __PROJECT__LPP__FILE__HBTRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__HBTRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hbtrd_itf.hh C++ interface to LAPACK (s,d,c,z)hbtrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hbtrd_itf.hh
    (excerpt adapted from xhbtrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhbtrd reduces a DATA TYPE hermitian band matrix a to BASE DATA TYPE symmetric
    **  tridiagonal form t by a unitary similarity transformation:
    **  q**h * a * q = t.
    **
    **  arguments
    **  =========
    **
    **  vect    (input) char
    **          = 'n':  do not form q;
    **          = 'v':  form q;
    **          = 'u':  update a matrix x, by forming x*q.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kd >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the upper or lower triangle of the hermitian band
    **          matrix a, stored in the first kd+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **          on exit, the diagonal elements of ab are overwritten by the
    **          diagonal elements of the tridiagonal matrix t; if kd > 0, the
    **          elements on the first superdiagonal (if uplo = 'u') or the
    **          first subdiagonal (if uplo = 'l') are overwritten by the
    **          off-diagonal elements of t; the rest of ab is overwritten by
    **          values generated during the reduction.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  d       (output) BASE DATA TYPE array, dimension (n)
    **          the diagonal elements of the tridiagonal matrix t.
    **
    **  e       (output) BASE DATA TYPE array, dimension (n-1)
    **          the off-diagonal elements of the tridiagonal matrix t:
    **          e(i) = t(i,i+1) if uplo = 'u'; e(i) = t(i+1,i) if uplo = 'l'.
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq,n)
    **          on entry, if vect = 'u', then q must contain an n-by-n
    **          matrix x; if vect = 'n' or 'v', then q need not be set.
    **
    **          on exit:
    **          if vect = 'v', q contains the n-by-n unitary matrix q;
    **          if vect = 'u', q contains the product x*q;
    **          if vect = 'n', the array q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.
    **          ldq >= 1, and ldq >= n if vect = 'v' or 'u'.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  modified by linda kaufman, bell labs.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hbtrd(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       const float* d,
       const float* e,
       std::complex<float>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hbtrd(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       const float* d,
       const float* e,
       std::complex<float>* q,
       const long int* ldq,
       long int* info)
  */
  /*! fn
   inline void hbtrd(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       const double* d,
       const double* e,
       std::complex<double>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hbtrd(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       const double* d,
       const double* e,
       std::complex<double>* q,
       const long int* ldq,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chbtrd.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HBTRD(NAME, T, TBASE)\
inline void hbtrd(\
    const char* vect,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    const TBASE* d,\
    const TBASE* e,\
    T* q,\
    const long int* ldq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(*n);\
    F77NAME( NAME )(vect, uplo, n, kd, ab, ldab, d, e, q, ldq, w.getw(), info);\
}\
inline void hbtrd(\
    const char* vect,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    const TBASE* d,\
    const TBASE* e,\
    T* q,\
    const long int* ldq,\
    long int* info)\
{\
   workspace<T> w;\
   hbtrd(vect, uplo, n, kd, ab, ldab, d, e, q, ldq, info, w);\
}\

    LPP_HBTRD(chbtrd, std::complex<float>, float)
    LPP_HBTRD(zhbtrd, std::complex<double>, double)

#undef LPP_HBTRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hbtrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
