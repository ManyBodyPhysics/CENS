#ifndef __PROJECT__LPP__FILE__LAED8_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED8_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed8_itf.hh C++ interface to LAPACK (c,d,c,z)laed8
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed8_itf.hh
    (excerpt adapted from xlaed8.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed8 merges the two sets of eigenvalues together into a single
    **  sorted set.  then it tries to deflate the size of the problem.
    **  there are two ways in which deflation can occur:  when two or more
    **  eigenvalues are close together or if there is a tiny element in the
    **  z vector.  for each such occurrence the order of the related secular
    **  equation problem is reduced by one.
    **
    **  arguments
    **  =========
    **
    **  k      (output) long int
    **         contains the number of non-deflated eigenvalues.
    **         this is the order of the related secular equation.
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  qsiz   (input) long int
    **         the dimension of the unitary matrix used to reduce
    **         the dense or band matrix to tridiagonal form.
    **         qsiz >= n if icompq = 1.
    **
    **  q      (input/output) DATA TYPE array, dimension (ldq,n)
    **         on entry, q contains the eigenvectors of the partially solved
    **         system which has been previously updated in matrix
    **         multiplies with other partially solved eigensystems.
    **         on exit, q contains the trailing (n-k) updated eigenvectors
    **         (those which were deflated) in its last n-k columns.
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= max( 1, n ).
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry, d contains the eigenvalues of the two submatrices to
    **         be combined.  on exit, d contains the trailing (n-k) updated
    **         eigenvalues (those which were deflated) sorted into increasing
    **         order.
    **
    **  rho    (input/output) BASE DATA TYPE
    **         contains the off diagonal element associated with the rank-1
    **         cut which originally split the two submatrices which are now
    **         being recombined. rho is modified during the computation to
    **         the value required by slaed3.
    **
    **  cutpnt (input) long int
    **         contains the location of the last eigenvalue in the leading
    **         sub-matrix.  min(1,n) <= cutpnt <= n.
    **
    **  z      (input) BASE DATA TYPE array, dimension (n)
    **         on input this vector contains the updating vector (the last
    **         row of the first sub-eigenvector matrix and the first row of
    **         the second sub-eigenvector matrix).  the contents of z are
    **         destroyed during the updating process.
    **
    **  dlamda (output) BASE DATA TYPE array, dimension (n)
    **         contains a copy of the first k eigenvalues which will be used
    **         by slaed3 to form the secular equation.
    **
    **  q2     (output) DATA TYPE array, dimension (ldq2,n)
    **         if icompq = 0, q2 is not referenced.  otherwise,
    **         contains a copy of the first k eigenvectors which will be used
    **         by slaed7 in a matrix multiply (sgemm) to update the new
    **         eigenvectors.
    **
    **  ldq2   (input) long int
    **         the leading dimension of the array q2.  ldq2 >= max( 1, n ).
    **
    **  w      (output) BASE DATA TYPE array, dimension (n)
    **         this will hold the first k values of the final
    **         deflation-altered z-vector and will be passed to slaed3.
    **
    **
    **
    **  indxq  (input) long int array, dimension (n)
    **         this contains the permutation which separately sorts the two
    **         sub-problems in d into ascending order.  note that elements in
    **         the second half of this permutation must first have cutpnt
    **         added to their values in order to be accurate.
    **
    **  perm   (output) long int array, dimension (n)
    **         contains the permutations (from deflation and sorting) to be
    **         applied to each eigenblock.
    **
    **  givptr (output) long int
    **         contains the number of givens rotations which took place in
    **         this subproblem.
    **
    **  givcol (output) long int array, dimension (2, n)
    **         each pair of numbers indicates a pair of columns to take place
    **         in a givens rotation.
    **
    **  givnum (output) BASE DATA TYPE array, dimension (2, n)
    **         each number indicates the s value to be used in the
    **         corresponding givens rotation.
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed8(
        const long int* icompq,
        long int* k,
        const long int* n,
        const long int* qsiz,
        float* d,
        const float* q,
        const long int* ldq,
        const long int* indxq,
        float* rho,
        const long int* cutpnt,
        const float* z,
        float* dlamda,
        float* q2,
        const long int* ldq2,
        float* ws,
        long int* perm,
        long int* givptr,
        long int* givcol,
        float* givnum,
        long int* indxp,
        const long int* indx,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed8(
        const long int* icompq,
        long int* k,
        const long int* n,
        const long int* qsiz,
        float* d,
        const float* q,
        const long int* ldq,
        const long int* indxq,
        float* rho,
        const long int* cutpnt,
        const float* z,
        float* dlamda,
        float* q2,
        const long int* ldq2,
        float* ws,
        long int* perm,
        long int* givptr,
        long int* givcol,
        float* givnum,
        long int* indxp,
        const long int* indx,
        long int* info)
  */
  /*! fn
   inline void laed8(
        const long int* icompq,
        long int* k,
        const long int* n,
        const long int* qsiz,
        double* d,
        const double* q,
        const long int* ldq,
        const long int* indxq,
        double* rho,
        const long int* cutpnt,
        const double* z,
        double* dlamda,
        double* q2,
        const long int* ldq2,
        double* ws,
        long int* perm,
        long int* givptr,
        long int* givcol,
        double* givnum,
        long int* indxp,
        const long int* indx,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed8(
        const long int* icompq,
        long int* k,
        const long int* n,
        const long int* qsiz,
        double* d,
        const double* q,
        const long int* ldq,
        const long int* indxq,
        double* rho,
        const long int* cutpnt,
        const double* z,
        double* dlamda,
        double* q2,
        const long int* ldq2,
        double* ws,
        long int* perm,
        long int* givptr,
        long int* givcol,
        double* givnum,
        long int* indxp,
        const long int* indx,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed8.f)
  //    *  INDXP  (workspace) long int array, dimension (N)
  //    *         The permutation used to place deflated values of D at the end
  //    *         of the array.  INDXP(1:K) points to the nondeflated D-values
  //    *         and INDXP(K+1:N) points to the deflated eigenvalues.
  //    *
  //    *  INDX   (workspace) long int array, dimension (N)
  //    *         The permutation used to sort the contents of D into ascending
  //    *         order.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED8(NAME, T)\
inline void laed8(\
    const long int* icompq,\
    long int* k,\
    const long int* n,\
    const long int* qsiz,\
    T* d,\
    const T* q,\
    const long int* ldq,\
    const long int* indxq,\
    T* rho,\
    const long int* cutpnt,\
    const T* z,\
    T* dlamda,\
    T* q2,\
    const long int* ldq2,\
    T* ws,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    T* givnum,\
    long int* indxp,\
    const long int* indx,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(icompq, k, n, qsiz, d, q, ldq, indxq, rho, cutpnt, z, dlamda, q2, ldq2, ws, perm, givptr, givcol, givnum, indxp, indx, info);\
}\
inline void laed8(\
    const long int* icompq,\
    long int* k,\
    const long int* n,\
    const long int* qsiz,\
    T* d,\
    const T* q,\
    const long int* ldq,\
    const long int* indxq,\
    T* rho,\
    const long int* cutpnt,\
    const T* z,\
    T* dlamda,\
    T* q2,\
    const long int* ldq2,\
    T* ws,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    T* givnum,\
    long int* indxp,\
    const long int* indx,\
    long int* info)\
{\
   workspace<T> w;\
   laed8(icompq, k, n, qsiz, d, q, ldq, indxq, rho, cutpnt, z, dlamda, q2, ldq2, ws, perm, givptr, givcol, givnum, indxp, indx, info, w);\
}\

    LPP_LAED8(slaed8, float)
    LPP_LAED8(dlaed8, double)

#undef LPP_LAED8


  // The following macro provides the 4 functions 
  /*! fn
   inline void laed8(
       long int* k,
       const long int* n,
       const long int* qsiz,
       const std::complex<float>* q,
       const long int* ldq,
       const float* d,
       float* rho,
       const long int* cutpnt,
       const float* z,
       float* dlamda,
       std::complex<float>* q2,
       const long int* ldq2,
       float* ws,
       long int* indxp,
       long int* indx,
       const long int* indxq,
       long int* perm,
       long int* givptr,
       long int* givcol,
       float* givnum,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laed8(
       long int* k,
       const long int* n,
       const long int* qsiz,
       const std::complex<float>* q,
       const long int* ldq,
       const float* d,
       float* rho,
       const long int* cutpnt,
       const float* z,
       float* dlamda,
       std::complex<float>* q2,
       const long int* ldq2,
       float* ws,
       long int* indxp,
       long int* indx,
       const long int* indxq,
       long int* perm,
       long int* givptr,
       long int* givcol,
       float* givnum,
       long int* info)
  */
  /*! fn
   inline void laed8(
       long int* k,
       const long int* n,
       const long int* qsiz,
       const std::complex<double>* q,
       const long int* ldq,
       const double* d,
       double* rho,
       const long int* cutpnt,
       const double* z,
       double* dlamda,
       std::complex<double>* q2,
       const long int* ldq2,
       double* ws,
       long int* indxp,
       long int* indx,
       const long int* indxq,
       long int* perm,
       long int* givptr,
       long int* givcol,
       double* givnum,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laed8(
       long int* k,
       const long int* n,
       const long int* qsiz,
       const std::complex<double>* q,
       const long int* ldq,
       const double* d,
       double* rho,
       const long int* cutpnt,
       const double* z,
       double* dlamda,
       std::complex<double>* q2,
       const long int* ldq2,
       double* ws,
       long int* indxp,
       long int* indx,
       const long int* indxq,
       long int* perm,
       long int* givptr,
       long int* givcol,
       double* givnum,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claed8.f)
  //    *  INDXP  (workspace) long int array, dimension (N)
  //    *         This will contain the permutation used to place deflated
  //    *         values of D at the end of the array. On output INDXP(1:K)
  //    *         points to the nondeflated D-values and INDXP(K+1:N)
  //    *         points to the deflated eigenvalues.
  //    *
  //    *  INDX   (workspace) long int array, dimension (N)
  //    *         This will contain the permutation used to sort the contents of
  //    *         D into ascending order.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED8(NAME, T, TBASE)\
inline void laed8(\
    long int* k,\
    const long int* n,\
    const long int* qsiz,\
    const T* q,\
    const long int* ldq,\
    const TBASE* d,\
    TBASE* rho,\
    const long int* cutpnt,\
    const TBASE* z,\
    TBASE* dlamda,\
    T* q2,\
    const long int* ldq2,\
    TBASE* ws,\
    long int* indxp,\
    long int* indx,\
    const long int* indxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    TBASE* givnum,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(k, n, qsiz, q, ldq, d, rho, cutpnt, z, dlamda, q2, ldq2, ws, indxp, indx, indxq, perm, givptr, givcol, givnum, info);\
}\
inline void laed8(\
    long int* k,\
    const long int* n,\
    const long int* qsiz,\
    const T* q,\
    const long int* ldq,\
    const TBASE* d,\
    TBASE* rho,\
    const long int* cutpnt,\
    const TBASE* z,\
    TBASE* dlamda,\
    T* q2,\
    const long int* ldq2,\
    TBASE* ws,\
    long int* indxp,\
    long int* indx,\
    const long int* indxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    TBASE* givnum,\
    long int* info)\
{\
   workspace<T> w;\
   laed8(k, n, qsiz, q, ldq, d, rho, cutpnt, z, dlamda, q2, ldq2, ws, indxp, indx, indxq, perm, givptr, givcol, givnum, info, w);\
}\

    LPP_LAED8(claed8, std::complex<float>,  float)
    LPP_LAED8(zlaed8, std::complex<double>, double)

#undef LPP_LAED8



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed8_itf.hh
// /////////////////////////////////////////////////////////////////////////////
