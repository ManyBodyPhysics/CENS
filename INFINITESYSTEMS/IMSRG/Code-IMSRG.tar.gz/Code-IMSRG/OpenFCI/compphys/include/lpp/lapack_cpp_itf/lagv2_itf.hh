#ifndef __PROJECT__LPP__FILE__LAGV2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAGV2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lagv2_itf.hh C++ interface to LAPACK (s,d,c,z)lagv2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lagv2_itf.hh
    (excerpt adapted from xlagv2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlagv2 computes the generalized schur factorization of a BASE DATA TYPE 2-by-2
    **  matrix pencil (a,b) where b is upper triangular. this routine
    **  computes orthogonal (rotation) matrices given by csl, snl and csr,
    **  snr such that
    **
    **  1) if the pencil (a,b) has two BASE DATA TYPE eigenvalues (include 0/0 or 1/0
    **     types), then
    **
    **     [ a11 a12 ] := [  csl  snl ] [ a11 a12 ] [  csr -snr ]
    **     [  0  a22 ]    [ -snl  csl ] [ a21 a22 ] [  snr  csr ]
    **
    **     [ b11 b12 ] := [  csl  snl ] [ b11 b12 ] [  csr -snr ]
    **     [  0  b22 ]    [ -snl  csl ] [  0  b22 ] [  snr  csr ],
    **
    **  2) if the pencil (a,b) has a pair of DATA TYPE conjugate eigenvalues,
    **     then
    **
    **     [ a11 a12 ] := [  csl  snl ] [ a11 a12 ] [  csr -snr ]
    **     [ a21 a22 ]    [ -snl  csl ] [ a21 a22 ] [  snr  csr ]
    **
    **     [ b11  0  ] := [  csl  snl ] [ b11 b12 ] [  csr -snr ]
    **     [  0  b22 ]    [ -snl  csl ] [  0  b22 ] [  snr  csr ]
    **
    **     where b11 >= b22 > 0.
    **
    **
    **  arguments
    **  =========
    **
    **  a       (input/output) BASE DATA TYPE array, dimension (lda, 2)
    **          on entry, the 2 x 2 matrix a.
    **          on exit, a is overwritten by the ``a-part'' of the
    **          generalized schur form.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= 2.
    **
    **  b       (input/output) BASE DATA TYPE array, dimension (ldb, 2)
    **          on entry, the upper triangular 2 x 2 matrix b.
    **          on exit, b is overwritten by the ``b-part'' of the
    **          generalized schur form.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= 2.
    **
    **  alphar  (output) BASE DATA TYPE array, dimension (2)
    **  alphai  (output) BASE DATA TYPE array, dimension (2)
    **  beta    (output) BASE DATA TYPE array, dimension (2)
    **          (alphar(k)+i*alphai(k))/beta(k) are the eigenvalues of the
    **          pencil (a,b), k=1,2, i = sqrt(-1).  note that beta(k) may
    **          be zero.
    **
    **  csl     (output) BASE DATA TYPE
    **          the cosine of the left rotation matrix.
    **
    **  snl     (output) BASE DATA TYPE
    **          the sine of the left rotation matrix.
    **
    **  csr     (output) BASE DATA TYPE
    **          the cosine of the right rotation matrix.
    **
    **  snr     (output) BASE DATA TYPE
    **          the sine of the right rotation matrix.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     mark fahey, department of mathematics, univ. of kentucky, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lagv2(
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        float* csl,
        float* snl,
        float* csr,
        float* snr,
        workspace<float> & w)
  */
  /*! fn
   inline void lagv2(
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        float* csl,
        float* snl,
        float* csr,
        float* snr)
  */
  /*! fn
   inline void lagv2(
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        double* csl,
        double* snl,
        double* csr,
        double* snr,
        workspace<double> & w)
  */
  /*! fn
   inline void lagv2(
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        double* csl,
        double* snl,
        double* csr,
        double* snr)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slagv2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGV2(NAME, T)\
inline void lagv2(\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    T* csl,\
    T* snl,\
    T* csr,\
    T* snr,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(a, lda, b, ldb, alphar, alphai, beta, csl, snl, csr, snr);\
}\
inline void lagv2(\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    T* csl,\
    T* snl,\
    T* csr,\
    T* snr)\
{\
   workspace<T> w;\
   lagv2(a, lda, b, ldb, alphar, alphai, beta, csl, snl, csr, snr, w);\
}\

    LPP_LAGV2(slagv2, float)
    LPP_LAGV2(dlagv2, double)

#undef LPP_LAGV2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lagv2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
