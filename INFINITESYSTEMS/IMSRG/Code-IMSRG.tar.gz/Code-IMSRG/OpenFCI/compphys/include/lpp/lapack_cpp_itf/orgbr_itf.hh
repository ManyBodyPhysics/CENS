#ifndef __PROJECT__LPP__FILE__ORGBR_HH__INCLUDED
#define __PROJECT__LPP__FILE__ORGBR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : orgbr_itf.hh C++ interface to LAPACK (s,d,c,z)orgbr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file orgbr_itf.hh
    (excerpt adapted from xorgbr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xorgbr generates one of the BASE DATA TYPE orthogonal matrices q or p**t
    **  determined by dgebrd when reducing a BASE DATA TYPE matrix a to bidiagonal
    **  form: a = q * b * p**t.  q and p**t are defined as products of
    **  elementary reflectors h(i) or g(i) respectively.
    **
    **  if vect = 'q', a is assumed to have been an m-by-k matrix, and q
    **  is of order m:
    **  if m >= k, q = h(1) h(2) . . . h(k) and xorgbr returns the first n
    **  columns of q, where m >= n >= k;
    **  if m < k, q = h(1) h(2) . . . h(m-1) and xorgbr returns q as an
    **  m-by-m matrix.
    **
    **  if vect = 'p', a is assumed to have been a k-by-n matrix, and p**t
    **  is of order n:
    **  if k < n, p**t = g(k) . . . g(2) g(1) and xorgbr returns the first m
    **  rows of p**t, where n >= m >= k;
    **  if k >= n, p**t = g(n-1) . . . g(2) g(1) and xorgbr returns p**t as
    **  an n-by-n matrix.
    **
    **  arguments
    **  =========
    **
    **  vect    (input) char
    **          specifies whether the matrix q or the matrix p**t is
    **          required, as defined in the transformation applied by dgebrd:
    **          = 'q':  generate q;
    **          = 'p':  generate p**t.
    **
    **  m       (input) long int
    **          the number of rows of the matrix q or p**t to be returned.
    **          m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix q or p**t to be returned.
    **          n >= 0.
    **          if vect = 'q', m >= n >= min(m,k);
    **          if vect = 'p', n >= m >= min(n,k).
    **
    **  k       (input) long int
    **          if vect = 'q', the number of columns in the original m-by-k
    **          matrix reduced by dgebrd.
    **          if vect = 'p', the number of rows in the original k-by-n
    **          matrix reduced by dgebrd.
    **          k >= 0.
    **
    **  a       (input/output) BASE DATA TYPE array, dimension (lda,n)
    **          on entry, the vectors which define the elementary reflectors,
    **          as returned by dgebrd.
    **          on exit, the m-by-n matrix q or p**t.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  tau     (input) BASE DATA TYPE array, dimension
    **                                (min(m,k)) if vect = 'q'
    **                                (min(n,k)) if vect = 'p'
    **          tau(i) must contain the scalar factor of the elementary
    **          reflector h(i) or g(i), which determines q or p**t, as
    **          returned by dgebrd in its array argument tauq or taup.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void orgbr(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* k,
        float* a,
        const long int* lda,
        const float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void orgbr(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* k,
        float* a,
        const long int* lda,
        const float* tau,
        long int* info)
  */
  /*! fn
   inline void orgbr(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* k,
        double* a,
        const long int* lda,
        const double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void orgbr(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* k,
        double* a,
        const long int* lda,
        const double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sorgbr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,min(M,N)).
  //    *          For optimum performance LWORK >= min(M,N)*NB, where NB
  //    *          is the optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_ORGBR(NAME, T)\
inline void orgbr(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    T* a,\
    const long int* lda,\
    const T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(vect, m, n, k, a, lda, tau, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(vect, m, n, k, a, lda, tau, w.getw(), &w.neededsize(), info);\
}\
inline void orgbr(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    T* a,\
    const long int* lda,\
    const T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   orgbr(vect, m, n, k, a, lda, tau, info, w);\
}\

    LPP_ORGBR(sorgbr, float)
    LPP_ORGBR(dorgbr, double)

#undef LPP_ORGBR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of orgbr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
