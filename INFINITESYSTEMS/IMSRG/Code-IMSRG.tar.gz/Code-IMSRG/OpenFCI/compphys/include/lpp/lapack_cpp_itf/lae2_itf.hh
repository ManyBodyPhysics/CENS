#ifndef __PROJECT__LPP__FILE__LAE2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAE2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lae2_itf.hh C++ interface to LAPACK (s,d,c,z)lae2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lae2_itf.hh
    (excerpt adapted from xlae2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlae2  computes the eigenvalues of a 2-by-2 symmetric matrix
    **     [  a   b  ]
    **     [  b   c  ].
    **  on return, rt1 is the eigenvalue of larger absolute value, and rt2
    **  is the eigenvalue of smaller absolute value.
    **
    **  arguments
    **  =========
    **
    **  a       (input) BASE DATA TYPE
    **          the (1,1) element of the 2-by-2 matrix.
    **
    **  b       (input) BASE DATA TYPE
    **          the (1,2) and (2,1) elements of the 2-by-2 matrix.
    **
    **  c       (input) BASE DATA TYPE
    **          the (2,2) element of the 2-by-2 matrix.
    **
    **  rt1     (output) BASE DATA TYPE
    **          the eigenvalue of larger absolute value.
    **
    **  rt2     (output) BASE DATA TYPE
    **          the eigenvalue of smaller absolute value.
    **
    **  further details
    **  ===============
    **
    **  rt1 is accurate to a few ulps barring over/underflow.
    **
    **  rt2 may be inaccurate if there is massive cancellation in the
    **  determinant a*c-b*b; higher precision or correctly rounded or
    **  correctly truncated arithmetic would be needed to compute rt2
    **  accurately in all cases.
    **
    **  overflow is possible only if rt1 is within a factor of 5 of overflow.
    **  underflow is harmless if the input data is 0 or exceeds
    **     underflow_threshold / macheps.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lae2(
        const float* a,
        const float* b,
        const float* c,
        float* rt1,
        float* rt2,
        workspace<float> & w)
  */
  /*! fn
   inline void lae2(
        const float* a,
        const float* b,
        const float* c,
        float* rt1,
        float* rt2)
  */
  /*! fn
   inline void lae2(
        const double* a,
        const double* b,
        const double* c,
        double* rt1,
        double* rt2,
        workspace<double> & w)
  */
  /*! fn
   inline void lae2(
        const double* a,
        const double* b,
        const double* c,
        double* rt1,
        double* rt2)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slae2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAE2(NAME, T)\
inline void lae2(\
    const T* a,\
    const T* b,\
    const T* c,\
    T* rt1,\
    T* rt2,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(a, b, c, rt1, rt2);\
}\
inline void lae2(\
    const T* a,\
    const T* b,\
    const T* c,\
    T* rt1,\
    T* rt2)\
{\
   workspace<T> w;\
   lae2(a, b, c, rt1, rt2, w);\
}\

    LPP_LAE2(slae2, float)
    LPP_LAE2(dlae2, double)

#undef LPP_LAE2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lae2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
