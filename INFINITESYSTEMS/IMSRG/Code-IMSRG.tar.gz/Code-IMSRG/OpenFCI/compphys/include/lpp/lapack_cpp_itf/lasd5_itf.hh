#ifndef __PROJECT__LPP__FILE__LASD5_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD5_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd5_itf.hh C++ interface to LAPACK (s,d,c,z)lasd5
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd5_itf.hh
    (excerpt adapted from xlasd5.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this subroutine computes the square root of the i-th eigenvalue
    **  of a positive symmetric rank-one modification of a 2-by-2 diagonal
    **  matrix
    **
    **             diag( d ) * diag( d ) +  rho *  z * transpose(z) .
    **
    **  the diagonal entries in the array d are assumed to satisfy
    **
    **             0 <= d(i) < d(j)  for  i < j .
    **
    **  we also assume rho > 0 and that the euclidean norm of the vector
    **  z is one.
    **
    **  arguments
    **  =========
    **
    **  i      (input) long int
    **         the index of the eigenvalue to be computed.  i = 1 or i = 2.
    **
    **  d      (input) BASE DATA TYPE array, dimension ( 2 )
    **         the original eigenvalues.  we assume 0 <= d(1) < d(2).
    **
    **  z      (input) BASE DATA TYPE array, dimension ( 2 )
    **         the components of the updating vector.
    **
    **  delta  (output) BASE DATA TYPE array, dimension ( 2 )
    **         contains (d(j) - lambda_i) in its  j-th component.
    **         the vector delta contains the information necessary
    **         to construct the eigenvectors.
    **
    **  rho    (input) BASE DATA TYPE
    **         the scalar in the symmetric updating formula.
    **
    **  dsigma (output) BASE DATA TYPE
    **         the computed lambda_i, the i-th updated eigenvalue.
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ren-cang li, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd5(
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dsigma,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd5(
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dsigma)
  */
  /*! fn
   inline void lasd5(
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dsigma,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd5(
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dsigma)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd5.f)
  //    *  WORK   (workspace) DATA array, dimension ( 2 )
  //    *         WORK contains (D(j) + sigma_I) in its  j-th component.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD5(NAME, T)\
inline void lasd5(\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dsigma,\
    workspace<T> & w)\
{\
    w.resizew( 2 );\
    F77NAME( NAME )(i, d, z, delta, rho, dsigma, w.getw());\
}\
inline void lasd5(\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dsigma)   \
{\
   workspace<T> w;\
   lasd5(i, d, z, delta, rho, dsigma, w);\
}\

    LPP_LASD5(slasd5, float)
    LPP_LASD5(dlasd5, double)

#undef LPP_LASD5



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd5_itf.hh
// /////////////////////////////////////////////////////////////////////////////
