#ifndef __PROJECT__LPP__FILE__GELSY_HH__INCLUDED
#define __PROJECT__LPP__FILE__GELSY_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gelsy_itf.hh C++ interface to LAPACK (c,d,c,z)gelsy
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gelsy_itf.hh
    (excerpt adapted from xgelsy.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgelsy computes the minimum-norm solution to a DATA TYPE linear least
    **  squares problem:
    **      minimize || a * x - b ||
    **  using a complete orthogonal factorization of a.  a is an m-by-n
    **  matrix which may be rank-deficient.
    **
    **  several right hand side vectors b and solution vectors x can be
    **  handled in a single call; they are stored as the columns of the
    **  m-by-nrhs right hand side matrix b and the n-by-nrhs solution
    **  matrix x.
    **
    **  the routine first computes a qr factorization with column pivoting:
    **      a * p = q * [ r11 r12 ]
    **                  [  0  r22 ]
    **  with r11 defined as the largest leading submatrix whose estimated
    **  condition number is less than 1/rcond.  the order of r11, rank,
    **  is the effective rank of a.
    **
    **  then, r22 is considered to be negligible, and r12 is annihilated
    **  by unitary transformations from the right, arriving at the
    **  complete orthogonal factorization:
    **     a * p = q * [ t11 0 ] * z
    **                 [  0  0 ]
    **  the minimum-norm solution is then
    **     x = p * z' [ inv(t11)*q1'*b ]
    **                [        0       ]
    **  where q1 consists of the first rank columns of q.
    **
    **  this routine is basically identical to the original xgelsx except
    **  three differences:
    **    o the permutation of matrix b (the right hand side) is faster and
    **      more simple.
    **    o the call to the subroutine xgeqpf has been substituted by the
    **      the call to the subroutine xgeqp3. this subroutine is a blas-3
    **      version of the qr factorization with column pivoting.
    **    o matrix b (the right hand side) is updated with blas-3.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of
    **          columns of matrices b and x. nrhs >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, a has been overwritten by details of its
    **          complete orthogonal factorization.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the m-by-nrhs right hand side matrix b.
    **          on exit, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,m,n).
    **
    **  jpvt    (input/output) long int array, dimension (n)
    **          on entry, if jpvt(i) .ne. 0, the i-th column of a is permuted
    **          to the front of ap, otherwise column i is a free column.
    **          on exit, if jpvt(i) = k, then the i-th column of a*p
    **          was the k-th column of a.
    **
    **  rcond   (input) BASE DATA TYPE
    **          rcond is used to determine the effective rank of a, which
    **          is defined as the order of the largest leading triangular
    **          submatrix r11 in the qr factorization with pivoting of a,
    **          whose estimated condition number < 1/rcond.
    **
    **  rank    (output) long int
    **          the effective rank of a, i.e., the order of the submatrix
    **          r11.  this is the same as the order of the submatrix t11
    **          in the complete orthogonal factorization of a.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    a. petitet, computer science dept., univ. of tenn., knoxville, usa
    **    e. quintana-orti, depto. de informatica, universidad jaime i, spain
    **    g. quintana-orti, depto. de informatica, universidad jaime i, spain
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gelsy(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* jpvt,
        const float* rcond,
        long int* rank,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gelsy(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* jpvt,
        const float* rcond,
        long int* rank,
        long int* info)
  */
  /*! fn
   inline void gelsy(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* jpvt,
        const double* rcond,
        long int* rank,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gelsy(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* jpvt,
        const double* rcond,
        long int* rank,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgelsy.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          The unblocked strategy requires that:
  //    *             LWORK >= MAX( MN+3*N+1, 2*MN+NRHS ),
  //    *          where MN = min( M, N ).
  //    *          The block algorithm requires that:
  //    *             LWORK >= MAX( MN+2*N+NB*(N+1), 2*MN+NB*NRHS ),
  //    *          where NB is an upper bound on the blocksize returned
  //    *          by ILAENV for the routines SGEQP3, STZRZF, STZRQF, SORMQR,
  //    *          and SORMRZ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELSY(NAME, T)\
inline void gelsy(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* jpvt,\
    const T* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, w.getw(), &w.neededsize(), info);\
}\
inline void gelsy(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* jpvt,\
    const T* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   gelsy(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, info, w);\
}\

    LPP_GELSY(sgelsy, float)
    LPP_GELSY(dgelsy, double)

#undef LPP_GELSY


  // The following macro provides the 4 functions 
  /*! fn
   inline void gelsy(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* jpvt,
       const float* rcond,
       long int* rank,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gelsy(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* jpvt,
       const float* rcond,
       long int* rank,
       long int* info)
  */
  /*! fn
   inline void gelsy(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* jpvt,
       const double* rcond,
       long int* rank,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gelsy(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* jpvt,
       const double* rcond,
       long int* rank,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgelsy.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          The unblocked strategy requires that:
  //    *            LWORK >= MN + MAX( 2*MN, N+1, MN+NRHS )
  //    *          where MN = min(M,N).
  //    *          The block algorithm requires that:
  //    *            LWORK >= MN + MAX( 2*MN, NB*(N+1), MN+MN*NB, MN+NB*NRHS )
  //    *          where NB is an upper bound on the blocksize returned
  //    *          by ILAENV for the routines CGEQP3, CTZRZF, CTZRQF, CUNMQR,
  //    *          and CUNMRZ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELSY(NAME, T, TBASE)\
inline void gelsy(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* jpvt,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(2**n);\
    F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void gelsy(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* jpvt,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   gelsy(m, n, nrhs, a, lda, b, ldb, jpvt, rcond, rank, info, w);\
}\

    LPP_GELSY(cgelsy, std::complex<float>,  float)
    LPP_GELSY(zgelsy, std::complex<double>, double)

#undef LPP_GELSY



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gelsy_itf.hh
// /////////////////////////////////////////////////////////////////////////////
