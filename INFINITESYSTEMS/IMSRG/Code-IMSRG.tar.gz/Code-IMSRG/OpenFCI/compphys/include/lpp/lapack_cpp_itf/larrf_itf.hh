#ifndef __PROJECT__LPP__FILE__LARRF_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARRF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larrf_itf.hh C++ interface to LAPACK (s,d,c,z)larrf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larrf_itf.hh
    (excerpt adapted from xlarrf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  given the initial representation l d l^t and its cluster of close
    **  eigenvalues (in a relative measure), w( ifirst ), w( ifirst+1 ), ...
    **  w( ilast ), xlarrf finds a new relatively robust representation
    **  l d l^t - sigma i = l(+) d(+) l(+)^t such that at least one of the
    **  eigenvalues of l(+) d(+) l(+)^t is relatively isolated.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d.
    **
    **  l       (input) BASE DATA TYPE array, dimension (n-1)
    **          the (n-1) subdiagonal elements of the unit bidiagonal
    **          matrix l.
    **
    **  ld      (input) BASE DATA TYPE array, dimension (n-1)
    **          the n-1 elements l(i)*d(i).
    **
    **  lld     (input) BASE DATA TYPE array, dimension (n-1)
    **          the n-1 elements l(i)*l(i)*d(i).
    **
    **  ifirst  (input) long int
    **          the index of the first eigenvalue in the cluster.
    **
    **  ilast   (input) long int
    **          the index of the last eigenvalue in the cluster.
    **
    **  w       (input/output) BASE DATA TYPE array, dimension (n)
    **          on input, the eigenvalues of l d l^t in ascending order.
    **          w( ifirst ) through w( ilast ) form the cluster of relatively
    **          close eigenalues.
    **          on output, w( ifirst ) thru' w( ilast ) are estimates of the
    **          corresponding eigenvalues of l(+) d(+) l(+)^t.
    **
    **  sigma   (input) BASE DATA TYPE
    **          the shift used to form l(+) d(+) l(+)^t.
    **
    **  dplus   (output) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d(+).
    **
    **  lplus   (output) BASE DATA TYPE array, dimension (n)
    **          the first (n-1) elements of lplus contain the subdiagonal
    **          elements of the unit bidiagonal matrix l(+). lplus( n ) is
    **          set to sigma.
    **
    **  WORK    (input) BASE DATA TYPE array, dimension (???)
    **          WORKspace.
    **
    **
    **  info    (output) long int (???) (jtl)
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larrf(
        const long int* n,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const long int* ifirst,
        const long int* ilast,
        float* ws,
        float* dplus,
        float* lplus,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void larrf(
        const long int* n,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const long int* ifirst,
        const long int* ilast,
        float* ws,
        float* dplus,
        float* lplus,
        long int* info)
  */
  /*! fn
   inline void larrf(
        const long int* n,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const long int* ifirst,
        const long int* ilast,
        double* ws,
        double* dplus,
        double* lplus,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void larrf(
        const long int* n,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const long int* ifirst,
        const long int* ilast,
        double* ws,
        double* dplus,
        double* lplus,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarrf.f)
  //    *  IWORK   (workspace) long int array, dimension (???) (JTL)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARRF(NAME, T)\
inline void larrf(\
    const long int* n,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const long int* ifirst,\
    const long int* ilast,\
    T* ws,\
    T* dplus,\
    T* lplus,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(*n);/* unknown */                                         \
  w.resizew(*n);/* unknown */                                          \
    F77NAME( NAME )(n, d, l, ld, lld, ifirst, ilast, ws, dplus, lplus, w.getw(), w.getiw(), info);\
}\
inline void larrf(\
    const long int* n,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const long int* ifirst,\
    const long int* ilast,\
    T* ws,\
    T* dplus,\
    T* lplus,\
    long int* info)\
{\
   workspace<T> w;\
   larrf(n, d, l, ld, lld, ifirst, ilast, ws, dplus, lplus, info, w);\
}\

    LPP_LARRF(slarrf, float)
    LPP_LARRF(dlarrf, double)

#undef LPP_LARRF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larrf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
