#ifndef __PROJECT__LPP__FILE__GETC2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GETC2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : getc2_itf.hh C++ interface to LAPACK (c,d,c,z)getc2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file getc2_itf.hh
    (excerpt adapted from xgetc2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgetc2 computes an lu factorization, using complete pivoting, of the
    **  n-by-n matrix a. the factorization has the form a = p * l * u * q,
    **  where p and q are permutation matrices, l is lower triangular with
    **  unit diagonal elements and u is upper triangular.
    **
    **  this is a level 1 blas version of the algorithm.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the n-by-n matrix to be factored.
    **          on exit, the factors l and u from the factorization
    **          a = p*l*u*q; the unit diagonal elements of l are not stored.
    **          if u(k, k) appears to be less than smin, u(k, k) is given the
    **          value of smin, giving a nonsingular perturbed system.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1, n).
    **
    **  ipiv    (output) long int array, dimension (n).
    **          the pivot indices; for 1 <= i <= n, row i of the
    **          matrix has been interchanged with row ipiv(i).
    **
    **  jpiv    (output) long int array, dimension (n).
    **          the pivot indices; for 1 <= j <= n, column j of the
    **          matrix has been interchanged with column jpiv(j).
    **
    **  info    (output) long int
    **           = 0: successful exit
    **           > 0: if info = k, u(k, k) is likely to produce overflow if
    **                one tries to solve for x in ax = b. so u is perturbed
    **                to avoid the overflow.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void getc2(
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* jpiv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void getc2(
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* jpiv,
        long int* info)
  */
  /*! fn
   inline void getc2(
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* jpiv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void getc2(
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* jpiv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgetc2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GETC2(NAME, T)\
inline void getc2(\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* jpiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, ipiv, jpiv, info);\
}\
inline void getc2(\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* jpiv,\
    long int* info)\
{\
   workspace<T> w;\
   getc2(n, a, lda, ipiv, jpiv, info, w);\
}\

    LPP_GETC2(sgetc2, float)
    LPP_GETC2(dgetc2, double)

#undef LPP_GETC2


  // The following macro provides the 4 functions 
  /*! fn
   inline void getc2(
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* jpiv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void getc2(
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* jpiv,
       long int* info)
  */
  /*! fn
   inline void getc2(
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* jpiv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void getc2(
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* jpiv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgetc2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GETC2(NAME, T, TBASE)\
inline void getc2(\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* jpiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, ipiv, jpiv, info);\
}\
inline void getc2(\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* jpiv,\
    long int* info)\
{\
   workspace<T> w;\
   getc2(n, a, lda, ipiv, jpiv, info, w);\
}\

    LPP_GETC2(cgetc2, std::complex<float>,  float)
    LPP_GETC2(zgetc2, std::complex<double>, double)

#undef LPP_GETC2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of getc2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
