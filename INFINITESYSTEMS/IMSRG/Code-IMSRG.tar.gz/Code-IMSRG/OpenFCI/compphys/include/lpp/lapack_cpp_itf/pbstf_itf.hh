#ifndef __PROJECT__LPP__FILE__PBSTF_HH__INCLUDED
#define __PROJECT__LPP__FILE__PBSTF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pbstf_itf.hh C++ interface to LAPACK (c,d,c,z)pbstf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pbstf_itf.hh
    (excerpt adapted from xpbstf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpbstf computes a split cholesky factorization of a DATA TYPE
    **  hermitian positive definite band matrix a.
    **
    **  this routine is designed to be used in conjunction with chbgst.
    **
    **  the factorization has the form  a = s**h*s  where s is a band matrix
    **  of the same bandwidth as a and the following structure:
    **
    **    s = ( u    )
    **        ( m  l )
    **
    **  where u is upper triangular of order m = (n+kd)/2, and l is lower
    **  triangular of order n-m.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kd >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the upper or lower triangle of the hermitian band
    **          matrix a, stored in the first kd+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **
    **          on exit, if info = 0, the factor s from the split cholesky
    **          factorization a = s**h*s. see further details.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, the factorization could not be completed,
    **               because the updated element a(i,i) was negative; the
    **               matrix a is not positive definite.
    **
    **  further details
    **  ===============
    **
    **  the band storage scheme is illustrated by the following example, when
    **  n = 7, kd = 2:
    **
    **  s = ( s11  s12  s13                     )
    **      (      s22  s23  s24                )
    **      (           s33  s34                )
    **      (                s44                )
    **      (           s53  s54  s55           )
    **      (                s64  s65  s66      )
    **      (                     s75  s76  s77 )
    **
    **  if uplo = 'u', the array ab holds:
    **
    **  on entry:                          on exit:
    **
    **   *    *   a13  a24  a35  a46  a57   *    *   s13  s24  s53' s64' s75'
    **   *   a12  a23  a34  a45  a56  a67   *   s12  s23  s34  s54' s65' s76'
    **  a11  a22  a33  a44  a55  a66  a77  s11  s22  s33  s44  s55  s66  s77
    **
    **  if uplo = 'l', the array ab holds:
    **
    **  on entry:                          on exit:
    **
    **  a11  a22  a33  a44  a55  a66  a77  s11  s22  s33  s44  s55  s66  s77
    **  a21  a32  a43  a54  a65  a76   *   s12' s23' s34' s54  s65  s76   *
    **  a31  a42  a53  a64  a64   *    *   s13' s24' s53  s64  s75   *    *
    **
    **  array elements marked * are not used by the routine; s12' denotes
    **  conjg(s12); the diagonal elements of s are BASE DATA TYPE.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pbstf(
        const char* uplo,
        const long int* n,
        const long int* kd,
        float* ab,
        const long int* ldab,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pbstf(
        const char* uplo,
        const long int* n,
        const long int* kd,
        float* ab,
        const long int* ldab,
        long int* info)
  */
  /*! fn
   inline void pbstf(
        const char* uplo,
        const long int* n,
        const long int* kd,
        double* ab,
        const long int* ldab,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pbstf(
        const char* uplo,
        const long int* n,
        const long int* kd,
        double* ab,
        const long int* ldab,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spbstf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBSTF(NAME, T)\
inline void pbstf(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, info);\
}\
inline void pbstf(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info)\
{\
   workspace<T> w;\
   pbstf(uplo, n, kd, ab, ldab, info, w);\
}\

    LPP_PBSTF(spbstf, float)
    LPP_PBSTF(dpbstf, double)

#undef LPP_PBSTF


  // The following macro provides the 4 functions 
  /*! fn
   inline void pbstf(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pbstf(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<float>* ab,
       const long int* ldab,
       long int* info)
  */
  /*! fn
   inline void pbstf(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pbstf(
       const char* uplo,
       const long int* n,
       const long int* kd,
       std::complex<double>* ab,
       const long int* ldab,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpbstf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBSTF(NAME, T, TBASE)\
inline void pbstf(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, info);\
}\
inline void pbstf(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    T* ab,\
    const long int* ldab,\
    long int* info)\
{\
   workspace<T> w;\
   pbstf(uplo, n, kd, ab, ldab, info, w);\
}\

    LPP_PBSTF(cpbstf, std::complex<float>,  float)
    LPP_PBSTF(zpbstf, std::complex<double>, double)

#undef LPP_PBSTF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pbstf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
