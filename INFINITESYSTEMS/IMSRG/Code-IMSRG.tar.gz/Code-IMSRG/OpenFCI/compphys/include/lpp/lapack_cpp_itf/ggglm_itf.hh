#ifndef __PROJECT__LPP__FILE__GGGLM_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGGLM_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggglm_itf.hh C++ interface to LAPACK (c,d,c,z)ggglm
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggglm_itf.hh
    (excerpt adapted from xggglm.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggglm solves a general gauss-markov linear model (glm) problem:
    **
    **          minimize || y ||_2   subject to   d = a*x + b*y
    **              x
    **
    **  where a is an n-by-m matrix, b is an n-by-p matrix, and d is a
    **  given n-vector. it is assumed that m <= n <= m+p, and
    **
    **             rank(a) = m    and    rank( a b ) = n.
    **
    **  under these assumptions, the constrained equation is always
    **  consistent, and there is a unique solution x and a minimal 2-norm
    **  solution y, which is obtained using a generalized qr factorization
    **  of a and b.
    **
    **  in particular, if matrix b is square nonsingular, then the problem
    **  glm is equivalent to the following weighted linear least squares
    **  problem
    **
    **               minimize || inv(b)*(z-a*x) ||_2
    **                   x
    **
    **  where inv(b) denotes the inverse of b.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of rows of the matrices a and b.  n >= 0.
    **
    **  m       (input) long int
    **          the number of columns of the matrix a.  0 <= m <= n.
    **
    **  p       (input) long int
    **          the number of columns of the matrix b.  p >= n-m.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,m)
    **          on entry, the n-by-m matrix a.
    **          on exit, a is destroyed.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,p)
    **          on entry, the n-by-p matrix b.
    **          on exit, b is destroyed.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  d       (input/output) DATA TYPE array, dimension (n)
    **          on entry, d is the left hand side of the glm equation.
    **          on exit, d is destroyed.
    **
    **  x       (output) DATA TYPE array, dimension (m)
    **  y       (output) DATA TYPE array, dimension (p)
    **          on exit, x and y are the solutions of the glm problem.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  ===================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggglm(
        const long int* n,
        const long int* m,
        const long int* p,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* d,
        float* x,
        float* y,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggglm(
        const long int* n,
        const long int* m,
        const long int* p,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* d,
        float* x,
        float* y,
        long int* info)
  */
  /*! fn
   inline void ggglm(
        const long int* n,
        const long int* m,
        const long int* p,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* d,
        double* x,
        double* y,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggglm(
        const long int* n,
        const long int* m,
        const long int* p,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* d,
        double* x,
        double* y,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggglm.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N+M+P).
  //    *          For optimum performance, LWORK >= M+min(N,P)+max(N,P)*NB,
  //    *          where NB is an upper bound for the optimal blocksizes for
  //    *          SGEQRF, SGERQF, SORMQR and SORMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGGLM(NAME, T)\
inline void ggglm(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* d,\
    T* x,\
    T* y,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, m, p, a, lda, b, ldb, d, x, y, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, m, p, a, lda, b, ldb, d, x, y, w.getw(), &w.neededsize(), info);\
}\
inline void ggglm(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* d,\
    T* x,\
    T* y,\
    long int* info)\
{\
   workspace<T> w;\
   ggglm(n, m, p, a, lda, b, ldb, d, x, y, info, w);\
}\

    LPP_GGGLM(sggglm, float)
    LPP_GGGLM(dggglm, double)

#undef LPP_GGGLM


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggglm(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* d,
       std::complex<float>* x,
       std::complex<float>* y,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggglm(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* d,
       std::complex<float>* x,
       std::complex<float>* y,
       long int* info)
  */
  /*! fn
   inline void ggglm(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* d,
       std::complex<double>* x,
       std::complex<double>* y,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggglm(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* d,
       std::complex<double>* x,
       std::complex<double>* y,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggglm.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N+M+P).
  //    *          For optimum performance, LWORK >= M+min(N,P)+max(N,P)*NB,
  //    *          where NB is an upper bound for the optimal blocksizes for
  //    *          CGEQRF, CGERQF, CUNMQR and CUNMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGGLM(NAME, T, TBASE)\
inline void ggglm(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* d,\
    T* x,\
    T* y,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, m, p, a, lda, b, ldb, d, x, y, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, m, p, a, lda, b, ldb, d, x, y, w.getw(), &w.neededsize(), info);\
}\
inline void ggglm(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* d,\
    T* x,\
    T* y,\
    long int* info)\
{\
   workspace<T> w;\
   ggglm(n, m, p, a, lda, b, ldb, d, x, y, info, w);\
}\

    LPP_GGGLM(cggglm, std::complex<float>,  float)
    LPP_GGGLM(zggglm, std::complex<double>, double)

#undef LPP_GGGLM



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggglm_itf.hh
// /////////////////////////////////////////////////////////////////////////////
