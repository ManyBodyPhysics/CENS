#ifndef __PROJECT__LPP__FILE__GTRFS_HH__INCLUDED
#define __PROJECT__LPP__FILE__GTRFS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gtrfs_itf.hh C++ interface to LAPACK (s,d,c,z)gtrfs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gtrfs_itf.hh
    (excerpt adapted from xgtrfs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgtrfs improves the computed solution to a system of linear
    **  equations when the coefficient matrix is tridiagonal, and provides
    **  error bounds and backward error estimates for the solution.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) char
    **          specifies the form of the system of equations:
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  dl      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) subdiagonal elements of a.
    **
    **  d       (input) DATA TYPE array, dimension (n)
    **          the diagonal elements of a.
    **
    **  du      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) superdiagonal elements of a.
    **
    **  dlf     (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) multipliers that define the matrix l from the
    **          lu factorization of a as computed by cgttrf.
    **
    **  df      (input) DATA TYPE array, dimension (n)
    **          the n diagonal elements of the upper triangular matrix u from
    **          the lu factorization of a.
    **
    **  duf     (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) elements of the first superdiagonal of u.
    **
    **  du2     (input) DATA TYPE array, dimension (n-2)
    **          the (n-2) elements of the second superdiagonal of u.
    **
    **  ipiv    (input) long int array, dimension (n)
    **          the pivot indices; for 1 <= i <= n, row i of the matrix was
    **          interchanged with row ipiv(i).  ipiv(i) will always be either
    **          i or i+1; ipiv(i) = i indicates a row interchange was not
    **          required.
    **
    **  b       (input) DATA TYPE array, dimension (ldb,nrhs)
    **          the right hand side matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (input/output) DATA TYPE array, dimension (ldx,nrhs)
    **          on entry, the solution matrix x, as computed by cgttrs.
    **          on exit, the improved solution matrix x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the estimated forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).  the estimate is as reliable as
    **          the estimate for rcond, and is almost always a slight
    **          overestimate of the true error.
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  internal parameters
    **  ===================
    **
    **  itmax is the maximum number of steps of iterative refinement.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gtrfs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* dlf,
        const float* df,
        const float* duf,
        const float* du2,
        const long int* ipiv,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gtrfs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* dlf,
        const float* df,
        const float* duf,
        const float* du2,
        const long int* ipiv,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void gtrfs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* dlf,
        const double* df,
        const double* duf,
        const double* du2,
        const long int* ipiv,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gtrfs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* dlf,
        const double* df,
        const double* duf,
        const double* du2,
        const long int* ipiv,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgtrfs.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTRFS(NAME, T)\
inline void gtrfs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* dlf,\
    const T* df,\
    const T* duf,\
    const T* du2,\
    const long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*n);\
    w.resizew(3**n);\
    F77NAME( NAME )(trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, ferr, berr, w.getw(), w.getiw(), info);\
}\
inline void gtrfs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* dlf,\
    const T* df,\
    const T* duf,\
    const T* du2,\
    const long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   gtrfs(trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_GTRFS(sgtrfs, float)
    LPP_GTRFS(dgtrfs, double)

#undef LPP_GTRFS


  // The following macro provides the 4 functions 
  /*! fn
   inline void gtrfs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* dlf,
       const std::complex<float>* df,
       const std::complex<float>* duf,
       const std::complex<float>* du2,
       const long int* ipiv,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gtrfs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* dlf,
       const std::complex<float>* df,
       const std::complex<float>* duf,
       const std::complex<float>* du2,
       const long int* ipiv,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void gtrfs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* dlf,
       const std::complex<double>* df,
       const std::complex<double>* duf,
       const std::complex<double>* du2,
       const long int* ipiv,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gtrfs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* dlf,
       const std::complex<double>* df,
       const std::complex<double>* duf,
       const std::complex<double>* du2,
       const long int* ipiv,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgtrfs.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTRFS(NAME, T, TBASE)\
inline void gtrfs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* dlf,\
    const T* df,\
    const T* duf,\
    const T* du2,\
    const long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(*n);\
    w.resizew(2**n);\
    F77NAME( NAME )(trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, ferr, berr, w.getw(), w.getrw(), info);\
}\
inline void gtrfs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* dlf,\
    const T* df,\
    const T* duf,\
    const T* du2,\
    const long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   gtrfs(trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_GTRFS(cgtrfs, std::complex<float>, float)
    LPP_GTRFS(zgtrfs, std::complex<double>, double)

#undef LPP_GTRFS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gtrfs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
