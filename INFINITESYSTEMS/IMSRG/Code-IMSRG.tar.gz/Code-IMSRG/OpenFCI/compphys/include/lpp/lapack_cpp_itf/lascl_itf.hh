#ifndef __PROJECT__LPP__FILE__LASCL_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASCL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lascl_itf.hh C++ interface to LAPACK (c,d,c,z)lascl
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lascl_itf.hh
    (excerpt adapted from xlascl.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlascl multiplies the m by n DATA TYPE matrix a by the BASE DATA TYPE scalar
    **  cto/cfrom.  this is done without over/underflow as long as the final
    **  result cto*a(i,j)/cfrom does not over/underflow. type specifies that
    **  a may be full, upper triangular, lower triangular, upper hessenberg,
    **  or banded.
    **
    **  arguments
    **  =========
    **
    **  type    (input) char
    **          type indices the storage type of the input matrix.
    **          = 'g':  a is a full matrix.
    **          = 'l':  a is a lower triangular matrix.
    **          = 'u':  a is an upper triangular matrix.
    **          = 'h':  a is an upper hessenberg matrix.
    **          = 'b':  a is a symmetric band matrix with lower bandwidth kl
    **                  and upper bandwidth ku and with the only the lower
    **                  half stored.
    **          = 'q':  a is a symmetric band matrix with lower bandwidth kl
    **                  and upper bandwidth ku and with the only the upper
    **                  half stored.
    **          = 'z':  a is a band matrix with lower bandwidth kl and upper
    **                  bandwidth ku.
    **
    **  kl      (input) long int
    **          the lower bandwidth of a.  referenced only if type = 'b',
    **          'q' or 'z'.
    **
    **  ku      (input) long int
    **          the upper bandwidth of a.  referenced only if type = 'b',
    **          'q' or 'z'.
    **
    **  cfrom   (input) BASE DATA TYPE
    **  cto     (input) BASE DATA TYPE
    **          the matrix a is multiplied by cto/cfrom. a(i,j) is computed
    **          without over/underflow if the final result cto*a(i,j)/cfrom
    **          can be represented without over/underflow.  cfrom must be
    **          nonzero.
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,m)
    **          the matrix to be multiplied by cto/cfrom.  see type for the
    **          storage type.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  info    (output) long int
    **          0  - successful exit
    **          <0 - if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lascl(
        const char* type,
        const long int* kl,
        const long int* ku,
        const float* cfrom,
        const float* cto,
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lascl(
        const char* type,
        const long int* kl,
        const long int* ku,
        const float* cfrom,
        const float* cto,
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info)
  */
  /*! fn
   inline void lascl(
        const char* type,
        const long int* kl,
        const long int* ku,
        const double* cfrom,
        const double* cto,
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lascl(
        const char* type,
        const long int* kl,
        const long int* ku,
        const double* cfrom,
        const double* cto,
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slascl.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASCL(NAME, T)\
inline void lascl(\
    const char* type,\
    const long int* kl,\
    const long int* ku,\
    const T* cfrom,\
    const T* cto,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(type, kl, ku, cfrom, cto, m, n, a, lda, info);\
}\
inline void lascl(\
    const char* type,\
    const long int* kl,\
    const long int* ku,\
    const T* cfrom,\
    const T* cto,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   lascl(type, kl, ku, cfrom, cto, m, n, a, lda, info, w);\
}\

    LPP_LASCL(slascl, float)
    LPP_LASCL(dlascl, double)

#undef LPP_LASCL


  // The following macro provides the 4 functions 
  /*! fn
   inline void lascl(
       const char* type,
       const long int* kl,
       const long int* ku,
       const float* cfrom,
       const float* cto,
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lascl(
       const char* type,
       const long int* kl,
       const long int* ku,
       const float* cfrom,
       const float* cto,
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info)
  */
  /*! fn
   inline void lascl(
       const char* type,
       const long int* kl,
       const long int* ku,
       const double* cfrom,
       const double* cto,
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lascl(
       const char* type,
       const long int* kl,
       const long int* ku,
       const double* cfrom,
       const double* cto,
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clascl.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASCL(NAME, T, TBASE)\
inline void lascl(\
    const char* type,\
    const long int* kl,\
    const long int* ku,\
    const TBASE* cfrom,\
    const TBASE* cto,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(type, kl, ku, cfrom, cto, m, n, a, lda, info);\
}\
inline void lascl(\
    const char* type,\
    const long int* kl,\
    const long int* ku,\
    const TBASE* cfrom,\
    const TBASE* cto,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   lascl(type, kl, ku, cfrom, cto, m, n, a, lda, info, w);\
}\

    LPP_LASCL(clascl, std::complex<float>,  float)
    LPP_LASCL(zlascl, std::complex<double>, double)

#undef LPP_LASCL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lascl_itf.hh
// /////////////////////////////////////////////////////////////////////////////
