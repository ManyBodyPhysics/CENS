#ifndef __PROJECT__LPP__FILE__LARUV_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARUV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laruv_itf.hh C++ interface to LAPACK (s,d,c,z)laruv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laruv_itf.hh
    (excerpt adapted from xlaruv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaruv returns a vector of n random BASE DATA TYPE numbers from a uniform (0,1)
    **  distribution (n <= 128).
    **
    **  this is an auxiliary routine called by dlarnv and zlarnv.
    **
    **  arguments
    **  =========
    **
    **  iseed   (input/output) long int array, dimension (4)
    **          on entry, the seed of the random number generator; the array
    **          elements must be between 0 and 4095, and iseed(4) must be
    **          odd.
    **          on exit, the seed is updated.
    **
    **  n       (input) long int
    **          the number of random numbers to be generated. n <= 128.
    **
    **  x       (output) BASE DATA TYPE array, dimension (n)
    **          the generated random numbers.
    **
    **  further details
    **  ===============
    **
    **  this routine uses a multiplicative congruential method with modulus
    **  2**48 and multiplier 33952834046453 (see g.s.fishman,
    **  'multiplicative congruential random number generators with modulus
    **  2**b: an exhaustive analysis for b = 32 and a partial analysis for
    **  b = 48', math. comp. 189, pp 331-344, 1990).
    **
    **  48-bit integers are stored in 4 integer array elements with 12 bits
    **  per element. hence the routine is portable across machines with
    **  integers of 32 bits or more.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laruv(
        long int* iseed,
        const long int* n,
        float* x,
        workspace<float> & w)
  */
  /*! fn
   inline void laruv(
        long int* iseed,
        const long int* n,
        float* x)
  */
  /*! fn
   inline void laruv(
        long int* iseed,
        const long int* n,
        double* x,
        workspace<double> & w)
  */
  /*! fn
   inline void laruv(
        long int* iseed,
        const long int* n,
        double* x)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaruv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARUV(NAME, T)\
inline void laruv(\
    long int* iseed,\
    const long int* n,\
    T* x,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(iseed, n, x);\
}\
inline void laruv(\
    long int* iseed,\
    const long int* n,\
    T* x)\
{\
   workspace<T> w;\
   laruv(iseed, n, x, w);\
}\

    LPP_LARUV(slaruv, float)
    LPP_LARUV(dlaruv, double)

#undef LPP_LARUV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laruv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
