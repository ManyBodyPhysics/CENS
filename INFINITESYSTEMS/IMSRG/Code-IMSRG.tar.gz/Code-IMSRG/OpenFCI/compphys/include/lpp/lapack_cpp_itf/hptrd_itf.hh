#ifndef __PROJECT__LPP__FILE__HPTRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__HPTRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hptrd_itf.hh C++ interface to LAPACK (c,d,c,z)hptrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hptrd_itf.hh
    (excerpt adapted from xhptrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhptrd reduces a DATA TYPE hermitian matrix a stored in packed form to
    **  BASE DATA TYPE symmetric tridiagonal form t by a unitary similarity
    **  transformation: q**h * a * q = t.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the hermitian matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2*n-j)/2) = a(i,j) for j<=i<=n.
    **          on exit, if uplo = 'u', the diagonal and first superdiagonal
    **          of a are overwritten by the corresponding elements of the
    **          tridiagonal matrix t, and the elements above the first
    **          superdiagonal, with the array tau, represent the unitary
    **          matrix q as a product of elementary reflectors; if uplo
    **          = 'l', the diagonal and first subdiagonal of a are over-
    **          written by the corresponding elements of the tridiagonal
    **          matrix t, and the elements below the first subdiagonal, with
    **          the array tau, represent the unitary matrix q as a product
    **          of elementary reflectors. see further details.
    **
    **  d       (output) BASE DATA TYPE array, dimension (n)
    **          the diagonal elements of the tridiagonal matrix t:
    **          d(i) = a(i,i).
    **
    **  e       (output) BASE DATA TYPE array, dimension (n-1)
    **          the off-diagonal elements of the tridiagonal matrix t:
    **          e(i) = a(i,i+1) if uplo = 'u', e(i) = a(i+1,i) if uplo = 'l'.
    **
    **  tau     (output) DATA TYPE array, dimension (n-1)
    **          the scalar factors of the elementary reflectors (see further
    **          details).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  if uplo = 'u', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(n-1) . . . h(2) h(1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(i+1:n) = 0 and v(i) = 1; v(1:i-1) is stored on exit in ap,
    **  overwriting a(1:i-1,i+1), and tau is stored in tau(i).
    **
    **  if uplo = 'l', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(1) h(2) . . . h(n-1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i) = 0 and v(i+1) = 1; v(i+2:n) is stored on exit in ap,
    **  overwriting a(i+2:n,i), and tau is stored in tau(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hptrd(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       float* d,
       float* e,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hptrd(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       float* d,
       float* e,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void hptrd(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       double* d,
       double* e,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hptrd(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       double* d,
       double* e,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chptrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_HPTRD(NAME, T, TBASE)\
inline void hptrd(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    TBASE* d,\
    TBASE* e,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, ap, d, e, tau, info);\
}\
inline void hptrd(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    TBASE* d,\
    TBASE* e,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   hptrd(uplo, n, ap, d, e, tau, info, w);\
}\

    LPP_HPTRD(chptrd, std::complex<float>,  float)
    LPP_HPTRD(zhptrd, std::complex<double>, double)

#undef LPP_HPTRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hptrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
