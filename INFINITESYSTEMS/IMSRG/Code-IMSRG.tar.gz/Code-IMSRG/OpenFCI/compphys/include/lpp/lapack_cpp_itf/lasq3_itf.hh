#ifndef __PROJECT__LPP__FILE__LASQ3_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASQ3_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasq3_itf.hh C++ interface to LAPACK (s,d,c,z)lasq3
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasq3_itf.hh
    (excerpt adapted from xlasq3.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasq3 checks for deflation, computes a shift (tau) and calls dqds.
    **  in case of failure it changes shifts, and tries again until output
    **  is positive.
    **
    **  arguments
    **  =========
    **
    **  i0     (input) long int
    **         first index.
    **
    **  n0     (input) long int
    **         last index.
    **
    **  z      (input) BASE DATA TYPE array, dimension ( 4*n )
    **         z holds the qd array.
    **
    **  pp     (input) long int
    **         pp=0 for ping, pp=1 for pong.
    **
    **  dmin   (output) BASE DATA TYPE
    **         minimum value of d.
    **
    **  sigma  (output) BASE DATA TYPE
    **         sum of shifts used in current segment.
    **
    **  desig  (input/output) BASE DATA TYPE
    **         lower order part of sigma
    **
    **  qmax   (input) BASE DATA TYPE
    **         maximum value of q.
    **
    **  nfail  (output) long int
    **         number of times shift was too big.
    **
    **  iter   (output) long int
    **         number of iterations.
    **
    **  ndiv   (output) long int
    **         number of divisions.
    **
    **  ttype  (output) long int
    **         shift type.
    **
    **  ieee   (input) logical
    **         flag for ieee or non ieee arithmetic (passed to dlasq5).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasq3(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        float* dmin,
        float* sigma,
        float* desig,
        const float* qmax,
        long int* nfail,
        long int* iter,
        long int* ndiv,
        const long int* ieee,
        workspace<float> & w)
  */
  /*! fn
   inline void lasq3(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        float* dmin,
        float* sigma,
        float* desig,
        const float* qmax,
        long int* nfail,
        long int* iter,
        long int* ndiv,
        const long int* ieee)
  */
  /*! fn
   inline void lasq3(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        double* dmin,
        double* sigma,
        double* desig,
        const double* qmax,
        long int* nfail,
        long int* iter,
        long int* ndiv,
        const long int* ieee,
        workspace<double> & w)
  */
  /*! fn
   inline void lasq3(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        double* dmin,
        double* sigma,
        double* desig,
        const double* qmax,
        long int* nfail,
        long int* iter,
        long int* ndiv,
        const long int* ieee)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasq3.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASQ3(NAME, T)\
inline void lasq3(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    T* dmin,\
    T* sigma,\
    T* desig,\
    const T* qmax,\
    long int* nfail,\
    long int* iter,\
    long int* ndiv,\
    const long int* ieee,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(i0, n0, z, pp, dmin, sigma, desig, qmax, nfail, iter, ndiv, ieee);\
}\
inline void lasq3(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    T* dmin,\
    T* sigma,\
    T* desig,\
    const T* qmax,\
    long int* nfail,\
    long int* iter,\
    long int* ndiv,\
    const long int* ieee)\
{\
   workspace<T> w;\
   lasq3(i0, n0, z, pp, dmin, sigma, desig, qmax, nfail, iter, ndiv, ieee, w);\
}\

    LPP_LASQ3(slasq3, float)
    LPP_LASQ3(dlasq3, double)

#undef LPP_LASQ3



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasq3_itf.hh
// /////////////////////////////////////////////////////////////////////////////
