#ifndef __PROJECT__LPP__FILE__TGSNA_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGSNA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgsna_itf.hh C++ interface to LAPACK (s,d,c,z)tgsna
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgsna_itf.hh
    (excerpt adapted from xtgsna.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgsna estimates reciprocal condition numbers for specified
    **  eigenvalues and/or eigenvectors of a matrix pair (a, b).
    **
    **  (a, b) must be in generalized schur canonical form, that is, a and
    **  b are both upper triangular.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies whether condition numbers are required for
    **          eigenvalues (s) or eigenvectors (dif):
    **          = 'e': for eigenvalues only (s);
    **          = 'v': for eigenvectors only (dif);
    **          = 'b': for both eigenvalues and eigenvectors (s and dif).
    **
    **  howmny  (input) char
    **          = 'a': compute condition numbers for all eigenpairs;
    **          = 's': compute condition numbers for selected eigenpairs
    **                 specified by the array select.
    **
    **  select  (input) logical array, dimension (n)
    **          if howmny = 's', select specifies the eigenpairs for which
    **          condition numbers are required. to select condition numbers
    **          for the corresponding j-th eigenvalue and/or eigenvector,
    **          select(j) must be set to .true..
    **          if howmny = 'a', select is not referenced.
    **
    **  n       (input) long int
    **          the order of the square matrix pair (a, b). n >= 0.
    **
    **  a       (input) DATA TYPE array, dimension (lda,n)
    **          the upper triangular matrix a in the pair (a,b).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input) DATA TYPE array, dimension (ldb,n)
    **          the upper triangular matrix b in the pair (a, b).
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  vl      (input) DATA TYPE array, dimension (ldvl,m)
    **          if job = 'e' or 'b', vl must contain left eigenvectors of
    **          (a, b), corresponding to the eigenpairs specified by howmny
    **          and select.  the eigenvectors must be stored in consecutive
    **          columns of vl, as returned by ctgevc.
    **          if job = 'v', vl is not referenced.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the array vl. ldvl >= 1; and
    **          if job = 'e' or 'b', ldvl >= n.
    **
    **  vr      (input) DATA TYPE array, dimension (ldvr,m)
    **          if job = 'e' or 'b', vr must contain right eigenvectors of
    **          (a, b), corresponding to the eigenpairs specified by howmny
    **          and select.  the eigenvectors must be stored in consecutive
    **          columns of vr, as returned by ctgevc.
    **          if job = 'v', vr is not referenced.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr. ldvr >= 1;
    **          if job = 'e' or 'b', ldvr >= n.
    **
    **  s       (output) BASE DATA TYPE array, dimension (mm)
    **          if job = 'e' or 'b', the reciprocal condition numbers of the
    **          selected eigenvalues, stored in consecutive elements of the
    **          array.
    **          if job = 'v', s is not referenced.
    **
    **  dif     (output) BASE DATA TYPE array, dimension (mm)
    **          if job = 'v' or 'b', the estimated reciprocal condition
    **          numbers of the selected eigenvectors, stored in consecutive
    **          elements of the array.
    **          if the eigenvalues cannot be reordered to compute dif(j),
    **          dif(j) is set to 0; this can only occur when the true value
    **          would be very small anyway.
    **          for each eigenvalue/vector specified by select, dif stores
    **          a frobenius norm-based estimate of difl.
    **          if job = 'e', dif is not referenced.
    **
    **  mm      (input) long int
    **          the number of elements in the arrays s and dif. mm >= m.
    **
    **  m       (output) long int
    **          the number of elements of the arrays s and dif used to store
    **          the specified condition numbers; for each selected eigenvalue
    **          one element is used. if howmny = 'a', m is set to n.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the reciprocal of the condition number of the i-th generalized
    **  eigenvalue w = (a, b) is defined as
    **
    **          s(i) = (|v'au|**2 + |v'bu|**2)**(1/2) / (norm(u)*norm(v))
    **
    **  where u and v are the right and left eigenvectors of (a, b)
    **  corresponding to w; |z| denotes the absolute value of the DATA TYPE
    **  number, and norm(u) denotes the 2-norm of the vector u. the pair
    **  (a, b) corresponds to an eigenvalue w = a/b (= v'au/v'bu) of the
    **  matrix pair (a, b). if both a and b equal zero, then (a,b) is
    **  singular and s(i) = -1 is returned.
    **
    **  an approximate error bound on the chordal distance between the i-th
    **  computed generalized eigenvalue w and the corresponding exact
    **  eigenvalue lambda is
    **
    **          chord(w, lambda) <=   eps * norm(a, b) / s(i),
    **
    **  where eps is the machine precision.
    **
    **  the reciprocal of the condition number of the right eigenvector u
    **  and left eigenvector v corresponding to the generalized eigenvalue w
    **  is defined as follows. suppose
    **
    **                   (a, b) = ( a   *  ) ( b  *  )  1
    **                            ( 0  a22 ),( 0 b22 )  n-1
    **                              1  n-1     1 n-1
    **
    **  then the reciprocal condition number dif(i) is
    **
    **          difl[(a, b), (a22, b22)]  = sigma-min( zl )
    **
    **  where sigma-min(zl) denotes the smallest singular value of
    **
    **         zl = [ kron(a, in-1) -kron(1, a22) ]
    **              [ kron(b, in-1) -kron(1, b22) ].
    **
    **  here in-1 is the identity matrix of size n-1 and x' is the conjugate
    **  transpose of x. kron(x, y) is the kronecker product between the
    **  matrices x and y.
    **
    **  we approximate the smallest singular value of zl with an upper
    **  bound. this is done by clatdf.
    **
    **  an approximate error bound for a computed eigenvector vl(i) or
    **  vr(i) is given by
    **
    **                      eps * norm(a, b) / dif(i).
    **
    **  see ref. [2-3] for more details and further references.
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  references
    **  ==========
    **
    **  [1] b. kagstrom; a direct method for reordering eigenvalues in the
    **      generalized BASE DATA TYPE schur form of a regular matrix pair (a, b), in
    **      m.s. moonen et al (eds), linear algebra for large scale and
    **      BASE DATA TYPE-time applications, kluwer academic publ. 1993, pp 195-218.
    **
    **  [2] b. kagstrom and p. poromaa; computing eigenspaces with specified
    **      eigenvalues of a regular matrix pair (a, b) and condition
    **      estimation: theory, algorithms and software, report
    **      uminf - 94.04, department of computing science, umea university,
    **      s-901 87 umea, sweden, 1994. also as lapack WORKing note 87.
    **      to appear in numerical algorithms, 1996.
    **
    **  [3] b. kagstrom and p. poromaa, lapack-style algorithms and software
    **      for solving the generalized sylvester equation and estimating the
    **      separation between regular matrix pairs, report uminf - 93.23,
    **      department of computing science, umea university, s-901 87 umea,
    **      sweden, december 1993, revised april 1994, also as lapack WORKing
    **      note 75.
    **      to appear in acm trans. on math. software, vol 22, no 1, 1996.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        const float* s,
        float* dif,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        const float* s,
        float* dif,
        const long int* mm,
        const long int* m,
        long int* info)
  */
  /*! fn
   inline void tgsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        const double* s,
        double* dif,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        const double* s,
        double* dif,
        const long int* mm,
        const long int* m,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgsna.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          If JOB = 'E', WORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= N.
  //    *          If JOB = 'V' or 'B' LWORK >= 2*N*(N+2)+16.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N + 6)
  //    *          If JOB = 'E', IWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSNA(NAME, T)\
inline void tgsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const T* s,\
    T* dif,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n) + 6);\
    F77NAME( NAME )(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, w.getw(), w.query(), w.getiw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, w.getw(), &w.neededsize(), w.getiw(), info);\
}\
inline void tgsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const T* s,\
    T* dif,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   tgsna(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, info, w);\
}\

    LPP_TGSNA(stgsna, float)
    LPP_TGSNA(dtgsna, double)

#undef LPP_TGSNA


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       const float* s,
       float* dif,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       const float* s,
       float* dif,
       const long int* mm,
       const long int* m,
       long int* info)
  */
  /*! fn
   inline void tgsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       const double* s,
       double* dif,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       const double* s,
       double* dif,
       const long int* mm,
       const long int* m,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgsna.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          If JOB = 'E', WORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK  (input) long int
  //    *          The dimension of the array WORK. LWORK >= 1.
  //    *          If JOB = 'V' or 'B', LWORK >= 2*N*N.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N+2)
  //    *          If JOB = 'E', IWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSNA(NAME, T, TBASE)\
inline void tgsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const TBASE* s,\
    TBASE* dif,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n)+2);\
    F77NAME( NAME )(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, w.getw(), w.query(), w.getiw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, w.getw(), &w.neededsize(), w.getiw(), info);\
}\
inline void tgsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const TBASE* s,\
    TBASE* dif,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   tgsna(job, howmny, select, n, a, lda, b, ldb, vl, ldvl, vr, ldvr, s, dif, mm, m, info, w);\
}\

    LPP_TGSNA(ctgsna, std::complex<float>, float)
    LPP_TGSNA(ztgsna, std::complex<double>, double)

#undef LPP_TGSNA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgsna_itf.hh
// /////////////////////////////////////////////////////////////////////////////
