#ifndef __PROJECT__LPP__FILE__LASD1_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD1_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd1_itf.hh C++ interface to LAPACK (s,d,c,z)lasd1
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd1_itf.hh
    (excerpt adapted from xlasd1.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd1 computes the svd of an upper bidiagonal n-by-m matrix b,
    **  where n = nl + nr + 1 and m = n + sqre. xlasd1 is called from dlasd0.
    **
    **  a related subroutine dlasd7 handles the case in which the singular
    **  values (and the singular vectors in factored form) are desired.
    **
    **  xlasd1 computes the svd as follows:
    **
    **                ( d1(in)  0    0     0 )
    **    b = u(in) * (   z1'   a   z2'    b ) * vt(in)
    **                (   0     0   d2(in) 0 )
    **
    **      = u(out) * ( d(out) 0) * vt(out)
    **
    **  where z' = (z1' a z2' b) = u' vt', and u is a vector of dimension m
    **  with alpha and beta in the nl+1 and nl+2 th entries and zeros
    **  elsewhere; and the entry b is empty if sqre = 0.
    **
    **  the left singular vectors of the original matrix are stored in u, and
    **  the transpose of the right singular vectors are stored in vt, and the
    **  singular values are in d.  the algorithm consists of three stages:
    **
    **     the first stage consists of deflating the size of the problem
    **     when there are multiple singular values or when there are zeros in
    **     the z vector.  for each such occurence the dimension of the
    **     secular equation problem is reduced by one.  this stage is
    **     performed by the routine dlasd2.
    **
    **     the second stage consists of calculating the updated
    **     singular values. this is done by finding the square roots of the
    **     roots of the secular equation via the routine dlasd4 (as called
    **     by dlasd3). this routine also calculates the singular vectors of
    **     the current problem.
    **
    **     the final stage consists of computing the updated singular vectors
    **     directly using the updated singular values.  the singular vectors
    **     for the current problem are multiplied with the singular vectors
    **     from the overall problem.
    **
    **  arguments
    **  =========
    **
    **  nl     (input) long int
    **         the row dimension of the upper block.  nl >= 1.
    **
    **  nr     (input) long int
    **         the row dimension of the lower block.  nr >= 1.
    **
    **  sqre   (input) long int
    **         = 0: the lower block is an nr-by-nr square matrix.
    **         = 1: the lower block is an nr-by-(nr+1) rectangular matrix.
    **
    **         the bidiagonal matrix has row dimension n = nl + nr + 1,
    **         and column dimension m = n + sqre.
    **
    **  d      (input/output) BASE DATA TYPE array,
    **                        dimension (n = nl+nr+1).
    **         on entry d(1:nl,1:nl) contains the singular values of the
    **         upper block; and d(nl+2:n) contains the singular values of
    **         the lower block. on exit d(1:n) contains the singular values
    **         of the modified matrix.
    **
    **  alpha  (input) BASE DATA TYPE
    **         contains the diagonal element associated with the added row.
    **
    **  beta   (input) BASE DATA TYPE
    **         contains the off-diagonal element associated with the added
    **         row.
    **
    **  u      (input/output) BASE DATA TYPE array, dimension(ldu,n)
    **         on entry u(1:nl, 1:nl) contains the left singular vectors of
    **         the upper block; u(nl+2:n, nl+2:n) contains the left singular
    **         vectors of the lower block. on exit u contains the left
    **         singular vectors of the bidiagonal matrix.
    **
    **  ldu    (input) long int
    **         the leading dimension of the array u.  ldu >= max( 1, n ).
    **
    **  vt     (input/output) BASE DATA TYPE array, dimension(ldvt,m)
    **         where m = n + sqre.
    **         on entry vt(1:nl+1, 1:nl+1)' contains the right singular
    **         vectors of the upper block; vt(nl+2:m, nl+2:m)' contains
    **         the right singular vectors of the lower block. on exit
    **         vt' contains the right singular vectors of the
    **         bidiagonal matrix.
    **
    **  ldvt   (input) long int
    **         the leading dimension of the array vt.  ldvt >= max( 1, m ).
    **
    **  idxq  (output) long int array, dimension(n)
    **         this contains the permutation which will reintegrate the
    **         subproblem just solved back into sorted order, i.e.
    **         d( idxq( i = 1, n ) ) will be in ascending order.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd1(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        float* d,
        const float* alpha,
        const float* beta,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        long int* idxq,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd1(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        float* d,
        const float* alpha,
        const float* beta,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        long int* idxq,
        long int* info)
  */
  /*! fn
   inline void lasd1(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        double* d,
        const double* alpha,
        const double* beta,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        long int* idxq,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd1(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        double* d,
        const double* alpha,
        const double* beta,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        long int* idxq,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd1.f)
  //    *  IWORK  (workspace) long int array, dimension( 4 * N )
  //    *
  //    *  WORK   (workspace) float array, dimension( 3*M**2 + 2*M )
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD1(NAME, T)\
inline void lasd1(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    T* d,\
    const T* alpha,\
    const T* beta,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* idxq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*nl);/*A VERIFIER*/\
    w.resizew( 3*(*nr)*(*nr) + 2*(*nr) );/*A VERIFIER*/                    \
    F77NAME( NAME )(nl, nr, sqre, d, alpha, beta, u, ldu, vt, ldvt, idxq, w.getiw(), w.getw(), info);\
}\
inline void lasd1(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    T* d,\
    const T* alpha,\
    const T* beta,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* idxq,\
    long int* info)\
{\
   workspace<T> w;\
   lasd1(nl, nr, sqre, d, alpha, beta, u, ldu, vt, ldvt, idxq, info, w);\
}\

    LPP_LASD1(slasd1, float)
    LPP_LASD1(dlasd1, double)

#undef LPP_LASD1



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd1_itf.hh
// /////////////////////////////////////////////////////////////////////////////
