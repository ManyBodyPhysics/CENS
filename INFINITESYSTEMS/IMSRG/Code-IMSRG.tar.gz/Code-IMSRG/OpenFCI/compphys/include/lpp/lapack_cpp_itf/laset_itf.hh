#ifndef __PROJECT__LPP__FILE__LASET_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASET_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laset_itf.hh C++ interface to LAPACK (c,d,c,z)laset
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laset_itf.hh
    (excerpt adapted from xlaset.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaset initializes a 2-d array a to beta on the diagonal and
    **  alpha on the offdiagonals.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies the part of the matrix a to be set.
    **          = 'u':      upper triangular part is set. the lower triangle
    **                      is unchanged.
    **          = 'l':      lower triangular part is set. the upper triangle
    **                      is unchanged.
    **          otherwise:  all of the matrix a is set.
    **
    **  m       (input) long int
    **          on entry, m specifies the number of rows of a.
    **
    **  n       (input) long int
    **          on entry, n specifies the number of columns of a.
    **
    **  alpha   (input) DATA TYPE
    **          all the offdiagonal array elements are set to alpha.
    **
    **  beta    (input) DATA TYPE
    **          all the diagonal array elements are set to beta.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m by n matrix a.
    **          on exit, a(i,j) = alpha, 1 <= i <= m, 1 <= j <= n, i.ne.j;
    **                   a(i,i) = beta , 1 <= i <= min(m,n)
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laset(
        const char* uplo,
        const long int* m,
        const long int* n,
        const float* alpha,
        const float* beta,
        const float* a,
        const long int* lda,
        workspace<float> & w)
  */
  /*! fn
   inline void laset(
        const char* uplo,
        const long int* m,
        const long int* n,
        const float* alpha,
        const float* beta,
        const float* a,
        const long int* lda)
  */
  /*! fn
   inline void laset(
        const char* uplo,
        const long int* m,
        const long int* n,
        const double* alpha,
        const double* beta,
        const double* a,
        const long int* lda,
        workspace<double> & w)
  */
  /*! fn
   inline void laset(
        const char* uplo,
        const long int* m,
        const long int* n,
        const double* alpha,
        const double* beta,
        const double* a,
        const long int* lda)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaset.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASET(NAME, T)\
inline void laset(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* alpha,\
    const T* beta,\
    const T* a,\
    const long int* lda,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, m, n, alpha, beta, a, lda);\
}\
inline void laset(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* alpha,\
    const T* beta,\
    const T* a,\
    const long int* lda)\
{\
   workspace<T> w;\
   laset(uplo, m, n, alpha, beta, a, lda, w);\
}\

    LPP_LASET(slaset, float)
    LPP_LASET(dlaset, double)

#undef LPP_LASET


  // The following macro provides the 4 functions 
  /*! fn
   inline void laset(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<float>* alpha,
       const std::complex<float>* beta,
       const std::complex<float>* a,
       const long int* lda,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laset(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<float>* alpha,
       const std::complex<float>* beta,
       const std::complex<float>* a,
       const long int* lda)
  */
  /*! fn
   inline void laset(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<double>* alpha,
       const std::complex<double>* beta,
       const std::complex<double>* a,
       const long int* lda,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laset(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<double>* alpha,
       const std::complex<double>* beta,
       const std::complex<double>* a,
       const long int* lda)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claset.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASET(NAME, T, TBASE)\
inline void laset(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* alpha,\
    const T* beta,\
    const T* a,\
    const long int* lda,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, m, n, alpha, beta, a, lda);\
}\
inline void laset(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* alpha,\
    const T* beta,\
    const T* a,\
    const long int* lda)\
{\
   workspace<T> w;\
   laset(uplo, m, n, alpha, beta, a, lda, w);\
}\

    LPP_LASET(claset, std::complex<float>,  float)
    LPP_LASET(zlaset, std::complex<double>, double)

#undef LPP_LASET



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laset_itf.hh
// /////////////////////////////////////////////////////////////////////////////
