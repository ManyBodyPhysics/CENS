#ifndef __PROJECT__LPP__FILE__LARZB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARZB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larzb_itf.hh C++ interface to LAPACK (c,d,c,z)larzb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larzb_itf.hh
    (excerpt adapted from xlarzb.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarzb applies a DATA TYPE block reflector h or its transpose h**h
    **  to a DATA TYPE distributed m-by-n  c from the left or the right.
    **
    **  currently, only storev = 'r' and direct = 'b' are supported.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'l': apply h or h' from the left
    **          = 'r': apply h or h' from the right
    **
    **  trans   (input) char
    **          = 'n': apply h (no transpose)
    **          = 'c': apply h' (conjugate transpose)
    **
    **  direct  (input) char
    **          indicates how h is formed from a product of elementary
    **          reflectors
    **          = 'f': h = h(1) h(2) . . . h(k) (forward, not supported yet)
    **          = 'b': h = h(k) . . . h(2) h(1) (backward)
    **
    **  storev  (input) char
    **          indicates how the vectors which define the elementary
    **          reflectors are stored:
    **          = 'c': columnwise                        (not supported yet)
    **          = 'r': rowwise
    **
    **  m       (input) long int
    **          the number of rows of the matrix c.
    **
    **  n       (input) long int
    **          the number of columns of the matrix c.
    **
    **  k       (input) long int
    **          the order of the matrix t (= the number of elementary
    **          reflectors whose product defines the block reflector).
    **
    **  l       (input) long int
    **          the number of columns of the matrix v containing the
    **          meaningful part of the householder reflectors.
    **          if side = 'l', m >= l >= 0, if side = 'r', n >= l >= 0.
    **
    **  v       (input) DATA TYPE array, dimension (ldv,nv).
    **          if storev = 'c', nv = k; if storev = 'r', nv = l.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v.
    **          if storev = 'c', ldv >= l; if storev = 'r', ldv >= k.
    **
    **  t       (input) DATA TYPE array, dimension (ldt,k)
    **          the triangular k-by-k matrix t in the representation of the
    **          block reflector.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= k.
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n matrix c.
    **          on exit, c is overwritten by h*c or h'*c or c*h or c*h'.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m).
    **
    **
    **  ldWORK  (input) long int
    **          the leading dimension of the array WORK.
    **          if side = 'l', ldWORK >= max(1,n);
    **          if side = 'r', ldWORK >= max(1,m).
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    a. petitet, computer science dept., univ. of tenn., knoxville, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larzb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const long int* l,
        const float* v,
        const long int* ldv,
        const float* t,
        const long int* ldt,
        const float* c,
        const long int* ldc,
        workspace<float> & w)
  */
  /*! fn
   inline void larzb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const long int* l,
        const float* v,
        const long int* ldv,
        const float* t,
        const long int* ldt,
        const float* c,
        const long int* ldc)
  */
  /*! fn
   inline void larzb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const long int* l,
        const double* v,
        const long int* ldv,
        const double* t,
        const long int* ldt,
        const double* c,
        const long int* ldc,
        workspace<double> & w)
  */
  /*! fn
   inline void larzb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const long int* l,
        const double* v,
        const long int* ldv,
        const double* t,
        const long int* ldt,
        const double* c,
        const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarzb.f)
  //    *  WORK    (workspace) float array, dimension (LDWORK,K)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZB(NAME, T)\
inline void larzb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w.getw(), w.query());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w.getw(), &w.neededsize());\
}\
inline void larzb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc)                       \
{\
   workspace<T> w;\
   larzb(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w);\
}\

    LPP_LARZB(slarzb, float)
    LPP_LARZB(dlarzb, double)

#undef LPP_LARZB


  // The following macro provides the 4 functions 
  /*! fn
   inline void larzb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const long int* l,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* c,
       const long int* ldc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larzb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const long int* l,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* c,
       const long int* ldc)
  */
  /*! fn
   inline void larzb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const long int* l,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* c,
       const long int* ldc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larzb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const long int* l,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* c,
       const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarzb.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (LDWORK,K)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZB(NAME, T, TBASE)\
inline void larzb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w.getw(), w.query());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w.getw(), &w.neededsize());\
}\
inline void larzb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc)                       \
{\
   workspace<T> w;\
   larzb(side, trans, direct, storev, m, n, k, l, v, ldv, t, ldt, c, ldc, w);\
}\

    LPP_LARZB(clarzb, std::complex<float>,  float)
    LPP_LARZB(zlarzb, std::complex<double>, double)

#undef LPP_LARZB



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larzb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
