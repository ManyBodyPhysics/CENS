#ifndef __PROJECT__LPP__FILE__GTTRS_HH__INCLUDED
#define __PROJECT__LPP__FILE__GTTRS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gttrs_itf.hh C++ interface to LAPACK (c,d,c,z)gttrs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gttrs_itf.hh
    (excerpt adapted from xgttrs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgttrs solves one of the systems of equations
    **     a * x = b,  a**t * x = b,  or  a**h * x = b,
    **  with a tridiagonal matrix a using the lu factorization computed
    **  by cgttrf.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) character
    **          specifies the form of the system of equations.
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  n       (input) long int
    **          the order of the matrix a.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  dl      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) multipliers that define the matrix l from the
    **          lu factorization of a.
    **
    **  d       (input) DATA TYPE array, dimension (n)
    **          the n diagonal elements of the upper triangular matrix u from
    **          the lu factorization of a.
    **
    **  du      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) elements of the first super-diagonal of u.
    **
    **  du2     (input) DATA TYPE array, dimension (n-2)
    **          the (n-2) elements of the second super-diagonal of u.
    **
    **  ipiv    (input) long int array, dimension (n)
    **          the pivot indices; for 1 <= i <= n, row i of the matrix was
    **          interchanged with row ipiv(i).  ipiv(i) will always be either
    **          i or i+1; ipiv(i) = i indicates a row interchange was not
    **          required.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the matrix of right hand side vectors b.
    **          on exit, b is overwritten by the solution vectors x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -k, the k-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gttrs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* du2,
        const long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gttrs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* du2,
        const long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void gttrs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* du2,
        const long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gttrs(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* du2,
        const long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgttrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTTRS(NAME, T)\
inline void gttrs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, info);\
}\
inline void gttrs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gttrs(trans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, info, w);\
}\

    LPP_GTTRS(sgttrs, float)
    LPP_GTTRS(dgttrs, double)

#undef LPP_GTTRS


  // The following macro provides the 4 functions 
  /*! fn
   inline void gttrs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* du2,
       const long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gttrs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* du2,
       const long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void gttrs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* du2,
       const long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gttrs(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* du2,
       const long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgttrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTTRS(NAME, T, TBASE)\
inline void gttrs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, info);\
}\
inline void gttrs(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gttrs(trans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, info, w);\
}\

    LPP_GTTRS(cgttrs, std::complex<float>,  float)
    LPP_GTTRS(zgttrs, std::complex<double>, double)

#undef LPP_GTTRS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gttrs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
