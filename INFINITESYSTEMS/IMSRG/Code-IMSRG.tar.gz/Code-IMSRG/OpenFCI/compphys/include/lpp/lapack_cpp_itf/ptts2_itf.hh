#ifndef __PROJECT__LPP__FILE__PTTS2_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTTS2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ptts2_itf.hh C++ interface to LAPACK (c,d,c,z)ptts2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ptts2_itf.hh
    (excerpt adapted from xptts2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xptts2 solves a tridiagonal system of the form
    **     a * x = b
    **  using the factorization a = u'*d*u or a = l*d*l' computed by cpttrf.
    **  d is a diagonal matrix specified in the vector d, u (or l) is a unit
    **  bidiagonal matrix whose superdiagonal (subdiagonal) is specified in
    **  the vector e, and x and b are n by nrhs matrices.
    **
    **  arguments
    **  =========
    **
    **  iuplo   (input) long int
    **          specifies the form of the factorization and whether the
    **          vector e is the superdiagonal of the upper bidiagonal factor
    **          u or the subdiagonal of the lower bidiagonal factor l.
    **          = 1:  a = u'*d*u, e is the superdiagonal of u
    **          = 0:  a = l*d*l', e is the subdiagonal of l
    **
    **  n       (input) long int
    **          the order of the tridiagonal matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d from the
    **          factorization a = u'*d*u or a = l*d*l'.
    **
    **  e       (input) DATA TYPE array, dimension (n-1)
    **          if iuplo = 1, the (n-1) superdiagonal elements of the unit
    **          bidiagonal factor u from the factorization a = u'*d*u.
    **          if iuplo = 0, the (n-1) subdiagonal elements of the unit
    **          bidiagonal factor l from the factorization a = l*d*l'.
    **
    **  b       (input/output) BASE DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the right hand side vectors b for the system of
    **          linear equations.
    **          on exit, the solution vectors, x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ptts2(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        float* b,
        const long int* ldb,
        workspace<float> & w)
  */
  /*! fn
   inline void ptts2(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        float* b,
        const long int* ldb)
  */
  /*! fn
   inline void ptts2(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        double* b,
        const long int* ldb,
        workspace<double> & w)
  */
  /*! fn
   inline void ptts2(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        double* b,
        const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sptts2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTS2(NAME, T)\
inline void ptts2(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, nrhs, d, e, b, ldb);\
}\
inline void ptts2(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   ptts2(n, nrhs, d, e, b, ldb, w);\
}\

    LPP_PTTS2(sptts2, float)
    LPP_PTTS2(dptts2, double)

#undef LPP_PTTS2


  // The following macro provides the 4 functions 
  /*! fn
   inline void ptts2(
       const long int* iuplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ptts2(
       const long int* iuplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb)
  */
  /*! fn
   inline void ptts2(
       const long int* iuplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ptts2(
       const long int* iuplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cptts2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTS2(NAME, T, TBASE)\
inline void ptts2(\
    const long int* iuplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(iuplo, n, nrhs, d, e, b, ldb);\
}\
inline void ptts2(\
    const long int* iuplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   ptts2(iuplo, n, nrhs, d, e, b, ldb, w);\
}\

    LPP_PTTS2(cptts2, std::complex<float>,  float)
    LPP_PTTS2(zptts2, std::complex<double>, double)

#undef LPP_PTTS2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ptts2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
