#ifndef __PROJECT__LPP__FILE__LAEIN_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAEIN_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laein_itf.hh C++ interface to LAPACK (s,d,c,z)laein
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laein_itf.hh
    (excerpt adapted from xlaein.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaein uses inverse iteration to find a right or left eigenvector
    **  corresponding to the eigenvalue w of a DATA TYPE upper hessenberg
    **  matrix h.
    **
    **  arguments
    **  =========
    **
    **  rightv   (input) logical
    **          = .true. : compute right eigenvector;
    **          = .false.: compute left eigenvector.
    **
    **  noinit   (input) logical
    **          = .true. : no initial vector supplied in v
    **          = .false.: initial vector supplied in v.
    **
    **  n       (input) long int
    **          the order of the matrix h.  n >= 0.
    **
    **  h       (input) DATA TYPE array, dimension (ldh,n)
    **          the upper hessenberg matrix h.
    **
    **  ldh     (input) long int
    **          the leading dimension of the array h.  ldh >= max(1,n).
    **
    **  w       (input) DATA TYPE
    **          the eigenvalue of h whose corresponding right or left
    **          eigenvector is to be computed.
    **
    **  v       (input/output) DATA TYPE array, dimension (n)
    **          on entry, if noinit = .false., v must contain a starting
    **          vector for inverse iteration; otherwise v need not be set.
    **          on exit, v contains the computed eigenvector, normalized so
    **          that the component of largest magnitude has magnitude 1; here
    **          the magnitude of a DATA TYPE number (x,y) is taken to be
    **          |x| + |y|.
    **
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **
    **  eps3    (input) BASE DATA TYPE
    **          a small machine-dependent value which is used to perturb
    **          close eigenvalues, and to replace zero pivots.
    **
    **  smlnum  (input) BASE DATA TYPE
    **          a machine-dependent value close to the underflow threshold.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          = 1:  inverse iteration did not converge; v is set to the
    **                last iterate.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laein(
        const long int* rightv,
        const long int* noinit,
        const long int* n,
        const float* h,
        const long int* ldh,
        const float* wr,
        const float* wi,
        float* vr,
        float* vi,
        float* b,
        const long int* ldb,
        const float* eps3,
        const float* smlnum,
        const float* bignum,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laein(
        const long int* rightv,
        const long int* noinit,
        const long int* n,
        const float* h,
        const long int* ldh,
        const float* wr,
        const float* wi,
        float* vr,
        float* vi,
        float* b,
        const long int* ldb,
        const float* eps3,
        const float* smlnum,
        const float* bignum,
        long int* info)
  */
  /*! fn
   inline void laein(
        const long int* rightv,
        const long int* noinit,
        const long int* n,
        const double* h,
        const long int* ldh,
        const double* wr,
        const double* wi,
        double* vr,
        double* vi,
        double* b,
        const long int* ldb,
        const double* eps3,
        const double* smlnum,
        const double* bignum,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laein(
        const long int* rightv,
        const long int* noinit,
        const long int* n,
        const double* h,
        const long int* ldh,
        const double* wr,
        const double* wi,
        double* vr,
        double* vi,
        double* b,
        const long int* ldb,
        const double* eps3,
        const double* smlnum,
        const double* bignum,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaein.f)
  //    *  B       (workspace) float array, dimension (LDB,N)
  //    *
  //    *  WORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAEIN(NAME, T)\
inline void laein(\
    const long int* rightv,\
    const long int* noinit,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    const T* wr,\
    const T* wi,\
    T* vr,\
    T* vi,\
    T* b,\
    const long int* ldb,\
    const T* eps3,\
    const T* smlnum,\
    const T* bignum,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(rightv, noinit, n, h, ldh, wr, wi, vr, vi, b, ldb, w.getw(), eps3, smlnum, bignum, info);\
}\
inline void laein(\
    const long int* rightv,\
    const long int* noinit,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    const T* wr,\
    const T* wi,\
    T* vr,\
    T* vi,\
    T* b,\
    const long int* ldb,\
    const T* eps3,\
    const T* smlnum,\
    const T* bignum,\
    long int* info)\
{\
   workspace<T> w;\
   laein(rightv, noinit, n, h, ldh, wr, wi, vr, vi, b, ldb, eps3, smlnum, bignum, info, w);\
}\

    LPP_LAEIN(slaein, float)
    LPP_LAEIN(dlaein, double)

#undef LPP_LAEIN


  // The following macro provides the 4 functions 
  /*! fn
   inline void laein(
       const long int* rightv,
       const long int* noinit,
       const long int* n,
       const std::complex<float>* h,
       const long int* ldh,
       const std::complex<float>* ws,
       const std::complex<float>* v,
       std::complex<float>* b,
       const long int* ldb,
       const float* eps3,
       const float* smlnum,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laein(
       const long int* rightv,
       const long int* noinit,
       const long int* n,
       const std::complex<float>* h,
       const long int* ldh,
       const std::complex<float>* ws,
       const std::complex<float>* v,
       std::complex<float>* b,
       const long int* ldb,
       const float* eps3,
       const float* smlnum,
       long int* info)
  */
  /*! fn
   inline void laein(
       const long int* rightv,
       const long int* noinit,
       const long int* n,
       const std::complex<double>* h,
       const long int* ldh,
       const std::complex<double>* ws,
       const std::complex<double>* v,
       std::complex<double>* b,
       const long int* ldb,
       const double* eps3,
       const double* smlnum,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laein(
       const long int* rightv,
       const long int* noinit,
       const long int* n,
       const std::complex<double>* h,
       const long int* ldh,
       const std::complex<double>* ws,
       const std::complex<double>* v,
       std::complex<double>* b,
       const long int* ldb,
       const double* eps3,
       const double* smlnum,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claein.f)
  //    *  B       (workspace) std::complex<float> array, dimension (LDB,N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAEIN(NAME, T, TBASE)\
inline void laein(\
    const long int* rightv,\
    const long int* noinit,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    const T* ws,\
    const T* v,\
    const TBASE* eps3,\
    const TBASE* smlnum,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew ((*n));\
    F77NAME( NAME )(rightv, noinit, n, h, ldh, ws, v, w.getw(), n, w.getrw(), eps3, smlnum, info); \
}\
inline void laein(\
    const long int* rightv,\
    const long int* noinit,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    const T* ws,\
    const T* v,\
    T* b,\
    const long int* ldb,\
    const TBASE* eps3,\
    const TBASE* smlnum,\
    long int* info)\
{\
   workspace<T> w;\
   laein(rightv, noinit, n, h, ldh, ws, v, eps3, smlnum, info, w);\
}\

    LPP_LAEIN(claein, std::complex<float>, float)
    LPP_LAEIN(zlaein, std::complex<double>, double)

#undef LPP_LAEIN



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laein_itf.hh
// /////////////////////////////////////////////////////////////////////////////
