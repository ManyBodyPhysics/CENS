#ifndef __PROJECT__LPP__FILE__LAGS2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAGS2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lags2_itf.hh C++ interface to LAPACK (c,d,c,z)lags2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lags2_itf.hh
    (excerpt adapted from xlags2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlags2 computes 2-by-2 unitary matrices u, v and q, such
    **  that if ( upper ) then
    **
    **            u'*a*q = u'*( a1 a2 )*q = ( x  0  )
    **                        ( 0  a3 )     ( x  x  )
    **  and
    **            v'*b*q = v'*( b1 b2 )*q = ( x  0  )
    **                        ( 0  b3 )     ( x  x  )
    **
    **  or if ( .not.upper ) then
    **
    **            u'*a*q = u'*( a1 0  )*q = ( x  x  )
    **                        ( a2 a3 )     ( 0  x  )
    **  and
    **            v'*b*q = v'*( b1 0  )*q = ( x  x  )
    **                        ( b2 b3 )     ( 0  x  )
    **  where
    **
    **    u = (     csu      snu ), v = (     csv     snv ),
    **        ( -conjg(snu)  csu )      ( -conjg(snv) csv )
    **
    **    q = (     csq      snq )
    **        ( -conjg(snq)  csq )
    **
    **  z' denotes the conjugate transpose of z.
    **
    **  the rows of the transformed a and b are parallel. moreover, if the
    **  input 2-by-2 matrix a is not zero, then the transformed (1,1) entry
    **  of a is not zero. if the input matrices a and b are both not zero,
    **  then the transformed (2,2) element of b is not zero, except when the
    **  first rows of input a and b are parallel and the second rows are
    **  zero.
    **
    **  arguments
    **  =========
    **
    **  upper   (input) logical
    **          = .true.: the input matrices a and b are upper triangular.
    **          = .false.: the input matrices a and b are lower triangular.
    **
    **  a1      (input) BASE DATA TYPE
    **  a2      (input) DATA TYPE
    **  a3      (input) BASE DATA TYPE
    **          on entry, a1, a2 and a3 are elements of the input 2-by-2
    **          upper (lower) triangular matrix a.
    **
    **  b1      (input) BASE DATA TYPE
    **  b2      (input) DATA TYPE
    **  b3      (input) BASE DATA TYPE
    **          on entry, b1, b2 and b3 are elements of the input 2-by-2
    **          upper (lower) triangular matrix b.
    **
    **  csu     (output) BASE DATA TYPE
    **  snu     (output) DATA TYPE
    **          the desired unitary matrix u.
    **
    **  csv     (output) BASE DATA TYPE
    **  snv     (output) DATA TYPE
    **          the desired unitary matrix v.
    **
    **  csq     (output) BASE DATA TYPE
    **  snq     (output) DATA TYPE
    **          the desired unitary matrix q.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lags2(
        const long int* upper,
        const float* a1,
        const float* a2,
        const float* a3,
        const float* b1,
        const float* b2,
        const float* b3,
        float* csu,
        float* snu,
        float* csv,
        float* snv,
        float* csq,
        float* snq,
        workspace<float> & w)
  */
  /*! fn
   inline void lags2(
        const long int* upper,
        const float* a1,
        const float* a2,
        const float* a3,
        const float* b1,
        const float* b2,
        const float* b3,
        float* csu,
        float* snu,
        float* csv,
        float* snv,
        float* csq,
        float* snq)
  */
  /*! fn
   inline void lags2(
        const long int* upper,
        const double* a1,
        const double* a2,
        const double* a3,
        const double* b1,
        const double* b2,
        const double* b3,
        double* csu,
        double* snu,
        double* csv,
        double* snv,
        double* csq,
        double* snq,
        workspace<double> & w)
  */
  /*! fn
   inline void lags2(
        const long int* upper,
        const double* a1,
        const double* a2,
        const double* a3,
        const double* b1,
        const double* b2,
        const double* b3,
        double* csu,
        double* snu,
        double* csv,
        double* snv,
        double* csq,
        double* snq)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slags2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGS2(NAME, T)\
inline void lags2(\
    const long int* upper,\
    const T* a1,\
    const T* a2,\
    const T* a3,\
    const T* b1,\
    const T* b2,\
    const T* b3,\
    T* csu,\
    T* snu,\
    T* csv,\
    T* snv,\
    T* csq,\
    T* snq,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(upper, a1, a2, a3, b1, b2, b3, csu, snu, csv, snv, csq, snq);\
}\
inline void lags2(\
    const long int* upper,\
    const T* a1,\
    const T* a2,\
    const T* a3,\
    const T* b1,\
    const T* b2,\
    const T* b3,\
    T* csu,\
    T* snu,\
    T* csv,\
    T* snv,\
    T* csq,\
    T* snq)\
{\
   workspace<T> w;\
   lags2(upper, a1, a2, a3, b1, b2, b3, csu, snu, csv, snv, csq, snq, w);\
}\

    LPP_LAGS2(slags2, float)
    LPP_LAGS2(dlags2, double)

#undef LPP_LAGS2


  // The following macro provides the 4 functions 
  /*! fn
   inline void lags2(
       const long int* upper,
       const float* a1,
       const std::complex<float>* a2,
       const float* a3,
       const float* b1,
       const std::complex<float>* b2,
       const float* b3,
       float* csu,
       std::complex<float>* snu,
       float* csv,
       std::complex<float>* snv,
       float* csq,
       std::complex<float>* snq,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lags2(
       const long int* upper,
       const float* a1,
       const std::complex<float>* a2,
       const float* a3,
       const float* b1,
       const std::complex<float>* b2,
       const float* b3,
       float* csu,
       std::complex<float>* snu,
       float* csv,
       std::complex<float>* snv,
       float* csq,
       std::complex<float>* snq)
  */
  /*! fn
   inline void lags2(
       const long int* upper,
       const double* a1,
       const std::complex<double>* a2,
       const double* a3,
       const double* b1,
       const std::complex<double>* b2,
       const double* b3,
       double* csu,
       std::complex<double>* snu,
       double* csv,
       std::complex<double>* snv,
       double* csq,
       std::complex<double>* snq,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lags2(
       const long int* upper,
       const double* a1,
       const std::complex<double>* a2,
       const double* a3,
       const double* b1,
       const std::complex<double>* b2,
       const double* b3,
       double* csu,
       std::complex<double>* snu,
       double* csv,
       std::complex<double>* snv,
       double* csq,
       std::complex<double>* snq)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clags2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGS2(NAME, T, TBASE)\
inline void lags2(\
    const long int* upper,\
    const TBASE* a1,\
    const T* a2,\
    const TBASE* a3,\
    const TBASE* b1,\
    const T* b2,\
    const TBASE* b3,\
    TBASE* csu,\
    T* snu,\
    TBASE* csv,\
    T* snv,\
    TBASE* csq,\
    T* snq,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(upper, a1, a2, a3, b1, b2, b3, csu, snu, csv, snv, csq, snq);\
}\
inline void lags2(\
    const long int* upper,\
    const TBASE* a1,\
    const T* a2,\
    const TBASE* a3,\
    const TBASE* b1,\
    const T* b2,\
    const TBASE* b3,\
    TBASE* csu,\
    T* snu,\
    TBASE* csv,\
    T* snv,\
    TBASE* csq,\
    T* snq)\
{\
   workspace<T> w;\
   lags2(upper, a1, a2, a3, b1, b2, b3, csu, snu, csv, snv, csq, snq, w);\
}\

    LPP_LAGS2(clags2, std::complex<float>,  float)
    LPP_LAGS2(zlags2, std::complex<double>, double)

#undef LPP_LAGS2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lags2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
