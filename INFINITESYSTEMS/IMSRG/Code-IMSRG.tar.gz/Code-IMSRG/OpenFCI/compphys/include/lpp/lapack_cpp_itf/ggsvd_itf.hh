#ifndef __PROJECT__LPP__FILE__GGSVD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGSVD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggsvd_itf.hh C++ interface to LAPACK (s,d,c,z)ggsvd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggsvd_itf.hh
    (excerpt adapted from xggsvd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggsvd computes the generalized singular value decomposition (gsvd)
    **  of an m-by-n DATA TYPE matrix a and p-by-n DATA TYPE matrix b:
    **
    **        u'*a*q = d1*( 0 r ),    v'*b*q = d2*( 0 r )
    **
    **  where u, v and q are unitary matrices, and z' means the conjugate
    **  transpose of z.  let k+l = the effective numerical rank of the
    **  matrix (a',b')', then r is a (k+l)-by-(k+l) nonsingular upper
    **  triangular matrix, d1 and d2 are m-by-(k+l) and p-by-(k+l) "diagonal"
    **  matrices and of the following structures, respectively:
    **
    **  if m-k-l >= 0,
    **
    **                      k  l
    **         d1 =     k ( i  0 )
    **                  l ( 0  c )
    **              m-k-l ( 0  0 )
    **
    **                    k  l
    **         d2 =   l ( 0  s )
    **              p-l ( 0  0 )
    **
    **                  n-k-l  k    l
    **    ( 0 r ) = k (  0   r11  r12 )
    **              l (  0    0   r22 )
    **  where
    **
    **    c = diag( alpha(k+1), ... , alpha(k+l) ),
    **    s = diag( beta(k+1),  ... , beta(k+l) ),
    **    c**2 + s**2 = i.
    **
    **    r is stored in a(1:k+l,n-k-l+1:n) on exit.
    **
    **  if m-k-l < 0,
    **
    **                    k m-k k+l-m
    **         d1 =   k ( i  0    0   )
    **              m-k ( 0  c    0   )
    **
    **                      k m-k k+l-m
    **         d2 =   m-k ( 0  s    0  )
    **              k+l-m ( 0  0    i  )
    **                p-l ( 0  0    0  )
    **
    **                     n-k-l  k   m-k  k+l-m
    **    ( 0 r ) =     k ( 0    r11  r12  r13  )
    **                m-k ( 0     0   r22  r23  )
    **              k+l-m ( 0     0    0   r33  )
    **
    **  where
    **
    **    c = diag( alpha(k+1), ... , alpha(m) ),
    **    s = diag( beta(k+1),  ... , beta(m) ),
    **    c**2 + s**2 = i.
    **
    **    (r11 r12 r13 ) is stored in a(1:m, n-k-l+1:n), and r33 is stored
    **    ( 0  r22 r23 )
    **    in b(m-k+1:l,n+m-k-l+1:n) on exit.
    **
    **  the routine computes c, s, r, and optionally the unitary
    **  transformation matrices u, v and q.
    **
    **  in particular, if b is an n-by-n nonsingular matrix, then the gsvd of
    **  a and b implicitly gives the svd of a*inv(b):
    **                       a*inv(b) = u*(d1*inv(d2))*v'.
    **  if ( a',b')' has orthnormal columns, then the gsvd of a and b is also
    **  equal to the cs decomposition of a and b. furthermore, the gsvd can
    **  be used to derive the solution of the eigenvalue problem:
    **                       a'*a x = lambda* b'*b x.
    **  in some literature, the gsvd of a and b is presented in the form
    **                   u'*a*x = ( 0 d1 ),   v'*b*x = ( 0 d2 )
    **  where u and v are orthogonal and x is nonsingular, and d1 and d2 are
    **  ``diagonal''.  the former gsvd form can be converted to the latter
    **  form by taking the nonsingular matrix x as
    **
    **                        x = q*(  i   0    )
    **                              (  0 inv(r) )
    **
    **  arguments
    **  =========
    **
    **  jobu    (input) char
    **          = 'u':  unitary matrix u is computed;
    **          = 'n':  u is not computed.
    **
    **  jobv    (input) char
    **          = 'v':  unitary matrix v is computed;
    **          = 'n':  v is not computed.
    **
    **  jobq    (input) char
    **          = 'q':  unitary matrix q is computed;
    **          = 'n':  q is not computed.
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrices a and b.  n >= 0.
    **
    **  p       (input) long int
    **          the number of rows of the matrix b.  p >= 0.
    **
    **  k       (output) long int
    **  l       (output) long int
    **          on exit, k and l specify the dimension of the subblocks
    **          described in purpose.
    **          k + l = effective numerical rank of (a',b')'.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, a contains the triangular matrix r, or part of r.
    **          see purpose for details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the p-by-n matrix b.
    **          on exit, b contains part of the triangular matrix r if
    **          m-k-l < 0.  see purpose for details.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,p).
    **
    **  alpha   (output) BASE DATA TYPE array, dimension (n)
    **  beta    (output) BASE DATA TYPE array, dimension (n)
    **          on exit, alpha and beta contain the generalized singular
    **          value pairs of a and b;
    **            alpha(1:k) = 1,
    **            beta(1:k)  = 0,
    **          and if m-k-l >= 0,
    **            alpha(k+1:k+l) = c,
    **            beta(k+1:k+l)  = s,
    **          or if m-k-l < 0,
    **            alpha(k+1:m)= c, alpha(m+1:k+l)= 0
    **            beta(k+1:m) = s, beta(m+1:k+l) = 1
    **          and
    **            alpha(k+l+1:n) = 0
    **            beta(k+l+1:n)  = 0
    **
    **  u       (output) DATA TYPE array, dimension (ldu,m)
    **          if jobu = 'u', u contains the m-by-m unitary matrix u.
    **          if jobu = 'n', u is not referenced.
    **
    **  ldu     (input) long int
    **          the leading dimension of the array u. ldu >= max(1,m) if
    **          jobu = 'u'; ldu >= 1 otherwise.
    **
    **  v       (output) DATA TYPE array, dimension (ldv,p)
    **          if jobv = 'v', v contains the p-by-p unitary matrix v.
    **          if jobv = 'n', v is not referenced.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v. ldv >= max(1,p) if
    **          jobv = 'v'; ldv >= 1 otherwise.
    **
    **  q       (output) DATA TYPE array, dimension (ldq,n)
    **          if jobq = 'q', q contains the n-by-n unitary matrix q.
    **          if jobq = 'n', q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q. ldq >= max(1,n) if
    **          jobq = 'q'; ldq >= 1 otherwise.
    **
    **
    **
    **
    **  info    (output)long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, the jacobi-type procedure failed to
    **                converge.  for further details, see subroutine ctgsja.
    **
    **  internal parameters
    **  ===================
    **
    **  tola    BASE DATA TYPE
    **  tolb    BASE DATA TYPE
    **          tola and tolb are the thresholds to determine the effective
    **          rank of (a',b')'. generally, they are set to
    **                   tola = max(m,n)*norm(a)*macheps,
    **                   tolb = max(p,n)*norm(b)*macheps.
    **          the size of tola and tolb may affect the size of backward
    **          errors of the decomposition.
    **
    **  further details
    **  ===============
    **
    **  2-96 based on modifications by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggsvd(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        const long int* m,
        const long int* n,
        const long int* p,
        long int* k,
        long int* l,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alpha,
        float* beta,
        const float* u,
        const long int* ldu,
        const float* v,
        const long int* ldv,
        const float* q,
        const long int* ldq,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggsvd(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        const long int* m,
        const long int* n,
        const long int* p,
        long int* k,
        long int* l,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alpha,
        float* beta,
        const float* u,
        const long int* ldu,
        const float* v,
        const long int* ldv,
        const float* q,
        const long int* ldq,
        long int* info)
  */
  /*! fn
   inline void ggsvd(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        const long int* m,
        const long int* n,
        const long int* p,
        long int* k,
        long int* l,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alpha,
        double* beta,
        const double* u,
        const long int* ldu,
        const double* v,
        const long int* ldv,
        const double* q,
        const long int* ldq,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggsvd(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        const long int* m,
        const long int* n,
        const long int* p,
        long int* k,
        long int* l,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alpha,
        double* beta,
        const double* u,
        const long int* ldu,
        const double* v,
        const long int* ldv,
        const double* q,
        const long int* ldq,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggsvd.f)
  //    *  WORK    (workspace) float array,
  //    *                      dimension (max(3*N,M,P)+N)
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (N)
  //    *          On exit, IWORK stores the sorting information. More
  //    *          precisely, the following loop will sort ALPHA
  //    *             for I = K+1, min(M,K+L)
  //    *                 swap ALPHA(I) and ALPHA(IWORK(I))
  //    *             endfor
  //    *          such that ALPHA(1) >= ALPHA(2) >= ... >= ALPHA(N).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGSVD(NAME, T)\
inline void ggsvd(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    long int* k,\
    long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*n);\
    w.resizew(std::max(3**n,std::max(*m,*p))+*n);                           \
    F77NAME( NAME )(jobu, jobv, jobq, m, n, p, k, l, a, lda, b, ldb, alpha, beta, u, ldu, v, ldv, q, ldq, w.getw(), w.getiw(), info);\
}\
inline void ggsvd(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    long int* k,\
    long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* info)\
{\
   workspace<T> w;\
   ggsvd(jobu, jobv, jobq, m, n, p, k, l, a, lda, b, ldb, alpha, beta, u, ldu, v, ldv, q, ldq, info, w);\
}\

    LPP_GGSVD(sggsvd, float)
    LPP_GGSVD(dggsvd, double)

#undef LPP_GGSVD


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggsvd(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       const long int* m,
       const long int* n,
       const long int* p,
       long int* k,
       long int* l,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       float* alpha,
       float* beta,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggsvd(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       const long int* m,
       const long int* n,
       const long int* p,
       long int* k,
       long int* l,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       float* alpha,
       float* beta,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* q,
       const long int* ldq,
       long int* info)
  */
  /*! fn
   inline void ggsvd(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       const long int* m,
       const long int* n,
       const long int* p,
       long int* k,
       long int* l,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       double* alpha,
       double* beta,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggsvd(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       const long int* m,
       const long int* n,
       const long int* p,
       long int* k,
       long int* l,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       double* alpha,
       double* beta,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* q,
       const long int* ldq,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggsvd.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (max(3*N,M,P)+N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (N)
  //    *          On exit, IWORK stores the sorting information. More
  //    *          precisely, the following loop will sort ALPHA
  //    *             for I = K+1, min(M,K+L)
  //    *                 swap ALPHA(I) and ALPHA(IWORK(I))
  //    *             endfor
  //    *          such that ALPHA(1) >= ALPHA(2) >= ... >= ALPHA(N).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGSVD(NAME, T, TBASE)\
inline void ggsvd(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    long int* k,\
    long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    TBASE* alpha,\
    TBASE* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(2**n);\
    w.resizeiw(*n);\
    w.resizew(std::max(3**n,std::max(*m,*p))+*n);                      \
    F77NAME( NAME )(jobu, jobv, jobq, m, n, p, k, l, a, lda, b, ldb,\
                    alpha, beta, u, ldu, v, ldv, q, ldq,\
                    w.getw(), w.getrw(), w.getiw(), info);  \
}\
inline void ggsvd(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    long int* k,\
    long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    TBASE* alpha,\
    TBASE* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* info)\
{\
   workspace<T> w;\
   ggsvd(jobu, jobv, jobq, m, n, p, k, l, a, lda, b, ldb, alpha, beta, u, ldu, v, ldv, q, ldq, info, w);\
}\

    LPP_GGSVD(cggsvd, std::complex<float> , float)
    LPP_GGSVD(zggsvd, std::complex<double>, double)
  
#undef LPP_GGSVD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggsvd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
