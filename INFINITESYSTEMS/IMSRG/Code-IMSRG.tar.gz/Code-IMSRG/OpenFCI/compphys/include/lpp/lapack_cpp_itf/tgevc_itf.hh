#ifndef __PROJECT__LPP__FILE__TGEVC_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGEVC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgevc_itf.hh C++ interface to LAPACK (s,d,c,z)tgevc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgevc_itf.hh
    (excerpt adapted from xtgevc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgevc computes some or all of the right and/or left eigenvectors of
    **  a pair of DATA TYPE matrices (s,p), where s and p are upper triangular.
    **  matrix pairs of this type are produced by the generalized schur
    **  factorization of a DATA TYPE matrix pair (a,b):
    **  
    **     a = q*s*z**h,  b = q*p*z**h
    **  
    **  as computed by cgghrd + chgeqz.
    **  
    **  the right eigenvector x and the left eigenvector y of (s,p)
    **  corresponding to an eigenvalue w are defined by:
    **  
    **     s*x = w*p*x,  (y**h)*s = w*(y**h)*p,
    **  
    **  where y**h denotes the conjugate tranpose of y.
    **  the eigenvalues are not input to this routine, but are computed
    **  directly from the diagonal elements of s and p.
    **  
    **  this routine returns the matrices x and/or y of right and left
    **  eigenvectors of (s,p), or the products z*x and/or q*y,
    **  where z and q are input matrices.
    **  if q and z are the unitary factors from the generalized schur
    **  factorization of a matrix pair (a,b), then z*x and q*y
    **  are the matrices of right and left eigenvectors of (a,b).
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'r': compute right eigenvectors only;
    **          = 'l': compute left eigenvectors only;
    **          = 'b': compute both right and left eigenvectors.
    **
    **  howmny  (input) char
    **          = 'a': compute all right and/or left eigenvectors;
    **          = 'b': compute all right and/or left eigenvectors,
    **                 backtransformed by the matrices in vr and/or vl;
    **          = 's': compute selected right and/or left eigenvectors,
    **                 specified by the logical array select.
    **
    **  select  (input) logical array, dimension (n)
    **          if howmny='s', select specifies the eigenvectors to be
    **          computed.  the eigenvector corresponding to the j-th
    **          eigenvalue is computed if select(j) = .true..
    **          not referenced if howmny = 'a' or 'b'.
    **
    **  n       (input) long int
    **          the order of the matrices s and p.  n >= 0.
    **
    **  s       (input) DATA TYPE array, dimension (lds,n)
    **          the upper triangular matrix s from a generalized schur
    **          factorization, as computed by chgeqz.
    **
    **  lds     (input) long int
    **          the leading dimension of array s.  lds >= max(1,n).
    **
    **  p       (input) DATA TYPE array, dimension (ldp,n)
    **          the upper triangular matrix p from a generalized schur
    **          factorization, as computed by chgeqz.  p must have BASE DATA TYPE
    **          diagonal elements.
    **
    **  ldp     (input) long int
    **          the leading dimension of array p.  ldp >= max(1,n).
    **
    **  vl      (input/output) DATA TYPE array, dimension (ldvl,mm)
    **          on entry, if side = 'l' or 'b' and howmny = 'b', vl must
    **          contain an n-by-n matrix q (usually the unitary matrix q
    **          of left schur vectors returned by chgeqz).
    **          on exit, if side = 'l' or 'b', vl contains:
    **          if howmny = 'a', the matrix y of left eigenvectors of (s,p);
    **          if howmny = 'b', the matrix q*y;
    **          if howmny = 's', the left eigenvectors of (s,p) specified by
    **                      select, stored consecutively in the columns of
    **                      vl, in the same order as their eigenvalues.
    **          not referenced if side = 'r'.
    **
    **  ldvl    (input) long int
    **          the leading dimension of array vl.  ldvl >= 1, and if
    **          side = 'l' or 'l' or 'b' or 'b', ldvl >= n.
    **
    **  vr      (input/output) DATA TYPE array, dimension (ldvr,mm)
    **          on entry, if side = 'r' or 'b' and howmny = 'b', vr must
    **          contain an n-by-n matrix q (usually the unitary matrix z
    **          of right schur vectors returned by chgeqz).
    **          on exit, if side = 'r' or 'b', vr contains:
    **          if howmny = 'a', the matrix x of right eigenvectors of (s,p);
    **          if howmny = 'b', the matrix z*x;
    **          if howmny = 's', the right eigenvectors of (s,p) specified by
    **                      select, stored consecutively in the columns of
    **                      vr, in the same order as their eigenvalues.
    **          not referenced if side = 'l'.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr.  ldvr >= 1, and if
    **          side = 'r' or 'b', ldvr >= n.
    **
    **  mm      (input) long int
    **          the number of columns in the arrays vl and/or vr. mm >= m.
    **
    **  m       (output) long int
    **          the number of columns in the arrays vl and/or vr actually
    **          used to store the eigenvectors.  if howmny = 'a' or 'b', m
    **          is set to n.  each selected eigenvector occupies one column.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgevc(
        const char* side,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* s,
        const long int* lds,
        const float* p,
        const long int* ldp,
        float* vl,
        const long int* ldvl,
        float* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgevc(
        const char* side,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* s,
        const long int* lds,
        const float* p,
        const long int* ldp,
        float* vl,
        const long int* ldvl,
        float* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* info)
  */
  /*! fn
   inline void tgevc(
        const char* side,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* s,
        const long int* lds,
        const double* p,
        const long int* ldp,
        double* vl,
        const long int* ldvl,
        double* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgevc(
        const char* side,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* s,
        const long int* lds,
        const double* p,
        const long int* ldp,
        double* vl,
        const long int* ldvl,
        double* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgevc.f)
  //    *  WORK    (workspace) float array, dimension (6*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEVC(NAME, T)\
inline void tgevc(\
    const char* side,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* s,\
    const long int* lds,\
    const T* p,\
    const long int* ldp,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(6*(*n));\
    F77NAME( NAME )(side, howmny, select, n, s, lds, p, ldp, vl, ldvl, vr, ldvr, mm, m, w.getw(), info);\
}\
inline void tgevc(\
    const char* side,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* s,\
    const long int* lds,\
    const T* p,\
    const long int* ldp,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   tgevc(side, howmny, select, n, s, lds, p, ldp, vl, ldvl, vr, ldvr, mm, m, info, w);\
}\

    LPP_TGEVC(stgevc, float)
    LPP_TGEVC(dtgevc, double)

#undef LPP_TGEVC


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgevc(
       const char* side,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* s,
       const long int* lds,
       const std::complex<float>* p,
       const long int* ldp,
       std::complex<float>* vl,
       const long int* ldvl,
       std::complex<float>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgevc(
       const char* side,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* s,
       const long int* lds,
       const std::complex<float>* p,
       const long int* ldp,
       std::complex<float>* vl,
       const long int* ldvl,
       std::complex<float>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* info)
  */
  /*! fn
   inline void tgevc(
       const char* side,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* s,
       const long int* lds,
       const std::complex<double>* p,
       const long int* ldp,
       std::complex<double>* vl,
       const long int* ldvl,
       std::complex<double>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgevc(
       const char* side,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* s,
       const long int* lds,
       const std::complex<double>* p,
       const long int* ldp,
       std::complex<double>* vl,
       const long int* ldvl,
       std::complex<double>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgevc.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEVC(NAME, T, TBASE)\
inline void tgevc(\
    const char* side,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* s,\
    const long int* lds,\
    const T* p,\
    const long int* ldp,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(2*(*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(side, howmny, select, n, s, lds, p, ldp, vl, ldvl, vr, ldvr, mm, m, w.getw(), w.getrw(), info);\
}\
inline void tgevc(\
    const char* side,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* s,\
    const long int* lds,\
    const T* p,\
    const long int* ldp,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   tgevc(side, howmny, select, n, s, lds, p, ldp, vl, ldvl, vr, ldvr, mm, m, info, w);\
}\

    LPP_TGEVC(ctgevc, std::complex<float>, float)
    LPP_TGEVC(ztgevc, std::complex<double>, double)

#undef LPP_TGEVC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgevc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
