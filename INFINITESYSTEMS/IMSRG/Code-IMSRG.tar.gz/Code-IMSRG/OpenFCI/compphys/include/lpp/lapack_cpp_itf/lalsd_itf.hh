#ifndef __PROJECT__LPP__FILE__LALSD_HH__INCLUDED
#define __PROJECT__LPP__FILE__LALSD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lalsd_itf.hh C++ interface to LAPACK (s,d,c,z)lalsd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lalsd_itf.hh
    (excerpt adapted from xlalsd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlalsd uses the singular value decomposition of a to solve the least
    **  squares problem of finding x to minimize the euclidean norm of each
    **  column of a*x-b, where a is n-by-n upper bidiagonal, and x and b
    **  are n-by-nrhs. the solution x overwrites b.
    **
    **  the singular values of a smaller than rcond times the largest
    **  singular value are treated as zero in solving the least squares
    **  problem; in this case a minimum norm solution is returned.
    **  the actual singular values are returned in d in ascending order.
    **
    **  this code makes very mild assumptions about floating point
    **  arithmetic. it will WORK on machines with a guard digit in
    **  add/subtract, or on those binary machines without guard digits
    **  which subtract like the cray xmp, cray ymp, cray c 90, or cray 2.
    **  it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  arguments
    **  =========
    **
    **  uplo   (input) char
    **         = 'u': d and e define an upper bidiagonal matrix.
    **         = 'l': d and e define a  lower bidiagonal matrix.
    **
    **  smlsiz (input) long int
    **         the maximum size of the subproblems at the bottom of the
    **         computation tree.
    **
    **  n      (input) long int
    **         the dimension of the  bidiagonal matrix.  n >= 0.
    **
    **  nrhs   (input) long int
    **         the number of columns of b. nrhs must be at least 1.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry d contains the main diagonal of the bidiagonal
    **         matrix. on exit, if info = 0, d contains its singular values.
    **
    **  e      (input) BASE DATA TYPE array, dimension (n-1)
    **         contains the super-diagonal entries of the bidiagonal matrix.
    **         on exit, e has been destroyed.
    **
    **  b      (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **         on input, b contains the right hand sides of the least
    **         squares problem. on output, b contains the solution x.
    **
    **  ldb    (input) long int
    **         the leading dimension of b in the calling subprogram.
    **         ldb must be at least max(1,n).
    **
    **  rcond  (input) BASE DATA TYPE
    **         the singular values of a less than or equal to rcond times
    **         the largest singular value are treated as zero in solving
    **         the least squares problem. if rcond is negative,
    **         machine precision is used instead.
    **         for example, if diag(s)*x=b were the least squares problem,
    **         where diag(s) is a diagonal matrix of singular values, the
    **         solution would be x(i) = b(i) / s(i) if s(i) is greater than
    **         rcond*max(s), and x(i) = 0 if s(i) is less than or equal to
    **         rcond*max(s).
    **
    **  rank   (output) long int
    **         the number of singular values of a greater than rcond times
    **         the largest singular value.
    **
    **
    **
    **
    **  info   (output) long int
    **         = 0:  successful exit.
    **         < 0:  if info = -i, the i-th argument had an illegal value.
    **         > 0:  the algorithm failed to compute an singular value while
    **               WORKing on the submatrix lying in rows and columns
    **               info/(n+1) through mod(info,n+1).
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and ren-cang li, computer science division, university of
    **       california at berkeley, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////


 

  // The following macro provides the 4 functions 
  /*! fn
   inline void lalsd(
        const char* uplo,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        float* d,
        const float* e,
        float* b,
        const long int* ldb,
        const float* rcond,
        long int* rank,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lalsd(
        const char* uplo,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        float* d,
        const float* e,
        float* b,
        const long int* ldb,
        const float* rcond,
        long int* rank,
        long int* info)
  */
  /*! fn
   inline void lalsd(
        const char* uplo,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        double* d,
        const double* e,
        double* b,
        const long int* ldb,
        const double* rcond,
        long int* rank,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lalsd(
        const char* uplo,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        double* d,
        const double* e,
        double* b,
        const long int* ldb,
        const double* rcond,
        long int* rank,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slalsd.f)
  //    *  WORK   (workspace) float array, dimension at least
  //    *         (9*N + 2*N*SMLSIZ + 8*N*NLVL + N*NRHS + (SMLSIZ+1)**2),
  //    *         where NLVL = max(0, INT(log_2 (N/(SMLSIZ+1))) + 1).
  //    *
  //    *  IWORK  (workspace) long int array, dimension at least
  //    *         (3*N*NLVL + 11*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LALSD(NAME, T)\
inline void lalsd(\
    const char* uplo,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    T* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    const T* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{                                                                       \
  long int nlvl = (long int)std::max(0l, (long int)(log(double(*n))/log(2.0)/double(*smlsiz+1))+1); \
  w.resizeiw((3*nlvl + 11)*(*n));                                       \
  w.resizew( (*n)*(9 + 2*(*smlsiz) + 8*nlvl + *nrhs) + (*smlsiz+1)*(*smlsiz+1)); \
  F77NAME( NAME )(uplo, smlsiz, n, nrhs, d, e, b, ldb, rcond, rank, w.getw(), w.getiw(), info); \
}\
inline void lalsd(\
    const char* uplo,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    T* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    const T* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   lalsd(uplo, smlsiz, n, nrhs, d, e, b, ldb, rcond, rank, info, w);\
}\

    LPP_LALSD(slalsd, float)
    LPP_LALSD(dlalsd, double)

#undef LPP_LALSD


  // The following macro provides the 4 functions 
  /*! fn
   inline void lalsd(
       const char* uplo,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       float* d,
       const float* e,
       std::complex<float>* b,
       const long int* ldb,
       const float* rcond,
       long int* rank,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lalsd(
       const char* uplo,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       float* d,
       const float* e,
       std::complex<float>* b,
       const long int* ldb,
       const float* rcond,
       long int* rank,
       long int* info)
  */
  /*! fn
   inline void lalsd(
       const char* uplo,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       double* d,
       const double* e,
       std::complex<double>* b,
       const long int* ldb,
       const double* rcond,
       long int* rank,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lalsd(
       const char* uplo,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       double* d,
       const double* e,
       std::complex<double>* b,
       const long int* ldb,
       const double* rcond,
       long int* rank,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clalsd.f)
  //    *  WORK   (workspace) std::complex<float> array, dimension at least
  //    *         (N * NRHS).
  //    *
  //    *  RWORK  (workspace) float array, dimension at least
  //    *         (9*N + 2*N*SMLSIZ + 8*N*NLVL + 3*SMLSIZ*NRHS + (SMLSIZ+1)**2),
  //    *         where
  //    *         NLVL = MAX( 0, INT( LOG_2( MIN( M,N )/(SMLSIZ+1) ) ) + 1 )
  //    *
  //    *  IWORK  (workspace) long int array, dimension at least
  //    *         (3*N*NLVL + 11*N).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LALSD(NAME, T, TBASE)\
inline void lalsd(\
    const char* uplo,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    TBASE* d,\
    const TBASE* e,\
    T* b,\
    const long int* ldb,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{\
  long int nlvl = (long int)std::max(0l, (long int)(log2(double(*n))/double(*smlsiz+1))+1); \
  w.resizeiw((3*nlvl + 11)*(*n));                                       \
  w.resizerw( (*n)*(9 + 2*(*smlsiz) + 8*nlvl) + 3*(*smlsiz)*(*nrhs) + (*smlsiz+1)*(*smlsiz+1)); \
  w.resizew((*n)*(*nrhs));                                              \
  F77NAME( NAME )(uplo, smlsiz, n, nrhs, d, e, b, ldb, rcond, rank, w.getw(), w.getrw(), w.getiw(), info); \
}\
inline void lalsd(\
    const char* uplo,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    TBASE* d,\
    const TBASE* e,\
    T* b,\
    const long int* ldb,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   lalsd(uplo, smlsiz, n, nrhs, d, e, b, ldb, rcond, rank, info, w);\
}\

    LPP_LALSD(clalsd, std::complex<float>, float)
    LPP_LALSD(zlalsd, std::complex<double>, double)

#undef LPP_LALSD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lalsd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
