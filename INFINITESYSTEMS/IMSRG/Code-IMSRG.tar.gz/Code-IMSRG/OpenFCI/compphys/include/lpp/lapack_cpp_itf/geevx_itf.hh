#ifndef __PROJECT__LPP__FILE__GEEVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEEVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geevx_itf.hh C++ interface to LAPACK (c,d,c,z)geevx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geevx_itf.hh
    (excerpt adapted from xgeevx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgeevx computes for an n-by-n DATA TYPE nonsymmetric matrix a, the
    **  eigenvalues and, optionally, the left and/or right eigenvectors.
    **
    **  optionally also, it computes a balancing transformation to improve
    **  the conditioning of the eigenvalues and eigenvectors (ilo, ihi,
    **  scale, and abnrm), reciprocal condition numbers for the eigenvalues
    **  (rconde), and reciprocal condition numbers for the right
    **  eigenvectors (rcondv).
    **
    **  the right eigenvector v(j) of a satisfies
    **                   a * v(j) = lambda(j) * v(j)
    **  where lambda(j) is its eigenvalue.
    **  the left eigenvector u(j) of a satisfies
    **                u(j)**h * a = lambda(j) * u(j)**h
    **  where u(j)**h denotes the conjugate transpose of u(j).
    **
    **  the computed eigenvectors are normalized to have euclidean norm
    **  equal to 1 and largest component BASE DATA TYPE.
    **
    **  balancing a matrix means permuting the rows and columns to make it
    **  more nearly upper triangular, and applying a diagonal similarity
    **  transformation d * a * d**(-1), where d is a diagonal matrix, to
    **  make its rows and columns closer in norm and the condition numbers
    **  of its eigenvalues and eigenvectors smaller.  the computed
    **  reciprocal condition numbers correspond to the balanced matrix.
    **  permuting rows and columns will not change the condition numbers
    **  (in exact arithmetic) but diagonal scaling will.  for further
    **  explanation of balancing, see section 4.10.2 of the lapack
    **  users' guide.
    **
    **  arguments
    **  =========
    **
    **  balanc  (input) char
    **          indicates how the input matrix should be diagonally scaled
    **          and/or permuted to improve the conditioning of its
    **          eigenvalues.
    **          = 'n': do not diagonally scale or permute;
    **          = 'p': perform permutations to make the matrix more nearly
    **                 upper triangular. do not diagonally scale;
    **          = 's': diagonally scale the matrix, ie. replace a by
    **                 d*a*d**(-1), where d is a diagonal matrix chosen
    **                 to make the rows and columns of a more equal in
    **                 norm. do not permute;
    **          = 'b': both diagonally scale and permute a.
    **
    **          computed reciprocal condition numbers will be for the matrix
    **          after balancing and/or permuting. permuting does not change
    **          condition numbers (in exact arithmetic), but balancing does.
    **
    **  jobvl   (input) char
    **          = 'n': left eigenvectors of a are not computed;
    **          = 'v': left eigenvectors of a are computed.
    **          if sense = 'e' or 'b', jobvl must = 'v'.
    **
    **  jobvr   (input) char
    **          = 'n': right eigenvectors of a are not computed;
    **          = 'v': right eigenvectors of a are computed.
    **          if sense = 'e' or 'b', jobvr must = 'v'.
    **
    **  sense   (input) char
    **          determines which reciprocal condition numbers are computed.
    **          = 'n': none are computed;
    **          = 'e': computed for eigenvalues only;
    **          = 'v': computed for right eigenvectors only;
    **          = 'b': computed for eigenvalues and right eigenvectors.
    **
    **          if sense = 'e' or 'b', both left and right eigenvectors
    **          must also be computed (jobvl = 'v' and jobvr = 'v').
    **
    **  n       (input) long int
    **          the order of the matrix a. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the n-by-n matrix a.
    **          on exit, a has been overwritten.  if jobvl = 'v' or
    **          jobvr = 'v', a contains the schur form of the balanced 
    **          version of the matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          w contains the computed eigenvalues.
    **
    **  vl      (output) DATA TYPE array, dimension (ldvl,n)
    **          if jobvl = 'v', the left eigenvectors u(j) are stored one
    **          after another in the columns of vl, in the same order
    **          as their eigenvalues.
    **          if jobvl = 'n', vl is not referenced.
    **          u(j) = vl(:,j), the j-th column of vl.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the array vl.  ldvl >= 1; if
    **          jobvl = 'v', ldvl >= n.
    **
    **  vr      (output) DATA TYPE array, dimension (ldvr,n)
    **          if jobvr = 'v', the right eigenvectors v(j) are stored one
    **          after another in the columns of vr, in the same order
    **          as their eigenvalues.
    **          if jobvr = 'n', vr is not referenced.
    **          v(j) = vr(:,j), the j-th column of vr.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr.  ldvr >= 1; if
    **          jobvr = 'v', ldvr >= n.
    **
    **  ilo,ihi (output) long int
    **          ilo and ihi are integer values determined when a was
    **          balanced.  the balanced a(i,j) = 0 if i > j and
    **          j = 1,...,ilo-1 or i = ihi+1,...,n.
    **
    **  scale   (output) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and scaling factors applied
    **          when balancing a.  if p(j) is the index of the row and column
    **          interchanged with row and column j, and d(j) is the scaling
    **          factor applied to row and column j, then
    **          scale(j) = p(j),    for j = 1,...,ilo-1
    **                   = d(j),    for j = ilo,...,ihi
    **                   = p(j)     for j = ihi+1,...,n.
    **          the order in which the interchanges are made is n to ihi+1,
    **          then 1 to ilo-1.
    **
    **  abnrm   (output) BASE DATA TYPE
    **          the one-norm of the balanced matrix (the maximum
    **          of the sum of absolute values of elements of any column).
    **
    **  rconde  (output) BASE DATA TYPE array, dimension (n)
    **          rconde(j) is the reciprocal condition number of the j-th
    **          eigenvalue.
    **
    **  rcondv  (output) BASE DATA TYPE array, dimension (n)
    **          rcondv(j) is the reciprocal condition number of the j-th
    **          right eigenvector.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = i, the qr algorithm failed to compute all the
    **                eigenvalues, and no eigenvectors or condition numbers
    **                have been computed; elements 1:ilo-1 and i+1:n of w
    **                contain eigenvalues which have converged.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const float* a,
        const long int* lda,
        float* wr,
        float* wi,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        float* scale,
        float* abnrm,
        float* rconde,
        float* rcondv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const float* a,
        const long int* lda,
        float* wr,
        float* wi,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        float* scale,
        float* abnrm,
        float* rconde,
        float* rcondv,
        long int* info)
  */
  /*! fn
   inline void geevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const double* a,
        const long int* lda,
        double* wr,
        double* wi,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        double* scale,
        double* abnrm,
        double* rconde,
        double* rcondv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const double* a,
        const long int* lda,
        double* wr,
        double* wi,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        double* scale,
        double* abnrm,
        double* rconde,
        double* rcondv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeevx.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.   If SENSE = 'N' or 'E',
  //    *          LWORK >= max(1,2*N), and if JOBVL = 'V' or JOBVR = 'V',
  //    *          LWORK >= 3*N.  If SENSE = 'V' or 'B', LWORK >= N*(N+6).
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (2*N-2)
  //    *          If SENSE = 'N' or 'E', not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEEVX(NAME, T)\
inline void geevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* wr,\
    T* wi,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    T* scale,\
    T* abnrm,\
    T* rconde,\
    T* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw((lower(*sense) == 'n' || lower(*sense) ==  'e') ? 0 : 2**n-2); \
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, w.getw(), w.query(), w.getiw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, w.getw(), &w.neededsize(), w.getiw(), info);\
}\
inline void geevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* wr,\
    T* wi,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    T* scale,\
    T* abnrm,\
    T* rconde,\
    T* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   geevx(balanc, jobvl, jobvr, sense, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, info, w);\
}\

    LPP_GEEVX(sgeevx, float)
    LPP_GEEVX(dgeevx, double)

#undef LPP_GEEVX


  // The following macro provides the 4 functions 
  /*! fn
   inline void geevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* ws,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       float* scale,
       float* abnrm,
       float* rconde,
       float* rcondv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* ws,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       float* scale,
       float* abnrm,
       float* rconde,
       float* rcondv,
       long int* info)
  */
  /*! fn
   inline void geevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* ws,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       double* scale,
       double* abnrm,
       double* rconde,
       double* rcondv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* ws,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       double* scale,
       double* abnrm,
       double* rconde,
       double* rcondv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeevx.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  If SENSE = 'N' or 'E',
  //    *          LWORK >= max(1,2*N), and if SENSE = 'V' or 'B',
  //    *          LWORK >= N*N+2*N.
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEEVX(NAME, T, TBASE)\
inline void geevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* ws,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    TBASE* scale,\
    TBASE* abnrm,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(2**n);\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, ws, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, ws, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void geevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* ws,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    TBASE* scale,\
    TBASE* abnrm,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   geevx(balanc, jobvl, jobvr, sense, n, a, lda, ws, vl, ldvl, vr, ldvr, ilo, ihi, scale, abnrm, rconde, rcondv, info, w);\
}\

    LPP_GEEVX(cgeevx, std::complex<float>,  float)
    LPP_GEEVX(zgeevx, std::complex<double>, double)

#undef LPP_GEEVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geevx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
