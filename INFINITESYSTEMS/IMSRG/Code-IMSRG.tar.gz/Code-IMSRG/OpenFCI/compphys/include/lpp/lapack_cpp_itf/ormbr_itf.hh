#ifndef __PROJECT__LPP__FILE__ORMBR_HH__INCLUDED
#define __PROJECT__LPP__FILE__ORMBR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ormbr_itf.hh C++ interface to LAPACK (s,d,c,z)ormbr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ormbr_itf.hh
    (excerpt adapted from xormbr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  if vect = 'q', xormbr overwrites the general BASE DATA TYPE m-by-n matrix c
    **  with
    **                  side = 'l'     side = 'r'
    **  trans = 'n':      q * c          c * q
    **  trans = 't':      q**t * c       c * q**t
    **
    **  if vect = 'p', xormbr overwrites the general BASE DATA TYPE m-by-n matrix c
    **  with
    **                  side = 'l'     side = 'r'
    **  trans = 'n':      p * c          c * p
    **  trans = 't':      p**t * c       c * p**t
    **
    **  here q and p**t are the orthogonal matrices determined by dgebrd when
    **  reducing a BASE DATA TYPE matrix a to bidiagonal form: a = q * b * p**t. q and
    **  p**t are defined as products of elementary reflectors h(i) and g(i)
    **  respectively.
    **
    **  let nq = m if side = 'l' and nq = n if side = 'r'. thus nq is the
    **  order of the orthogonal matrix q or p**t that is applied.
    **
    **  if vect = 'q', a is assumed to have been an nq-by-k matrix:
    **  if nq >= k, q = h(1) h(2) . . . h(k);
    **  if nq < k, q = h(1) h(2) . . . h(nq-1).
    **
    **  if vect = 'p', a is assumed to have been a k-by-nq matrix:
    **  if k < nq, p = g(1) g(2) . . . g(k);
    **  if k >= nq, p = g(1) g(2) . . . g(nq-1).
    **
    **  arguments
    **  =========
    **
    **  vect    (input) char
    **          = 'q': apply q or q**t;
    **          = 'p': apply p or p**t.
    **
    **  side    (input) char
    **          = 'l': apply q, q**t, p or p**t from the left;
    **          = 'r': apply q, q**t, p or p**t from the right.
    **
    **  trans   (input) char
    **          = 'n':  no transpose, apply q  or p;
    **          = 't':  transpose, apply q**t or p**t.
    **
    **  m       (input) long int
    **          the number of rows of the matrix c. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix c. n >= 0.
    **
    **  k       (input) long int
    **          if vect = 'q', the number of columns in the original
    **          matrix reduced by dgebrd.
    **          if vect = 'p', the number of rows in the original
    **          matrix reduced by dgebrd.
    **          k >= 0.
    **
    **  a       (input) BASE DATA TYPE array, dimension
    **                                (lda,min(nq,k)) if vect = 'q'
    **                                (lda,nq)        if vect = 'p'
    **          the vectors which define the elementary reflectors h(i) and
    **          g(i), whose products determine the matrices q and p, as
    **          returned by dgebrd.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.
    **          if vect = 'q', lda >= max(1,nq);
    **          if vect = 'p', lda >= max(1,min(nq,k)).
    **
    **  tau     (input) BASE DATA TYPE array, dimension (min(nq,k))
    **          tau(i) must contain the scalar factor of the elementary
    **          reflector h(i) or g(i) which determines q or p, as returned
    **          by dgebrd in the array argument tauq or taup.
    **
    **  c       (input/output) BASE DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n matrix c.
    **          on exit, c is overwritten by q*c or q**t*c or c*q**t or c*q
    **          or p*c or p**t*c or c*p or c*p**t.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ormbr(
        const char* vect,
        const char* side,
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* k,
        const float* a,
        const long int* lda,
        const float* tau,
        const float* c,
        const long int* ldc,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ormbr(
        const char* vect,
        const char* side,
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* k,
        const float* a,
        const long int* lda,
        const float* tau,
        const float* c,
        const long int* ldc,
        long int* info)
  */
  /*! fn
   inline void ormbr(
        const char* vect,
        const char* side,
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* k,
        const double* a,
        const long int* lda,
        const double* tau,
        const double* c,
        const long int* ldc,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ormbr(
        const char* vect,
        const char* side,
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* k,
        const double* a,
        const long int* lda,
        const double* tau,
        const double* c,
        const long int* ldc,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sormbr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If SIDE = 'L', LWORK >= max(1,N);
  //    *          if SIDE = 'R', LWORK >= max(1,M).
  //    *          For optimum performance LWORK >= N*NB if SIDE = 'L', and
  //    *          LWORK >= M*NB if SIDE = 'R', where NB is the optimal
  //    *          blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_ORMBR(NAME, T)\
inline void ormbr(\
    const char* vect,\
    const char* side,\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* a,\
    const long int* lda,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(vect, side, trans, m, n, k, a, lda, tau, c, ldc, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(vect, side, trans, m, n, k, a, lda, tau, c, ldc, w.getw(), &w.neededsize(), info);\
}\
inline void ormbr(\
    const char* vect,\
    const char* side,\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* a,\
    const long int* lda,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   ormbr(vect, side, trans, m, n, k, a, lda, tau, c, ldc, info, w);\
}\

    LPP_ORMBR(sormbr, float)
    LPP_ORMBR(dormbr, double)

#undef LPP_ORMBR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ormbr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
