#ifndef __PROJECT__LPP__FILE__LAHQR_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAHQR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lahqr_itf.hh C++ interface to LAPACK (c,d,c,z)lahqr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lahqr_itf.hh
    (excerpt adapted from xlahqr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlahqr is an auxiliary routine called by chseqr to update the
    **  eigenvalues and schur decomposition already computed by chseqr, by
    **  dealing with the hessenberg submatrix in rows and columns ilo to ihi.
    **
    **  arguments
    **  =========
    **
    **  wantt   (input) logical
    **          = .true. : the full schur form t is required;
    **          = .false.: only eigenvalues are required.
    **
    **  wantz   (input) logical
    **          = .true. : the matrix of schur vectors z is required;
    **          = .false.: schur vectors are not required.
    **
    **  n       (input) long int
    **          the order of the matrix h.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          it is assumed that h is already upper triangular in rows and
    **          columns ihi+1:n, and that h(ilo,ilo-1) = 0 (unless ilo = 1).
    **          xlahqr WORKs primarily with the hessenberg submatrix in rows
    **          and columns ilo to ihi, but applies transformations to all of
    **          h if wantt is .true..
    **          1 <= ilo <= max(1,ihi); ihi <= n.
    **
    **  h       (input/output) DATA TYPE array, dimension (ldh,n)
    **          on entry, the upper hessenberg matrix h.
    **          on exit, if wantt is .true., h is upper triangular in rows
    **          and columns ilo:ihi, with any 2-by-2 diagonal blocks in
    **          standard form. if wantt is .false., the contents of h are
    **          unspecified on exit.
    **
    **  ldh     (input) long int
    **          the leading dimension of the array h. ldh >= max(1,n).
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          the computed eigenvalues ilo to ihi are stored in the
    **          corresponding elements of w. if wantt is .true., the
    **          eigenvalues are stored in the same order as on the diagonal
    **          of the schur form returned in h, with w(i) = h(i,i).
    **
    **  iloz    (input) long int
    **  ihiz    (input) long int
    **          specify the rows of z to which transformations must be
    **          applied if wantz is .true..
    **          1 <= iloz <= ilo; ihi <= ihiz <= n.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          if wantz is .true., on entry z must contain the current
    **          matrix z of transformations accumulated by chseqr, and on
    **          exit z has been updated; transformations are applied only to
    **          the submatrix z(iloz:ihiz,ilo:ihi).
    **          if wantz is .false., z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z. ldz >= max(1,n).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          > 0: if info = i, xlahqr failed to compute all the
    **               eigenvalues ilo to ihi in a total of 30*(ihi-ilo+1)
    **               iterations; elements i+1:ihi of w contain those
    **               eigenvalues which have been successfully computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lahqr(
        const long int* wantt,
        const long int* wantz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* wr,
        float* wi,
        const long int* iloz,
        const long int* ihiz,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lahqr(
        const long int* wantt,
        const long int* wantz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* wr,
        float* wi,
        const long int* iloz,
        const long int* ihiz,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void lahqr(
        const long int* wantt,
        const long int* wantz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* wr,
        double* wi,
        const long int* iloz,
        const long int* ihiz,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lahqr(
        const long int* wantt,
        const long int* wantz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* wr,
        double* wi,
        const long int* iloz,
        const long int* ihiz,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slahqr.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAHQR(NAME, T)\
inline void lahqr(\
    const long int* wantt,\
    const long int* wantz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    T* wi,\
    const long int* iloz,\
    const long int* ihiz,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantt, wantz, n, ilo, ihi, h, ldh, wr, wi, iloz, ihiz, z, ldz, info);\
}\
inline void lahqr(\
    const long int* wantt,\
    const long int* wantz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    T* wi,\
    const long int* iloz,\
    const long int* ihiz,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   lahqr(wantt, wantz, n, ilo, ihi, h, ldh, wr, wi, iloz, ihiz, z, ldz, info, w);\
}\

    LPP_LAHQR(slahqr, float)
    LPP_LAHQR(dlahqr, double)

#undef LPP_LAHQR


  // The following macro provides the 4 functions 
  /*! fn
   inline void lahqr(
       const long int* wantt,
       const long int* wantz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       const std::complex<float>* ws,
       const long int* iloz,
       const long int* ihiz,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lahqr(
       const long int* wantt,
       const long int* wantz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       const std::complex<float>* ws,
       const long int* iloz,
       const long int* ihiz,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void lahqr(
       const long int* wantt,
       const long int* wantz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       const std::complex<double>* ws,
       const long int* iloz,
       const long int* ihiz,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lahqr(
       const long int* wantt,
       const long int* wantz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       const std::complex<double>* ws,
       const long int* iloz,
       const long int* ihiz,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clahqr.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAHQR(NAME, T, TBASE)\
inline void lahqr(\
    const long int* wantt,\
    const long int* wantz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    const T* ws,\
    const long int* iloz,\
    const long int* ihiz,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantt, wantz, n, ilo, ihi, h, ldh, ws, iloz, ihiz, z, ldz, info);\
}\
inline void lahqr(\
    const long int* wantt,\
    const long int* wantz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    const T* ws,\
    const long int* iloz,\
    const long int* ihiz,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   lahqr(wantt, wantz, n, ilo, ihi, h, ldh, ws, iloz, ihiz, z, ldz, info, w);\
}\

    LPP_LAHQR(clahqr, std::complex<float>,  float)
    LPP_LAHQR(zlahqr, std::complex<double>, double)

#undef LPP_LAHQR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lahqr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
