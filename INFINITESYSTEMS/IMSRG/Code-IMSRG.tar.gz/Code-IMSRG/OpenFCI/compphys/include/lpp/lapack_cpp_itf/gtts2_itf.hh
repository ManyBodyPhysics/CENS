#ifndef __PROJECT__LPP__FILE__GTTS2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GTTS2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gtts2_itf.hh C++ interface to LAPACK (c,d,c,z)gtts2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gtts2_itf.hh
    (excerpt adapted from xgtts2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgtts2 solves one of the systems of equations
    **     a * x = b,  a**t * x = b,  or  a**h * x = b,
    **  with a tridiagonal matrix a using the lu factorization computed
    **  by cgttrf.
    **
    **  arguments
    **  =========
    **
    **  itrans  (input) long int
    **          specifies the form of the system of equations.
    **          = 0:  a * x = b     (no transpose)
    **          = 1:  a**t * x = b  (transpose)
    **          = 2:  a**h * x = b  (conjugate transpose)
    **
    **  n       (input) long int
    **          the order of the matrix a.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  dl      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) multipliers that define the matrix l from the
    **          lu factorization of a.
    **
    **  d       (input) DATA TYPE array, dimension (n)
    **          the n diagonal elements of the upper triangular matrix u from
    **          the lu factorization of a.
    **
    **  du      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) elements of the first super-diagonal of u.
    **
    **  du2     (input) DATA TYPE array, dimension (n-2)
    **          the (n-2) elements of the second super-diagonal of u.
    **
    **  ipiv    (input) long int array, dimension (n)
    **          the pivot indices; for 1 <= i <= n, row i of the matrix was
    **          interchanged with row ipiv(i).  ipiv(i) will always be either
    **          i or i+1; ipiv(i) = i indicates a row interchange was not
    **          required.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the matrix of right hand side vectors b.
    **          on exit, b is overwritten by the solution vectors x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gtts2(
        const long int* itrans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* du2,
        const long int* ipiv,
        float* b,
        const long int* ldb,
        workspace<float> & w)
  */
  /*! fn
   inline void gtts2(
        const long int* itrans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        const float* du2,
        const long int* ipiv,
        float* b,
        const long int* ldb)
  */
  /*! fn
   inline void gtts2(
        const long int* itrans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* du2,
        const long int* ipiv,
        double* b,
        const long int* ldb,
        workspace<double> & w)
  */
  /*! fn
   inline void gtts2(
        const long int* itrans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        const double* du2,
        const long int* ipiv,
        double* b,
        const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgtts2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTTS2(NAME, T)\
inline void gtts2(\
    const long int* itrans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(itrans, n, nrhs, dl, d, du, du2, ipiv, b, ldb);\
}\
inline void gtts2(\
    const long int* itrans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   gtts2(itrans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, w);\
}\

    LPP_GTTS2(sgtts2, float)
    LPP_GTTS2(dgtts2, double)

#undef LPP_GTTS2


  // The following macro provides the 4 functions 
  /*! fn
   inline void gtts2(
       const long int* itrans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* du2,
       const long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gtts2(
       const long int* itrans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* du2,
       const long int* ipiv,
       std::complex<float>* b,
       const long int* ldb)
  */
  /*! fn
   inline void gtts2(
       const long int* itrans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* du2,
       const long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gtts2(
       const long int* itrans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* du2,
       const long int* ipiv,
       std::complex<double>* b,
       const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgtts2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTTS2(NAME, T, TBASE)\
inline void gtts2(\
    const long int* itrans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(itrans, n, nrhs, dl, d, du, du2, ipiv, b, ldb);\
}\
inline void gtts2(\
    const long int* itrans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* du2,\
    const long int* ipiv,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   gtts2(itrans, n, nrhs, dl, d, du, du2, ipiv, b, ldb, w);\
}\

    LPP_GTTS2(cgtts2, std::complex<float>,  float)
    LPP_GTTS2(zgtts2, std::complex<double>, double)

#undef LPP_GTTS2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gtts2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
