#ifndef __PROJECT__LPP__FILE__GTSVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GTSVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gtsvx_itf.hh C++ interface to LAPACK (s,d,c,z)gtsvx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gtsvx_itf.hh
    (excerpt adapted from xgtsvx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgtsvx uses the lu factorization to compute the solution to a DATA TYPE
    **  system of linear equations a * x = b, a**t * x = b, or a**h * x = b,
    **  where a is a tridiagonal matrix of order n and x and b are n-by-nrhs
    **  matrices.
    **
    **  error bounds on the solution and a condition estimate are also
    **  provided.
    **
    **  description
    **  ===========
    **
    **  the following steps are performed:
    **
    **  1. if fact = 'n', the lu decomposition is used to factor the matrix a
    **     as a = l * u, where l is a product of permutation and unit lower
    **     bidiagonal matrices and u is upper triangular with nonzeros in
    **     only the main diagonal and first two superdiagonals.
    **
    **  2. if some u(i,i)=0, so that u is exactly singular, then the routine
    **     returns with info = i. otherwise, the factored form of a is used
    **     to estimate the condition number of the matrix a.  if the
    **     reciprocal of the condition number is less than machine precision,
    **     info = n+1 is returned as a warning, but the routine still goes on
    **     to solve for x and compute error bounds as described below.
    **
    **  3. the system of equations is solved for x using the factored form
    **     of a.
    **
    **  4. iterative refinement is applied to improve the computed solution
    **     matrix and calculate error bounds and backward error estimates
    **     for it.
    **
    **  arguments
    **  =========
    **
    **  fact    (input) char
    **          specifies whether or not the factored form of a has been
    **          supplied on entry.
    **          = 'f':  dlf, df, duf, du2, and ipiv contain the factored form
    **                  of a; dl, d, du, dlf, df, duf, du2 and ipiv will not
    **                  be modified.
    **          = 'n':  the matrix will be copied to dlf, df, and duf
    **                  and factored.
    **
    **  trans   (input) char
    **          specifies the form of the system of equations:
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  dl      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) subdiagonal elements of a.
    **
    **  d       (input) DATA TYPE array, dimension (n)
    **          the n diagonal elements of a.
    **
    **  du      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) superdiagonal elements of a.
    **
    **  dlf     (input or output) DATA TYPE array, dimension (n-1)
    **          if fact = 'f', then dlf is an input argument and on entry
    **          contains the (n-1) multipliers that define the matrix l from
    **          the lu factorization of a as computed by cgttrf.
    **
    **          if fact = 'n', then dlf is an output argument and on exit
    **          contains the (n-1) multipliers that define the matrix l from
    **          the lu factorization of a.
    **
    **  df      (input or output) DATA TYPE array, dimension (n)
    **          if fact = 'f', then df is an input argument and on entry
    **          contains the n diagonal elements of the upper triangular
    **          matrix u from the lu factorization of a.
    **
    **          if fact = 'n', then df is an output argument and on exit
    **          contains the n diagonal elements of the upper triangular
    **          matrix u from the lu factorization of a.
    **
    **  duf     (input or output) DATA TYPE array, dimension (n-1)
    **          if fact = 'f', then duf is an input argument and on entry
    **          contains the (n-1) elements of the first superdiagonal of u.
    **
    **          if fact = 'n', then duf is an output argument and on exit
    **          contains the (n-1) elements of the first superdiagonal of u.
    **
    **  du2     (input or output) DATA TYPE array, dimension (n-2)
    **          if fact = 'f', then du2 is an input argument and on entry
    **          contains the (n-2) elements of the second superdiagonal of
    **          u.
    **
    **          if fact = 'n', then du2 is an output argument and on exit
    **          contains the (n-2) elements of the second superdiagonal of
    **          u.
    **
    **  ipiv    (input or output) long int array, dimension (n)
    **          if fact = 'f', then ipiv is an input argument and on entry
    **          contains the pivot indices from the lu factorization of a as
    **          computed by cgttrf.
    **
    **          if fact = 'n', then ipiv is an output argument and on exit
    **          contains the pivot indices from the lu factorization of a;
    **          row i of the matrix was interchanged with row ipiv(i).
    **          ipiv(i) will always be either i or i+1; ipiv(i) = i indicates
    **          a row interchange was not required.
    **
    **  b       (input) DATA TYPE array, dimension (ldb,nrhs)
    **          the n-by-nrhs right hand side matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (output) DATA TYPE array, dimension (ldx,nrhs)
    **          if info = 0 or info = n+1, the n-by-nrhs solution matrix x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  rcond   (output) BASE DATA TYPE
    **          the estimate of the reciprocal condition number of the matrix
    **          a.  if rcond is less than the machine precision (in
    **          particular, if rcond = 0), the matrix is singular to WORKing
    **          precision.  this condition is indicated by a return code of
    **          info > 0.
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the estimated forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).  the estimate is as reliable as
    **          the estimate for rcond, and is almost always a slight
    **          overestimate of the true error.
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, and i is
    **                <= n:  u(i,i) is exactly zero.  the factorization
    **                       has not been completed unless i = n, but the
    **                       factor u is exactly singular, so the solution
    **                       and error bounds could not be computed.
    **                       rcond = 0 is returned.
    **                = n+1: u is nonsingular, but rcond is less than machine
    **                       precision, meaning that the matrix is singular
    **                       to WORKing precision.  nevertheless, the
    **                       solution and error bounds are computed because
    **                       there are a number of situations where the
    **                       computed solution can be more accurate than the
    **                       value of rcond would suggest.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gtsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        float* dlf,
        float* df,
        float* duf,
        float* du2,
        long int* ipiv,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gtsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* dl,
        const float* d,
        const float* du,
        float* dlf,
        float* df,
        float* duf,
        float* du2,
        long int* ipiv,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void gtsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        double* dlf,
        double* df,
        double* duf,
        double* du2,
        long int* ipiv,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gtsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* dl,
        const double* d,
        const double* du,
        double* dlf,
        double* df,
        double* duf,
        double* du2,
        long int* ipiv,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgtsvx.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTSVX(NAME, T)\
inline void gtsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    T* dlf,\
    T* df,\
    T* duf,\
    T* du2,\
    long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*n);\
    w.resizew(3**n);\
    F77NAME( NAME )(fact, trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getiw(), info);\
}\
inline void gtsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    T* dlf,\
    T* df,\
    T* duf,\
    T* du2,\
    long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   gtsvx(fact, trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_GTSVX(sgtsvx, float)
    LPP_GTSVX(dgtsvx, double)

#undef LPP_GTSVX


  // The following macro provides the 4 functions 
  /*! fn
   inline void gtsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       std::complex<float>* dlf,
       std::complex<float>* df,
       std::complex<float>* duf,
       std::complex<float>* du2,
       long int* ipiv,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gtsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       std::complex<float>* dlf,
       std::complex<float>* df,
       std::complex<float>* duf,
       std::complex<float>* du2,
       long int* ipiv,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void gtsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       std::complex<double>* dlf,
       std::complex<double>* df,
       std::complex<double>* duf,
       std::complex<double>* du2,
       long int* ipiv,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gtsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       std::complex<double>* dlf,
       std::complex<double>* df,
       std::complex<double>* duf,
       std::complex<double>* du2,
       long int* ipiv,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgtsvx.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GTSVX(NAME, T, TBASE)\
inline void gtsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    T* dlf,\
    T* df,\
    T* duf,\
    T* du2,\
    long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(*n);\
    w.resizew(2**n);\
    F77NAME( NAME )(fact, trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getrw(), info);\
}\
inline void gtsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* dl,\
    const T* d,\
    const T* du,\
    T* dlf,\
    T* df,\
    T* duf,\
    T* du2,\
    long int* ipiv,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   gtsvx(fact, trans, n, nrhs, dl, d, du, dlf, df, duf, du2, ipiv, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_GTSVX(cgtsvx, std::complex<float>, float)
    LPP_GTSVX(zgtsvx, std::complex<double>, double)

#undef LPP_GTSVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gtsvx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
