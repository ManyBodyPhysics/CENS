#ifndef __PROJECT__LPP__FILE__LAED2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed2_itf.hh C++ interface to LAPACK (s,d,c,z)laed2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed2_itf.hh
    (excerpt adapted from xlaed2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed2 merges the two sets of eigenvalues together into a single
    **  sorted set.  then it tries to deflate the size of the problem.
    **  there are two ways in which deflation can occur:  when two or more
    **  eigenvalues are close together or if there is a tiny entry in the
    **  z vector.  for each such occurrence the order of the related secular
    **  equation problem is reduced by one.
    **
    **  arguments
    **  =========
    **
    **  k      (output) long int
    **         the number of non-deflated eigenvalues, and the order of the
    **         related secular equation. 0 <= k <=n.
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  n1     (input) long int
    **         the location of the last eigenvalue in the leading sub-matrix.
    **         min(1,n) <= n1 <= n/2.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry, d contains the eigenvalues of the two submatrices to
    **         be combined.
    **         on exit, d contains the trailing (n-k) updated eigenvalues
    **         (those which were deflated) sorted into increasing order.
    **
    **  q      (input/output) BASE DATA TYPE array, dimension (ldq, n)
    **         on entry, q contains the eigenvectors of two submatrices in
    **         the two square blocks with corners at (1,1), (n1,n1)
    **         and (n1+1, n1+1), (n,n).
    **         on exit, q contains the trailing (n-k) updated eigenvectors
    **         (those which were deflated) in its last n-k columns.
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  indxq  (input/output) long int array, dimension (n)
    **         the permutation which separately sorts the two sub-problems
    **         in d into ascending order.  note that elements in the second
    **         half of this permutation must first have n1 added to their
    **         values. destroyed on exit.
    **
    **  rho    (input/output) BASE DATA TYPE
    **         on entry, the off-diagonal element associated with the rank-1
    **         cut which originally split the two submatrices which are now
    **         being recombined.
    **         on exit, rho has been modified to the value required by
    **         dlaed3.
    **
    **  z      (input) BASE DATA TYPE array, dimension (n)
    **         on entry, z contains the updating vector (the last
    **         row of the first sub-eigenvector matrix and the first row of
    **         the second sub-eigenvector matrix).
    **         on exit, the contents of z have been destroyed by the updating
    **         process.
    **
    **  dlamda (output) BASE DATA TYPE array, dimension (n)
    **         a copy of the first k eigenvalues which will be used by
    **         dlaed3 to form the secular equation.
    **
    **  w      (output) BASE DATA TYPE array, dimension (n)
    **         the first k values of the final deflation-altered z-vector
    **         which will be passed to dlaed3.
    **
    **  q2     (output) BASE DATA TYPE array, dimension (n1**2+(n-n1)**2)
    **         a copy of the first k eigenvectors which will be used by
    **         dlaed3 in a matrix multiply (dgemm) to solve for the new
    **         eigenvectors.
    **
    **
    **  indxc  (output) long int array, dimension (n)
    **         the permutation used to arrange the columns of the deflated
    **         q matrix into three groups:  the first group contains non-zero
    **         elements only at and above n1, the second contains
    **         non-zero elements only below n1, and the third is dense.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **  modified by francoise tisseur, university of tennessee.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed2(
        long int* k,
        const long int* n,
        const long int* n1,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        float* rho,
        const float* z,
        float* dlamda,
        float* ws,
        float* q2,
        long int* indx,
        long int* indxc,
        long int* indxp,
        long int* coltyp,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed2(
        long int* k,
        const long int* n,
        const long int* n1,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        float* rho,
        const float* z,
        float* dlamda,
        float* ws,
        float* q2,
        long int* indx,
        long int* indxc,
        long int* indxp,
        long int* coltyp,
        long int* info)
  */
  /*! fn
   inline void laed2(
        long int* k,
        const long int* n,
        const long int* n1,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        double* rho,
        const double* z,
        double* dlamda,
        double* ws,
        double* q2,
        long int* indx,
        long int* indxc,
        long int* indxp,
        long int* coltyp,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed2(
        long int* k,
        const long int* n,
        const long int* n1,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        double* rho,
        const double* z,
        double* dlamda,
        double* ws,
        double* q2,
        long int* indx,
        long int* indxc,
        long int* indxp,
        long int* coltyp,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed2.f)
  //    *  INDX   (workspace) long int array, dimension (N)
  //    *         The permutation used to sort the contents of DLAMDA into
  //    *         ascending order.
  //    *
  //    *  INDXP  (workspace) long int array, dimension (N)
  //    *         The permutation used to place deflated values of D at the end
  //    *         of the array.  INDXP(1:K) points to the nondeflated D-values
  //    *         and INDXP(K+1:N) points to the deflated eigenvalues.
  //    *
  //    *  COLTYP (workspace/output) long int array, dimension (N)
  //    *         During execution, a label which will indicate which of the
  //    *         following types a column in the Q2 matrix is:
  //    *         1 : non-zero in the upper half only;
  //    *         2 : dense;
  //    *         3 : non-zero in the lower half only;
  //    *         4 : deflated.
  //    *         On exit, COLTYP(i) is the number of columns of type i,
  //    *         for i=1 to 4 only.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED2(NAME, T)\
inline void laed2(\
    long int* k,\
    const long int* n,\
    const long int* n1,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    T* rho,\
    const T* z,\
    T* dlamda,\
    T* ws,\
    T* q2,\
    long int* indx,\
    long int* indxc,\
    long int* indxp,\
    long int* coltyp,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(k, n, n1, d, q, ldq, indxq, rho, z, dlamda, ws, q2, indx, indxc, indxp, coltyp, info);\
}\
inline void laed2(\
    long int* k,\
    const long int* n,\
    const long int* n1,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    T* rho,\
    const T* z,\
    T* dlamda,\
    T* ws,\
    T* q2,\
    long int* indx,\
    long int* indxc,\
    long int* indxp,\
    long int* coltyp,\
    long int* info)\
{\
   workspace<T> w;\
   laed2(k, n, n1, d, q, ldq, indxq, rho, z, dlamda, ws, q2, indx, indxc, indxp, coltyp, info, w);\
}\

    LPP_LAED2(slaed2, float)
    LPP_LAED2(dlaed2, double)

#undef LPP_LAED2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
