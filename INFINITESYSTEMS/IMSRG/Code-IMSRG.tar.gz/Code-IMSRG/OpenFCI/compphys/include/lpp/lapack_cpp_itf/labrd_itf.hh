#ifndef __PROJECT__LPP__FILE__LABRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__LABRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : labrd_itf.hh C++ interface to LAPACK (c,d,c,z)labrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file labrd_itf.hh
    (excerpt adapted from xlabrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlabrd reduces the first nb rows and columns of a DATA TYPE general
    **  m by n matrix a to upper or lower BASE DATA TYPE bidiagonal form by a unitary
    **  transformation q' * a * p, and returns the matrices x and y which
    **  are needed to apply the transformation to the unreduced part of a.
    **
    **  if m >= n, a is reduced to upper bidiagonal form; if m < n, to lower
    **  bidiagonal form.
    **
    **  this is an auxiliary routine called by cgebrd
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows in the matrix a.
    **
    **  n       (input) long int
    **          the number of columns in the matrix a.
    **
    **  nb      (input) long int
    **          the number of leading rows and columns of a to be reduced.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m by n general matrix to be reduced.
    **          on exit, the first nb rows and columns of the matrix are
    **          overwritten; the rest of the array is unchanged.
    **          if m >= n, elements on and below the diagonal in the first nb
    **            columns, with the array tauq, represent the unitary
    **            matrix q as a product of elementary reflectors; and
    **            elements above the diagonal in the first nb rows, with the
    **            array taup, represent the unitary matrix p as a product
    **            of elementary reflectors.
    **          if m < n, elements below the diagonal in the first nb
    **            columns, with the array tauq, represent the unitary
    **            matrix q as a product of elementary reflectors, and
    **            elements on and above the diagonal in the first nb rows,
    **            with the array taup, represent the unitary matrix p as
    **            a product of elementary reflectors.
    **          see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  d       (output) BASE DATA TYPE array, dimension (nb)
    **          the diagonal elements of the first nb rows and columns of
    **          the reduced matrix.  d(i) = a(i,i).
    **
    **  e       (output) BASE DATA TYPE array, dimension (nb)
    **          the off-diagonal elements of the first nb rows and columns of
    **          the reduced matrix.
    **
    **  tauq    (output) DATA TYPE array dimension (nb)
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix q. see further details.
    **
    **  taup    (output) DATA TYPE array, dimension (nb)
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix p. see further details.
    **
    **  x       (output) DATA TYPE array, dimension (ldx,nb)
    **          the m-by-nb matrix x required to update the unreduced part
    **          of a.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x. ldx >= max(1,m).
    **
    **  y       (output) DATA TYPE array, dimension (ldy,nb)
    **          the n-by-nb matrix y required to update the unreduced part
    **          of a.
    **
    **  ldy     (output) long int
    **          the leading dimension of the array y. ldy >= max(1,n).
    **
    **  further details
    **  ===============
    **
    **  the matrices q and p are represented as products of elementary
    **  reflectors:
    **
    **     q = h(1) h(2) . . . h(nb)  and  p = g(1) g(2) . . . g(nb)
    **
    **  each h(i) and g(i) has the form:
    **
    **     h(i) = i - tauq * v * v'  and g(i) = i - taup * u * u'
    **
    **  where tauq and taup are DATA TYPE scalars, and v and u are DATA TYPE
    **  vectors.
    **
    **  if m >= n, v(1:i-1) = 0, v(i) = 1, and v(i:m) is stored on exit in
    **  a(i:m,i); u(1:i) = 0, u(i+1) = 1, and u(i+1:n) is stored on exit in
    **  a(i,i+1:n); tauq is stored in tauq(i) and taup in taup(i).
    **
    **  if m < n, v(1:i) = 0, v(i+1) = 1, and v(i+1:m) is stored on exit in
    **  a(i+2:m,i); u(1:i-1) = 0, u(i) = 1, and u(i:n) is stored on exit in
    **  a(i,i+1:n); tauq is stored in tauq(i) and taup in taup(i).
    **
    **  the elements of the vectors v and u together form the m-by-nb matrix
    **  v and the nb-by-n matrix u' which are needed, with x and y, to apply
    **  the transformation to the unreduced part of the matrix, using a block
    **  update of the form:  a := a - v*y' - x*u'.
    **
    **  the contents of a on exit are illustrated by the following examples
    **  with nb = 2:
    **
    **  m = 6 and n = 5 (m > n):          m = 5 and n = 6 (m < n):
    **
    **    (  1   1   u1  u1  u1 )           (  1   u1  u1  u1  u1  u1 )
    **    (  v1  1   1   u2  u2 )           (  1   1   u2  u2  u2  u2 )
    **    (  v1  v2  a   a   a  )           (  v1  1   a   a   a   a  )
    **    (  v1  v2  a   a   a  )           (  v1  v2  a   a   a   a  )
    **    (  v1  v2  a   a   a  )           (  v1  v2  a   a   a   a  )
    **    (  v1  v2  a   a   a  )
    **
    **  where a denotes an element of the original matrix which is unchanged,
    **  vi denotes an element of the vector defining h(i), and ui an element
    **  of the vector defining g(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void labrd(
        const long int* m,
        const long int* n,
        const long int* nb,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tauq,
        float* taup,
        float* x,
        const long int* ldx,
        float* y,
        long int* ldy,
        workspace<float> & w)
  */
  /*! fn
   inline void labrd(
        const long int* m,
        const long int* n,
        const long int* nb,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tauq,
        float* taup,
        float* x,
        const long int* ldx,
        float* y,
        long int* ldy)
  */
  /*! fn
   inline void labrd(
        const long int* m,
        const long int* n,
        const long int* nb,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tauq,
        double* taup,
        double* x,
        const long int* ldx,
        double* y,
        long int* ldy,
        workspace<double> & w)
  */
  /*! fn
   inline void labrd(
        const long int* m,
        const long int* n,
        const long int* nb,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tauq,
        double* taup,
        double* x,
        const long int* ldx,
        double* y,
        long int* ldy)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slabrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LABRD(NAME, T)\
inline void labrd(\
    const long int* m,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tauq,\
    T* taup,\
    T* x,\
    const long int* ldx,\
    T* y,\
    long int* ldy,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, nb, a, lda, d, e, tauq, taup, x, ldx, y, ldy);\
}\
inline void labrd(\
    const long int* m,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tauq,\
    T* taup,\
    T* x,\
    const long int* ldx,\
    T* y,\
    long int* ldy)\
{\
   workspace<T> w;\
   labrd(m, n, nb, a, lda, d, e, tauq, taup, x, ldx, y, ldy, w);\
}\

    LPP_LABRD(slabrd, float)
    LPP_LABRD(dlabrd, double)

#undef LPP_LABRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void labrd(
       const long int* m,
       const long int* n,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       const float* d,
       float* e,
       std::complex<float>* tauq,
       std::complex<float>* taup,
       std::complex<float>* x,
       const long int* ldx,
       std::complex<float>* y,
       long int* ldy,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void labrd(
       const long int* m,
       const long int* n,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       const float* d,
       float* e,
       std::complex<float>* tauq,
       std::complex<float>* taup,
       std::complex<float>* x,
       const long int* ldx,
       std::complex<float>* y,
       long int* ldy)
  */
  /*! fn
   inline void labrd(
       const long int* m,
       const long int* n,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       const double* d,
       double* e,
       std::complex<double>* tauq,
       std::complex<double>* taup,
       std::complex<double>* x,
       const long int* ldx,
       std::complex<double>* y,
       long int* ldy,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void labrd(
       const long int* m,
       const long int* n,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       const double* d,
       double* e,
       std::complex<double>* tauq,
       std::complex<double>* taup,
       std::complex<double>* x,
       const long int* ldx,
       std::complex<double>* y,
       long int* ldy)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clabrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LABRD(NAME, T, TBASE)\
inline void labrd(\
    const long int* m,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    const TBASE* d,\
    TBASE* e,\
    T* tauq,\
    T* taup,\
    T* x,\
    const long int* ldx,\
    T* y,\
    long int* ldy,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, nb, a, lda, d, e, tauq, taup, x, ldx, y, ldy);\
}\
inline void labrd(\
    const long int* m,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    const TBASE* d,\
    TBASE* e,\
    T* tauq,\
    T* taup,\
    T* x,\
    const long int* ldx,\
    T* y,\
    long int* ldy)\
{\
   workspace<T> w;\
   labrd(m, n, nb, a, lda, d, e, tauq, taup, x, ldx, y, ldy, w);\
}\

    LPP_LABRD(clabrd, std::complex<float>,  float)
    LPP_LABRD(zlabrd, std::complex<double>, double)

#undef LPP_LABRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of labrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
