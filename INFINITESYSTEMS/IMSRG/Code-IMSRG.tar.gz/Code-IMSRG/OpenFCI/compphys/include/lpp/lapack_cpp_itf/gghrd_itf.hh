#ifndef __PROJECT__LPP__FILE__GGHRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGHRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gghrd_itf.hh C++ interface to LAPACK (c,d,c,z)gghrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gghrd_itf.hh
    (excerpt adapted from xgghrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgghrd reduces a pair of DATA TYPE matrices (a,b) to generalized upper
    **  hessenberg form using unitary transformations, where a is a
    **  general matrix and b is upper triangular.  the form of the generalized
    **  eigenvalue problem is
    **     a*x = lambda*b*x,
    **  and b is typically made upper triangular by computing its qr
    **  factorization and moving the unitary matrix q to the left side
    **  of the equation.
    **
    **  this subroutine simultaneously reduces a to a hessenberg matrix h:
    **     q**h*a*z = h
    **  and transforms b to another upper triangular matrix t:
    **     q**h*b*z = t
    **  in order to reduce the problem to its standard form
    **     h*y = lambda*t*y
    **  where y = z**h*x.
    **
    **  the unitary matrices q and z are determined as products of givens
    **  rotations.  they may either be formed explicitly, or they may be
    **  postmultiplied into input matrices q1 and z1, so that
    **       q1 * a * z1**h = (q1*q) * h * (z1*z)**h
    **       q1 * b * z1**h = (q1*q) * t * (z1*z)**h
    **  if q1 is the unitary matrix from the qr factorization of b in the
    **  original equation a*x = lambda*b*x, then xgghrd reduces the original
    **  problem to generalized hessenberg form.
    **
    **  arguments
    **  =========
    **
    **  compq   (input) char
    **          = 'n': do not compute q;
    **          = 'i': q is initialized to the unit matrix, and the
    **                 unitary matrix q is returned;
    **          = 'v': q must contain a unitary matrix q1 on entry,
    **                 and the product q1*q is returned.
    **
    **  compz   (input) char
    **          = 'n': do not compute q;
    **          = 'i': q is initialized to the unit matrix, and the
    **                 unitary matrix q is returned;
    **          = 'v': q must contain a unitary matrix q1 on entry,
    **                 and the product q1*q is returned.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          ilo and ihi mark the rows and columns of a which are to be
    **          reduced.  it is assumed that a is already upper triangular
    **          in rows and columns 1:ilo-1 and ihi+1:n.  ilo and ihi are
    **          normally set by a previous call to cggbal; otherwise they
    **          should be set to 1 and n respectively.
    **          1 <= ilo <= ihi <= n, if n > 0; ilo=1 and ihi=0, if n=0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the n-by-n general matrix to be reduced.
    **          on exit, the upper triangle and the first subdiagonal of a
    **          are overwritten with the upper hessenberg matrix h, and the
    **          rest is set to zero.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the n-by-n upper triangular matrix b.
    **          on exit, the upper triangular matrix t = q**h b z.  the
    **          elements below the diagonal are set to zero.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq, n)
    **          on entry, if compq = 'v', the unitary matrix q1, typically
    **          from the qr factorization of b.
    **          on exit, if compq='i', the unitary matrix q, and if
    **          compq = 'v', the product q1*q.
    **          not referenced if compq='n'.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.
    **          ldq >= n if compq='v' or 'i'; ldq >= 1 otherwise.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz, n)
    **          on entry, if compz = 'v', the unitary matrix z1.
    **          on exit, if compz='i', the unitary matrix z, and if
    **          compz = 'v', the product z1*z.
    **          not referenced if compz='n'.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.
    **          ldz >= n if compz='v' or 'i'; ldz >= 1 otherwise.
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  this routine reduces a to hessenberg and b to triangular form by
    **  an unblocked reduction, as described in _matrix_computations_,
    **  by golub and van loan (johns hopkins press).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gghrd(
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gghrd(
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void gghrd(
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gghrd(
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgghrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGHRD(NAME, T)\
inline void gghrd(\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(compq, compz, n, ilo, ihi, a, lda, b, ldb, q, ldq, z, ldz, info);\
}\
inline void gghrd(\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   gghrd(compq, compz, n, ilo, ihi, a, lda, b, ldb, q, ldq, z, ldz, info, w);\
}\

    LPP_GGHRD(sgghrd, float)
    LPP_GGHRD(dgghrd, double)

#undef LPP_GGHRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gghrd(
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gghrd(
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void gghrd(
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gghrd(
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgghrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGHRD(NAME, T, TBASE)\
inline void gghrd(\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(compq, compz, n, ilo, ihi, a, lda, b, ldb, q, ldq, z, ldz, info);\
}\
inline void gghrd(\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   gghrd(compq, compz, n, ilo, ihi, a, lda, b, ldb, q, ldq, z, ldz, info, w);\
}\

    LPP_GGHRD(cgghrd, std::complex<float>,  float)
    LPP_GGHRD(zgghrd, std::complex<double>, double)

#undef LPP_GGHRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gghrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
