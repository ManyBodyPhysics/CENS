#ifndef __PROJECT__LPP__FILE__LARTV_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARTV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lartv_itf.hh C++ interface to LAPACK (c,d,c,z)lartv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lartv_itf.hh
    (excerpt adapted from xlartv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlartv applies a vector of DATA TYPE plane rotations with BASE DATA TYPE cosines
    **  to elements of the DATA TYPE vectors x and y. for i = 1,2,...,n
    **
    **     ( x(i) ) := (        c(i)   s(i) ) ( x(i) )
    **     ( y(i) )    ( -conjg(s(i))  c(i) ) ( y(i) )
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of plane rotations to be applied.
    **
    **  x       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          the vector x.
    **
    **  incx    (input) long int
    **          the increment between elements of x. incx > 0.
    **
    **  y       (input/output) DATA TYPE array, dimension (1+(n-1)*incy)
    **          the vector y.
    **
    **  incy    (input) long int
    **          the increment between elements of y. incy > 0.
    **
    **  c       (input) BASE DATA TYPE array, dimension (1+(n-1)*incc)
    **          the cosines of the plane rotations.
    **
    **  s       (input) DATA TYPE array, dimension (1+(n-1)*incc)
    **          the sines of the plane rotations.
    **
    **  incc    (input) long int
    **          the increment between elements of c and s. incc > 0.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lartv(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        const float* c,
        const float* s,
        const long int* incc,
        workspace<float> & w)
  */
  /*! fn
   inline void lartv(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        const float* c,
        const float* s,
        const long int* incc)
  */
  /*! fn
   inline void lartv(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        const double* c,
        const double* s,
        const long int* incc,
        workspace<double> & w)
  */
  /*! fn
   inline void lartv(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        const double* c,
        const double* s,
        const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slartv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARTV(NAME, T)\
inline void lartv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const T* c,\
    const T* s,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, c, s, incc);\
}\
inline void lartv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const T* c,\
    const T* s,\
    const long int* incc)\
{\
   workspace<T> w;\
   lartv(n, x, incx, y, incy, c, s, incc, w);\
}\

    LPP_LARTV(slartv, float)
    LPP_LARTV(dlartv, double)

#undef LPP_LARTV


  // The following macro provides the 4 functions 
  /*! fn
   inline void lartv(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       const float* c,
       const std::complex<float>* s,
       const long int* incc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lartv(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       const float* c,
       const std::complex<float>* s,
       const long int* incc)
  */
  /*! fn
   inline void lartv(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       const double* c,
       const std::complex<double>* s,
       const long int* incc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lartv(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       const double* c,
       const std::complex<double>* s,
       const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clartv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARTV(NAME, T, TBASE)\
inline void lartv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const TBASE* c,\
    const T* s,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, c, s, incc);\
}\
inline void lartv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const TBASE* c,\
    const T* s,\
    const long int* incc)\
{\
   workspace<T> w;\
   lartv(n, x, incx, y, incy, c, s, incc, w);\
}\

    LPP_LARTV(clartv, std::complex<float>,  float)
    LPP_LARTV(zlartv, std::complex<double>, double)

#undef LPP_LARTV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lartv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
