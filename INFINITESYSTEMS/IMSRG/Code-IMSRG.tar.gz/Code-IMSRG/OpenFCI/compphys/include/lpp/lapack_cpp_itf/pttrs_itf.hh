#ifndef __PROJECT__LPP__FILE__PTTRS_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTTRS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pttrs_itf.hh C++ interface to LAPACK (c,d,c,z)pttrs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pttrs_itf.hh
    (excerpt adapted from xpttrs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpttrs solves a tridiagonal system of the form
    **     a * x = b
    **  using the factorization a = u'*d*u or a = l*d*l' computed by cpttrf.
    **  d is a diagonal matrix specified in the vector d, u (or l) is a unit
    **  bidiagonal matrix whose superdiagonal (subdiagonal) is specified in
    **  the vector e, and x and b are n by nrhs matrices.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies the form of the factorization and whether the
    **          vector e is the superdiagonal of the upper bidiagonal factor
    **          u or the subdiagonal of the lower bidiagonal factor l.
    **          = 'u':  a = u'*d*u, e is the superdiagonal of u
    **          = 'l':  a = l*d*l', e is the subdiagonal of l
    **
    **  n       (input) long int
    **          the order of the tridiagonal matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d from the
    **          factorization a = u'*d*u or a = l*d*l'.
    **
    **  e       (input) DATA TYPE array, dimension (n-1)
    **          if uplo = 'u', the (n-1) superdiagonal elements of the unit
    **          bidiagonal factor u from the factorization a = u'*d*u.
    **          if uplo = 'l', the (n-1) subdiagonal elements of the unit
    **          bidiagonal factor l from the factorization a = l*d*l'.
    **
    **  b       (input/output) BASE DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the right hand side vectors b for the system of
    **          linear equations.
    **          on exit, the solution vectors, x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pttrs(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pttrs(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void pttrs(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pttrs(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spttrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTRS(NAME, T)\
inline void pttrs(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, nrhs, d, e, b, ldb, info);\
}\
inline void pttrs(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   pttrs(n, nrhs, d, e, b, ldb, info, w);\
}\

    LPP_PTTRS(spttrs, float)
    LPP_PTTRS(dpttrs, double)

#undef LPP_PTTRS


  // The following macro provides the 4 functions 
  /*! fn
   inline void pttrs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pttrs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void pttrs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pttrs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpttrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTRS(NAME, T, TBASE)\
inline void pttrs(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, d, e, b, ldb, info);\
}\
inline void pttrs(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   pttrs(uplo, n, nrhs, d, e, b, ldb, info, w);\
}\

    LPP_PTTRS(cpttrs, std::complex<float>,  float)
    LPP_PTTRS(zpttrs, std::complex<double>, double)

#undef LPP_PTTRS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pttrs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
