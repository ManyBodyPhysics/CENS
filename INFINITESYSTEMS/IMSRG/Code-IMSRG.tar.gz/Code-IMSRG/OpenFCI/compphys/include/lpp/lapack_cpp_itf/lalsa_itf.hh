#ifndef __PROJECT__LPP__FILE__LALSA_HH__INCLUDED
#define __PROJECT__LPP__FILE__LALSA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lalsa_itf.hh C++ interface to LAPACK (s,d,c,z)lalsa
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lalsa_itf.hh
    (excerpt adapted from xlalsa.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlalsa is an itermediate step in solving the least squares problem
    **  by computing the svd of the coefficient matrix in compact form (the
    **  singular vectors are computed as products of simple orthorgonal
    **  matrices.).
    **
    **  if icompq = 0, xlalsa applies the inverse of the left singular vector
    **  matrix of an upper bidiagonal matrix to the right hand side; and if
    **  icompq = 1, xlalsa applies the right singular vector matrix to the
    **  right hand side. the singular vector matrices were generated in
    **  compact form by xlalsa.
    **
    **  arguments
    **  =========
    **
    **  icompq (input) long int
    **         specifies whether the left or the right singular vector
    **         matrix is involved.
    **         = 0: left singular vector matrix
    **         = 1: right singular vector matrix
    **
    **  smlsiz (input) long int
    **         the maximum size of the subproblems at the bottom of the
    **         computation tree.
    **
    **  n      (input) long int
    **         the row and column dimensions of the upper bidiagonal matrix.
    **
    **  nrhs   (input) long int
    **         the number of columns of b and bx. nrhs must be at least 1.
    **
    **  b      (input) DATA TYPE array, dimension ( ldb, nrhs )
    **         on input, b contains the right hand sides of the least
    **         squares problem in rows 1 through m. on output, b contains
    **         the solution x in rows 1 through n.
    **
    **  ldb    (input) long int
    **         the leading dimension of b in the calling subprogram.
    **         ldb must be at least max(1,max( m, n ) ).
    **
    **  bx     (output) DATA TYPE array, dimension ( ldbx, nrhs )
    **         on exit, the result of applying the left or right singular
    **         vector matrix to b.
    **
    **  ldbx   (input) long int
    **         the leading dimension of bx.
    **
    **  u      (input) BASE DATA TYPE array, dimension ( ldu, smlsiz ).
    **         on entry, u contains the left singular vector matrices of all
    **         subproblems at the bottom level.
    **
    **  ldu    (input) long int, ldu = > n.
    **         the leading dimension of arrays u, vt, difl, difr,
    **         poles, givnum, and z.
    **
    **  vt     (input) BASE DATA TYPE array, dimension ( ldu, smlsiz+1 ).
    **         on entry, vt' contains the right singular vector matrices of
    **         all subproblems at the bottom level.
    **
    **  k      (input) long int array, dimension ( n ).
    **
    **  difl   (input) BASE DATA TYPE array, dimension ( ldu, nlvl ).
    **         where nlvl = int(log_2 (n/(smlsiz+1))) + 1.
    **
    **  difr   (input) BASE DATA TYPE array, dimension ( ldu, 2 * nlvl ).
    **         on entry, difl(*, i) and difr(*, 2 * i -1) record
    **         distances between singular values on the i-th level and
    **         singular values on the (i -1)-th level, and difr(*, 2 * i)
    **         record the normalizing factors of the right singular vectors
    **         matrices of subproblems on i-th level.
    **
    **  z      (input) BASE DATA TYPE array, dimension ( ldu, nlvl ).
    **         on entry, z(1, i) contains the components of the deflation-
    **         adjusted updating row vector for subproblems on the i-th
    **         level.
    **
    **  poles  (input) BASE DATA TYPE array, dimension ( ldu, 2 * nlvl ).
    **         on entry, poles(*, 2 * i -1: 2 * i) contains the new and old
    **         singular values involved in the secular equations on the i-th
    **         level.
    **
    **  givptr (input) long int array, dimension ( n ).
    **         on entry, givptr( i ) records the number of givens
    **         rotations performed on the i-th problem on the computation
    **         tree.
    **
    **  givcol (input) long int array, dimension ( ldgcol, 2 * nlvl ).
    **         on entry, for each i, givcol(*, 2 * i - 1: 2 * i) records the
    **         locations of givens rotations performed on the i-th level on
    **         the computation tree.
    **
    **  ldgcol (input) long int, ldgcol = > n.
    **         the leading dimension of arrays givcol and perm.
    **
    **  perm   (input) long int array, dimension ( ldgcol, nlvl ).
    **         on entry, perm(*, i) records permutations done on the i-th
    **         level of the computation tree.
    **
    **  givnum (input) BASE DATA TYPE array, dimension ( ldu, 2 * nlvl ).
    **         on entry, givnum(*, 2 *i -1 : 2 * i) records the c- and s-
    **         values of givens rotations performed on the i-th level on the
    **         computation tree.
    **
    **  c      (input) BASE DATA TYPE array, dimension ( n ).
    **         on entry, if the i-th subproblem is not square,
    **         c( i ) contains the c-value of a givens rotation related to
    **         the right null space of the i-th subproblem.
    **
    **  s      (input) BASE DATA TYPE array, dimension ( n ).
    **         on entry, if the i-th subproblem is not square,
    **         s( i ) contains the s-value of a givens rotation related to
    **         the right null space of the i-th subproblem.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and ren-cang li, computer science division, university of
    **       california at berkeley, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lalsa(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        const float* b,
        const long int* ldb,
        float* bx,
        const long int* ldbx,
        const float* u,
        const long int* ldu,
        const float* vt,
        const long int* k,
        const float* difl,
        const float* difr,
        const float* z,
        const float* poles,
        const long int* givptr,
        const long int* givcol,
        const long int* ldgcol,
        const long int* perm,
        const float* givnum,
        const float* c,
        const float* s,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lalsa(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        const float* b,
        const long int* ldb,
        float* bx,
        const long int* ldbx,
        const float* u,
        const long int* ldu,
        const float* vt,
        const long int* k,
        const float* difl,
        const float* difr,
        const float* z,
        const float* poles,
        const long int* givptr,
        const long int* givcol,
        const long int* ldgcol,
        const long int* perm,
        const float* givnum,
        const float* c,
        const float* s,
        long int* info)
  */
  /*! fn
   inline void lalsa(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        const double* b,
        const long int* ldb,
        double* bx,
        const long int* ldbx,
        const double* u,
        const long int* ldu,
        const double* vt,
        const long int* k,
        const double* difl,
        const double* difr,
        const double* z,
        const double* poles,
        const long int* givptr,
        const long int* givcol,
        const long int* ldgcol,
        const long int* perm,
        const double* givnum,
        const double* c,
        const double* s,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lalsa(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* nrhs,
        const double* b,
        const long int* ldb,
        double* bx,
        const long int* ldbx,
        const double* u,
        const long int* ldu,
        const double* vt,
        const long int* k,
        const double* difl,
        const double* difr,
        const double* z,
        const double* poles,
        const long int* givptr,
        const long int* givcol,
        const long int* ldgcol,
        const long int* perm,
        const double* givnum,
        const double* c,
        const double* s,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slalsa.f)
  //    *  WORK   (workspace) float array.
  //    *         The dimension must be at least N.
  //    *
  //    *  IWORK  (workspace) long int array.
  //    *         The dimension must be at least 3 * N
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LALSA(NAME, T)\
inline void lalsa(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    const T* b,\
    const long int* ldb,\
    T* bx,\
    const long int* ldbx,\
    const T* u,\
    const long int* ldu,\
    const T* vt,\
    const long int* k,\
    const T* difl,\
    const T* difr,\
    const T* z,\
    const T* poles,\
    const long int* givptr,\
    const long int* givcol,\
    const long int* ldgcol,\
    const long int* perm,\
    const T* givnum,\
    const T* c,\
    const T* s,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(3**n);\
    w.resizew(*n);\
    F77NAME( NAME )(icompq, smlsiz, n, nrhs, b, ldb, bx, ldbx, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, w.getw(), w.getiw(), info);\
}\
inline void lalsa(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    const T* b,\
    const long int* ldb,\
    T* bx,\
    const long int* ldbx,\
    const T* u,\
    const long int* ldu,\
    const T* vt,\
    const long int* k,\
    const T* difl,\
    const T* difr,\
    const T* z,\
    const T* poles,\
    const long int* givptr,\
    const long int* givcol,\
    const long int* ldgcol,\
    const long int* perm,\
    const T* givnum,\
    const T* c,\
    const T* s,\
    long int* info)\
{\
   workspace<T> w;\
   lalsa(icompq, smlsiz, n, nrhs, b, ldb, bx, ldbx, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, info, w);\
}\

    LPP_LALSA(slalsa, float)
    LPP_LALSA(dlalsa, double)

#undef LPP_LALSA


  // The following macro provides the 4 functions 
  /*! fn
   inline void lalsa(
       const long int* icompq,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* bx,
       const long int* ldbx,
       const float* u,
       const long int* ldu,
       const float* vt,
       const long int* k,
       const float* difl,
       const float* difr,
       const float* z,
       const float* poles,
       const long int* givptr,
       const long int* givcol,
       const long int* ldgcol,
       const long int* perm,
       const float* givnum,
       const float* c,
       const float* s,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lalsa(
       const long int* icompq,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* bx,
       const long int* ldbx,
       const float* u,
       const long int* ldu,
       const float* vt,
       const long int* k,
       const float* difl,
       const float* difr,
       const float* z,
       const float* poles,
       const long int* givptr,
       const long int* givcol,
       const long int* ldgcol,
       const long int* perm,
       const float* givnum,
       const float* c,
       const float* s,
       long int* info)
  */
  /*! fn
   inline void lalsa(
       const long int* icompq,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* bx,
       const long int* ldbx,
       const double* u,
       const long int* ldu,
       const double* vt,
       const long int* k,
       const double* difl,
       const double* difr,
       const double* z,
       const double* poles,
       const long int* givptr,
       const long int* givcol,
       const long int* ldgcol,
       const long int* perm,
       const double* givnum,
       const double* c,
       const double* s,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lalsa(
       const long int* icompq,
       const long int* smlsiz,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* bx,
       const long int* ldbx,
       const double* u,
       const long int* ldu,
       const double* vt,
       const long int* k,
       const double* difl,
       const double* difr,
       const double* z,
       const double* poles,
       const long int* givptr,
       const long int* givcol,
       const long int* ldgcol,
       const long int* perm,
       const double* givnum,
       const double* c,
       const double* s,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clalsa.f)
  //    *  RWORK  (workspace) float array, dimension at least
  //    *         max ( N, (SMLSZ+1)*NRHS*3 ).
  //    *
  //    *  IWORK  (workspace) long int array.
  //    *         The dimension must be at least 3 * N
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LALSA(NAME, T, TBASE)\
inline void lalsa(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    const T* b,\
    const long int* ldb,\
    T* bx,\
    const long int* ldbx,\
    const TBASE* u,\
    const long int* ldu,\
    const TBASE* vt,\
    const long int* k,\
    const TBASE* difl,\
    const TBASE* difr,\
    const TBASE* z,\
    const TBASE* poles,\
    const long int* givptr,\
    const long int* givcol,\
    const long int* ldgcol,\
    const long int* perm,\
    const TBASE* givnum,\
    const TBASE* c,\
    const TBASE* s,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizerw(std::max ( *n, (*smlsiz+1)*(*nrhs)*3 ));  \
  w.resizeiw(3**n);                                                     \
  F77NAME( NAME )(icompq, smlsiz, n, nrhs, b, ldb, bx, ldbx, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, w.getrw(), w.getiw(), info); \
}\
inline void lalsa(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* nrhs,\
    const T* b,\
    const long int* ldb,\
    T* bx,\
    const long int* ldbx,\
    const TBASE* u,\
    const long int* ldu,\
    const TBASE* vt,\
    const long int* k,\
    const TBASE* difl,\
    const TBASE* difr,\
    const TBASE* z,\
    const TBASE* poles,\
    const long int* givptr,\
    const long int* givcol,\
    const long int* ldgcol,\
    const long int* perm,\
    const TBASE* givnum,\
    const TBASE* c,\
    const TBASE* s,\
    long int* info)\
{\
   workspace<T> w;\
   lalsa(icompq, smlsiz, n, nrhs, b, ldb, bx, ldbx, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, info, w);\
}\

    LPP_LALSA(clalsa, std::complex<float>, float)
    LPP_LALSA(zlalsa, std::complex<double>, double)

#undef LPP_LALSA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lalsa_itf.hh
// /////////////////////////////////////////////////////////////////////////////
