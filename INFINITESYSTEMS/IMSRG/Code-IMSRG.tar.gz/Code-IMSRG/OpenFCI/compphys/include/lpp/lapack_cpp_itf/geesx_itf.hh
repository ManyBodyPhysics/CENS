#ifndef __PROJECT__LPP__FILE__GEESX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEESX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geesx_itf.hh C++ interface to LAPACK (c,d,c,z)geesx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geesx_itf.hh
    (excerpt adapted from xgeesx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgeesx computes for an n-by-n DATA TYPE nonsymmetric matrix a, the
    **  eigenvalues, the schur form t, and, optionally, the matrix of schur
    **  vectors z.  this gives the schur factorization a = z*t*(z**h).
    **
    **  optionally, it also orders the eigenvalues on the diagonal of the
    **  schur form so that selected eigenvalues are at the top left;
    **  computes a reciprocal condition number for the average of the
    **  selected eigenvalues (rconde); and computes a reciprocal condition
    **  number for the right invariant subspace corresponding to the
    **  selected eigenvalues (rcondv).  the leading columns of z form an
    **  orthonormal basis for this invariant subspace.
    **
    **  for further explanation of the reciprocal condition numbers rconde
    **  and rcondv, see section 4.10 of the lapack users' guide (where
    **  these quantities are called s and sep respectively).
    **
    **  a DATA TYPE matrix is in schur form if it is upper triangular.
    **
    **  arguments
    **  =========
    **
    **  jobvs   (input) char
    **          = 'n': schur vectors are not computed;
    **          = 'v': schur vectors are computed.
    **
    **  sort    (input) char
    **          specifies whether or not to order the eigenvalues on the
    **          diagonal of the schur form.
    **          = 'n': eigenvalues are not ordered;
    **          = 's': eigenvalues are ordered (see select).
    **
    **  select  (input) logical function of one DATA TYPE argument
    **          select must be declared external in the calling subroutine.
    **          if sort = 's', select is used to select eigenvalues to order
    **          to the top left of the schur form.
    **          if sort = 'n', select is not referenced.
    **          an eigenvalue w(j) is selected if select(w(j)) is true.
    **
    **  sense   (input) char
    **          determines which reciprocal condition numbers are computed.
    **          = 'n': none are computed;
    **          = 'e': computed for average of selected eigenvalues only;
    **          = 'v': computed for selected right invariant subspace only;
    **          = 'b': computed for both.
    **          if sense = 'e', 'v' or 'b', sort must equal 's'.
    **
    **  n       (input) long int
    **          the order of the matrix a. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the n-by-n matrix a.
    **          on exit, a is overwritten by its schur form t.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  sdim    (output) long int
    **          if sort = 'n', sdim = 0.
    **          if sort = 's', sdim = number of eigenvalues for which
    **                         select is true.
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          w contains the computed eigenvalues, in the same order
    **          that they appear on the diagonal of the output schur form t.
    **
    **  vs      (output) DATA TYPE array, dimension (ldvs,n)
    **          if jobvs = 'v', vs contains the unitary matrix z of schur
    **          vectors.
    **          if jobvs = 'n', vs is not referenced.
    **
    **  ldvs    (input) long int
    **          the leading dimension of the array vs.  ldvs >= 1, and if
    **          jobvs = 'v', ldvs >= n.
    **
    **  rconde  (output) BASE DATA TYPE
    **          if sense = 'e' or 'b', rconde contains the reciprocal
    **          condition number for the average of the selected eigenvalues.
    **          not referenced if sense = 'n' or 'v'.
    **
    **  rcondv  (output) BASE DATA TYPE
    **          if sense = 'v' or 'b', rcondv contains the reciprocal
    **          condition number for the selected right invariant subspace.
    **          not referenced if sense = 'n' or 'e'.
    **
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value.
    **          > 0: if info = i, and i is
    **             <= n: the qr algorithm failed to compute all the
    **                   eigenvalues; elements 1:ilo-1 and i+1:n of w
    **                   contain those eigenvalues which have converged; if
    **                   jobvs = 'v', vs contains the transformation which
    **                   reduces a to its partially converged schur form.
    **             = n+1: the eigenvalues could not be reordered because some
    **                   eigenvalues were too close to separate (the problem
    **                   is very ill-conditioned);
    **             = n+2: after reordering, roundoff changed values of some
    **                   DATA TYPE eigenvalues so that leading eigenvalues in
    **                   the schur form no longer satisfy select=.true.  this
    **                   could also be caused by underflow due to scaling.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geesx(
        const char* jobvs,
        const char* sort,
        const long int* select,
        const char* sense,
        const long int* n,
        float* a,
        const long int* lda,
        long int* sdim,
        float* wr,
        float* wi,
        const float* vs,
        const long int* ldvs,
        float* rconde,
        float* rcondv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geesx(
        const char* jobvs,
        const char* sort,
        const long int* select,
        const char* sense,
        const long int* n,
        float* a,
        const long int* lda,
        long int* sdim,
        float* wr,
        float* wi,
        const float* vs,
        const long int* ldvs,
        float* rconde,
        float* rcondv,
        long int* info)
  */
  /*! fn
   inline void geesx(
        const char* jobvs,
        const char* sort,
        const long int* select,
        const char* sense,
        const long int* n,
        double* a,
        const long int* lda,
        long int* sdim,
        double* wr,
        double* wi,
        const double* vs,
        const long int* ldvs,
        double* rconde,
        double* rcondv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geesx(
        const char* jobvs,
        const char* sort,
        const long int* select,
        const char* sense,
        const long int* n,
        double* a,
        const long int* lda,
        long int* sdim,
        double* wr,
        double* wi,
        const double* vs,
        const long int* ldvs,
        double* rconde,
        double* rcondv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeesx.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,3*N).
  //    *          Also, if SENSE = 'E' or 'V' or 'B',
  //    *          LWORK >= N+2*SDIM*(N-SDIM), where SDIM is the number of
  //    *          selected eigenvalues computed by this routine.  Note that
  //    *          N+2*SDIM*(N-SDIM) <= N+N*N/2.
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          Not referenced if SENSE = 'N' or 'E'.
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEESX(NAME, T)\
inline void geesx(\
    const char* jobvs,\
    const char* sort,\
    const long int* select,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* sdim,\
    T* wr,\
    T* wi,\
    const T* vs,\
    const long int* ldvs,\
    T* rconde,\
    T* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw((lower(*sort) == 'n' || lower(*sort) == 'e')? 0 : *n);     \
    w.resizebw((lower(*sort) == 'n')? 0 : *n);                          \
    long int liwork = -1; \
    F77NAME( NAME )(jobvs, sort, select, sense, n, a, lda, sdim, wr, wi, vs, ldvs, rconde, rcondv, w.getw(), w.query(), w.getiw(), &liwork, w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvs, sort, select, sense, n, a, lda, sdim, wr, wi, vs, ldvs, rconde, rcondv, w.getw(), &w.neededsize(), w.getiw(), &liwork, w.getbw(), info);\
}\
inline void geesx(\
    const char* jobvs,\
    const char* sort,\
    const long int* select,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* sdim,\
    T* wr,\
    T* wi,\
    const T* vs,\
    const long int* ldvs,\
    T* rconde,\
    T* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   geesx(jobvs, sort, select, sense, n, a, lda, sdim, wr, wi, vs, ldvs, rconde, rcondv, info, w);\
}\

    LPP_GEESX(sgeesx, float)
    LPP_GEESX(dgeesx, double)

#undef LPP_GEESX


  // The following macro provides the 4 functions 
  /*! fn
   inline void geesx(
       const char* jobvs,
       const char* sort,
       const long int* select,
       const char* sense,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* sdim,
       std::complex<float>* ws,
       const std::complex<float>* vs,
       const long int* ldvs,
       float* rconde,
       float* rcondv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geesx(
       const char* jobvs,
       const char* sort,
       const long int* select,
       const char* sense,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* sdim,
       std::complex<float>* ws,
       const std::complex<float>* vs,
       const long int* ldvs,
       float* rconde,
       float* rcondv,
       long int* info)
  */
  /*! fn
   inline void geesx(
       const char* jobvs,
       const char* sort,
       const long int* select,
       const char* sense,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* sdim,
       std::complex<double>* ws,
       const std::complex<double>* vs,
       const long int* ldvs,
       double* rconde,
       double* rcondv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geesx(
       const char* jobvs,
       const char* sort,
       const long int* select,
       const char* sense,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* sdim,
       std::complex<double>* ws,
       const std::complex<double>* vs,
       const long int* ldvs,
       double* rconde,
       double* rcondv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeesx.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,2*N).
  //    *          Also, if SENSE = 'E' or 'V' or 'B', LWORK >= 2*SDIM*(N-SDIM),
  //    *          where SDIM is the number of selected eigenvalues computed by
  //    *          this routine.  Note that 2*SDIM*(N-SDIM) <= N*N/2.
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEESX(NAME, T, TBASE)\
inline void geesx(\
    const char* jobvs,\
    const char* sort,\
    const long int* select,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* sdim,\
    T* ws,\
    const T* vs,\
    const long int* ldvs,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(*n);\
    w.resizebw((lower(*sort) == 'n') ? 0 : *n);                         \
    F77NAME( NAME )(jobvs, sort, select, sense, n, a, lda, sdim, ws, vs, ldvs, rconde, rcondv, w.getw(), w.query(), w.getrw(), w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvs, sort, select, sense, n, a, lda, sdim, ws, vs, ldvs, rconde, rcondv, w.getw(), &w.neededsize(), w.getrw(), w.getbw(), info);\
}\
inline void geesx(\
    const char* jobvs,\
    const char* sort,\
    const long int* select,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* sdim,\
    T* ws,\
    const T* vs,\
    const long int* ldvs,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   geesx(jobvs, sort, select, sense, n, a, lda, sdim, ws, vs, ldvs, rconde, rcondv, info, w);\
}\

    LPP_GEESX(cgeesx, std::complex<float>,  float)
    LPP_GEESX(zgeesx, std::complex<double>, double)

#undef LPP_GEESX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geesx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
