#ifndef __PROJECT__LPP__FILE__LASQ2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASQ2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasq2_itf.hh C++ interface to LAPACK (s,d,c,z)lasq2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasq2_itf.hh
    (excerpt adapted from xlasq2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasq2 computes all the eigenvalues of the symmetric positive 
    **  definite tridiagonal matrix associated with the qd array z to high
    **  relative accuracy are computed to high relative accuracy, in the
    **  absence of denormalization, underflow and overflow.
    **
    **  to see the relation of z to the tridiagonal matrix, let l be a
    **  unit lower bidiagonal matrix with subdiagonals z(2,4,6,,..) and
    **  let u be an upper bidiagonal matrix with 1's above and diagonal
    **  z(1,3,5,,..). the tridiagonal is l*u or, if you prefer, the
    **  symmetric tridiagonal to which it is similar.
    **
    **  note : xlasq2 defines a logical variable, ieee, which is true
    **  on machines which follow ieee-754 floating-point standard in their
    **  handling of infinities and nans, and false otherwise. this variable
    **  is passed to dlasq3.
    **
    **  arguments
    **  =========
    **
    **  n     (input) long int
    **        the number of rows and columns in the matrix. n >= 0.
    **
    **
    **  info  (output) long int
    **        = 0: successful exit
    **        < 0: if the i-th argument is a scalar and had an illegal
    **             value, then info = -i, if the i-th argument is an
    **             array and the j-entry had an illegal value, then
    **             info = -(i*100+j)
    **        > 0: the algorithm failed
    **              = 1, a split was marked by a positive value in e
    **              = 2, current block of z not diagonalized after 30*n
    **                   iterations (in inner while loop)
    **              = 3, termination criterion of outer while loop not met 
    **                   (program created more than n unreduced blocks)
    **
    **  further details
    **  ===============
    **  local variables: i0:n0 defines a current unreduced segment of z.
    **  the shifts are accumulated in sigma. iteration count is in iter.
    **  ping-pong is controlled by pp (alternates between 0 and 1).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasq2(
        const long int* n,
        float* z,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasq2(
        const long int* n,
        float* z,
        long int* info)
  */
  /*! fn
   inline void lasq2(
        const long int* n,
        double* z,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasq2(
        const long int* n,
        double* z,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasq2.f)
  //    *  Z     (workspace) float array, dimension ( 4*N )
  //    *        On entry Z holds the qd array. On exit, entries 1 to N hold
  //    *        the eigenvalues in decreasing order, Z( 2*N+1 ) holds the
  //    *        trace, and Z( 2*N+2 ) holds the sum of the eigenvalues. If
  //    *        N > 2, then Z( 2*N+3 ) holds the iteration count, Z( 2*N+4 )
  //    *        holds NDIVS/NIN^2, and Z( 2*N+5 ) holds the percentage of
  //    *        shifts that failed.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASQ2(NAME, T)\
inline void lasq2(\
    const long int* n,\
    T* z,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, z, info);\
}\
inline void lasq2(\
    const long int* n,\
    T* z,\
    long int* info)\
{\
   workspace<T> w;\
   lasq2(n, z, info, w);\
}\

    LPP_LASQ2(slasq2, float)
    LPP_LASQ2(dlasq2, double)

#undef LPP_LASQ2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasq2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
