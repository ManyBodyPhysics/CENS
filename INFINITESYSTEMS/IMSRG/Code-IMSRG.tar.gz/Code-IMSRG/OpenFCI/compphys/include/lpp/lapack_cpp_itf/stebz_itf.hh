#ifndef __PROJECT__LPP__FILE__STEBZ_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEBZ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : stebz_itf.hh C++ interface to LAPACK (s,d,c,z)stebz
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file stebz_itf.hh
    (excerpt adapted from xstebz.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xstebz computes the eigenvalues of a symmetric tridiagonal
    **  matrix t.  the user may ask for all eigenvalues, all eigenvalues
    **  in the half-open interval (vl, vu], or the il-th through iu-th
    **  eigenvalues.
    **
    **  to avoid overflow, the matrix must be scaled so that its
    **  largest element is no greater than overflow**(1/2) *
    **  underflow**(1/4) in absolute value, and for greatest
    **  accuracy, it should not be much smaller than that.
    **
    **  see w. kahan "accurate eigenvalues of a symmetric tridiagonal
    **  matrix", report cs41, computer science dept., stanford
    **  university, july 21, 1966.
    **
    **  arguments
    **  =========
    **
    **  range   (input) character
    **          = 'a': ("all")   all eigenvalues will be found.
    **          = 'v': ("value") all eigenvalues in the half-open interval
    **                           (vl, vu] will be found.
    **          = 'i': ("index") the il-th through iu-th eigenvalues (of the
    **                           entire matrix) will be found.
    **
    **  order   (input) character
    **          = 'b': ("by block") the eigenvalues will be grouped by
    **                              split-off block (see iblock, isplit) and
    **                              ordered from smallest to largest within
    **                              the block.
    **          = 'e': ("entire matrix")
    **                              the eigenvalues for the entire matrix
    **                              will be ordered from smallest to
    **                              largest.
    **
    **  n       (input) long int
    **          the order of the tridiagonal matrix t.  n >= 0.
    **
    **  vl      (input) BASE DATA TYPE
    **  vu      (input) BASE DATA TYPE
    **          if range='v', the lower and upper bounds of the interval to
    **          be searched for eigenvalues.  eigenvalues less than or equal
    **          to vl, or greater than vu, will not be returned.  vl < vu.
    **          not referenced if range = 'a' or 'i'.
    **
    **  il      (input) long int
    **  iu      (input) long int
    **          if range='i', the indices (in ascending order) of the
    **          smallest and largest eigenvalues to be returned.
    **          1 <= il <= iu <= n, if n > 0; il = 1 and iu = 0 if n = 0.
    **          not referenced if range = 'a' or 'v'.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the absolute tolerance for the eigenvalues.  an eigenvalue
    **          (or cluster) is considered to be located if it has been
    **          determined to lie in an interval whose width is abstol or
    **          less.  if abstol is less than or equal to zero, then ulp*|t|
    **          will be used, where |t| means the 1-norm of t.
    **
    **          eigenvalues will be computed most accurately when abstol is
    **          set to twice the underflow threshold 2*dlamch('s'), not zero.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the tridiagonal matrix t.
    **
    **  e       (input) BASE DATA TYPE array, dimension (n-1)
    **          the (n-1) off-diagonal elements of the tridiagonal matrix t.
    **
    **  m       (output) long int
    **          the actual number of eigenvalues found. 0 <= m <= n.
    **          (see also the description of info=2,3.)
    **
    **  nsplit  (output) long int
    **          the number of diagonal blocks in the matrix t.
    **          1 <= nsplit <= n.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          on exit, the first m elements of w will contain the
    **          eigenvalues.  (xstebz may use the remaining n-m elements as
    **          WORKspace.)
    **
    **  iblock  (output) long int array, dimension (n)
    **          at each row/column j where e(j) is zero or small, the
    **          matrix t is considered to split into a block diagonal
    **          matrix.  on exit, if info = 0, iblock(i) specifies to which
    **          block (from 1 to the number of blocks) the eigenvalue w(i)
    **          belongs.  (xstebz may use the remaining n-m elements as
    **          WORKspace.)
    **
    **  isplit  (output) long int array, dimension (n)
    **          the splitting points, at which t breaks up into submatrices.
    **          the first submatrix consists of rows/columns 1 to isplit(1),
    **          the second of rows/columns isplit(1)+1 through isplit(2),
    **          etc., and the nsplit-th consists of rows/columns
    **          isplit(nsplit-1)+1 through isplit(nsplit)=n.
    **          (only the first nsplit elements will actually be used, but
    **          since the user cannot know a priori what value nsplit will
    **          have, n words must be reserved for isplit.)
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  some or all of the eigenvalues failed to converge or
    **                were not computed:
    **                =1 or 3: bisection failed to converge for some
    **                        eigenvalues; these eigenvalues are flagged by a
    **                        negative block number.  the effect is that the
    **                        eigenvalues may not be as accurate as the
    **                        absolute and relative tolerances.  this is
    **                        generally caused by unexpectedly inaccurate
    **                        arithmetic.
    **                =2 or 3: range='i' only: not all of the eigenvalues
    **                        il:iu were found.
    **                        effect: m < iu+1-il
    **                        cause:  non-monotonic arithmetic, causing the
    **                                sturm sequence to be non-monotonic.
    **                        cure:   recalculate, using range='a', and pick
    **                                out eigenvalues il:iu.  in some cases,
    **                                increasing the parameter "fudge" may
    **                                make things WORK.
    **                = 4:    range='i', and the gershgorin interval
    **                        initially used was too small.  no eigenvalues
    **                        were computed.
    **                        probable cause: your machine has sloppy
    **                                        floating-point arithmetic.
    **                        cure: increase the parameter "fudge",
    **                              recompile, and try again.
    **
    **  internal parameters
    **  ===================
    **
    **  relfac  BASE DATA TYPE, default = 2.0e0
    **          the relative tolerance.  an interval (a,b] lies within
    **          "relative tolerance" if  b-a < relfac*ulp*max(|a|,|b|),
    **          where "ulp" is the machine precision (distance from 1 to
    **          the next larger floating point number.)
    **
    **  fudge   BASE DATA TYPE, default = 2
    **          a "fudge factor" to widen the gershgorin intervals.  ideally,
    **          a value of 1 should WORK, but on machines with sloppy
    **          arithmetic, this needs to be larger.  the default for
    **          publicly released versions should be large enough to handle
    **          the worst machine around.  note that this has no effect
    **          on accuracy of the solution.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void stebz(
        const char* range,
        const char* order,
        const long int* n,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        const float* d,
        const float* e,
        long int* m,
        long int* nsplit,
        float* ws,
        long int* iblock,
        long int* isplit,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void stebz(
        const char* range,
        const char* order,
        const long int* n,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        const float* d,
        const float* e,
        long int* m,
        long int* nsplit,
        float* ws,
        long int* iblock,
        long int* isplit,
        long int* info)
  */
  /*! fn
   inline void stebz(
        const char* range,
        const char* order,
        const long int* n,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        const double* d,
        const double* e,
        long int* m,
        long int* nsplit,
        double* ws,
        long int* iblock,
        long int* isplit,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void stebz(
        const char* range,
        const char* order,
        const long int* n,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        const double* d,
        const double* e,
        long int* m,
        long int* nsplit,
        double* ws,
        long int* iblock,
        long int* isplit,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sstebz.f)
  //    *  WORK    (workspace) float array, dimension (4*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (3*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEBZ(NAME, T)\
inline void stebz(\
    const char* range,\
    const char* order,\
    const long int* n,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    const T* d,\
    const T* e,\
    long int* m,\
    long int* nsplit,\
    T* ws,\
    long int* iblock,\
    long int* isplit,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(3*(*n));\
    w.resizew(4*(*n));\
    F77NAME( NAME )(range, order, n, vl, vu, il, iu, abstol, d, e, m, nsplit, ws, iblock, isplit, w.getw(), w.getiw(), info);\
}\
inline void stebz(\
    const char* range,\
    const char* order,\
    const long int* n,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    const T* d,\
    const T* e,\
    long int* m,\
    long int* nsplit,\
    T* ws,\
    long int* iblock,\
    long int* isplit,\
    long int* info)\
{\
   workspace<T> w;\
   stebz(range, order, n, vl, vu, il, iu, abstol, d, e, m, nsplit, ws, iblock, isplit, info, w);\
}\

    LPP_STEBZ(sstebz, float)
    LPP_STEBZ(dstebz, double)

#undef LPP_STEBZ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of stebz_itf.hh
// /////////////////////////////////////////////////////////////////////////////
