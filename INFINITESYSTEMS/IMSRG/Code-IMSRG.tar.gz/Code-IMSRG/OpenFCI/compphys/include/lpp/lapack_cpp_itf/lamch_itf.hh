#ifndef __PROJECT__LPP__FILE__LAMCH_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAMCH_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lamch_itf.hh C++ interface to LAPACK (s,d,c,z)lamch
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lamch_itf.hh
    (excerpt adapted from xlamch.f file commentaries)
    
    DATA TYPE can mean float, double, complex<float>, complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlamch determines single precision machine parameters.
    **
    **  arguments
    **  =========
    **
    **  cmach   (input) char
    **          specifies the value to be returned by xlamch:
    **          = 'e' or 'e',   xlamch := eps
    **          = 's' or 's ,   xlamch := sfmin
    **          = 'b' or 'b',   xlamch := base
    **          = 'p' or 'p',   xlamch := eps*base
    **          = 'n' or 'n',   xlamch := t
    **          = 'r' or 'r',   xlamch := rnd
    **          = 'm' or 'm',   xlamch := emin
    **          = 'u' or 'u',   xlamch := rmin
    **          = 'l' or 'l',   xlamch := emax
    **          = 'o' or 'o',   xlamch := rmax
    **
    **          where
    **
    **          eps   = relative machine precision
    **          sfmin = safe minimum, such that 1/sfmin does not overflow
    **          base  = base of the machine
    **          prec  = eps*base
    **          t     = number of (base) digits in the mantissa
    **          rnd   = 1.0 when rounding occurs in addition, 0.0 otherwise
    **          emin  = minimum exponent before (gradual) underflow
    **          rmin  = underflow threshold - base**(emin-1)
    **          emax  = largest exponent before overflow
    **          rmax  = overflow threshold  - (base**emax)*(1-eps)
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////

  // The following macro provides the  functions T being float or double
  // the second parameter is mandatory to choose the type.
  /*! fn
    inline T lamch(const char* cmach,  T)
  */
  
  
  // ///////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slamch.f)
  // ///////////////////////////////////////////////////////////////////////
  
  template < class T > inline T lamch( const char* cmach,  T)
  {
    return 0.0;          
  }
  template < > inline float lamch( const char* cmach, float)
  {
    return F77NAME(slamch)(cmach);          
  }
  template < > inline double lamch( const char* cmach, double)
  {
    return F77NAME(dlamch)(cmach);          
  }
  
}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lamch_itf.hh
// /////////////////////////////////////////////////////////////////////////////
