#ifndef __PROJECT__LPP__FILE__LARFB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARFB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larfb_itf.hh C++ interface to LAPACK (c,d,c,z)larfb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larfb_itf.hh
    (excerpt adapted from xlarfb.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarfb applies a DATA TYPE block reflector h or its transpose h' to a
    **  DATA TYPE m-by-n matrix c, from either the left or the right.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'l': apply h or h' from the left
    **          = 'r': apply h or h' from the right
    **
    **  trans   (input) char
    **          = 'n': apply h (no transpose)
    **          = 'c': apply h' (conjugate transpose)
    **
    **  direct  (input) char
    **          indicates how h is formed from a product of elementary
    **          reflectors
    **          = 'f': h = h(1) h(2) . . . h(k) (forward)
    **          = 'b': h = h(k) . . . h(2) h(1) (backward)
    **
    **  storev  (input) char
    **          indicates how the vectors which define the elementary
    **          reflectors are stored:
    **          = 'c': columnwise
    **          = 'r': rowwise
    **
    **  m       (input) long int
    **          the number of rows of the matrix c.
    **
    **  n       (input) long int
    **          the number of columns of the matrix c.
    **
    **  k       (input) long int
    **          the order of the matrix t (= the number of elementary
    **          reflectors whose product defines the block reflector).
    **
    **  v       (input) DATA TYPE array, dimension
    **                                (ldv,k) if storev = 'c'
    **                                (ldv,m) if storev = 'r' and side = 'l'
    **                                (ldv,n) if storev = 'r' and side = 'r'
    **          the matrix v. see further details.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v.
    **          if storev = 'c' and side = 'l', ldv >= max(1,m);
    **          if storev = 'c' and side = 'r', ldv >= max(1,n);
    **          if storev = 'r', ldv >= k.
    **
    **  t       (input) DATA TYPE array, dimension (ldt,k)
    **          the triangular k-by-k matrix t in the representation of the
    **          block reflector.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= k.
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n matrix c.
    **          on exit, c is overwritten by h*c or h'*c or c*h or c*h'.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m).
    **
    **
    **  ldWORK  (input) long int
    **          the leading dimension of the array WORK.
    **          if side = 'l', ldWORK >= max(1,n);
    **          if side = 'r', ldWORK >= max(1,m).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larfb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const float* v,
        const long int* ldv,
        const float* t,
        const long int* ldt,
        const float* c,
        const long int* ldc,
        workspace<float> & w)
  */
  /*! fn
   inline void larfb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const float* v,
        const long int* ldv,
        const float* t,
        const long int* ldt,
        const float* c,
        const long int* ldc)
  */
  /*! fn
   inline void larfb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const double* v,
        const long int* ldv,
        const double* t,
        const long int* ldt,
        const double* c,
        const long int* ldc,
        workspace<double> & w)
  */
  /*! fn
   inline void larfb(
        const char* side,
        const char* trans,
        const char* direct,
        const char* storev,
        const long int* m,
        const long int* n,
        const long int* k,
        const double* v,
        const long int* ldv,
        const double* t,
        const long int* ldt,
        const double* c,
        const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarfb.f)
  //    *  WORK    (workspace) float array, dimension (LDWORK,K)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARFB(NAME, T)\
inline void larfb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w.getw(), w.query());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w.getw(), &w.neededsize());\
}\
inline void larfb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larfb(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w);\
}\

    LPP_LARFB(slarfb, float)
    LPP_LARFB(dlarfb, double)

#undef LPP_LARFB


  // The following macro provides the 4 functions 
  /*! fn
   inline void larfb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* c,
       const long int* ldc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larfb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* c,
       const long int* ldc)
  */
  /*! fn
   inline void larfb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* c,
       const long int* ldc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larfb(
       const char* side,
       const char* trans,
       const char* direct,
       const char* storev,
       const long int* m,
       const long int* n,
       const long int* k,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* c,
       const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarfb.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (LDWORK,K)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARFB(NAME, T, TBASE)\
inline void larfb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w.getw(), w.query());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w.getw(), &w.neededsize());\
}\
inline void larfb(\
    const char* side,\
    const char* trans,\
    const char* direct,\
    const char* storev,\
    const long int* m,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* t,\
    const long int* ldt,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larfb(side, trans, direct, storev, m, n, k, v, ldv, t, ldt, c, ldc, w);\
}\

    LPP_LARFB(clarfb, std::complex<float>,  float)
    LPP_LARFB(zlarfb, std::complex<double>, double)

#undef LPP_LARFB



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larfb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
