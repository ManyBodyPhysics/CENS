#ifndef __PROJECT__LPP__FILE__LAPLL_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAPLL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lapll_itf.hh C++ interface to LAPACK (c,d,c,z)lapll
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lapll_itf.hh
    (excerpt adapted from xlapll.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  given two column vectors x and y, let
    **
    **                       a = ( x y ).
    **
    **  the subroutine first computes the qr factorization of a = q*r,
    **  and then computes the svd of the 2-by-2 upper triangular matrix r.
    **  the smaller singular value of r is returned in ssmin, which is used
    **  as the measurement of the linear dependency of the vectors x and y.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the length of the vectors x and y.
    **
    **  x       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          on entry, x contains the n-vector x.
    **          on exit, x is overwritten.
    **
    **  incx    (input) long int
    **          the increment between successive elements of x. incx > 0.
    **
    **  y       (input/output) DATA TYPE array, dimension (1+(n-1)*incy)
    **          on entry, y contains the n-vector y.
    **          on exit, y is overwritten.
    **
    **  incy    (input) long int
    **          the increment between successive elements of y. incy > 0.
    **
    **  ssmin   (output) BASE DATA TYPE
    **          the smallest singular value of the n-by-2 matrix a = ( x y ).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lapll(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        float* ssmin,
        workspace<float> & w)
  */
  /*! fn
   inline void lapll(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        float* ssmin)
  */
  /*! fn
   inline void lapll(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        double* ssmin,
        workspace<double> & w)
  */
  /*! fn
   inline void lapll(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        double* ssmin)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slapll.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPLL(NAME, T)\
inline void lapll(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    T* ssmin,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, ssmin);\
}\
inline void lapll(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    T* ssmin)\
{\
   workspace<T> w;\
   lapll(n, x, incx, y, incy, ssmin, w);\
}\

    LPP_LAPLL(slapll, float)
    LPP_LAPLL(dlapll, double)

#undef LPP_LAPLL


  // The following macro provides the 4 functions 
  /*! fn
   inline void lapll(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       float* ssmin,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lapll(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       float* ssmin)
  */
  /*! fn
   inline void lapll(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       double* ssmin,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lapll(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       double* ssmin)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clapll.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPLL(NAME, T, TBASE)\
inline void lapll(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    TBASE* ssmin,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, ssmin);\
}\
inline void lapll(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    TBASE* ssmin)\
{\
   workspace<T> w;\
   lapll(n, x, incx, y, incy, ssmin, w);\
}\

    LPP_LAPLL(clapll, std::complex<float>,  float)
    LPP_LAPLL(zlapll, std::complex<double>, double)

#undef LPP_LAPLL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lapll_itf.hh
// /////////////////////////////////////////////////////////////////////////////
