#ifndef __PROJECT__LPP__FILE__POTF2_HH__INCLUDED
#define __PROJECT__LPP__FILE__POTF2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : potf2_itf.hh C++ interface to LAPACK (c,d,c,z)potf2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file potf2_itf.hh
    (excerpt adapted from xpotf2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpotf2 computes the cholesky factorization of a DATA TYPE hermitian
    **  positive definite matrix a.
    **
    **  the factorization has the form
    **     a = u' * u ,  if uplo = 'u', or
    **     a = l  * l',  if uplo = 'l',
    **  where u is an upper triangular matrix and l is lower triangular.
    **
    **  this is the unblocked version of the algorithm, calling level 2 blas.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is stored.
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n by n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n by n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, if info = 0, the factor u or l from the cholesky
    **          factorization a = u'*u  or a = l*l'.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **          > 0: if info = k, the leading minor of order k is not
    **               positive definite, and the factorization could not be
    **               completed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void potf2(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void potf2(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info)
  */
  /*! fn
   inline void potf2(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void potf2(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spotf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POTF2(NAME, T)\
inline void potf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, info);\
}\
inline void potf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   potf2(uplo, n, a, lda, info, w);\
}\

    LPP_POTF2(spotf2, float)
    LPP_POTF2(dpotf2, double)

#undef LPP_POTF2


  // The following macro provides the 4 functions 
  /*! fn
   inline void potf2(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void potf2(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info)
  */
  /*! fn
   inline void potf2(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void potf2(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpotf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POTF2(NAME, T, TBASE)\
inline void potf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, info);\
}\
inline void potf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   potf2(uplo, n, a, lda, info, w);\
}\

    LPP_POTF2(cpotf2, std::complex<float>,  float)
    LPP_POTF2(zpotf2, std::complex<double>, double)

#undef LPP_POTF2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of potf2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
