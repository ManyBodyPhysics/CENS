#ifndef __PROJECT__LPP__FILE__TBCON_HH__INCLUDED
#define __PROJECT__LPP__FILE__TBCON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tbcon_itf.hh C++ interface to LAPACK (s,d,c,z)tbcon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tbcon_itf.hh
    (excerpt adapted from xtbcon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtbcon estimates the reciprocal of the condition number of a
    **  triangular band matrix a, in either the 1-norm or the infinity-norm.
    **
    **  the norm of a is computed and an estimate is obtained for
    **  norm(inv(a)), then the reciprocal of the condition number is
    **  computed as
    **     rcond = 1 / ( norm(a) * norm(inv(a)) ).
    **
    **  arguments
    **  =========
    **
    **  norm    (input) char
    **          specifies whether the 1-norm condition number or the
    **          infinity-norm condition number is required:
    **          = '1' or 'o':  1-norm;
    **          = 'i':         infinity-norm.
    **
    **  uplo    (input) char
    **          = 'u':  a is upper triangular;
    **          = 'l':  a is lower triangular.
    **
    **  diag    (input) char
    **          = 'n':  a is non-unit triangular;
    **          = 'u':  a is unit triangular.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals or subdiagonals of the
    **          triangular band matrix a.  kd >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the upper or lower triangular band matrix a, stored in the
    **          first kd+1 rows of the array. the j-th column of a is stored
    **          in the j-th column of the array ab as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **          if diag = 'u', the diagonal elements of a are not referenced
    **          and are assumed to be 1.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  rcond   (output) BASE DATA TYPE
    **          the reciprocal of the condition number of the matrix a,
    **          computed as rcond = 1/(norm(a) * norm(inv(a))).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tbcon(
        const char* norm,
        const char* uplo,
        const char* diag,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* rcond,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tbcon(
        const char* norm,
        const char* uplo,
        const char* diag,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* rcond,
        long int* info)
  */
  /*! fn
   inline void tbcon(
        const char* norm,
        const char* uplo,
        const char* diag,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* rcond,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tbcon(
        const char* norm,
        const char* uplo,
        const char* diag,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* rcond,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stbcon.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TBCON(NAME, T)\
inline void tbcon(\
    const char* norm,\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(3*(*n));\
    F77NAME( NAME )(norm, uplo, diag, n, kd, ab, ldab, rcond, w.getw(), w.getiw(), info);\
}\
inline void tbcon(\
    const char* norm,\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   tbcon(norm, uplo, diag, n, kd, ab, ldab, rcond, info, w);\
}\

    LPP_TBCON(stbcon, float)
    LPP_TBCON(dtbcon, double)

#undef LPP_TBCON


  // The following macro provides the 4 functions 
  /*! fn
   inline void tbcon(
       const char* norm,
       const char* uplo,
       const char* diag,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       float* rcond,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tbcon(
       const char* norm,
       const char* uplo,
       const char* diag,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       float* rcond,
       long int* info)
  */
  /*! fn
   inline void tbcon(
       const char* norm,
       const char* uplo,
       const char* diag,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       double* rcond,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tbcon(
       const char* norm,
       const char* uplo,
       const char* diag,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       double* rcond,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctbcon.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TBCON(NAME, T, TBASE)\
inline void tbcon(\
    const char* norm,\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    TBASE* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(norm, uplo, diag, n, kd, ab, ldab, rcond, w.getw(), w.getrw(), info);\
}\
inline void tbcon(\
    const char* norm,\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    TBASE* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   tbcon(norm, uplo, diag, n, kd, ab, ldab, rcond, info, w);\
}\

    LPP_TBCON(ctbcon, std::complex<float>, float)
    LPP_TBCON(ztbcon, std::complex<double>, double)

#undef LPP_TBCON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tbcon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
