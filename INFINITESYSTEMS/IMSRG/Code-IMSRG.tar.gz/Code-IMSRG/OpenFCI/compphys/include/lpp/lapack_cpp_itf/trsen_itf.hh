#ifndef __PROJECT__LPP__FILE__TRSEN_HH__INCLUDED
#define __PROJECT__LPP__FILE__TRSEN_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : trsen_itf.hh C++ interface to LAPACK (s,d,c,z)trsen
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file trsen_itf.hh
    (excerpt adapted from xtrsen.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtrsen reorders the schur factorization of a DATA TYPE matrix
    **  a = q*t*q**h, so that a selected cluster of eigenvalues appears in
    **  the leading positions on the diagonal of the upper triangular matrix
    **  t, and the leading columns of q form an orthonormal basis of the
    **  corresponding right invariant subspace.
    **
    **  optionally the routine computes the reciprocal condition numbers of
    **  the cluster of eigenvalues and/or the invariant subspace.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies whether condition numbers are required for the
    **          cluster of eigenvalues (s) or the invariant subspace (sep):
    **          = 'n': none;
    **          = 'e': for eigenvalues only (s);
    **          = 'v': for invariant subspace only (sep);
    **          = 'b': for both eigenvalues and invariant subspace (s and
    **                 sep).
    **
    **  compq   (input) char
    **          = 'v': update the matrix q of schur vectors;
    **          = 'n': do not update q.
    **
    **  select  (input) logical array, dimension (n)
    **          select specifies the eigenvalues in the selected cluster. to
    **          select the j-th eigenvalue, select(j) must be set to .true..
    **
    **  n       (input) long int
    **          the order of the matrix t. n >= 0.
    **
    **  t       (input/output) DATA TYPE array, dimension (ldt,n)
    **          on entry, the upper triangular matrix t.
    **          on exit, t is overwritten by the reordered matrix t, with the
    **          selected eigenvalues as the leading diagonal elements.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= max(1,n).
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq,n)
    **          on entry, if compq = 'v', the matrix q of schur vectors.
    **          on exit, if compq = 'v', q has been postmultiplied by the
    **          unitary transformation matrix which reorders t; the leading m
    **          columns of q form an orthonormal basis for the specified
    **          invariant subspace.
    **          if compq = 'n', q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.
    **          ldq >= 1; and if compq = 'v', ldq >= n.
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          the reordered eigenvalues of t, in the same order as they
    **          appear on the diagonal of t.
    **
    **  m       (output) long int
    **          the dimension of the specified invariant subspace.
    **          0 <= m <= n.
    **
    **  s       (output) BASE DATA TYPE
    **          if job = 'e' or 'b', s is a lower bound on the reciprocal
    **          condition number for the selected cluster of eigenvalues.
    **          s cannot underestimate the true reciprocal condition number
    **          by more than a factor of sqrt(n). if m = 0 or n, s = 1.
    **          if job = 'n' or 'v', s is not referenced.
    **
    **  sep     (output) BASE DATA TYPE
    **          if job = 'v' or 'b', sep is the estimated reciprocal
    **          condition number of the specified invariant subspace. if
    **          m = 0 or n, sep = norm(t).
    **          if job = 'n' or 'e', sep is not referenced.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  xtrsen first collects the selected eigenvalues by computing a unitary
    **  transformation z to move them to the top left corner of t. in other
    **  words, the selected eigenvalues are the eigenvalues of t11 in:
    **
    **                z'*t*z = ( t11 t12 ) n1
    **                         (  0  t22 ) n2
    **                            n1  n2
    **
    **  where n = n1+n2 and z' means the conjugate transpose of z. the first
    **  n1 columns of z span the specified invariant subspace of t.
    **
    **  if t has been obtained from the schur factorization of a matrix
    **  a = q*t*q', then the reordered schur factorization of a is given by
    **  a = (q*z)*(z'*t*z)*(q*z)', and the first n1 columns of q*z span the
    **  corresponding invariant subspace of a.
    **
    **  the reciprocal condition number of the average of the eigenvalues of
    **  t11 may be returned in s. s lies between 0 (very badly conditioned)
    **  and 1 (very well conditioned). it is computed as follows. first we
    **  compute r so that
    **
    **                         p = ( i  r ) n1
    **                             ( 0  0 ) n2
    **                               n1 n2
    **
    **  is the projector on the invariant subspace associated with t11.
    **  r is the solution of the sylvester equation:
    **
    **                        t11*r - r*t22 = t12.
    **
    **  let f-norm(m) denote the frobenius-norm of m and 2-norm(m) denote
    **  the two-norm of m. then s is computed as the lower bound
    **
    **                      (1 + f-norm(r)**2)**(-1/2)
    **
    **  on the reciprocal of 2-norm(p), the true reciprocal condition number.
    **  s cannot underestimate 1 / 2-norm(p) by more than a factor of
    **  sqrt(n).
    **
    **  an approximate error bound for the computed average of the
    **  eigenvalues of t11 is
    **
    **                         eps * norm(t) / s
    **
    **  where eps is the machine precision.
    **
    **  the reciprocal condition number of the right invariant subspace
    **  spanned by the first n1 columns of z (or of q*z) is returned in sep.
    **  sep is defined as the separation of t11 and t22:
    **
    **                     sep( t11, t22 ) = sigma-min( c )
    **
    **  where sigma-min(c) is the smallest singular value of the
    **  n1*n2-by-n1*n2 matrix
    **
    **     c  = kprod( i(n2), t11 ) - kprod( transpose(t22), i(n1) )
    **
    **  i(m) is an m by m identity matrix, and kprod denotes the kronecker
    **  product. we estimate sigma-min(c) by the reciprocal of an estimate of
    **  the 1-norm of inverse(c). the true reciprocal 1-norm of inverse(c)
    **  cannot differ from sigma-min(c) by more than a factor of sqrt(n1*n2).
    **
    **  when sep is small, small changes in t can cause large changes in
    **  the invariant subspace. an approximate bound on the maximum angular
    **  error in the computed right invariant subspace is
    **
    **                      eps * norm(t) / sep
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void trsen(
        const char* job,
        const char* compq,
        const long int* select,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        float* wr,
        float* wi,
        const long int* m,
        const float* s,
        float* sep,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void trsen(
        const char* job,
        const char* compq,
        const long int* select,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        float* wr,
        float* wi,
        const long int* m,
        const float* s,
        float* sep,
        long int* info)
  */
  /*! fn
   inline void trsen(
        const char* job,
        const char* compq,
        const long int* select,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        double* wr,
        double* wi,
        const long int* m,
        const double* s,
        double* sep,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void trsen(
        const char* job,
        const char* compq,
        const long int* select,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        double* wr,
        double* wi,
        const long int* m,
        const double* s,
        double* sep,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from strsen.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If JOB = 'N', LWORK >= max(1,N);
  //    *          if JOB = 'E', LWORK >= max(1,M*(N-M));
  //    *          if JOB = 'V' or 'B', LWORK >= max(1,2*M*(N-M)).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSEN(NAME, T)\
inline void trsen(\
    const char* job,\
    const char* compq,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    T* wr,\
    T* wi,\
    const long int* m,\
    const T* s,\
    T* sep,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, compq, select, n, t, ldt, q, ldq, wr, wi, m, s, sep, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizeiw(w.neededisize());                                         \
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compq, select, n, t, ldt, q, ldq, wr, wi, m, s, sep,\
                    w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info); \
}\
inline void trsen(\
    const char* job,\
    const char* compq,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    T* wr,\
    T* wi,\
    const long int* m,\
    const T* s,\
    T* sep,\
    long int* info)\
{\
   workspace<T> w;\
   trsen(job, compq, select, n, t, ldt, q, ldq, wr, wi, m, s, sep, info, w);\
}\

    LPP_TRSEN(strsen, float)
    LPP_TRSEN(dtrsen, double)

#undef LPP_TRSEN


  // The following macro provides the 4 functions 
  /*! fn
   inline void trsen(
       const char* job,
       const char* compq,
       const long int* select,
       const long int* n,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* q,
       const long int* ldq,
       std::complex<float>* ws,
       const long int* m,
       const float* s,
       float* sep,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void trsen(
       const char* job,
       const char* compq,
       const long int* select,
       const long int* n,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* q,
       const long int* ldq,
       std::complex<float>* ws,
       const long int* m,
       const float* s,
       float* sep,
       long int* info)
  */
  /*! fn
   inline void trsen(
       const char* job,
       const char* compq,
       const long int* select,
       const long int* n,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* q,
       const long int* ldq,
       std::complex<double>* ws,
       const long int* m,
       const double* s,
       double* sep,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void trsen(
       const char* job,
       const char* compq,
       const long int* select,
       const long int* n,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* q,
       const long int* ldq,
       std::complex<double>* ws,
       const long int* m,
       const double* s,
       double* sep,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctrsen.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If JOB = 'N', LWORK >= 1;
  //    *          if JOB = 'E', LWORK = max(1,M*(N-M));
  //    *          if JOB = 'V' or 'B', LWORK >= max(1,2*M*(N-M)).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSEN(NAME, T, TBASE)\
inline void trsen(\
    const char* job,\
    const char* compq,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    T* ws,\
    const long int* m,\
    const TBASE* s,\
    TBASE* sep,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, compq, select, n, t, ldt, q, ldq, ws, m, s, sep, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compq, select, n, t, ldt, q, ldq, ws, m, s, sep, w.getw(), &w.neededsize(), info);\
}\
inline void trsen(\
    const char* job,\
    const char* compq,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    T* ws,\
    const long int* m,\
    const TBASE* s,\
    TBASE* sep,\
    long int* info)\
{\
   workspace<T> w;\
   trsen(job, compq, select, n, t, ldt, q, ldq, ws, m, s, sep, info, w);\
}\

    LPP_TRSEN(ctrsen, std::complex<float>, float)
    LPP_TRSEN(ztrsen, std::complex<double>, double)

#undef LPP_TRSEN



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of trsen_itf.hh
// /////////////////////////////////////////////////////////////////////////////
