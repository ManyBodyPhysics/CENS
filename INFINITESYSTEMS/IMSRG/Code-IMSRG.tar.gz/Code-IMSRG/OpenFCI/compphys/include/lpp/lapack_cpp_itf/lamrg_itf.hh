#ifndef __PROJECT__LPP__FILE__LAMRG_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAMRG_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lamrg_itf.hh C++ interface to LAPACK (s,d,c,z)lamrg
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lamrg_itf.hh
    (excerpt adapted from xlamrg.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlamrg will create a permutation list which will merge the elements
    **  of a (which is composed of two independently sorted sets) into a
    **  single set which is sorted in ascending order.
    **
    **  arguments
    **  =========
    **
    **  n1     (input) long int
    **  n2     (input) long int
    **         these arguements contain the respective lengths of the two
    **         sorted lists to be merged.
    **
    **  a      (input) BASE DATA TYPE array, dimension (n1+n2)
    **         the first n1 elements of a contain a list of numbers which
    **         are sorted in either ascending or descending order.  likewise
    **         for the final n2 elements.
    **
    **  dtrd1  (input) long int
    **  dtrd2  (input) long int
    **         these are the strides to be taken through the array a.
    **         allowable strides are 1 and -1.  they indicate whether a
    **         subset of a is sorted in ascending (dtrdx = 1) or descending
    **         (dtrdx = -1) order.
    **
    **  index  (output) long int array, dimension (n1+n2)
    **         on exit this array will contain a permutation such that
    **         if b( i ) = a( index( i ) ) for i=1,n1+n2, then b will be
    **         sorted in ascending order.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lamrg(
        const long int* n1,
        const long int* n2,
        float* a,
        const long int* strd1,
        const long int* strd2,
        long int* index,
        workspace<float> & w)
  */
  /*! fn
   inline void lamrg(
        const long int* n1,
        const long int* n2,
        float* a,
        const long int* strd1,
        const long int* strd2,
        long int* index)
  */
  /*! fn
   inline void lamrg(
        const long int* n1,
        const long int* n2,
        double* a,
        const long int* strd1,
        const long int* strd2,
        long int* index,
        workspace<double> & w)
  */
  /*! fn
   inline void lamrg(
        const long int* n1,
        const long int* n2,
        double* a,
        const long int* strd1,
        const long int* strd2,
        long int* index)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slamrg.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAMRG(NAME, T)\
inline void lamrg(\
    const long int* n1,\
    const long int* n2,\
    T* a,\
    const long int* strd1,\
    const long int* strd2,\
    long int* index,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n1, n2, a, strd1, strd2, index);\
}\
inline void lamrg(\
    const long int* n1,\
    const long int* n2,\
    T* a,\
    const long int* strd1,\
    const long int* strd2,\
    long int* index)\
{\
   workspace<T> w;\
   lamrg(n1, n2, a, strd1, strd2, index, w);\
}\

    LPP_LAMRG(slamrg, float)
    LPP_LAMRG(dlamrg, double)

#undef LPP_LAMRG



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lamrg_itf.hh
// /////////////////////////////////////////////////////////////////////////////
