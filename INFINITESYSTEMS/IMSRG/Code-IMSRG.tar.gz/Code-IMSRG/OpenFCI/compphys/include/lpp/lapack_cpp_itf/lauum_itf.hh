#ifndef __PROJECT__LPP__FILE__LAUUM_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAUUM_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lauum_itf.hh C++ interface to LAPACK (c,d,c,z)lauum
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lauum_itf.hh
    (excerpt adapted from xlauum.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlauum computes the product u * u' or l' * l, where the triangular
    **  factor u or l is stored in the upper or lower triangular part of
    **  the array a.
    **
    **  if uplo = 'u' or 'u' then the upper triangle of the result is stored,
    **  overwriting the factor u in a.
    **  if uplo = 'l' or 'l' then the lower triangle of the result is stored,
    **  overwriting the factor l in a.
    **
    **  this is the blocked form of the algorithm, calling level 3 blas.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the triangular factor stored in the array a
    **          is upper or lower triangular:
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the triangular factor u or l.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the triangular factor u or l.
    **          on exit, if uplo = 'u', the upper triangle of a is
    **          overwritten with the upper triangle of the product u * u';
    **          if uplo = 'l', the lower triangle of a is overwritten with
    **          the lower triangle of the product l' * l.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lauum(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lauum(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* info)
  */
  /*! fn
   inline void lauum(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lauum(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slauum.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAUUM(NAME, T)\
inline void lauum(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, info);\
}\
inline void lauum(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   lauum(uplo, n, a, lda, info, w);\
}\

    LPP_LAUUM(slauum, float)
    LPP_LAUUM(dlauum, double)

#undef LPP_LAUUM


  // The following macro provides the 4 functions 
  /*! fn
   inline void lauum(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lauum(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* info)
  */
  /*! fn
   inline void lauum(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lauum(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clauum.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAUUM(NAME, T, TBASE)\
inline void lauum(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, info);\
}\
inline void lauum(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* info)\
{\
   workspace<T> w;\
   lauum(uplo, n, a, lda, info, w);\
}\

    LPP_LAUUM(clauum, std::complex<float>,  float)
    LPP_LAUUM(zlauum, std::complex<double>, double)

#undef LPP_LAUUM



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lauum_itf.hh
// /////////////////////////////////////////////////////////////////////////////
