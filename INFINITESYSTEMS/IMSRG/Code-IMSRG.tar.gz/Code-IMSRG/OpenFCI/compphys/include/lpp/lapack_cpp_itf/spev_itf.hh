#ifndef __PROJECT__LPP__FILE__SPEV_HH__INCLUDED
#define __PROJECT__LPP__FILE__SPEV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : spev_itf.hh C++ interface to LAPACK (s,d,c,z)spev
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file spev_itf.hh
    (excerpt adapted from xspev.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xspev computes all the eigenvalues and, optionally, eigenvectors of a
    **  BASE DATA TYPE symmetric matrix a in packed storage.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) BASE DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the symmetric matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2*n-j)/2) = a(i,j) for j<=i<=n.
    **
    **          on exit, ap is overwritten by values generated during the
    **          reduction to tridiagonal form.  if uplo = 'u', the diagonal
    **          and first superdiagonal of the tridiagonal matrix t overwrite
    **          the corresponding elements of a, and if uplo = 'l', the
    **          diagonal and first subdiagonal of t overwrite the
    **          corresponding elements of a.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the eigenvalues in ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, n)
    **          if jobz = 'v', then if info = 0, z contains the orthonormal
    **          eigenvectors of the matrix a, with the i-th column of z
    **          holding the eigenvector associated with w(i).
    **          if jobz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = i, the algorithm failed to converge; i
    **                off-diagonal elements of an intermediate tridiagonal
    **                form did not converge to zero.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void spev(
        const char* jobz,
        const char* uplo,
        const long int* n,
        float* ap,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void spev(
        const char* jobz,
        const char* uplo,
        const long int* n,
        float* ap,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void spev(
        const char* jobz,
        const char* uplo,
        const long int* n,
        double* ap,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void spev(
        const char* jobz,
        const char* uplo,
        const long int* n,
        double* ap,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sspev.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPEV(NAME, T)\
inline void spev(\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(3*(*n));\
    F77NAME( NAME )(jobz, uplo, n, ap, ws, z, ldz, w.getw(), info);\
}\
inline void spev(\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   spev(jobz, uplo, n, ap, ws, z, ldz, info, w);\
}\

    LPP_SPEV(sspev, float)
    LPP_SPEV(dspev, double)

#undef LPP_SPEV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of spev_itf.hh
// /////////////////////////////////////////////////////////////////////////////
