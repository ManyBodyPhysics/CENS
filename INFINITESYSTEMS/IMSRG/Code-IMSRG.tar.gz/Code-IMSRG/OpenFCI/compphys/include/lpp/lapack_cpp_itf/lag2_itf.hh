#ifndef __PROJECT__LPP__FILE__LAG2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAG2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lag2_itf.hh C++ interface to LAPACK (s,d,c,z)lag2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lag2_itf.hh
    (excerpt adapted from xlag2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlag2 computes the eigenvalues of a 2 x 2 generalized eigenvalue
    **  problem  a - w b, with scaling as necessary to avoid over-/underflow.
    **
    **  the scaling factor "s" results in a modified eigenvalue equation
    **
    **      s a - w b
    **
    **  where  s  is a non-negative scaling factor chosen so that  ws,  w b,
    **  and  s a  do not overflow and, if possible, do not underflow, either.
    **
    **  arguments
    **  =========
    **
    **  a       (input) BASE DATA TYPE array, dimension (lda, 2)
    **          on entry, the 2 x 2 matrix a.  it is assumed that its 1-norm
    **          is less than 1/safmin.  entries less than
    **          sqrt(safmin)*norm(a) are subject to being treated as zero.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= 2.
    **
    **  b       (input) BASE DATA TYPE array, dimension (ldb, 2)
    **          on entry, the 2 x 2 upper triangular matrix b.  it is
    **          assumed that the one-norm of b is less than 1/safmin.  the
    **          diagonals should be at least sqrt(safmin) times the largest
    **          element of b (in absolute value); if a diagonal is smaller
    **          than that, then  +/- sqrt(safmin) will be used instead of
    **          that diagonal.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= 2.
    **
    **  safmin  (input) BASE DATA TYPE
    **          the smallest positive number s.t. 1/safmin does not
    **          overflow.  (this should always be dlamch('s') -- it is an
    **          argument in order to avoid having to call dlamch frequently.)
    **
    **  scale1  (output) BASE DATA TYPE
    **          a scaling factor used to avoid over-/underflow in the
    **          eigenvalue equation which defines the first eigenvalue.  if
    **          the eigenvalues are DATA TYPE, then the eigenvalues are
    **          ( wr1  +/-  wi i ) / scale1  (which may lie outside the
    **          exponent range of the machine), scale1=scale2, and scale1
    **          will always be positive.  if the eigenvalues are BASE DATA TYPE, then
    **          the first (BASE DATA TYPE) eigenvalue is  wr1 / scale1 , but this may
    **          overflow or underflow, and in fact, scale1 may be zero or
    **          less than the underflow threshhold if the exact eigenvalue
    **          is sufficiently large.
    **
    **  scale2  (output) BASE DATA TYPE
    **          a scaling factor used to avoid over-/underflow in the
    **          eigenvalue equation which defines the second eigenvalue.  if
    **          the eigenvalues are DATA TYPE, then scale2=scale1.  if the
    **          eigenvalues are BASE DATA TYPE, then the second (BASE DATA TYPE) eigenvalue is
    **          wr2 / scale2 , but this may overflow or underflow, and in
    **          fact, scale2 may be zero or less than the underflow
    **          threshhold if the exact eigenvalue is sufficiently large.
    **
    **  wr1     (output) BASE DATA TYPE
    **          if the eigenvalue is BASE DATA TYPE, then wr1 is scale1 times the
    **          eigenvalue closest to the (2,2) element of a b**(-1).  if the
    **          eigenvalue is DATA TYPE, then wr1=wr2 is scale1 times the BASE DATA TYPE
    **          part of the eigenvalues.
    **
    **  wr2     (output) BASE DATA TYPE
    **          if the eigenvalue is BASE DATA TYPE, then wr2 is scale2 times the
    **          other eigenvalue.  if the eigenvalue is DATA TYPE, then
    **          wr1=wr2 is scale1 times the BASE DATA TYPE part of the eigenvalues.
    **
    **  wi      (output) BASE DATA TYPE
    **          if the eigenvalue is BASE DATA TYPE, then wi is zero.  if the
    **          eigenvalue is DATA TYPE, then wi is scale1 times the imaginary
    **          part of the eigenvalues.  wi will always be non-negative.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lag2(
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* safmin,
        float* scale1,
        float* scale2,
        float* wr1,
        float* wr2,
        float* wi,
        workspace<float> & w)
  */
  /*! fn
   inline void lag2(
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* safmin,
        float* scale1,
        float* scale2,
        float* wr1,
        float* wr2,
        float* wi)
  */
  /*! fn
   inline void lag2(
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* safmin,
        double* scale1,
        double* scale2,
        double* wr1,
        double* wr2,
        double* wi,
        workspace<double> & w)
  */
  /*! fn
   inline void lag2(
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* safmin,
        double* scale1,
        double* scale2,
        double* wr1,
        double* wr2,
        double* wi)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slag2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAG2(NAME, T)\
inline void lag2(\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* safmin,\
    T* scale1,\
    T* scale2,\
    T* wr1,\
    T* wr2,\
    T* wi,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(a, lda, b, ldb, safmin, scale1, scale2, wr1, wr2, wi);\
}\
inline void lag2(\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* safmin,\
    T* scale1,\
    T* scale2,\
    T* wr1,\
    T* wr2,\
    T* wi)\
{\
   workspace<T> w;\
   lag2(a, lda, b, ldb, safmin, scale1, scale2, wr1, wr2, wi, w);\
}\

    LPP_LAG2(slag2, float)
    LPP_LAG2(dlag2, double)

#undef LPP_LAG2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lag2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
