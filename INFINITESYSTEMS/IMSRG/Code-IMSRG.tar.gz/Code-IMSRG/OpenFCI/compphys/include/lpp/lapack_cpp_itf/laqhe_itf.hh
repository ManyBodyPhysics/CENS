#ifndef __PROJECT__LPP__FILE__LAQHE_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQHE_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqhe_itf.hh C++ interface to LAPACK (c,d,c,z)laqhe
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqhe_itf.hh
    (excerpt adapted from xlaqhe.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqhe equilibrates a hermitian matrix a using the scaling factors
    **  in the vector s.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is stored.
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n by n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n by n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, if equed = 'y', the equilibrated matrix:
    **          diag(s) * a * diag(s).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(n,1).
    **
    **  s       (input) BASE DATA TYPE array, dimension (n)
    **          the scale factors for a.
    **
    **  scond   (input) BASE DATA TYPE
    **          ratio of the smallest s(i) to the largest s(i).
    **
    **  amax    (input) BASE DATA TYPE
    **          absolute value of largest matrix entry.
    **
    **  equed   (output) char
    **          specifies whether or not equilibration was done.
    **          = 'n':  no equilibration.
    **          = 'y':  equilibration was done, i.e., a has been replaced by
    **                  diag(s) * a * diag(s).
    **
    **  internal parameters
    **  ===================
    **
    **  thresh is a threshold value used to decide if scaling should be done
    **  based on the ratio of the scaling factors.  if scond < thresh,
    **  scaling is done.
    **
    **  large and small are threshold values used to decide if scaling should
    **  be done based on the absolute size of the largest matrix element.
    **  if amax > large or amax < small, scaling is done.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqhe(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const float* s,
       const float* scond,
       const float* amax,
       char* equed,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laqhe(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const float* s,
       const float* scond,
       const float* amax,
       char* equed)
  */
  /*! fn
   inline void laqhe(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const double* s,
       const double* scond,
       const double* amax,
       char* equed,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laqhe(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const double* s,
       const double* scond,
       const double* amax,
       char* equed)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claqhe.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQHE(NAME, T, TBASE)\
inline void laqhe(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const TBASE* s,\
    const TBASE* scond,\
    const TBASE* amax,\
    char* equed,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, s, scond, amax, equed);\
}\
inline void laqhe(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const TBASE* s,\
    const TBASE* scond,\
    const TBASE* amax,\
    char* equed)\
{\
   workspace<T> w;\
   laqhe(uplo, n, a, lda, s, scond, amax, equed, w);\
}\

    LPP_LAQHE(claqhe, std::complex<float>,  float)
    LPP_LAQHE(zlaqhe, std::complex<double>, double)

#undef LPP_LAQHE



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqhe_itf.hh
// /////////////////////////////////////////////////////////////////////////////
