#ifndef __PROJECT__LPP__FILE__SPTRI_HH__INCLUDED
#define __PROJECT__LPP__FILE__SPTRI_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sptri_itf.hh C++ interface to LAPACK (s,d,c,z)sptri
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sptri_itf.hh
    (excerpt adapted from xsptri.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsptri computes the inverse of a DATA TYPE symmetric indefinite matrix
    **  a in packed storage using the factorization a = u*d*u**t or
    **  a = l*d*l**t computed by csptrf.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the details of the factorization are stored
    **          as an upper or lower triangular matrix.
    **          = 'u':  upper triangular, form is a = u*d*u**t;
    **          = 'l':  lower triangular, form is a = l*d*l**t.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the block diagonal matrix d and the multipliers
    **          used to obtain the factor u or l as computed by csptrf,
    **          stored as a packed triangular matrix.
    **
    **          on exit, if info = 0, the (symmetric) inverse of the original
    **          matrix, stored as a packed triangular matrix. the j-th column
    **          of inv(a) is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = inv(a)(i,j) for 1<=i<=j;
    **          if uplo = 'l',
    **             ap(i + (j-1)*(2n-j)/2) = inv(a)(i,j) for j<=i<=n.
    **
    **  ipiv    (input) long int array, dimension (n)
    **          details of the interchanges and the block structure of d
    **          as determined by csptrf.
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, d(i,i) = 0; the matrix is singular and its
    **               inverse could not be computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sptri(
        const char* uplo,
        const long int* n,
        float* ap,
        const long int* ipiv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sptri(
        const char* uplo,
        const long int* n,
        float* ap,
        const long int* ipiv,
        long int* info)
  */
  /*! fn
   inline void sptri(
        const char* uplo,
        const long int* n,
        double* ap,
        const long int* ipiv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sptri(
        const char* uplo,
        const long int* n,
        double* ap,
        const long int* ipiv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssptri.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPTRI(NAME, T)\
inline void sptri(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(uplo, n, ap, ipiv, w.getw(), info);\
}\
inline void sptri(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   sptri(uplo, n, ap, ipiv, info, w);\
}\

    LPP_SPTRI(ssptri, float)
    LPP_SPTRI(dsptri, double)

#undef LPP_SPTRI


  // The following macro provides the 4 functions 
  /*! fn
   inline void sptri(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const long int* ipiv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void sptri(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const long int* ipiv,
       long int* info)
  */
  /*! fn
   inline void sptri(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const long int* ipiv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void sptri(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const long int* ipiv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from csptri.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPTRI(NAME, T, TBASE)\
inline void sptri(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(uplo, n, ap, ipiv, w.getw(), info);\
}\
inline void sptri(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   sptri(uplo, n, ap, ipiv, info, w);\
}\

    LPP_SPTRI(csptri, std::complex<float>, float)
    LPP_SPTRI(zsptri, std::complex<double>, double)

#undef LPP_SPTRI



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sptri_itf.hh
// /////////////////////////////////////////////////////////////////////////////
