#ifndef __PROJECT__LPP__FILE__LASDQ_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASDQ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasdq_itf.hh C++ interface to LAPACK (s,d,c,z)lasdq
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasdq_itf.hh
    (excerpt adapted from xlasdq.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasdq computes the singular value decomposition (svd) of a BASE DATA TYPE
    **  (upper or lower) bidiagonal matrix with diagonal d and offdiagonal
    **  e, accumulating the transformations if desired. letting b denote
    **  the input bidiagonal matrix, the algorithm computes orthogonal
    **  matrices q and p such that b = q * s * p' (p' denotes the transpose
    **  of p). the singular values s are overwritten on d.
    **
    **  the input matrix u  is changed to u  * q  if desired.
    **  the input matrix vt is changed to p' * vt if desired.
    **  the input matrix c  is changed to q' * c  if desired.
    **
    **  see "computing  small singular values of bidiagonal matrices with
    **  guaranteed high relative accuracy," by j. demmel and w. kahan,
    **  lapack WORKing note #3, for a detailed description of the algorithm.
    **
    **  arguments
    **  =========
    **
    **  uplo  (input) char
    **        on entry, uplo specifies whether the input bidiagonal matrix
    **        is upper or lower bidiagonal, and wether it is square are
    **        not.
    **           uplo = 'u' or 'u'   b is upper bidiagonal.
    **           uplo = 'l' or 'l'   b is lower bidiagonal.
    **
    **  sqre  (input) long int
    **        = 0: then the input matrix is n-by-n.
    **        = 1: then the input matrix is n-by-(n+1) if uplu = 'u' and
    **             (n+1)-by-n if uplu = 'l'.
    **
    **        the bidiagonal matrix has
    **        n = nl + nr + 1 rows and
    **        m = n + sqre >= n columns.
    **
    **  n     (input) long int
    **        on entry, n specifies the number of rows and columns
    **        in the matrix. n must be at least 0.
    **
    **  ncvt  (input) long int
    **        on entry, ncvt specifies the number of columns of
    **        the matrix vt. ncvt must be at least 0.
    **
    **  nru   (input) long int
    **        on entry, nru specifies the number of rows of
    **        the matrix u. nru must be at least 0.
    **
    **  ncc   (input) long int
    **        on entry, ncc specifies the number of columns of
    **        the matrix c. ncc must be at least 0.
    **
    **  d     (input/output) BASE DATA TYPE array, dimension (n)
    **        on entry, d contains the diagonal entries of the
    **        bidiagonal matrix whose svd is desired. on normal exit,
    **        d contains the singular values in ascending order.
    **
    **  e     (input/output) BASE DATA TYPE array.
    **        dimension is (n-1) if sqre = 0 and n if sqre = 1.
    **        on entry, the entries of e contain the offdiagonal entries
    **        of the bidiagonal matrix whose svd is desired. on normal
    **        exit, e will contain 0. if the algorithm does not converge,
    **        d and e will contain the diagonal and superdiagonal entries
    **        of a bidiagonal matrix orthogonally equivalent to the one
    **        given as input.
    **
    **  vt    (input/output) BASE DATA TYPE array, dimension (ldvt, ncvt)
    **        on entry, contains a matrix which on exit has been
    **        premultiplied by p', dimension n-by-ncvt if sqre = 0
    **        and (n+1)-by-ncvt if sqre = 1 (not referenced if ncvt=0).
    **
    **  ldvt  (input) long int
    **        on entry, ldvt specifies the leading dimension of vt as
    **        declared in the calling (sub) program. ldvt must be at
    **        least 1. if ncvt is nonzero ldvt must also be at least n.
    **
    **  u     (input/output) BASE DATA TYPE array, dimension (ldu, n)
    **        on entry, contains a  matrix which on exit has been
    **        postmultiplied by q, dimension nru-by-n if sqre = 0
    **        and nru-by-(n+1) if sqre = 1 (not referenced if nru=0).
    **
    **  ldu   (input) long int
    **        on entry, ldu  specifies the leading dimension of u as
    **        declared in the calling (sub) program. ldu must be at
    **        least max( 1, nru ) .
    **
    **  c     (input/output) BASE DATA TYPE array, dimension (ldc, ncc)
    **        on entry, contains an n-by-ncc matrix which on exit
    **        has been premultiplied by q'  dimension n-by-ncc if sqre = 0
    **        and (n+1)-by-ncc if sqre = 1 (not referenced if ncc=0).
    **
    **  ldc   (input) long int
    **        on entry, ldc  specifies the leading dimension of c as
    **        declared in the calling (sub) program. ldc must be at
    **        least 1. if ncc is nonzero, ldc must also be at least n.
    **
    **
    **  info  (output) long int
    **        on exit, a value of 0 indicates a successful exit.
    **        if info < 0, argument number -info is illegal.
    **        if info > 0, the algorithm did not converge, and info
    **        specifies how many superdiagonals did not converge.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasdq(
        const char* uplo,
        const long int* sqre,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        float* d,
        const float* e,
        const float* vt,
        const long int* ldvt,
        const float* u,
        const long int* ldu,
        const float* c,
        const long int* ldc,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasdq(
        const char* uplo,
        const long int* sqre,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        float* d,
        const float* e,
        const float* vt,
        const long int* ldvt,
        const float* u,
        const long int* ldu,
        const float* c,
        const long int* ldc,
        long int* info)
  */
  /*! fn
   inline void lasdq(
        const char* uplo,
        const long int* sqre,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        double* d,
        const double* e,
        const double* vt,
        const long int* ldvt,
        const double* u,
        const long int* ldu,
        const double* c,
        const long int* ldc,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasdq(
        const char* uplo,
        const long int* sqre,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        double* d,
        const double* e,
        const double* vt,
        const long int* ldvt,
        const double* u,
        const long int* ldu,
        const double* c,
        const long int* ldc,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasdq.f)
  //    *  WORK  (workspace) float array, dimension (4*N)
  //    *        Workspace. Only referenced if one of NCVT, NRU, or NCC is
  //    *        nonzero, and if N is at least 2.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASDQ(NAME, T)\
inline void lasdq(\
    const char* uplo,\
    const long int* sqre,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    T* d,\
    const T* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(4*(*n));\
    F77NAME( NAME )(uplo, sqre, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, w.getw(), info);\
}\
inline void lasdq(\
    const char* uplo,\
    const long int* sqre,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    T* d,\
    const T* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   lasdq(uplo, sqre, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, info, w);\
}\

    LPP_LASDQ(slasdq, float)
    LPP_LASDQ(dlasdq, double)

#undef LPP_LASDQ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasdq_itf.hh
// /////////////////////////////////////////////////////////////////////////////
