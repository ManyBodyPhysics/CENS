#ifndef __PROJECT__LPP__FILE__LASD2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd2_itf.hh C++ interface to LAPACK (s,d,c,z)lasd2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd2_itf.hh
    (excerpt adapted from xlasd2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd2 merges the two sets of singular values together into a single
    **  sorted set.  then it tries to deflate the size of the problem.
    **  there are two ways in which deflation can occur:  when two or more
    **  singular values are close together or if there is a tiny entry in the
    **  z vector.  for each such occurrence the order of the related secular
    **  equation problem is reduced by one.
    **
    **  xlasd2 is called from dlasd1.
    **
    **  arguments
    **  =========
    **
    **  nl     (input) long int
    **         the row dimension of the upper block.  nl >= 1.
    **
    **  nr     (input) long int
    **         the row dimension of the lower block.  nr >= 1.
    **
    **  sqre   (input) long int
    **         = 0: the lower block is an nr-by-nr square matrix.
    **         = 1: the lower block is an nr-by-(nr+1) rectangular matrix.
    **
    **         the bidiagonal matrix has n = nl + nr + 1 rows and
    **         m = n + sqre >= n columns.
    **
    **  k      (output) long int
    **         contains the dimension of the non-deflated matrix,
    **         this is the order of the related secular equation. 1 <= k <=n.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension(n)
    **         on entry d contains the singular values of the two submatrices
    **         to be combined.  on exit d contains the trailing (n-k) updated
    **         singular values (those which were deflated) sorted into
    **         increasing order.
    **
    **  alpha  (input) BASE DATA TYPE
    **         contains the diagonal element associated with the added row.
    **
    **  beta   (input) BASE DATA TYPE
    **         contains the off-diagonal element associated with the added
    **         row.
    **
    **  u      (input/output) BASE DATA TYPE array, dimension(ldu,n)
    **         on entry u contains the left singular vectors of two
    **         submatrices in the two square blocks with corners at (1,1),
    **         (nl, nl), and (nl+2, nl+2), (n,n).
    **         on exit u contains the trailing (n-k) updated left singular
    **         vectors (those which were deflated) in its last n-k columns.
    **
    **  ldu    (input) long int
    **         the leading dimension of the array u.  ldu >= n.
    **
    **  z      (output) BASE DATA TYPE array, dimension(n)
    **         on exit z contains the updating row vector in the secular
    **         equation.
    **
    **  dsigma (output) BASE DATA TYPE array, dimension (n)
    **         contains a copy of the diagonal elements (k-1 singular values
    **         and one zero) in the secular equation.
    **
    **  u2     (output) BASE DATA TYPE array, dimension(ldu2,n)
    **         contains a copy of the first k-1 left singular vectors which
    **         will be used by dlasd3 in a matrix multiply (dgemm) to solve
    **         for the new left singular vectors. u2 is arranged into four
    **         blocks. the first block contains a column with 1 at nl+1 and
    **         zero everywhere else; the second block contains non-zero
    **         entries only at and above nl; the third contains non-zero
    **         entries only below nl+1; and the fourth is dense.
    **
    **  ldu2   (input) long int
    **         the leading dimension of the array u2.  ldu2 >= n.
    **
    **  vt     (input/output) BASE DATA TYPE array, dimension(ldvt,m)
    **         on entry vt' contains the right singular vectors of two
    **         submatrices in the two square blocks with corners at (1,1),
    **         (nl+1, nl+1), and (nl+2, nl+2), (m,m).
    **         on exit vt' contains the trailing (n-k) updated right singular
    **         vectors (those which were deflated) in its last n-k columns.
    **         in case sqre =1, the last row of vt spans the right null
    **         space.
    **
    **  ldvt   (input) long int
    **         the leading dimension of the array vt.  ldvt >= m.
    **
    **  vt2    (output) BASE DATA TYPE array, dimension(ldvt2,n)
    **         vt2' contains a copy of the first k right singular vectors
    **         which will be used by dlasd3 in a matrix multiply (dgemm) to
    **         solve for the new right singular vectors. vt2 is arranged into
    **         three blocks. the first block contains a row that corresponds
    **         to the special 0 diagonal element in sigma; the second block
    **         contains non-zeros only at and before nl +1; the third block
    **         contains non-zeros only at and after  nl +2.
    **
    **  ldvt2  (input) long int
    **         the leading dimension of the array vt2.  ldvt2 >= m.
    **
    **
    **
    **  idxc   (output) long int array, dimension(n)
    **         this will contain the permutation used to arrange the columns
    **         of the deflated u matrix into three groups:  the first group
    **         contains non-zero entries only at and above nl, the second
    **         contains non-zero entries only below nl+2, and the third is
    **         dense.
    **
    **
    **  idxq   (input) long int array, dimension(n)
    **         this contains the permutation which separately sorts the two
    **         sub-problems in d into ascending order.  note that entries in
    **         the first hlaf of this permutation must first be moved one
    **         position backward; and entries in the second half
    **         must first have nl+1 added to their values.
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd2(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        float* d,
        float* z,
        const float* alpha,
        const float* beta,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        float* dsigma,
        float* u2,
        const long int* ldu2,
        float* vt2,
        const long int* ldvt2,
        long int* idxp,
        long int* idx,
        long int* idxc,
        const long int* idxq,
        long int* coltyp,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd2(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        float* d,
        float* z,
        const float* alpha,
        const float* beta,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        float* dsigma,
        float* u2,
        const long int* ldu2,
        float* vt2,
        const long int* ldvt2,
        long int* idxp,
        long int* idx,
        long int* idxc,
        const long int* idxq,
        long int* coltyp,
        long int* info)
  */
  /*! fn
   inline void lasd2(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        double* d,
        double* z,
        const double* alpha,
        const double* beta,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        double* dsigma,
        double* u2,
        const long int* ldu2,
        double* vt2,
        const long int* ldvt2,
        long int* idxp,
        long int* idx,
        long int* idxc,
        const long int* idxq,
        long int* coltyp,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd2(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        double* d,
        double* z,
        const double* alpha,
        const double* beta,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        double* dsigma,
        double* u2,
        const long int* ldu2,
        double* vt2,
        const long int* ldvt2,
        long int* idxp,
        long int* idx,
        long int* idxc,
        const long int* idxq,
        long int* coltyp,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd2.f)
  //    *  IDXP   (workspace) long int array, dimension(N)
  //    *         This will contain the permutation used to place deflated
  //    *         values of D at the end of the array. On output IDXP(2:K)
  //    *         points to the nondeflated D-values and IDXP(K+1:N)
  //    *         points to the deflated singular values.
  //    *
  //    *  IDX    (workspace) long int array, dimension(N)
  //    *         This will contain the permutation used to sort the contents of
  //    *         D into ascending order.
  //    *
  //    *  COLTYP (workspace/output) long int array, dimension(N)
  //    *         As workspace, this will contain a label which will indicate
  //    *         which of the following types a column in the U2 matrix or a
  //    *         row in the VT2 matrix is:
  //    *         1 : non-zero in the upper half only
  //    *         2 : non-zero in the lower half only
  //    *         3 : dense
  //    *         4 : deflated
  //    *
  //    *         On exit, it is an array of dimension 4, with COLTYP(I) being
  //    *         the dimension of the I-th type columns.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD2(NAME, T)\
inline void lasd2(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    long int* k,\
    T* d,\
    T* z,\
    const T* alpha,\
    const T* beta,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    T* dsigma,\
    T* u2,\
    const long int* ldu2,\
    T* vt2,\
    const long int* ldvt2,\
    long int* idxp,\
    long int* idx,\
    long int* idxc,\
    const long int* idxq,\
    long int* coltyp,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(nl, nr, sqre, k, d, z, alpha, beta, u, ldu, vt, ldvt, dsigma, u2, ldu2, vt2, ldvt2, idxp, idx, idxc, idxq, coltyp, info);\
}\
inline void lasd2(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    long int* k,\
    T* d,\
    T* z,\
    const T* alpha,\
    const T* beta,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    T* dsigma,\
    T* u2,\
    const long int* ldu2,\
    T* vt2,\
    const long int* ldvt2,\
    long int* idxp,\
    long int* idx,\
    long int* idxc,\
    const long int* idxq,\
    long int* coltyp,\
    long int* info)\
{\
   workspace<T> w;\
   lasd2(nl, nr, sqre, k, d, z, alpha, beta, u, ldu, vt, ldvt, dsigma, u2, ldu2, vt2, ldvt2, idxp, idx, idxc, idxq, coltyp, info, w);\
}\

    LPP_LASD2(slasd2, float)
    LPP_LASD2(dlasd2, double)

#undef LPP_LASD2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
