#ifndef __PROJECT__LPP__FILE__LAR1V_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAR1V_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lar1v_itf.hh C++ interface to LAPACK (s,d,c,z)lar1v
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lar1v_itf.hh
    (excerpt adapted from xlar1v.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlar1v computes the (scaled) r-th column of the inverse of
    **  the sumbmatrix in rows b1 through bn of the tridiagonal matrix
    **  l d l^t - sigma i. the following steps accomplish this computation :
    **  (a) stationary qd transform,  l d l^t - sigma i = l(+) d(+) l(+)^t,
    **  (b) progressive qd transform, l d l^t - sigma i = u(-) d(-) u(-)^t,
    **  (c) computation of the diagonal elements of the inverse of
    **      l d l^t - sigma i by combining the above transforms, and choosing
    **      r as the index where the diagonal of the inverse is (one of the)
    **      largest in magnitude.
    **  (d) computation of the (scaled) r-th column of the inverse using the
    **      twisted factorization obtained by combining the top part of the
    **      the stationary and the bottom part of the progressive transform.
    **
    **  arguments
    **  =========
    **
    **  n        (input) long int
    **           the order of the matrix l d l^t.
    **
    **  b1       (input) long int
    **           first index of the submatrix of l d l^t.
    **
    **  bn       (input) long int
    **           last index of the submatrix of l d l^t.
    **
    **  sigma    (input) BASE DATA TYPE
    **           the shift. initially, when r = 0, sigma should be a good
    **           approximation to an eigenvalue of l d l^t.
    **
    **  l        (input) BASE DATA TYPE array, dimension (n-1)
    **           the (n-1) subdiagonal elements of the unit bidiagonal matrix
    **           l, in elements 1 to n-1.
    **
    **  d        (input) BASE DATA TYPE array, dimension (n)
    **           the n diagonal elements of the diagonal matrix d.
    **
    **  ld       (input) BASE DATA TYPE array, dimension (n-1)
    **           the n-1 elements l(i)*d(i).
    **
    **  lld      (input) BASE DATA TYPE array, dimension (n-1)
    **           the n-1 elements l(i)*l(i)*d(i).
    **
    **  gersch   (input) BASE DATA TYPE array, dimension (2*n)
    **           the n gerschgorin intervals. these are used to restrict
    **           the initial search for r, when r is input as 0.
    **
    **  z        (output) DATA TYPE array, dimension (n)
    **           the (scaled) r-th column of the inverse. z(r) is returned
    **           to be 1.
    **
    **  ztz      (output) BASE DATA TYPE
    **           the square of the norm of z.
    **
    **  mingma   (output) BASE DATA TYPE
    **           the reciprocal of the largest (in magnitude) diagonal
    **           element of the inverse of l d l^t - sigma i.
    **
    **  r        (input/output) long int
    **           initially, r should be input to be 0 and is then output as
    **           the index where the diagonal element of the inverse is
    **           largest in magnitude. in later iterations, this same value
    **           of r should be input.
    **
    **  isuppz   (output) long int array, dimension (2)
    **           the support of the vector in z, i.e., the vector z is
    **           nonzero only in elements isuppz(1) through isuppz( 2 ).
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **     ken stanley, computer science division, university of
    **       california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lar1v(
        const long int* n,
        const long int* b1,
        const long int* bn,
        const float* sigma,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const float* gersch,
        float* z,
        float* ztz,
        float* mingma,
        const long int* r,
        long int* isuppz,
        workspace<float> & w)
  */
  /*! fn
   inline void lar1v(
        const long int* n,
        const long int* b1,
        const long int* bn,
        const float* sigma,
        const float* d,
        const float* l,
        const float* ld,
        const float* lld,
        const float* gersch,
        float* z,
        float* ztz,
        float* mingma,
        const long int* r,
        long int* isuppz)
  */
  /*! fn
   inline void lar1v(
        const long int* n,
        const long int* b1,
        const long int* bn,
        const double* sigma,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const double* gersch,
        double* z,
        double* ztz,
        double* mingma,
        const long int* r,
        long int* isuppz,
        workspace<double> & w)
  */
  /*! fn
   inline void lar1v(
        const long int* n,
        const long int* b1,
        const long int* bn,
        const double* sigma,
        const double* d,
        const double* l,
        const double* ld,
        const double* lld,
        const double* gersch,
        double* z,
        double* ztz,
        double* mingma,
        const long int* r,
        long int* isuppz)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slar1v.f)
  //    *  WORK     (workspace) float array, dimension (4*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAR1V(NAME, T)\
inline void lar1v(\
    const long int* n,\
    const long int* b1,\
    const long int* bn,\
    const T* sigma,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const T* gersch,\
    T* z,\
    T* ztz,\
    T* mingma,\
    const long int* r,\
    long int* isuppz,\
    workspace<T> & w)\
{\
    w.resizew(4*(*n));\
    F77NAME( NAME )(n, b1, bn, sigma, d, l, ld, lld, gersch, z, ztz, mingma, r, isuppz, w.getw());\
}\
inline void lar1v(\
    const long int* n,\
    const long int* b1,\
    const long int* bn,\
    const T* sigma,\
    const T* d,\
    const T* l,\
    const T* ld,\
    const T* lld,\
    const T* gersch,\
    T* z,\
    T* ztz,\
    T* mingma,\
    const long int* r,\
    long int* isuppz) \
{\
   workspace<T> w;\
   lar1v(n, b1, bn, sigma, d, l, ld, lld, gersch, z, ztz, mingma, r, isuppz, w);\
}\

    LPP_LAR1V(slar1v, float)
    LPP_LAR1V(dlar1v, double)

#undef LPP_LAR1V


  // The following macro provides the 4 functions 
  /*! fn
   inline void lar1v(
       const long int* n,
       const long int* b1,
       const long int* bn,
       const float* sigma,
       const float* d,
       const float* l,
       const float* ld,
       const float* lld,
       const float* gersch,
       std::complex<float>* z,
       float* ztz,
       float* mingma,
       const long int* r,
       long int* isuppz,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lar1v(
       const long int* n,
       const long int* b1,
       const long int* bn,
       const float* sigma,
       const float* d,
       const float* l,
       const float* ld,
       const float* lld,
       const float* gersch,
       std::complex<float>* z,
       float* ztz,
       float* mingma,
       const long int* r,
       long int* isuppz)
  */
  /*! fn
   inline void lar1v(
       const long int* n,
       const long int* b1,
       const long int* bn,
       const double* sigma,
       const double* d,
       const double* l,
       const double* ld,
       const double* lld,
       const double* gersch,
       std::complex<double>* z,
       double* ztz,
       double* mingma,
       const long int* r,
       long int* isuppz,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lar1v(
       const long int* n,
       const long int* b1,
       const long int* bn,
       const double* sigma,
       const double* d,
       const double* l,
       const double* ld,
       const double* lld,
       const double* gersch,
       std::complex<double>* z,
       double* ztz,
       double* mingma,
       const long int* r,
       long int* isuppz)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clar1v.f)
  //    *  WORK     (workspace) float array, dimension (4*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAR1V(NAME, T, TBASE)\
inline void lar1v(\
    const long int* n,\
    const long int* b1,\
    const long int* bn,\
    const TBASE* sigma,\
    const TBASE* d,\
    const TBASE* l,\
    const TBASE* ld,\
    const TBASE* lld,\
    const TBASE* gersch,\
    T* z,\
    TBASE* ztz,\
    TBASE* mingma,\
    const long int* r,\
    long int* isuppz,\
    workspace<T> & w)\
{\
    w.resizerw(4*(*n));\
    F77NAME( NAME )(n, b1, bn, sigma, d, l, ld, lld, gersch, z, ztz, mingma, r, isuppz, w.getrw());\
}\
inline void lar1v(\
    const long int* n,\
    const long int* b1,\
    const long int* bn,\
    const TBASE* sigma,\
    const TBASE* d,\
    const TBASE* l,\
    const TBASE* ld,\
    const TBASE* lld,\
    const TBASE* gersch,\
    T* z,\
    TBASE* ztz,\
    TBASE* mingma,\
    const long int* r,\
    long int* isuppz) \
{\
   workspace<T> w;\
   lar1v(n, b1, bn, sigma, d, l, ld, lld, gersch, z, ztz, mingma, r, isuppz, w);\
}\

    LPP_LAR1V(clar1v, std::complex<float>, float)
    LPP_LAR1V(zlar1v, std::complex<double>, double)

#undef LPP_LAR1V



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lar1v_itf.hh
// /////////////////////////////////////////////////////////////////////////////
