#ifndef __PROJECT__LPP__FILE__GGESX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGESX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggesx_itf.hh C++ interface to LAPACK (c,d,c,z)ggesx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggesx_itf.hh
    (excerpt adapted from xggesx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggesx computes for a pair of n-by-n DATA TYPE nonsymmetric matrices
    **  (a,b), the generalized eigenvalues, the DATA TYPE schur form (s,t),
    **  and, optionally, the left and/or right matrices of schur vectors (vsl
    **  and vsr).  this gives the generalized schur factorization
    **
    **       (a,b) = ( (vsl) s (vsr)**h, (vsl) t (vsr)**h )
    **
    **  where (vsr)**h is the conjugate-transpose of vsr.
    **
    **  optionally, it also orders the eigenvalues so that a selected cluster
    **  of eigenvalues appears in the leading diagonal blocks of the upper
    **  triangular matrix s and the upper triangular matrix t; computes
    **  a reciprocal condition number for the average of the selected
    **  eigenvalues (rconde); and computes a reciprocal condition number for
    **  the right and left deflating subspaces corresponding to the selected
    **  eigenvalues (rcondv). the leading columns of vsl and vsr then form
    **  an orthonormal basis for the corresponding left and right eigenspaces
    **  (zeflating subspaces).
    **
    **  a generalized eigenvalue for a pair of matrices (a,b) is a scalar w
    **  or a ratio alpha/beta = ws, such that  a - w*b is singular.  it is
    **  usually represented as the pair (alpha,beta), as there is a
    **  reasonable interpretation for beta=0 or for both being zero.
    **
    **  a pair of matrices (s,t) is in generalized DATA TYPE schur form if t is
    **  upper triangular with non-negative diagonal and s is upper
    **  triangular.
    **
    **  arguments
    **  =========
    **
    **  jobvsl  (input) char
    **          = 'n':  do not compute the left schur vectors;
    **          = 'v':  compute the left schur vectors.
    **
    **  jobvsr  (input) char
    **          = 'n':  do not compute the right schur vectors;
    **          = 'v':  compute the right schur vectors.
    **
    **  sort    (input) char
    **          specifies whether or not to order the eigenvalues on the
    **          diagonal of the generalized schur form.
    **          = 'n':  eigenvalues are not ordered;
    **          = 's':  eigenvalues are ordered (see selctg).
    **
    **  selctg  (input) logical function of two DATA TYPE arguments
    **          selctg must be declared external in the calling subroutine.
    **          if sort = 'n', selctg is not referenced.
    **          if sort = 's', selctg is used to select eigenvalues to sort
    **          to the top left of the schur form.
    **          note that a selected DATA TYPE eigenvalue may no longer satisfy
    **          selctg(alpha(j),beta(j)) = .true. after ordering, since
    **          ordering may change the value of DATA TYPE eigenvalues
    **          (especially if the eigenvalue is ill-conditioned), in this
    **          case info is set to n+3 see info below).
    **
    **  sense   (input) character
    **          determines which reciprocal condition numbers are computed.
    **          = 'n' : none are computed;
    **          = 'e' : computed for average of selected eigenvalues only;
    **          = 'v' : computed for selected deflating subspaces only;
    **          = 'b' : computed for both.
    **          if sense = 'e', 'v', or 'b', sort must equal 's'.
    **
    **  n       (input) long int
    **          the order of the matrices a, b, vsl, and vsr.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the first of the pair of matrices.
    **          on exit, a has been overwritten by its generalized schur
    **          form s.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the second of the pair of matrices.
    **          on exit, b has been overwritten by its generalized schur
    **          form t.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  ldb >= max(1,n).
    **
    **  sdim    (output) long int
    **          if sort = 'n', sdim = 0.
    **          if sort = 's', sdim = number of eigenvalues (after sorting)
    **          for which selctg is true.
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **  beta    (output) DATA TYPE array, dimension (n)
    **          on exit, alpha(j)/beta(j), j=1,...,n, will be the
    **          generalized eigenvalues.  alpha(j) and beta(j),j=1,...,n  are
    **          the diagonals of the DATA TYPE schur form (s,t).  beta(j) will
    **          be non-negative BASE DATA TYPE.
    **
    **          note: the quotients alpha(j)/beta(j) may easily over- or
    **          underflow, and beta(j) may even be zero.  thus, the user
    **          should avoid naively computing the ratio alpha/beta.
    **          however, alpha will be always less than and usually
    **          comparable with norm(a) in magnitude, and beta always less
    **          than and usually comparable with norm(b).
    **
    **  vsl     (output) DATA TYPE array, dimension (ldvsl,n)
    **          if jobvsl = 'v', vsl will contain the left schur vectors.
    **          not referenced if jobvsl = 'n'.
    **
    **  ldvsl   (input) long int
    **          the leading dimension of the matrix vsl. ldvsl >=1, and
    **          if jobvsl = 'v', ldvsl >= n.
    **
    **  vsr     (output) DATA TYPE array, dimension (ldvsr,n)
    **          if jobvsr = 'v', vsr will contain the right schur vectors.
    **          not referenced if jobvsr = 'n'.
    **
    **  ldvsr   (input) long int
    **          the leading dimension of the matrix vsr. ldvsr >= 1, and
    **          if jobvsr = 'v', ldvsr >= n.
    **
    **  rconde  (output) BASE DATA TYPE array, dimension ( 2 )
    **          if sense = 'e' or 'b', rconde(1) and rconde(2) contain the
    **          reciprocal condition numbers for the average of the selected
    **          eigenvalues.
    **          not referenced if sense = 'n' or 'v'.
    **
    **  rcondv  (output) BASE DATA TYPE array, dimension ( 2 )
    **          if sense = 'v' or 'b', rcondv(1) and rcondv(2) contain the
    **          reciprocal condition number for the selected deflating
    **          subspaces.
    **          not referenced if sense = 'n' or 'e'.
    **
    **
    **
    **
    **
    **  lIWORK  (input) long int
    **          the dimension of the array WORK. lIWORK >= n+2.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          = 1,...,n:
    **                the qz iteration failed.  (a,b) are not in schur
    **                form, but alpha(j) and beta(j) should be correct for
    **                j=info+1,...,n.
    **          > n:  =n+1: other than qz iteration failed in chgeqz
    **                =n+2: after reordering, roundoff changed values of
    **                      some DATA TYPE eigenvalues so that leading
    **                      eigenvalues in the generalized schur form no
    **                      longer satisfy selctg=.true.  this could also
    **                      be caused due to scaling.
    **                =n+3: reordering failed in ctgsen.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggesx(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const char* sense,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* sdim,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        float* rconde,
        float* rcondv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggesx(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const char* sense,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* sdim,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        float* rconde,
        float* rcondv,
        long int* info)
  */
  /*! fn
   inline void ggesx(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const char* sense,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* sdim,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        double* rconde,
        double* rcondv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggesx(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const char* sense,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* sdim,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        double* rconde,
        double* rcondv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggesx.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= 8*(N+1)+16.
  //    *          If SENSE = 'E', 'V', or 'B',
  //    *          LWORK >= MAX( 8*(N+1)+16, 2*SDIM*(N-SDIM) ).
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (LIWORK)
  //    *          Not referenced if SENSE = 'N'.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGESX(NAME, T)\
inline void ggesx(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* selctg,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    T* rconde,\
    T* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizebw(*n);\
    long int liwork = -1; \
    F77NAME( NAME )(jobvsl, jobvsr, sort, selctg, sense, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, w.getw(), w.query(), w.getiw(), &liwork, w.getbw(), info); \
    w.resizeiw(liwork);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvsl, jobvsr, sort, selctg, sense, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, w.getw(), &w.neededsize(), w.getiw(), &liwork, w.getbw(), info);\
}\
inline void ggesx(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* selctg,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    T* rconde,\
    T* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   ggesx(jobvsl, jobvsr, sort, selctg, sense, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, info, w);\
}\

    LPP_GGESX(sggesx, float)
    LPP_GGESX(dggesx, double)

#undef LPP_GGESX


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggesx(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const char* sense,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       float* rconde,
       float* rcondv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggesx(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const char* sense,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       float* rconde,
       float* rcondv,
       long int* info)
  */
  /*! fn
   inline void ggesx(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const char* sense,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       double* rconde,
       double* rcondv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggesx(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const char* sense,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       double* rconde,
       double* rcondv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggesx.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= 2*N.
  //    *          If SENSE = 'E', 'V', or 'B',
  //    *          LWORK >= MAX(2*N, 2*SDIM*(N-SDIM)).
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension ( 8*N )
  //    *          Real workspace.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          Not referenced if SENSE = 'N'.
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGESX(NAME, T, TBASE)\
inline void ggesx(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* delctg,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(8**n);\
    w.resizebw(*n);\
    long int liwork = -1; \
    F77NAME( NAME )(jobvsl, jobvsr, sort, delctg, sense, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, w.getw(), w.query(), w.getrw(), w.getiw(), &liwork, w.getbw(), info);\
    w.resizew(w.neededsize());\
    w.resizeiw(liwork);\
    F77NAME( NAME )(jobvsl, jobvsr, sort, delctg, sense, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, w.getw(), &w.neededsize(), w.getrw(), w.getiw(), &liwork, w.getbw(), info);\
}\
inline void ggesx(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* delctg,\
    const char* sense,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   ggesx(jobvsl, jobvsr, sort, delctg, sense, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, rconde, rcondv, info, w);\
}\

    LPP_GGESX(cggesx, std::complex<float>,  float)
    LPP_GGESX(zggesx, std::complex<double>, double)

#undef LPP_GGESX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggesx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
