#ifndef __PROJECT__LPP__FILE__LANGB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LANGB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : langb_itf.hh C++ interface to LAPACK (s,d,c,z)langb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file langb_itf.hh
  (excerpt adapted from xlangb.f file commentaries)
  
  DATA TYPE can mean float, double, complex<float>, complex<double>
  
  BASE TYPE can mean respectively float, double, float, double
  
  In some cases only two of these types types are available
  the two real or the two complex ones.
  CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
  in the C++ calls, but through the workspace parameter,
  their use is transparent for the caller (see lapackworkspace.hh)
  
  *
  **  purpose
  **  =======
  **
  **  xlangb  returns the value of the one norm,  or the frobenius norm, or
  **  the  infinity norm,  or the element of  largest absolute value  of an
  **  n by n band matrix  a,  with kl sub-diagonals and ku super-diagonals.
  **
  **  description
  **  ===========
  **
  **  xlangb returns the value
  **
  **     xlangb = ( max(abs(a(i,j))), norm = 'm' or 'm'
  **              (
  **              ( norm1(a),         norm = '1', 'o' or 'o'
  **              (
  **              ( normi(a),         norm = 'i' or 'i'
  **              (
  **              ( normf(a),         norm = 'f', 'f', 'e' or 'e'
  **
  **  where  norm1  denotes the  one norm of a matrix (maximum column sum),
  **  normi  denotes the  infinity norm  of a matrix  (maximum row sum) and
  **  normf  denotes the  frobenius norm of a matrix (square root of sum of
  **  squares).  note that  max(abs(a(i,j)))  is not a  matrix norm.
  **
  **  arguments
  **  =========
  **
  **  norm    (input) char
  **          specifies the value to be returned in xlangb as described
  **          above.
  **
  **  n       (input) long int
  **          the order of the matrix a.  n >= 0.  when n = 0, xlangb is
  **          set to zero.
  **
  **  kl      (input) long int
  **          the number of sub-diagonals of the matrix a.  kl >= 0.
  **
  **  ku      (input) long int
  **          the number of super-diagonals of the matrix a.  ku >= 0.
  **
  **  ab      (input) DATA TYPE array, dimension (ldab,n)
  **          the band matrix a, stored in rows 1 to kl+ku+1.  the j-th
  **          column of a is stored in the j-th column of the array ab as
  **          follows:
  **          ab(ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(n,j+kl).
  **
  **  ldab    (input) long int
  **          the leading dimension of the array ab.  ldab >= kl+ku+1.
  **
  **/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////
  
  
  
  
  // The following macro provides the 8 functions 
  /*! fn
    inline float langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const float* ab,
    const long int* ldab,
    workspace<float> & w)
  */
  /*! fn
    inline float langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const float* ab,
    const long int* ldab)
  */
  /*! fn
    inline double langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const double* ab,
    const long int* ldab,
    workspace<double> & w)
  */
  /*! fn
    inline double langb(
    const char* norm,
    const long int* n, 
    const long int* kl,
    const long int* ku,
    const double* ab,
    const long int* ldab)
  */
  /*! fn
    inline float langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const comple<float> * ab,
    const long int* ldab,
    workspace<comple<float> > & w)
  */
  /*! fn
    inline float langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const comple<float> * ab,
    const long int* ldab)
  */
  /*! fn
    inline double langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const complex<double>* ab,
    const long int* ldab,
    workspace<complex<double> > & w)
  */
  /*! fn
    inline double langb(
    const char* norm,
    const long int* n,
    const long int* kl,
    const long int* ku,
    const complex<double>* ab,
    const long int* ldab)
  */
  
  
  // ///////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slangb.f)
  //    *  WORK    (workspace) BASE DATA array, dimension (LWORK),
  //    *          where LWORK >= N when NORM = 'I'; otherwise, WORK is not
  //    *          referenced.
  //    *
  // ///////////////////////////////////////////////////////////////////////
  
#define LPP_LANGB(NAME, T, TBASE)                                       \
  inline TBASE langb(                                                   \
                     const char* norm,                                  \
                     const long int* n,                                 \
                     const long int* kl,                                \
                     const long int* ku,                                \
                     const T* ab,                                       \
                     const long int* ldab,                              \
                     workspace<T> & w)                                  \
  {                                                                     \
    w.resizerw((lower(*norm) == 'i')?*n:0);                              \
    return F77NAME( NAME )(norm, n, kl, ku, ab, ldab, w.getrw());        \
  }                                                                     \
    inline TBASE langb(                                                 \
                       const char* norm,                                \
                       const long int* n,                               \
                       const long int* kl,                              \
                       const long int* ku,                              \
                       const T* ab,                                     \
                       const long int* ldab)                            \
    {                                                                   \
      workspace<T> w;                                                   \
      return langb(norm, n, kl, ku, ab, ldab, w);                       \
    }                                                                   \
    
  LPP_LANGB(slangb, float             , float)
    LPP_LANGB(dlangb, double            , double)
    LPP_LANGB(clangb, std::complex < float > , float)
    LPP_LANGB(zlangb, std::complex < double >, double)
    
    
#undef LPP_LANGB
  
  
  
  }
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of langb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
