#ifndef __PROJECT__LPP__FILE__LAED7_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED7_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed7_itf.hh C++ interface to LAPACK (s,d,c,z)laed7
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed7_itf.hh
    (excerpt adapted from xlaed7.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed7 computes the updated eigensystem of a diagonal
    **  matrix after modification by a rank-one symmetric matrix. this
    **  routine is used only for the eigenproblem which requires all
    **  eigenvalues and optionally eigenvectors of a dense or banded
    **  hermitian matrix that has been reduced to tridiagonal form.
    **
    **    t = q(in) ( d(in) + rho * z*z' ) q'(in) = q(out) * d(out) * q'(out)
    **
    **    where z = q'u, u is a vector of length n with ones in the
    **    cutpnt and cutpnt + 1 th elements and zeros elsewhere.
    **
    **     the eigenvectors of the original matrix are stored in q, and the
    **     eigenvalues are in d.  the algorithm consists of three stages:
    **
    **        the first stage consists of deflating the size of the problem
    **        when there are multiple eigenvalues or if there is a zero in
    **        the z vector.  for each such occurence the dimension of the
    **        secular equation problem is reduced by one.  this stage is
    **        performed by the routine slaed2.
    **
    **        the second stage consists of calculating the updated
    **        eigenvalues. this is done by finding the roots of the secular
    **        equation via the routine slaed4 (as called by slaed3).
    **        this routine also calculates the eigenvectors of the current
    **        problem.
    **
    **        the final stage consists of computing the updated eigenvectors
    **        directly using the updated eigenvalues.  the eigenvectors for
    **        the current problem are multiplied with the eigenvectors from
    **        the overall problem.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  cutpnt (input) long int
    **         contains the location of the last eigenvalue in the leading
    **         sub-matrix.  min(1,n) <= cutpnt <= n.
    **
    **  qsiz   (input) long int
    **         the dimension of the unitary matrix used to reduce
    **         the full matrix to tridiagonal form.  qsiz >= n.
    **
    **  tlvls  (input) long int
    **         the total number of merging levels in the overall divide and
    **         conquer tree.
    **
    **  curlvl (input) long int
    **         the current level in the overall merge routine,
    **         0 <= curlvl <= tlvls.
    **
    **  curpbm (input) long int
    **         the current problem in the current level in the overall
    **         merge routine (counting from upper left to lower right).
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry, the eigenvalues of the rank-1-perturbed matrix.
    **         on exit, the eigenvalues of the repaired matrix.
    **
    **  q      (input/output) DATA TYPE array, dimension (ldq,n)
    **         on entry, the eigenvectors of the rank-1-perturbed matrix.
    **         on exit, the eigenvectors of the repaired tridiagonal matrix.
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  rho    (input) BASE DATA TYPE
    **         contains the subdiagonal element used to create the rank-1
    **         modification.
    **
    **  indxq  (output) long int array, dimension (n)
    **         this contains the permutation which will reintegrate the
    **         subproblem just solved back into sorted order,
    **         ie. d( indxq( i = 1, n ) ) will be in ascending order.
    **
    **
    **
    **
    **  qstore (input/output) BASE DATA TYPE array, dimension (n**2+1)
    **         stores eigenvectors of submatrices encountered during
    **         divide and conquer, packed together. qptr points to
    **         beginning of the submatrices.
    **
    **  qptr   (input/output) long int array, dimension (n+2)
    **         list of indices pointing to beginning of submatrices stored
    **         in qstore. the submatrices are numbered starting at the
    **         bottom left of the divide and conquer tree, from left to
    **         right and bottom to top.
    **
    **  prmptr (input) long int array, dimension (n lg n)
    **         contains a list of pointers which indicate where in perm a
    **         level's permutation is stored.  prmptr(i+1) - prmptr(i)
    **         indicates the size of the permutation and also the size of
    **         the full, non-deflated problem.
    **
    **  perm   (input) long int array, dimension (n lg n)
    **         contains the permutations (from deflation and sorting) to be
    **         applied to each eigenblock.
    **
    **  givptr (input) long int array, dimension (n lg n)
    **         contains a list of pointers which indicate where in givcol a
    **         level's givens rotations are stored.  givptr(i+1) - givptr(i)
    **         indicates the number of givens rotations.
    **
    **  givcol (input) long int array, dimension (2, n lg n)
    **         each pair of numbers indicates a pair of columns to take place
    **         in a givens rotation.
    **
    **  givnum (input) BASE DATA TYPE array, dimension (2, n lg n)
    **         each number indicates the s value to be used in the
    **         corresponding givens rotation.
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an eigenvalue did not converge
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed7(
        const long int* icompq,
        const long int* n,
        const long int* qsiz,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        const float* rho,
        const long int* cutpnt,
        float* qstore,
        long int* qptr,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const float* givnum,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed7(
        const long int* icompq,
        const long int* n,
        const long int* qsiz,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        const float* rho,
        const long int* cutpnt,
        float* qstore,
        long int* qptr,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const float* givnum,
        long int* info)
  */
  /*! fn
   inline void laed7(
        const long int* icompq,
        const long int* n,
        const long int* qsiz,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        const double* rho,
        const long int* cutpnt,
        double* qstore,
        long int* qptr,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const double* givnum,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed7(
        const long int* icompq,
        const long int* n,
        const long int* qsiz,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        const double* rho,
        const long int* cutpnt,
        double* qstore,
        long int* qptr,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const double* givnum,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed7.f)
  //    *  WORK   (workspace) float array, dimension (3*N+QSIZ*N)
  //    *
  //    *  IWORK  (workspace) long int array, dimension (4*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED7(NAME, T)\
inline void laed7(\
    const long int* icompq,\
    const long int* n,\
    const long int* qsiz,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    const T* rho,\
    const long int* cutpnt,\
    T* qstore,\
    long int* qptr,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const T* givnum,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(4**n);\
    w.resizew(3*(*n)+(*qsiz)*(*n));                                     \
    F77NAME( NAME )(icompq, n, qsiz, tlvls, curlvl, curpbm, d, q, ldq, indxq,\
                    rho, cutpnt, qstore, qptr, prmptr, perm,\
                    givptr, givcol, givnum, w.getw(), w.getiw(), info); \
}\
inline void laed7(\
    const long int* icompq,\
    const long int* n,\
    const long int* qsiz,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    const T* rho,\
    const long int* cutpnt,\
    T* qstore,\
    long int* qptr,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const T* givnum,\
    long int* info)\
{\
   workspace<T> w;\
   laed7(icompq, n, qsiz, tlvls, curlvl, curpbm, d, q, ldq, indxq,\
         rho, cutpnt, qstore, qptr, prmptr, perm,\
         givptr, givcol, givnum, info, w);       \
}\

    LPP_LAED7(slaed7, float)
    LPP_LAED7(dlaed7, double)

#undef LPP_LAED7


  // The following macro provides the 4 functions 
  /*! fn
   inline void laed7(
       const long int* n,
       const long int* cutpnt,
       const long int* qsiz,
       const long int* tlvls,
       const long int* curlvl,
       const long int* curpbm,
       float* d,
       std::complex<float>* q,
       const long int* ldq,
       const float* rho,
       long int* indxq,
       float* qstore,
       long int* qptr,
       const long int* prmptr,
       const long int* perm,
       const long int* givptr,
       const long int* givcol,
       const float* givnum,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laed7(
       const long int* n,
       const long int* cutpnt,
       const long int* qsiz,
       const long int* tlvls,
       const long int* curlvl,
       const long int* curpbm,
       float* d,
       std::complex<float>* q,
       const long int* ldq,
       const float* rho,
       long int* indxq,
       float* qstore,
       long int* qptr,
       const long int* prmptr,
       const long int* perm,
       const long int* givptr,
       const long int* givcol,
       const float* givnum,
       long int* info)
  */
  /*! fn
   inline void laed7(
       const long int* n,
       const long int* cutpnt,
       const long int* qsiz,
       const long int* tlvls,
       const long int* curlvl,
       const long int* curpbm,
       double* d,
       std::complex<double>* q,
       const long int* ldq,
       const double* rho,
       long int* indxq,
       double* qstore,
       long int* qptr,
       const long int* prmptr,
       const long int* perm,
       const long int* givptr,
       const long int* givcol,
       const double* givnum,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laed7(
       const long int* n,
       const long int* cutpnt,
       const long int* qsiz,
       const long int* tlvls,
       const long int* curlvl,
       const long int* curpbm,
       double* d,
       std::complex<double>* q,
       const long int* ldq,
       const double* rho,
       long int* indxq,
       double* qstore,
       long int* qptr,
       const long int* prmptr,
       const long int* perm,
       const long int* givptr,
       const long int* givcol,
       const double* givnum,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claed7.f)
  //    *  IWORK  (workspace) long int array, dimension (4*N)
  //    *
  //    *  RWORK  (workspace) float array,
  //    *                                 dimension (3*N+2*QSIZ*N)
  //    *
  //    *  WORK   (workspace) std::complex<float> array, dimension (QSIZ*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED7(NAME, T, TBASE)\
inline void laed7(\
    const long int* n,\
    const long int* cutpnt,\
    const long int* qsiz,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    TBASE* d,\
    T* q,\
    const long int* ldq,\
    const TBASE* rho,\
    long int* indxq,\
    TBASE* qstore,\
    long int* qptr,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const TBASE* givnum,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizerw((3**n+2*(*qsiz)*(*n)));                                    \
  w.resizeiw(4**n);                                                     \
  w.resizew((*qsiz)*(*n));                                              \
  F77NAME( NAME )(n, cutpnt, qsiz, tlvls, curlvl, curpbm, d, q, ldq, rho, indxq, qstore, qptr, prmptr, perm, givptr, givcol, givnum, w.getw(), w.getrw(), w.getiw(), info); \
}\
inline void laed7(\
    const long int* n,\
    const long int* cutpnt,\
    const long int* qsiz,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    TBASE* d,\
    T* q,\
    const long int* ldq,\
    const TBASE* rho,\
    long int* indxq,\
    TBASE* qstore,\
    long int* qptr,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const TBASE* givnum,\
    long int* info)\
{\
   workspace<T> w;\
   laed7(n, cutpnt, qsiz, tlvls, curlvl, curpbm, d, q, ldq, rho, indxq, qstore, qptr, prmptr, perm, givptr, givcol, givnum, info, w);\
}\

    LPP_LAED7(claed7, std::complex<float>, float)
    LPP_LAED7(zlaed7, std::complex<double>, double)

#undef LPP_LAED7



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed7_itf.hh
// /////////////////////////////////////////////////////////////////////////////
