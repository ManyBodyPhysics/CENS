#ifndef __PROJECT__LPP__FILE__STEQR_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEQR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : steqr_itf.hh C++ interface to LAPACK (s,d,c,z)steqr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file steqr_itf.hh
    (excerpt adapted from xsteqr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsteqr computes all eigenvalues and, optionally, eigenvectors of a
    **  symmetric tridiagonal matrix using the implicit ql or qr method.
    **  the eigenvectors of a full or band DATA TYPE hermitian matrix can also
    **  be found if chetrd or chptrd or chbtrd has been used to reduce this
    **  matrix to tridiagonal form.
    **
    **  arguments
    **  =========
    **
    **  compz   (input) char
    **          = 'n':  compute eigenvalues only.
    **          = 'v':  compute eigenvalues and eigenvectors of the original
    **                  hermitian matrix.  on entry, z must contain the
    **                  unitary matrix used to reduce the original matrix
    **                  to tridiagonal form.
    **          = 'i':  compute eigenvalues and eigenvectors of the
    **                  tridiagonal matrix.  z is initialized to the identity
    **                  matrix.
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the diagonal elements of the tridiagonal matrix.
    **          on exit, if info = 0, the eigenvalues in ascending order.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix.
    **          on exit, e has been destroyed.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz, n)
    **          on entry, if  compz = 'v', then z contains the unitary
    **          matrix used in the reduction to tridiagonal form.
    **          on exit, if info = 0, then if compz = 'v', z contains the
    **          orthonormal eigenvectors of the original hermitian matrix,
    **          and if compz = 'i', z contains the orthonormal eigenvectors
    **          of the symmetric tridiagonal matrix.
    **          if compz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          eigenvectors are desired, then  ldz >= max(1,n).
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  the algorithm has failed to find all the eigenvalues in
    **                a total of 30*n iterations; if info = i, then i
    **                elements of e have not converged to zero; on exit, d
    **                and e contain the elements of a symmetric tridiagonal
    **                matrix which is unitarily similar to the original
    **                matrix.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void steqr(
        const char* compz,
        const long int* n,
        float* d,
        float* e,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void steqr(
        const char* compz,
        const long int* n,
        float* d,
        float* e,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void steqr(
        const char* compz,
        const long int* n,
        double* d,
        double* e,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void steqr(
        const char* compz,
        const long int* n,
        double* d,
        double* e,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssteqr.f)
  //    *  WORK    (workspace) float array, dimension (max(1,2*N-2))
  //    *          If COMPZ = 'N', then WORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEQR(NAME, T)\
inline void steqr(\
    const char* compz,\
    const long int* n,\
    T* d,\
    T* e,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(std::max(1l,2*(*n)-2));\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getw(), info);\
}\
inline void steqr(\
    const char* compz,\
    const long int* n,\
    T* d,\
    T* e,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   steqr(compz, n, d, e, z, ldz, info, w);\
}\

    LPP_STEQR(ssteqr, float)
    LPP_STEQR(dsteqr, double)

#undef LPP_STEQR


  // The following macro provides the 4 functions 
  /*! fn
   inline void steqr(
       const char* compz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void steqr(
       const char* compz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void steqr(
       const char* compz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void steqr(
       const char* compz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from csteqr.f)
  //    *  WORK    (workspace) float array, dimension (max(1,2*N-2))
  //    *          If COMPZ = 'N', then WORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEQR(NAME, T, TBASE)\
inline void steqr(\
    const char* compz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(std::max(1l,2*(*n)-2));\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getrw(), info);\
}\
inline void steqr(\
    const char* compz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   steqr(compz, n, d, e, z, ldz, info, w);\
}\

    LPP_STEQR(csteqr, std::complex<float>, float)
    LPP_STEQR(zsteqr, std::complex<double>, double)

#undef LPP_STEQR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of steqr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
