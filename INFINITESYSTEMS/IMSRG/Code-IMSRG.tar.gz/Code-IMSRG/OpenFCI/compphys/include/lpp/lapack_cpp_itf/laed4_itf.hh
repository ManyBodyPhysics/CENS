#ifndef __PROJECT__LPP__FILE__LAED4_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED4_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed4_itf.hh C++ interface to LAPACK (s,d,c,z)laed4
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed4_itf.hh
    (excerpt adapted from xlaed4.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this subroutine computes the i-th updated eigenvalue of a symmetric
    **  rank-one modification to a diagonal matrix whose elements are
    **  given in the array d, and that
    **
    **             d(i) < d(j)  for  i < j
    **
    **  and that rho > 0.  this is arranged by the calling routine, and is
    **  no loss in generality.  the rank-one modified system is thus
    **
    **             diag( d )  +  rho *  z * z_transpose.
    **
    **  where we assume the euclidean norm of z is 1.
    **
    **  the method consists of approximating the rational functions in the
    **  secular equation by simpler interpolating rational functions.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the length of all arrays.
    **
    **  i      (input) long int
    **         the index of the eigenvalue to be computed.  1 <= i <= n.
    **
    **  d      (input) BASE DATA TYPE array, dimension (n)
    **         the original eigenvalues.  it is assumed that they are in
    **         order, d(i) < d(j)  for i < j.
    **
    **  z      (input) BASE DATA TYPE array, dimension (n)
    **         the components of the updating vector.
    **
    **  delta  (output) BASE DATA TYPE array, dimension (n)
    **         if n .ne. 1, delta contains (d(j) - lambda_i) in its  j-th
    **         component.  if n = 1, then delta(1) = 1.  the vector delta
    **         contains the information necessary to construct the
    **         eigenvectors.
    **
    **  rho    (input) BASE DATA TYPE
    **         the scalar in the symmetric updating formula.
    **
    **  dlam   (output) BASE DATA TYPE
    **         the computed lambda_i, the i-th updated eigenvalue.
    **
    **  info   (output) long int
    **         = 0:  successful exit
    **         > 0:  if info = 1, the updating process failed.
    **
    **  internal parameters
    **  ===================
    **
    **  logical variable orgati (origin-at-i?) is used for distinguishing
    **  whether d(i) or d(i+1) is treated as the origin.
    **
    **            orgati = .true.    origin at i
    **            orgati = .false.   origin at i+1
    **
    **   logical variable swtch3 (switch-for-3-poles?) is for noting
    **   if we are WORKing with three poles!
    **
    **   maxit is the maximum number of iterations allowed for each
    **   eigenvalue.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ren-cang li, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed4(
        const long int* n,
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dlam,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed4(
        const long int* n,
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dlam,
        long int* info)
  */
  /*! fn
   inline void laed4(
        const long int* n,
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dlam,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed4(
        const long int* n,
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dlam,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed4.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED4(NAME, T)\
inline void laed4(\
    const long int* n,\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dlam,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, i, d, z, delta, rho, dlam, info);\
}\
inline void laed4(\
    const long int* n,\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dlam,\
    long int* info)\
{\
   workspace<T> w;\
   laed4(n, i, d, z, delta, rho, dlam, info, w);\
}\

    LPP_LAED4(slaed4, float)
    LPP_LAED4(dlaed4, double)

#undef LPP_LAED4



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed4_itf.hh
// /////////////////////////////////////////////////////////////////////////////
