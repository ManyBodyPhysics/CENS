#ifndef __PROJECT__LPP__FILE__TPRFS_HH__INCLUDED
#define __PROJECT__LPP__FILE__TPRFS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tprfs_itf.hh C++ interface to LAPACK (s,d,c,z)tprfs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tprfs_itf.hh
    (excerpt adapted from xtprfs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtprfs provides error bounds and backward error estimates for the
    **  solution to a system of linear equations with a triangular packed
    **  coefficient matrix.
    **
    **  the solution matrix x must be computed by ctptrs or some other
    **  means before entering this routine.  xtprfs does not do iterative
    **  refinement because doing so cannot improve the backward error.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  a is upper triangular;
    **          = 'l':  a is lower triangular.
    **
    **  trans   (input) char
    **          specifies the form of the system of equations:
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  diag    (input) char
    **          = 'n':  a is non-unit triangular;
    **          = 'u':  a is unit triangular.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrices b and x.  nrhs >= 0.
    **
    **  ap      (input) DATA TYPE array, dimension (n*(n+1)/2)
    **          the upper or lower triangular matrix a, packed columnwise in
    **          a linear array.  the j-th column of a is stored in the array
    **          ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = a(i,j) for j<=i<=n.
    **          if diag = 'u', the diagonal elements of a are not referenced
    **          and are assumed to be 1.
    **
    **  b       (input) DATA TYPE array, dimension (ldb,nrhs)
    **          the right hand side matrix b. 
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (input) DATA TYPE array, dimension (ldx,nrhs)
    **          the solution matrix x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the estimated forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).  the estimate is as reliable as
    **          the estimate for rcond, and is almost always a slight
    **          overestimate of the true error.
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tprfs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const float* ap,
        const float* b,
        const long int* ldb,
        const float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tprfs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const float* ap,
        const float* b,
        const long int* ldb,
        const float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void tprfs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const double* ap,
        const double* b,
        const long int* ldb,
        const double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tprfs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const double* ap,
        const double* b,
        const long int* ldb,
        const double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stprfs.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TPRFS(NAME, T)\
inline void tprfs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* ap,\
    const T* b,\
    const long int* ldb,\
    const T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(3*(*n));\
    F77NAME( NAME )(uplo, trans, diag, n, nrhs, ap, b, ldb, x, ldx, ferr, berr, w.getw(), w.getiw(), info);\
}\
inline void tprfs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* ap,\
    const T* b,\
    const long int* ldb,\
    const T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   tprfs(uplo, trans, diag, n, nrhs, ap, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_TPRFS(stprfs, float)
    LPP_TPRFS(dtprfs, double)

#undef LPP_TPRFS


  // The following macro provides the 4 functions 
  /*! fn
   inline void tprfs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* ap,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tprfs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* ap,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void tprfs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* ap,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tprfs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* ap,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctprfs.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TPRFS(NAME, T, TBASE)\
inline void tprfs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* ap,\
    const T* b,\
    const long int* ldb,\
    const T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(uplo, trans, diag, n, nrhs, ap, b, ldb, x, ldx, ferr, berr, w.getw(), w.getrw(), info);\
}\
inline void tprfs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* ap,\
    const T* b,\
    const long int* ldb,\
    const T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   tprfs(uplo, trans, diag, n, nrhs, ap, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_TPRFS(ctprfs, std::complex<float>, float)
    LPP_TPRFS(ztprfs, std::complex<double>, double)

#undef LPP_TPRFS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tprfs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
