#ifndef __PROJECT__LPP__FILE__LARRV_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARRV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larrv_itf.hh C++ interface to LAPACK (s,d,c,z)larrv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larrv_itf.hh
    (excerpt adapted from xlarrv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarrv computes the eigenvectors of the tridiagonal matrix
    **  t = l d l^t given l, d and the eigenvalues of l d l^t.
    **  the input eigenvalues should have high relative accuracy with
    **  respect to the entries of l and d. the desired accuracy of the
    **  output can be specified by the input parameter tol.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the diagonal matrix d.
    **          on exit, d may be overwritten.
    **
    **  l       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, the (n-1) subdiagonal elements of the unit
    **          bidiagonal matrix l in elements 1 to n-1 of l. l(n) need
    **          not be set. on exit, l is overwritten.
    **
    **  isplit  (input) long int array, dimension (n)
    **          the splitting points, at which t breaks up into submatrices.
    **          the first submatrix consists of rows/columns 1 to
    **          isplit( 1 ), the second of rows/columns isplit( 1 )+1
    **          through isplit( 2 ), etc.
    **
    **  tol     (input) BASE DATA TYPE
    **          the absolute error tolerance for the
    **          eigenvalues/eigenvectors.
    **          errors in the input eigenvalues must be bounded by tol.
    **          the eigenvectors output have residual norms
    **          bounded by tol, and the dot products between different
    **          eigenvectors are bounded by tol. tol must be at least
    **          n*eps*|t|, where eps is the machine precision and |t| is
    **          the 1-norm of the tridiagonal matrix.
    **
    **  m       (input) long int
    **          the total number of eigenvalues found.  0 <= m <= n.
    **          if range = 'a', m = n, and if range = 'i', m = iu-il+1.
    **
    **  w       (input) BASE DATA TYPE array, dimension (n)
    **          the first m elements of w contain the eigenvalues for
    **          which eigenvectors are to be computed.  the eigenvalues
    **          should be grouped by split-off block and ordered from
    **          smallest to largest within the block ( the output array
    **          w from slarre is expected here ).
    **          errors in w must be bounded by tol (see above).
    **
    **  iblock  (input) long int array, dimension (n)
    **          the submatrix indices associated with the corresponding
    **          eigenvalues in w; iblock(i)=1 if eigenvalue w(i) belongs to
    **          the first submatrix from the top, =2 if w(i) belongs to
    **          the second submatrix, etc. 
    **
    **  gersch   (input) BASE DATA TYPE array, dimension (2*n) (jtl)
    **           the n gerschgorin intervals. these are used to restrict
    **           the initial search for r, when r is input as 0.
    **
    **  z       (output) DATA TYPE array, dimension (ldz, max(1,m) )
    **          if jobz = 'v', then if info = 0, the first m columns of z
    **          contain the orthonormal eigenvectors of the matrix t
    **          corresponding to the selected eigenvalues, with the i-th
    **          column of z holding the eigenvector associated with w(i).
    **          if jobz = 'n', then z is not referenced.
    **          note: the user must ensure that at least max(1,m) columns are
    **          supplied in the array z; if range = 'v', the exact value of m
    **          is not known in advance and an upper bound must be used.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **  isuppz  (output) long int array, dimension ( 2*max(1,m) )
    **          the support of the eigenvectors in z, i.e., the indices
    **          indicating the nonzero elements in z. the i-th eigenvector
    **          is nonzero only in elements isuppz( 2*i-1 ) through
    **          isuppz( 2*i ).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = 1, internal error in slarrb
    **                if info = 2, internal error in cstein
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **     ken stanley, computer science division, university of
    **       california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larrv(
        const long int* n,
        float* d,
        float* l,
        const long int* isplit,
        const long int* m,
        const float* ws,
        const long int* iblock,
        const float* gersch,
        const float* tol,
        float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void larrv(
        const long int* n,
        float* d,
        float* l,
        const long int* isplit,
        const long int* m,
        const float* ws,
        const long int* iblock,
        const float* gersch,
        const float* tol,
        float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */
  /*! fn
   inline void larrv(
        const long int* n,
        double* d,
        double* l,
        const long int* isplit,
        const long int* m,
        const double* ws,
        const long int* iblock,
        const double* gersch,
        const double* tol,
        double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void larrv(
        const long int* n,
        double* d,
        double* l,
        const long int* isplit,
        const long int* m,
        const double* ws,
        const long int* iblock,
        const double* gersch,
        const double* tol,
        double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarrv.f)
  //    *  WORK    (workspace) float array, dimension (13*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (6*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARRV(NAME, T)\
inline void larrv(\
    const long int* n,\
    T* d,\
    T* l,\
    const long int* isplit,\
    const long int* m,\
    const T* ws,\
    const long int* iblock,\
    const T* gersch,\
    const T* tol,\
    T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(6*(*n));\
    w.resizew(13*(*n));\
    F77NAME( NAME )(n, d, l, isplit, m, ws, iblock, gersch, tol, z, ldz, isuppz, w.getw(), w.getiw(), info);\
}\
inline void larrv(\
    const long int* n,\
    T* d,\
    T* l,\
    const long int* isplit,\
    const long int* m,\
    const T* ws,\
    const long int* iblock,\
    const T* gersch,\
    const T* tol,\
    T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info)\
{\
   workspace<T> w;\
   larrv(n, d, l, isplit, m, ws, iblock, gersch, tol, z, ldz, isuppz, info, w);\
}\

    LPP_LARRV(slarrv, float)
    LPP_LARRV(dlarrv, double)

#undef LPP_LARRV


  // The following macro provides the 4 functions 
  /*! fn
   inline void larrv(
       const long int* n,
       float* d,
       float* l,
       const long int* isplit,
       const long int* m,
       const float* ws,
       const long int* iblock,
       const float* gersch,
       const float* tol,
       std::complex<float>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larrv(
       const long int* n,
       float* d,
       float* l,
       const long int* isplit,
       const long int* m,
       const float* ws,
       const long int* iblock,
       const float* gersch,
       const float* tol,
       std::complex<float>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info)
  */
  /*! fn
   inline void larrv(
       const long int* n,
       double* d,
       double* l,
       const long int* isplit,
       const long int* m,
       const double* ws,
       const long int* iblock,
       const double* gersch,
       const double* tol,
       std::complex<double>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larrv(
       const long int* n,
       double* d,
       double* l,
       const long int* isplit,
       const long int* m,
       const double* ws,
       const long int* iblock,
       const double* gersch,
       const double* tol,
       std::complex<double>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarrv.f)
  //    *  WORK    (workspace) float array, dimension (13*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (6*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARRV(NAME, T, TBASE)\
inline void larrv(\
    const long int* n,\
    TBASE* d,\
    TBASE* l,\
    const long int* isplit,\
    const long int* m,\
    const TBASE* ws,\
    const long int* iblock,\
    const TBASE* gersch,\
    const TBASE* tol,\
    T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(6*(*n));\
    w.resizerw(13*(*n));\
    F77NAME( NAME )(n, d, l, isplit, m, ws, iblock, gersch, tol, z, ldz, isuppz, w.getrw(), w.getiw(), info);\
}\
inline void larrv(\
    const long int* n,\
    TBASE* d,\
    TBASE* l,\
    const long int* isplit,\
    const long int* m,\
    const TBASE* ws,\
    const long int* iblock,\
    const TBASE* gersch,\
    const TBASE* tol,\
    T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info)\
{\
   workspace<T> w;\
   larrv(n, d, l, isplit, m, ws, iblock, gersch, tol, z, ldz, isuppz, info, w);\
}\

    LPP_LARRV(clarrv, std::complex<float>, float)
    LPP_LARRV(zlarrv, std::complex<double>, double)

#undef LPP_LARRV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larrv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
