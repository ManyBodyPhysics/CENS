#ifndef __PROJECT__LPP__FILE__LASD6_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD6_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd6_itf.hh C++ interface to LAPACK (s,d,c,z)lasd6
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd6_itf.hh
    (excerpt adapted from xlasd6.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd6 computes the svd of an updated upper bidiagonal matrix b
    **  obtained by merging two smaller ones by appending a row. this
    **  routine is used only for the problem which requires all singular
    **  values and optionally singular vector matrices in factored form.
    **  b is an n-by-m matrix with n = nl + nr + 1 and m = n + sqre.
    **  a related subroutine, dlasd1, handles the case in which all singular
    **  values and singular vectors of the bidiagonal matrix are desired.
    **
    **  xlasd6 computes the svd as follows:
    **
    **                ( d1(in)  0    0     0 )
    **    b = u(in) * (   z1'   a   z2'    b ) * vt(in)
    **                (   0     0   d2(in) 0 )
    **
    **      = u(out) * ( d(out) 0) * vt(out)
    **
    **  where z' = (z1' a z2' b) = u' vt', and u is a vector of dimension m
    **  with alpha and beta in the nl+1 and nl+2 th entries and zeros
    **  elsewhere; and the entry b is empty if sqre = 0.
    **
    **  the singular values of b can be computed using d1, d2, the first
    **  components of all the right singular vectors of the lower block, and
    **  the last components of all the right singular vectors of the upper
    **  block. these components are stored and updated in vf and vl,
    **  respectively, in xlasd6. hence u and vt are not explicitly
    **  referenced.
    **
    **  the singular values are stored in d. the algorithm consists of two
    **  stages:
    **
    **        the first stage consists of deflating the size of the problem
    **        when there are multiple singular values or if there is a zero
    **        in the z vector. for each such occurence the dimension of the
    **        secular equation problem is reduced by one. this stage is
    **        performed by the routine dlasd7.
    **
    **        the second stage consists of calculating the updated
    **        singular values. this is done by finding the roots of the
    **        secular equation via the routine dlasd4 (as called by dlasd8).
    **        this routine also updates vf and vl and computes the distances
    **        between the updated singular values and the old singular
    **        values.
    **
    **  xlasd6 is called from dlasda.
    **
    **  arguments
    **  =========
    **
    **  icompq (input) long int
    **         specifies whether singular vectors are to be computed in
    **         factored form:
    **         = 0: compute singular values only.
    **         = 1: compute singular vectors in factored form as well.
    **
    **  nl     (input) long int
    **         the row dimension of the upper block.  nl >= 1.
    **
    **  nr     (input) long int
    **         the row dimension of the lower block.  nr >= 1.
    **
    **  sqre   (input) long int
    **         = 0: the lower block is an nr-by-nr square matrix.
    **         = 1: the lower block is an nr-by-(nr+1) rectangular matrix.
    **
    **         the bidiagonal matrix has row dimension n = nl + nr + 1,
    **         and column dimension m = n + sqre.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension ( nl+nr+1 ).
    **         on entry d(1:nl,1:nl) contains the singular values of the
    **         upper block, and d(nl+2:n) contains the singular values
    **         of the lower block. on exit d(1:n) contains the singular
    **         values of the modified matrix.
    **
    **  vf     (input/output) BASE DATA TYPE array, dimension ( m )
    **         on entry, vf(1:nl+1) contains the first components of all
    **         right singular vectors of the upper block; and vf(nl+2:m)
    **         contains the first components of all right singular vectors
    **         of the lower block. on exit, vf contains the first components
    **         of all right singular vectors of the bidiagonal matrix.
    **
    **  vl     (input/output) BASE DATA TYPE array, dimension ( m )
    **         on entry, vl(1:nl+1) contains the  last components of all
    **         right singular vectors of the upper block; and vl(nl+2:m)
    **         contains the last components of all right singular vectors of
    **         the lower block. on exit, vl contains the last components of
    **         all right singular vectors of the bidiagonal matrix.
    **
    **  alpha  (input) BASE DATA TYPE
    **         contains the diagonal element associated with the added row.
    **
    **  beta   (input) BASE DATA TYPE
    **         contains the off-diagonal element associated with the added
    **         row.
    **
    **  idxq   (output) long int array, dimension ( n )
    **         this contains the permutation which will reintegrate the
    **         subproblem just solved back into sorted order, i.e.
    **         d( idxq( i = 1, n ) ) will be in ascending order.
    **
    **  perm   (output) long int array, dimension ( n )
    **         the permutations (from deflation and sorting) to be applied
    **         to each block. not referenced if icompq = 0.
    **
    **  givptr (output) long int
    **         the number of givens rotations which took place in this
    **         subproblem. not referenced if icompq = 0.
    **
    **  givcol (output) long int array, dimension ( ldgcol, 2 )
    **         each pair of numbers indicates a pair of columns to take place
    **         in a givens rotation. not referenced if icompq = 0.
    **
    **  ldgcol (input) long int
    **         leading dimension of givcol, must be at least n.
    **
    **  givnum (output) BASE DATA TYPE array, dimension ( ldgnum, 2 )
    **         each number indicates the c or s value to be used in the
    **         corresponding givens rotation. not referenced if icompq = 0.
    **
    **  ldgnum (input) long int
    **         the leading dimension of givnum and poles, must be at least n.
    **
    **  poles  (output) BASE DATA TYPE array, dimension ( ldgnum, 2 )
    **         on exit, poles(1,*) is an array containing the new singular
    **         values obtained from solving the secular equation, and
    **         poles(2,*) is an array containing the poles in the secular
    **         equation. not referenced if icompq = 0.
    **
    **  difl   (output) BASE DATA TYPE array, dimension ( n )
    **         on exit, difl(i) is the distance between i-th updated
    **         (undeflated) singular value and the i-th (undeflated) old
    **         singular value.
    **
    **  difr   (output) BASE DATA TYPE array,
    **                  dimension ( ldgnum, 2 ) if icompq = 1 and
    **                  dimension ( n ) if icompq = 0.
    **         on exit, difr(i, 1) is the distance between i-th updated
    **         (undeflated) singular value and the i+1-th (undeflated) old
    **         singular value.
    **
    **         if icompq = 1, difr(1:k,2) is an array containing the
    **         normalizing factors for the right singular vector matrix.
    **
    **         see dlasd8 for details on difl and difr.
    **
    **  z      (output) BASE DATA TYPE array, dimension ( m )
    **         the first elements of this array contain the components
    **         of the deflation-adjusted updating row vector.
    **
    **  k      (output) long int
    **         contains the dimension of the non-deflated matrix,
    **         this is the order of the related secular equation. 1 <= k <=n.
    **
    **  c      (output) BASE DATA TYPE
    **         c contains garbage if sqre =0 and the c-value of a givens
    **         rotation related to the right null space if sqre = 1.
    **
    **  s      (output) BASE DATA TYPE
    **         s contains garbage if sqre =0 and the s-value of a givens
    **         rotation related to the right null space if sqre = 1.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd6(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        float* d,
        float* vf,
        float* vl,
        const float* alpha,
        const float* beta,
        long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        float* givnum,
        const long int* ldgnum,
        float* poles,
        float* difl,
        float* difr,
        float* z,
        long int* k,
        const float* c,
        const float* s,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd6(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        float* d,
        float* vf,
        float* vl,
        const float* alpha,
        const float* beta,
        long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        float* givnum,
        const long int* ldgnum,
        float* poles,
        float* difl,
        float* difr,
        float* z,
        long int* k,
        const float* c,
        const float* s,
        long int* info)
  */
  /*! fn
   inline void lasd6(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        double* d,
        double* vf,
        double* vl,
        const double* alpha,
        const double* beta,
        long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        double* givnum,
        const long int* ldgnum,
        double* poles,
        double* difl,
        double* difr,
        double* z,
        long int* k,
        const double* c,
        const double* s,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd6(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        double* d,
        double* vf,
        double* vl,
        const double* alpha,
        const double* beta,
        long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        double* givnum,
        const long int* ldgnum,
        double* poles,
        double* difl,
        double* difr,
        double* z,
        long int* k,
        const double* c,
        const double* s,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd6.f)
  //    *  WORK   (workspace) float array, dimension ( 4 * M )
  //    *
  //    *  IWORK  (workspace) long int array, dimension ( 3 * N )
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD6(NAME, T)\
inline void lasd6(\
    const long int* icompq,\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    T* d,\
    T* vf,\
    T* vl,\
    const T* alpha,\
    const T* beta,\
    long int* idxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    T* givnum,\
    const long int* ldgnum,\
    T* poles,\
    T* difl,\
    T* difr,\
    T* z,\
    long int* k,\
    const T* c,\
    const T* s,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(3*(*nl));                           \
    w.resizew( 4 * (*nr) );\
    F77NAME( NAME )(icompq, nl, nr, sqre, d, vf, vl, alpha, beta, idxq, perm, givptr, givcol, ldgcol, givnum, ldgnum, poles, difl, difr, z, k, c, s, w.getw(), w.getiw(), info);\
}\
inline void lasd6(\
    const long int* icompq,\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    T* d,\
    T* vf,\
    T* vl,\
    const T* alpha,\
    const T* beta,\
    long int* idxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    T* givnum,\
    const long int* ldgnum,\
    T* poles,\
    T* difl,\
    T* difr,\
    T* z,\
    long int* k,\
    const T* c,\
    const T* s,\
    long int* info)\
{\
   workspace<T> w;\
   lasd6(icompq, nl, nr, sqre, d, vf, vl, alpha, beta, idxq, perm, givptr, givcol, ldgcol, givnum, ldgnum, poles, difl, difr, z, k, c, s, info, w);\
}\

    LPP_LASD6(slasd6, float)
    LPP_LASD6(dlasd6, double)

#undef LPP_LASD6



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd6_itf.hh
// /////////////////////////////////////////////////////////////////////////////
