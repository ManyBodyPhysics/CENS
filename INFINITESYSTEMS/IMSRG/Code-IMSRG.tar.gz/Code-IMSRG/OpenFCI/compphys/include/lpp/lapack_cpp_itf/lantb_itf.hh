#ifndef __PROJECT__LPP__FILE__LANTB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LANTB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lantb_itf.hh C++ interface to LAPACK (s,d,c,z)lantb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lantb_itf.hh
    (excerpt adapted from xlantb.f file commentaries)
    
    DATA TYPE can mean float, double, complex<float>, complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlantb  returns the value of the one norm,  or the frobenius norm, or
    **  the  infinity norm,  or the element of  largest absolute value  of an
    **  n by n triangular band matrix a,  with ( k + 1 ) diagonals.
    **
    **  description
    **  ===========
    **
    **  xlantb returns the value
    **
    **     xlantb = ( max(abs(a(i,j))), norm = 'm' or 'm'
    **              (
    **              ( norm1(a),         norm = '1', 'o' or 'o'
    **              (
    **              ( normi(a),         norm = 'i' or 'i'
    **              (
    **              ( normf(a),         norm = 'f', 'f', 'e' or 'e'
    **
    **  where  norm1  denotes the  one norm of a matrix (maximum column sum),
    **  normi  denotes the  infinity norm  of a matrix  (maximum row sum) and
    **  normf  denotes the  frobenius norm of a matrix (square root of sum of
    **  squares).  note that  max(abs(a(i,j)))  is not a  matrix norm.
    **
    **  arguments
    **  =========
    **
    **  norm    (input) char
    **          specifies the value to be returned in xlantb as described
    **          above.
    **
    **  uplo    (input) char
    **          specifies whether the matrix a is upper or lower triangular.
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  diag    (input) char
    **          specifies whether or not the matrix a is unit triangular.
    **          = 'n':  non-unit triangular
    **          = 'u':  unit triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.  when n = 0, xlantb is
    **          set to zero.
    **
    **  k       (input) long int
    **          the number of super-diagonals of the matrix a if uplo = 'u',
    **          or the number of sub-diagonals of the matrix a if uplo = 'l'.
    **          k >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the upper or lower triangular band matrix a, stored in the
    **          first k+1 rows of ab.  the j-th column of a is stored
    **          in the j-th column of the array ab as follows:
    **          if uplo = 'u', ab(k+1+i-j,j) = a(i,j) for max(1,j-k)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)   = a(i,j) for j<=i<=min(n,j+k).
    **          note that when diag = 'u', the elements of the array ab
    **          corresponding to the diagonal elements of the matrix a are
    **          not referenced, but are assumed to be one.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= k+1.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 8 functions 
  /*! fn
   inline float lantb(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const float* ab,
        const long int* ldab,
        workspace<float> & w)
  */
  /*! fn
   inline float lantb(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const float* ab,
        const long int* ldab)
  */
  /*! fn
   inline double lantb(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const double* ab,
        const long int* ldab,
        workspace<double> & w)
  */
  /*! fn
   inline double lantb(
        const char* norm,
        const char* uplo,
        const char* diag,
        const long int* n,
        const long int* k,
        const double* ab,
        const long int* ldab)
  */

    // The following macro provides the 4 functions 
  /*! fn
   inline float lantb(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<float>* ab,
       const long int* ldab,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline float lantb(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<float>* ab,
       const long int* ldab)
  */
  /*! fn
   inline double lantb(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<double>* ab,
       const long int* ldab,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline double lantb(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<double>* ab,
       const long int* ldab)
  */



  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slantb.f)
  //    *  WORK    (workspace) DATA array, dimension (LWORK),
  //    *          where LWORK >= N when NORM = 'I'; otherwise, WORK is not
  //    *          referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LANTB(NAME, T, TBASE)\
inline TBASE lantb(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const long int* k,\
    const T* ab,\
    const long int* ldab,\
    workspace<T> & w)\
{\
  w.resizerw((lower(*norm) == 'i')?*n:0);                                \
  return F77NAME( NAME )(norm, uplo, n, k, ab, ldab, w.getrw());        \
}\
inline TBASE lantb(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const long int* k,\
    const T* ab,\
    const long int* ldab)                       \
{\
   workspace<T> w;\
   return lantb(norm, uplo, n, k, ab, ldab, w);\
}\

    LPP_LANTB(slansb, float             , float)
    LPP_LANTB(dlansb, double            , double)
    LPP_LANTB(clansb, std::complex < float > , float)
    LPP_LANTB(zlansb, std::complex < double >, double)

#undef LPP_LANTB

}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lantb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
