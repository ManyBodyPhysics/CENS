#ifndef __PROJECT__LPP__FILE__GEQR2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEQR2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geqr2_itf.hh C++ interface to LAPACK (c,d,c,z)geqr2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geqr2_itf.hh
    (excerpt adapted from xgeqr2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgeqr2 computes a qr factorization of a DATA TYPE m by n matrix a:
    **  a = q * r.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m by n matrix a.
    **          on exit, the elements on and above the diagonal of the array
    **          contain the min(m,n) by n upper trapezoidal matrix r (r is
    **          upper triangular if m >= n); the elements below the diagonal,
    **          with the array tau, represent the unitary matrix q as a
    **          product of elementary reflectors (see further details).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  tau     (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors (see further
    **          details).
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of elementary reflectors
    **
    **     q = h(1) h(2) . . . h(k), where k = min(m,n).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in a(i+1:m,i),
    **  and tau in tau(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geqr2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geqr2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void geqr2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geqr2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeqr2.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQR2(NAME, T)\
inline void geqr2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(*n);\
    F77NAME( NAME )(m, n, a, lda, tau, w.getw(), info);\
}\
inline void geqr2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geqr2(m, n, a, lda, tau, info, w);\
}\

    LPP_GEQR2(sgeqr2, float)
    LPP_GEQR2(dgeqr2, double)

#undef LPP_GEQR2


  // The following macro provides the 4 functions 
  /*! fn
   inline void geqr2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geqr2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void geqr2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geqr2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeqr2.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQR2(NAME, T, TBASE)\
inline void geqr2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(*n);\
    F77NAME( NAME )(m, n, a, lda, tau, w.getw(), info);\
}\
inline void geqr2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geqr2(m, n, a, lda, tau, info, w);\
}\

    LPP_GEQR2(cgeqr2, std::complex<float>,  float)
    LPP_GEQR2(zgeqr2, std::complex<double>, double)

#undef LPP_GEQR2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geqr2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
