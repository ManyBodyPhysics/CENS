#ifndef __PROJECT__LPP__FILE__PTSV_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTSV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ptsv_itf.hh C++ interface to LAPACK (c,d,c,z)ptsv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ptsv_itf.hh
    (excerpt adapted from xptsv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xptsv computes the solution to a DATA TYPE system of linear equations
    **  a*x = b, where a is an n-by-n hermitian positive definite tridiagonal
    **  matrix, and x and b are n-by-nrhs matrices.
    **
    **  a is factored as a = l*d*l**h, and the factored form of a is then
    **  used to solve the system of equations.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal matrix
    **          a.  on exit, the n diagonal elements of the diagonal matrix
    **          d from the factorization a = l*d*l**h.
    **
    **  e       (input/output) DATA TYPE array, dimension (n-1)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix a.  on exit, the (n-1) subdiagonal elements of the
    **          unit bidiagonal factor l from the l*d*l**h factorization of
    **          a.  e can also be regarded as the superdiagonal of the unit
    **          bidiagonal factor u from the u**h*d*u factorization of a.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if info = 0, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, the leading minor of order i is not
    **                positive definite, and the solution has not been
    **                computed.  the factorization has not been completed
    **                unless i = n.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ptsv(
        const long int* n,
        const long int* nrhs,
        float* d,
        float* e,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ptsv(
        const long int* n,
        const long int* nrhs,
        float* d,
        float* e,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void ptsv(
        const long int* n,
        const long int* nrhs,
        double* d,
        double* e,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ptsv(
        const long int* n,
        const long int* nrhs,
        double* d,
        double* e,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sptsv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTSV(NAME, T)\
inline void ptsv(\
    const long int* n,\
    const long int* nrhs,\
    T* d,\
    T* e,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, nrhs, d, e, b, ldb, info);\
}\
inline void ptsv(\
    const long int* n,\
    const long int* nrhs,\
    T* d,\
    T* e,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   ptsv(n, nrhs, d, e, b, ldb, info, w);\
}\

    LPP_PTSV(sptsv, float)
    LPP_PTSV(dptsv, double)

#undef LPP_PTSV


  // The following macro provides the 4 functions 
  /*! fn
   inline void ptsv(
       const long int* n,
       const long int* nrhs,
       float* d,
       std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ptsv(
       const long int* n,
       const long int* nrhs,
       float* d,
       std::complex<float>* e,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void ptsv(
       const long int* n,
       const long int* nrhs,
       double* d,
       std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ptsv(
       const long int* n,
       const long int* nrhs,
       double* d,
       std::complex<double>* e,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cptsv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTSV(NAME, T, TBASE)\
inline void ptsv(\
    const long int* n,\
    const long int* nrhs,\
    TBASE* d,\
    T* e,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, nrhs, d, e, b, ldb, info);\
}\
inline void ptsv(\
    const long int* n,\
    const long int* nrhs,\
    TBASE* d,\
    T* e,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   ptsv(n, nrhs, d, e, b, ldb, info, w);\
}\

    LPP_PTSV(cptsv, std::complex<float>,  float)
    LPP_PTSV(zptsv, std::complex<double>, double)

#undef LPP_PTSV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ptsv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
