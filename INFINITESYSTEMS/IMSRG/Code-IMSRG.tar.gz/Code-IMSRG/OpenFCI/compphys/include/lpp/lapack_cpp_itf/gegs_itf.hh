#ifndef __PROJECT__LPP__FILE__GEGS_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEGS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gegs_itf.hh C++ interface to LAPACK (c,d,c,z)gegs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gegs_itf.hh
    (excerpt adapted from xgegs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this routine is deprecated and has been replaced by routine cgges.
    **
    **  xgegs computes the eigenvalues, schur form, and, optionally, the
    **  left and or/right schur vectors of a DATA TYPE matrix pair (a,b).
    **  given two square matrices a and b, the generalized schur
    **  factorization has the form
    **  
    **     a = q*s*z**h,  b = q*t*z**h
    **  
    **  where q and z are unitary matrices and s and t are upper triangular.
    **  the columns of q are the left schur vectors
    **  and the columns of z are the right schur vectors.
    **  
    **  if only the eigenvalues of (a,b) are needed, the driver routine
    **  cgegv should be used instead.  see cgegv for a description of the
    **  eigenvalues of the generalized nonsymmetric eigenvalue problem
    **  (gnep).
    **
    **  arguments
    **  =========
    **
    **  jobvsl   (input) char
    **          = 'n':  do not compute the left schur vectors;
    **          = 'v':  compute the left schur vectors (returned in vsl).
    **
    **  jobvsr   (input) char
    **          = 'n':  do not compute the right schur vectors;
    **          = 'v':  compute the right schur vectors (returned in vsr).
    **
    **  n       (input) long int
    **          the order of the matrices a, b, vsl, and vsr.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the matrix a.
    **          on exit, the upper triangular matrix s from the generalized
    **          schur factorization.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the matrix b.
    **          on exit, the upper triangular matrix t from the generalized
    **          schur factorization.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  ldb >= max(1,n).
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **          the DATA TYPE scalars alpha that define the eigenvalues of
    **          gnep.  alpha(j) = s(j,j), the diagonal element of the schur
    **          form of a.
    **
    **  beta    (output) DATA TYPE array, dimension (n)
    **          the non-negative BASE DATA TYPE scalars beta that define the
    **          eigenvalues of gnep.  beta(j) = t(j,j), the diagonal element
    **          of the triangular factor t.
    **
    **          together, the quantities alpha = alpha(j) and beta = beta(j)
    **          represent the j-th eigenvalue of the matrix pair (a,b), in
    **          one of the forms lambda = alpha/beta or mu = beta/alpha.
    **          since either lambda or mu may overflow, they should not,
    **          in general, be computed.
    **
    **  vsl     (output) DATA TYPE array, dimension (ldvsl,n)
    **          if jobvsl = 'v', the matrix of left schur vectors q.
    **          not referenced if jobvsl = 'n'.
    **
    **  ldvsl   (input) long int
    **          the leading dimension of the matrix vsl. ldvsl >= 1, and
    **          if jobvsl = 'v', ldvsl >= n.
    **
    **  vsr     (output) DATA TYPE array, dimension (ldvsr,n)
    **          if jobvsr = 'v', the matrix of right schur vectors z.
    **          not referenced if jobvsr = 'n'.
    **
    **  ldvsr   (input) long int
    **          the leading dimension of the matrix vsr. ldvsr >= 1, and
    **          if jobvsr = 'v', ldvsr >= n.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          =1,...,n:
    **                the qz iteration failed.  (a,b) are not in schur
    **                form, but alpha(j) and beta(j) should be correct for
    **                j=info+1,...,n.
    **          > n:  errors that usually indicate lapack problems:
    **                =n+1: error return from cggbal
    **                =n+2: error return from cgeqrf
    **                =n+3: error return from cunmqr
    **                =n+4: error return from cungqr
    **                =n+5: error return from cgghrd
    **                =n+6: error return from chgeqz (other than failed
    **                                               iteration)
    **                =n+7: error return from cggbak (computing vsl)
    **                =n+8: error return from cggbak (computing vsr)
    **                =n+9: error return from clascl (various places)
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gegs(
        const char* jobvsl,
        const char* jobvsr,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gegs(
        const char* jobvsl,
        const char* jobvsr,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        long int* info)
  */
  /*! fn
   inline void gegs(
        const char* jobvsl,
        const char* jobvsr,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gegs(
        const char* jobvsl,
        const char* jobvsr,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgegs.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,4*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *          To compute the optimal value of LWORK, call ILAENV to get
  //    *          blocksizes (for SGEQRF, SORMQR, and SORGQR.)  Then compute:
  //    *          NB  -- MAX of the blocksizes for SGEQRF, SORMQR, and SORGQR
  //    *          The optimal LWORK is  2*N + N*(NB+1).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEGS(NAME, T)\
inline void gegs(\
    const char* jobvsl,\
    const char* jobvsr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobvsl, jobvsr, n, a, lda, b, ldb, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvsl, jobvsr, n, a, lda, b, ldb, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), &w.neededsize(), info);\
}\
inline void gegs(\
    const char* jobvsl,\
    const char* jobvsr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info)\
{\
   workspace<T> w;\
   gegs(jobvsl, jobvsr, n, a, lda, b, ldb, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, info, w);\
}\

    LPP_GEGS(sgegs, float)
    LPP_GEGS(dgegs, double)

#undef LPP_GEGS


  // The following macro provides the 4 functions 
  /*! fn
   inline void gegs(
       const char* jobvsl,
       const char* jobvsr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gegs(
       const char* jobvsl,
       const char* jobvsr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       long int* info)
  */
  /*! fn
   inline void gegs(
       const char* jobvsl,
       const char* jobvsr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gegs(
       const char* jobvsl,
       const char* jobvsr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgegs.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,2*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *          To compute the optimal value of LWORK, call ILAENV to get
  //    *          blocksizes (for CGEQRF, CUNMQR, and CUNGQR.)  Then compute:
  //    *          NB  -- MAX of the blocksizes for CGEQRF, CUNMQR, and CUNGQR;
  //    *          the optimal LWORK is N*(NB+1).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace) float array, dimension (3*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEGS(NAME, T, TBASE)\
inline void gegs(\
    const char* jobvsl,\
    const char* jobvsr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(3**n);\
    F77NAME( NAME )(jobvsl, jobvsr, n, a, lda, b, ldb, alpha, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvsl, jobvsr, n, a, lda, b, ldb, alpha, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void gegs(\
    const char* jobvsl,\
    const char* jobvsr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info)\
{\
   workspace<T> w;\
   gegs(jobvsl, jobvsr, n, a, lda, b, ldb, alpha, beta, vsl, ldvsl, vsr, ldvsr, info, w);\
}\

    LPP_GEGS(cgegs, std::complex<float>,  float)
    LPP_GEGS(zgegs, std::complex<double>, double)

#undef LPP_GEGS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gegs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
