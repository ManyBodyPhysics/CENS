#ifndef __PROJECT__LPP__FILE__GEHRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEHRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gehrd_itf.hh C++ interface to LAPACK (c,d,c,z)gehrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gehrd_itf.hh
    (excerpt adapted from xgehrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgehrd reduces a DATA TYPE general matrix a to upper hessenberg form h
    **  by a unitary similarity transformation:  q' * a * q = h .
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          it is assumed that a is already upper triangular in rows
    **          and columns 1:ilo-1 and ihi+1:n. ilo and ihi are normally
    **          set by a previous call to cgebal; otherwise they should be
    **          set to 1 and n respectively. see further details.
    **          1 <= ilo <= ihi <= n, if n > 0; ilo=1 and ihi=0, if n=0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the n-by-n general matrix to be reduced.
    **          on exit, the upper triangle and the first subdiagonal of a
    **          are overwritten with the upper hessenberg matrix h, and the
    **          elements below the first subdiagonal, with the array tau,
    **          represent the unitary matrix q as a product of elementary
    **          reflectors. see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  tau     (output) DATA TYPE array, dimension (n-1)
    **          the scalar factors of the elementary reflectors (see further
    **          details). elements 1:ilo-1 and ihi:n-1 of tau are set to
    **          zero.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of (ihi-ilo) elementary
    **  reflectors
    **
    **     q = h(ilo) h(ilo+1) . . . h(ihi-1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i) = 0, v(i+1) = 1 and v(ihi+1:n) = 0; v(i+2:ihi) is stored on
    **  exit in a(i+2:ihi,i), and tau in tau(i).
    **
    **  the contents of a are illustrated by the following example, with
    **  n = 7, ilo = 2 and ihi = 6:
    **
    **  on entry,                        on exit,
    **
    **  ( a   a   a   a   a   a   a )    (  a   a   h   h   h   h   a )
    **  (     a   a   a   a   a   a )    (      a   h   h   h   h   a )
    **  (     a   a   a   a   a   a )    (      h   h   h   h   h   h )
    **  (     a   a   a   a   a   a )    (      v2  h   h   h   h   h )
    **  (     a   a   a   a   a   a )    (      v2  v3  h   h   h   h )
    **  (     a   a   a   a   a   a )    (      v2  v3  v4  h   h   h )
    **  (                         a )    (                          a )
    **
    **  where a denotes an element of the original matrix a, h denotes a
    **  modified element of the upper hessenberg matrix h, and vi denotes an
    **  element of the vector defining h(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gehrd(
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        float* a,
        const long int* lda,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gehrd(
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        float* a,
        const long int* lda,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void gehrd(
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        double* a,
        const long int* lda,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gehrd(
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        double* a,
        const long int* lda,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgehrd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of the array WORK.  LWORK >= max(1,N).
  //    *          For optimum performance LWORK >= N*NB, where NB is the
  //    *          optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEHRD(NAME, T)\
inline void gehrd(\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, ilo, ihi, a, lda, tau, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, ilo, ihi, a, lda, tau, w.getw(), &w.neededsize(), info);\
}\
inline void gehrd(\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   gehrd(n, ilo, ihi, a, lda, tau, info, w);\
}\

    LPP_GEHRD(sgehrd, float)
    LPP_GEHRD(dgehrd, double)

#undef LPP_GEHRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gehrd(
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gehrd(
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void gehrd(
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gehrd(
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgehrd.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of the array WORK.  LWORK >= max(1,N).
  //    *          For optimum performance LWORK >= N*NB, where NB is the
  //    *          optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEHRD(NAME, T, TBASE)\
inline void gehrd(\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, ilo, ihi, a, lda, tau, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, ilo, ihi, a, lda, tau, w.getw(), &w.neededsize(), info);\
}\
inline void gehrd(\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   gehrd(n, ilo, ihi, a, lda, tau, info, w);\
}\

    LPP_GEHRD(cgehrd, std::complex<float>,  float)
    LPP_GEHRD(zgehrd, std::complex<double>, double)

#undef LPP_GEHRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gehrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
