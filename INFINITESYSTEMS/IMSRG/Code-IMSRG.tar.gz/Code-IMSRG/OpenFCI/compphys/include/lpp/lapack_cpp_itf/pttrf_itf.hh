#ifndef __PROJECT__LPP__FILE__PTTRF_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTTRF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pttrf_itf.hh C++ interface to LAPACK (c,d,c,z)pttrf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pttrf_itf.hh
    (excerpt adapted from xpttrf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpttrf computes the l*d*l' factorization of a DATA TYPE hermitian
    **  positive definite tridiagonal matrix a.  the factorization may also
    **  be regarded as having the form a = u'*d*u.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal matrix
    **          a.  on exit, the n diagonal elements of the diagonal matrix
    **          d from the l*d*l' factorization of a.
    **
    **  e       (input/output) DATA TYPE array, dimension (n-1)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix a.  on exit, the (n-1) subdiagonal elements of the
    **          unit bidiagonal factor l from the l*d*l' factorization of a.
    **          e can also be regarded as the superdiagonal of the unit
    **          bidiagonal factor u from the u'*d*u factorization of a.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **          > 0: if info = k, the leading minor of order k is not
    **               positive definite; if k < n, the factorization could not
    **               be completed, while if k = n, the factorization was
    **               completed, but d(n) = 0.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pttrf(
        const long int* n,
        float* d,
        float* e,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pttrf(
        const long int* n,
        float* d,
        float* e,
        long int* info)
  */
  /*! fn
   inline void pttrf(
        const long int* n,
        double* d,
        double* e,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pttrf(
        const long int* n,
        double* d,
        double* e,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spttrf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTRF(NAME, T)\
inline void pttrf(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, d, e, info);\
}\
inline void pttrf(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info)\
{\
   workspace<T> w;\
   pttrf(n, d, e, info, w);\
}\

    LPP_PTTRF(spttrf, float)
    LPP_PTTRF(dpttrf, double)

#undef LPP_PTTRF


  // The following macro provides the 4 functions 
  /*! fn
   inline void pttrf(
       const long int* n,
       float* d,
       std::complex<float>* e,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pttrf(
       const long int* n,
       float* d,
       std::complex<float>* e,
       long int* info)
  */
  /*! fn
   inline void pttrf(
       const long int* n,
       double* d,
       std::complex<double>* e,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pttrf(
       const long int* n,
       double* d,
       std::complex<double>* e,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpttrf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTTRF(NAME, T, TBASE)\
inline void pttrf(\
    const long int* n,\
    TBASE* d,\
    T* e,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, d, e, info);\
}\
inline void pttrf(\
    const long int* n,\
    TBASE* d,\
    T* e,\
    long int* info)\
{\
   workspace<T> w;\
   pttrf(n, d, e, info, w);\
}\

    LPP_PTTRF(cpttrf, std::complex<float>,  float)
    LPP_PTTRF(zpttrf, std::complex<double>, double)

#undef LPP_PTTRF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pttrf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
