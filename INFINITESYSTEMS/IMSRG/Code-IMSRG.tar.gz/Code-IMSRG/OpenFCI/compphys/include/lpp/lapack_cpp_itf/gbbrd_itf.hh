#ifndef __PROJECT__LPP__FILE__GBBRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GBBRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gbbrd_itf.hh C++ interface to LAPACK (c,d,c,z)gbbrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gbbrd_itf.hh
    (excerpt adapted from xgbbrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgbbrd reduces a DATA TYPE general m-by-n band matrix a to BASE DATA TYPE upper
    **  bidiagonal form b by a unitary transformation: q' * a * p = b.
    **
    **  the routine computes b, and optionally forms q or p', or computes
    **  q'*c for a given matrix c.
    **
    **  arguments
    **  =========
    **
    **  vect    (input) char
    **          specifies whether or not the matrices q and p' are to be
    **          formed.
    **          = 'n': do not form q or p';
    **          = 'q': form q only;
    **          = 'p': form p' only;
    **          = 'b': form both.
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  ncc     (input) long int
    **          the number of columns of the matrix c.  ncc >= 0.
    **
    **  kl      (input) long int
    **          the number of subdiagonals of the matrix a. kl >= 0.
    **
    **  ku      (input) long int
    **          the number of superdiagonals of the matrix a. ku >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the m-by-n band matrix a, stored in rows 1 to
    **          kl+ku+1. the j-th column of a is stored in the j-th column of
    **          the array ab as follows:
    **          ab(ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(m,j+kl).
    **          on exit, a is overwritten by values generated during the
    **          reduction.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array a. ldab >= kl+ku+1.
    **
    **  d       (output) BASE DATA TYPE array, dimension (min(m,n))
    **          the diagonal elements of the bidiagonal matrix b.
    **
    **  e       (output) BASE DATA TYPE array, dimension (min(m,n)-1)
    **          the superdiagonal elements of the bidiagonal matrix b.
    **
    **  q       (output) DATA TYPE array, dimension (ldq,m)
    **          if vect = 'q' or 'b', the m-by-m unitary matrix q.
    **          if vect = 'n' or 'p', the array q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.
    **          ldq >= max(1,m) if vect = 'q' or 'b'; ldq >= 1 otherwise.
    **
    **  pt      (output) DATA TYPE array, dimension (ldpt,n)
    **          if vect = 'p' or 'b', the n-by-n unitary matrix p'.
    **          if vect = 'n' or 'q', the array pt is not referenced.
    **
    **  ldpt    (input) long int
    **          the leading dimension of the array pt.
    **          ldpt >= max(1,n) if vect = 'p' or 'b'; ldpt >= 1 otherwise.
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,ncc)
    **          on entry, an m-by-ncc matrix c.
    **          on exit, c is overwritten by q'*c.
    **          c is not referenced if ncc = 0.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c.
    **          ldc >= max(1,m) if ncc > 0; ldc >= 1 if ncc = 0.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gbbrd(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* ncc,
        const long int* kl,
        const long int* ku,
        float* ab,
        const long int* ldab,
        const float* d,
        const float* e,
        float* q,
        const long int* ldq,
        float* pt,
        const long int* ldpt,
        const float* c,
        const long int* ldc,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gbbrd(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* ncc,
        const long int* kl,
        const long int* ku,
        float* ab,
        const long int* ldab,
        const float* d,
        const float* e,
        float* q,
        const long int* ldq,
        float* pt,
        const long int* ldpt,
        const float* c,
        const long int* ldc,
        long int* info)
  */
  /*! fn
   inline void gbbrd(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* ncc,
        const long int* kl,
        const long int* ku,
        double* ab,
        const long int* ldab,
        const double* d,
        const double* e,
        double* q,
        const long int* ldq,
        double* pt,
        const long int* ldpt,
        const double* c,
        const long int* ldc,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gbbrd(
        const char* vect,
        const long int* m,
        const long int* n,
        const long int* ncc,
        const long int* kl,
        const long int* ku,
        double* ab,
        const long int* ldab,
        const double* d,
        const double* e,
        double* q,
        const long int* ldq,
        double* pt,
        const long int* ldpt,
        const double* c,
        const long int* ldc,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgbbrd.f)
  //    *  WORK    (workspace) float array, dimension (2*max(M,N))
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBBRD(NAME, T)\
inline void gbbrd(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* ncc,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    const T* d,\
    const T* e,\
    T* q,\
    const long int* ldq,\
    T* pt,\
    const long int* ldpt,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(2*std::max(*m, *n)); \
    F77NAME( NAME )(vect, m, n, ncc, kl, ku, ab, ldab, d, e, q, ldq, pt, ldpt, c, ldc, w.getw(), info);\
}\
inline void gbbrd(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* ncc,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    const T* d,\
    const T* e,\
    T* q,\
    const long int* ldq,\
    T* pt,\
    const long int* ldpt,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   gbbrd(vect, m, n, ncc, kl, ku, ab, ldab, d, e, q, ldq, pt, ldpt, c, ldc, info, w);\
}\

    LPP_GBBRD(sgbbrd, float)
    LPP_GBBRD(dgbbrd, double)

#undef LPP_GBBRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gbbrd(
       const char* vect,
       const long int* m,
       const long int* n,
       const long int* ncc,
       const long int* kl,
       const long int* ku,
       std::complex<float>* ab,
       const long int* ldab,
       const float* d,
       const float* e,
       std::complex<float>* q,
       const long int* ldq,
       std::complex<float>* pt,
       const long int* ldpt,
       const std::complex<float>* c,
       const long int* ldc,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gbbrd(
       const char* vect,
       const long int* m,
       const long int* n,
       const long int* ncc,
       const long int* kl,
       const long int* ku,
       std::complex<float>* ab,
       const long int* ldab,
       const float* d,
       const float* e,
       std::complex<float>* q,
       const long int* ldq,
       std::complex<float>* pt,
       const long int* ldpt,
       const std::complex<float>* c,
       const long int* ldc,
       long int* info)
  */
  /*! fn
   inline void gbbrd(
       const char* vect,
       const long int* m,
       const long int* n,
       const long int* ncc,
       const long int* kl,
       const long int* ku,
       std::complex<double>* ab,
       const long int* ldab,
       const double* d,
       const double* e,
       std::complex<double>* q,
       const long int* ldq,
       std::complex<double>* pt,
       const long int* ldpt,
       const std::complex<double>* c,
       const long int* ldc,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gbbrd(
       const char* vect,
       const long int* m,
       const long int* n,
       const long int* ncc,
       const long int* kl,
       const long int* ku,
       std::complex<double>* ab,
       const long int* ldab,
       const double* d,
       const double* e,
       std::complex<double>* q,
       const long int* ldq,
       std::complex<double>* pt,
       const long int* ldpt,
       const std::complex<double>* c,
       const long int* ldc,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgbbrd.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (max(M,N))
  //    *
  //    *  RWORK   (workspace) float array, dimension (max(M,N))
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBBRD(NAME, T, TBASE)\
inline void gbbrd(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* ncc,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    const TBASE* d,\
    const TBASE* e,\
    T* q,\
    const long int* ldq,\
    T* pt,\
    const long int* ldpt,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(std::max(*m, *n));                                          \
    w.resizew(std::max(*m, *n));                                          \
    F77NAME( NAME )(vect, m, n, ncc, kl, ku, ab, ldab, d, e, q, ldq, pt, ldpt, c, ldc, w.getw(), w.getrw(), info);\
}\
inline void gbbrd(\
    const char* vect,\
    const long int* m,\
    const long int* n,\
    const long int* ncc,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    const TBASE* d,\
    const TBASE* e,\
    T* q,\
    const long int* ldq,\
    T* pt,\
    const long int* ldpt,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   gbbrd(vect, m, n, ncc, kl, ku, ab, ldab, d, e, q, ldq, pt, ldpt, c, ldc, info, w);\
}\

      LPP_GBBRD(cgbbrd, std::complex<float>, float)
        LPP_GBBRD(zgbbrd, std::complex<double>, double)

#undef LPP_GBBRD



}
#endif
 
// /////////////////////////////////////////////////////////////////////////////
// End of gbbrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
