#ifndef __PROJECT__LPP__FILE__LAHRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAHRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lahrd_itf.hh C++ interface to LAPACK (c,d,c,z)lahrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lahrd_itf.hh
    (excerpt adapted from xlahrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlahrd reduces the first nb columns of a DATA TYPE general n-by-(n-k+1)
    **  matrix a so that elements below the k-th subdiagonal are zero. the
    **  reduction is performed by a unitary similarity transformation
    **  q' * a * q. the routine returns the matrices v and t which determine
    **  q as a block reflector i - v*t*v', and also the matrix y = a * v * t.
    **
    **  this is an auxiliary routine called by cgehrd.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.
    **
    **  k       (input) long int
    **          the offset for the reduction. elements below the k-th
    **          subdiagonal in the first nb columns are reduced to zero.
    **
    **  nb      (input) long int
    **          the number of columns to be reduced.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n-k+1)
    **          on entry, the n-by-(n-k+1) general matrix a.
    **          on exit, the elements on and above the k-th subdiagonal in
    **          the first nb columns are overwritten with the corresponding
    **          elements of the reduced matrix; the elements below the k-th
    **          subdiagonal, with the array tau, represent the matrix q as a
    **          product of elementary reflectors. the other columns of a are
    **          unchanged. see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  tau     (output) DATA TYPE array, dimension (nb)
    **          the scalar factors of the elementary reflectors. see further
    **          details.
    **
    **  t       (output) DATA TYPE array, dimension (ldt,nb)
    **          the upper triangular matrix t.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t.  ldt >= nb.
    **
    **  y       (output) DATA TYPE array, dimension (ldy,nb)
    **          the n-by-nb matrix y.
    **
    **  ldy     (input) long int
    **          the leading dimension of the array y. ldy >= max(1,n).
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of nb elementary reflectors
    **
    **     q = h(1) h(2) . . . h(nb).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i+k-1) = 0, v(i+k) = 1; v(i+k+1:n) is stored on exit in
    **  a(i+k+1:n,i), and tau in tau(i).
    **
    **  the elements of the vectors v together form the (n-k+1)-by-nb matrix
    **  v which is needed, with t and y, to apply the transformation to the
    **  unreduced part of the matrix, using an update of the form:
    **  a := (i - v*t*v') * (a - y*v').
    **
    **  the contents of a on exit are illustrated by the following example
    **  with n = 7, k = 3 and nb = 2:
    **
    **     ( a   h   a   a   a )
    **     ( a   h   a   a   a )
    **     ( a   h   a   a   a )
    **     ( h   h   a   a   a )
    **     ( v1  h   a   a   a )
    **     ( v1  v2  a   a   a )
    **     ( v1  v2  a   a   a )
    **
    **  where a denotes an element of the original matrix a, h denotes a
    **  modified element of the upper hessenberg matrix h, and vi denotes an
    **  element of the vector defining h(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lahrd(
        const long int* n,
        const long int* k,
        const long int* nb,
        float* a,
        const long int* lda,
        float* tau,
        float* t,
        const long int* ldt,
        float* y,
        const long int* ldy,
        workspace<float> & w)
  */
  /*! fn
   inline void lahrd(
        const long int* n,
        const long int* k,
        const long int* nb,
        float* a,
        const long int* lda,
        float* tau,
        float* t,
        const long int* ldt,
        float* y,
        const long int* ldy)
  */
  /*! fn
   inline void lahrd(
        const long int* n,
        const long int* k,
        const long int* nb,
        double* a,
        const long int* lda,
        double* tau,
        double* t,
        const long int* ldt,
        double* y,
        const long int* ldy,
        workspace<double> & w)
  */
  /*! fn
   inline void lahrd(
        const long int* n,
        const long int* k,
        const long int* nb,
        double* a,
        const long int* lda,
        double* tau,
        double* t,
        const long int* ldt,
        double* y,
        const long int* ldy)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slahrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAHRD(NAME, T)\
inline void lahrd(\
    const long int* n,\
    const long int* k,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* tau,\
    T* t,\
    const long int* ldt,\
    T* y,\
    const long int* ldy,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, k, nb, a, lda, tau, t, ldt, y, ldy);\
}\
inline void lahrd(\
    const long int* n,\
    const long int* k,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* tau,\
    T* t,\
    const long int* ldt,\
    T* y,\
    const long int* ldy)\
{\
   workspace<T> w;\
   lahrd(n, k, nb, a, lda, tau, t, ldt, y, ldy, w);\
}\

    LPP_LAHRD(slahrd, float)
    LPP_LAHRD(dlahrd, double)

#undef LPP_LAHRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void lahrd(
       const long int* n,
       const long int* k,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       std::complex<float>* t,
       const long int* ldt,
       std::complex<float>* y,
       const long int* ldy,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lahrd(
       const long int* n,
       const long int* k,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       std::complex<float>* t,
       const long int* ldt,
       std::complex<float>* y,
       const long int* ldy)
  */
  /*! fn
   inline void lahrd(
       const long int* n,
       const long int* k,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       std::complex<double>* t,
       const long int* ldt,
       std::complex<double>* y,
       const long int* ldy,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lahrd(
       const long int* n,
       const long int* k,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       std::complex<double>* t,
       const long int* ldt,
       std::complex<double>* y,
       const long int* ldy)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clahrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAHRD(NAME, T, TBASE)\
inline void lahrd(\
    const long int* n,\
    const long int* k,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* tau,\
    T* t,\
    const long int* ldt,\
    T* y,\
    const long int* ldy,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, k, nb, a, lda, tau, t, ldt, y, ldy);\
}\
inline void lahrd(\
    const long int* n,\
    const long int* k,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* tau,\
    T* t,\
    const long int* ldt,\
    T* y,\
    const long int* ldy)\
{\
   workspace<T> w;\
   lahrd(n, k, nb, a, lda, tau, t, ldt, y, ldy, w);\
}\

    LPP_LAHRD(clahrd, std::complex<float>,  float)
    LPP_LAHRD(zlahrd, std::complex<double>, double)

#undef LPP_LAHRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lahrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
