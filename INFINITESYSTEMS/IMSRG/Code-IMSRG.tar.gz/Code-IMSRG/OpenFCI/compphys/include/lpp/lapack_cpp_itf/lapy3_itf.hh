#ifndef __PROJECT__LPP__FILE__LAPY3_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAPY3_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lapy3_itf.hh C++ interface to LAPACK (s,d,c,z)lapy3
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lapy3_itf.hh
    (excerpt adapted from xlapy3.f file commentaries)
    
    DATA TYPE can mean float, double, complex<float>, complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlapy3 returns sqrt(x**2+y**2+z**2), taking care not to cause
    **  unnecessary overflow.
    **
    **  arguments
    **  =========
    **
    **  x       (input) BASE DATA TYPE
    **  y       (input) BASE DATA TYPE
    **  z       (input) BASE DATA TYPE
    **          x, y and z specify the values x, y and z.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lapy3(
        const float* x,
        const float* y,
        const float* z,
        workspace<float> & w)
  */
  /*! fn
   inline void lapy3(
        const float* x,
        const float* y,
        const float* z)
  */
  /*! fn
   inline void lapy3(
        const double* x,
        const double* y,
        const double* z,
        workspace<double> & w)
  */
  /*! fn
   inline void lapy3(
        const double* x,
        const double* y,
        const double* z)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slapy3.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPY3(NAME, T)\
inline T lapy3(\
    const T* x,\
    const T* y,\
    const T* z)\
{\
   return F77NAME( NAME )(x, y, z);\
}\


    LPP_LAPY3(slapy3, float)
    LPP_LAPY3(dlapy3, double)

#undef LPP_LAPY3



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lapy3_itf.hh
// /////////////////////////////////////////////////////////////////////////////
