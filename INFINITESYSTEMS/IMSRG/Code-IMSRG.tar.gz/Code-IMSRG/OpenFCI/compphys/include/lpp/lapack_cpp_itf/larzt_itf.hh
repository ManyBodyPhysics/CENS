#ifndef __PROJECT__LPP__FILE__LARZT_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARZT_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larzt_itf.hh C++ interface to LAPACK (c,d,c,z)larzt
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larzt_itf.hh
    (excerpt adapted from xlarzt.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarzt forms the triangular factor t of a DATA TYPE block reflector
    **  h of order > n, which is defined as a product of k elementary
    **  reflectors.
    **
    **  if direct = 'f', h = h(1) h(2) . . . h(k) and t is upper triangular;
    **
    **  if direct = 'b', h = h(k) . . . h(2) h(1) and t is lower triangular.
    **
    **  if storev = 'c', the vector which defines the elementary reflector
    **  h(i) is stored in the i-th column of the array v, and
    **
    **     h  =  i - v * t * v'
    **
    **  if storev = 'r', the vector which defines the elementary reflector
    **  h(i) is stored in the i-th row of the array v, and
    **
    **     h  =  i - v' * t * v
    **
    **  currently, only storev = 'r' and direct = 'b' are supported.
    **
    **  arguments
    **  =========
    **
    **  direct  (input) char
    **          specifies the order in which the elementary reflectors are
    **          multiplied to form the block reflector:
    **          = 'f': h = h(1) h(2) . . . h(k) (forward, not supported yet)
    **          = 'b': h = h(k) . . . h(2) h(1) (backward)
    **
    **  storev  (input) char
    **          specifies how the vectors which define the elementary
    **          reflectors are stored (see also further details):
    **          = 'c': columnwise                        (not supported yet)
    **          = 'r': rowwise
    **
    **  n       (input) long int
    **          the order of the block reflector h. n >= 0.
    **
    **  k       (input) long int
    **          the order of the triangular factor t (= the number of
    **          elementary reflectors). k >= 1.
    **
    **  v       (input/output) DATA TYPE array, dimension
    **                               (ldv,k) if storev = 'c'
    **                               (ldv,n) if storev = 'r'
    **          the matrix v. see further details.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v.
    **          if storev = 'c', ldv >= max(1,n); if storev = 'r', ldv >= k.
    **
    **  tau     (input) DATA TYPE array, dimension (k)
    **          tau(i) must contain the scalar factor of the elementary
    **          reflector h(i).
    **
    **  t       (output) DATA TYPE array, dimension (ldt,k)
    **          the k by k triangular factor t of the block reflector.
    **          if direct = 'f', t is upper triangular; if direct = 'b', t is
    **          lower triangular. the rest of the array is not used.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= k.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    a. petitet, computer science dept., univ. of tenn., knoxville, usa
    **
    **  the shape of the matrix v and the storage of the vectors which define
    **  the h(i) is best illustrated by the following example with n = 5 and
    **  k = 3. the elements equal to 1 are not stored; the corresponding
    **  array elements are modified but restored on exit. the rest of the
    **  array is not used.
    **
    **  direct = 'f' and storev = 'c':         direct = 'f' and storev = 'r':
    **
    **                                              ______v_____
    **         ( v1 v2 v3 )                        /            \
    **         ( v1 v2 v3 )                      ( v1 v1 v1 v1 v1 . . . . 1 )
    **     v = ( v1 v2 v3 )                      ( v2 v2 v2 v2 v2 . . . 1   )
    **         ( v1 v2 v3 )                      ( v3 v3 v3 v3 v3 . . 1     )
    **         ( v1 v2 v3 )
    **            .  .  .
    **            .  .  .
    **            1  .  .
    **               1  .
    **                  1
    **
    **  direct = 'b' and storev = 'c':         direct = 'b' and storev = 'r':
    **
    **                                                        ______v_____
    **            1                                          /            \
    **            .  1                           ( 1 . . . . v1 v1 v1 v1 v1 )
    **            .  .  1                        ( . 1 . . . v2 v2 v2 v2 v2 )
    **            .  .  .                        ( . . 1 . . v3 v3 v3 v3 v3 )
    **            .  .  .
    **         ( v1 v2 v3 )
    **         ( v1 v2 v3 )
    **     v = ( v1 v2 v3 )
    **         ( v1 v2 v3 )
    **         ( v1 v2 v3 )
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larzt(
        const char* direct,
        const char* storev,
        const long int* n,
        const long int* k,
        const float* v,
        const long int* ldv,
        const float* tau,
        const float* t,
        const long int* ldt,
        workspace<float> & w)
  */
  /*! fn
   inline void larzt(
        const char* direct,
        const char* storev,
        const long int* n,
        const long int* k,
        const float* v,
        const long int* ldv,
        const float* tau,
        const float* t,
        const long int* ldt)
  */
  /*! fn
   inline void larzt(
        const char* direct,
        const char* storev,
        const long int* n,
        const long int* k,
        const double* v,
        const long int* ldv,
        const double* tau,
        const double* t,
        const long int* ldt,
        workspace<double> & w)
  */
  /*! fn
   inline void larzt(
        const char* direct,
        const char* storev,
        const long int* n,
        const long int* k,
        const double* v,
        const long int* ldv,
        const double* tau,
        const double* t,
        const long int* ldt)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarzt.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZT(NAME, T)\
inline void larzt(\
    const char* direct,\
    const char* storev,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* tau,\
    const T* t,\
    const long int* ldt,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(direct, storev, n, k, v, ldv, tau, t, ldt);\
}\
inline void larzt(\
    const char* direct,\
    const char* storev,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* tau,\
    const T* t,\
    const long int* ldt)\
{\
   workspace<T> w;\
   larzt(direct, storev, n, k, v, ldv, tau, t, ldt, w);\
}\

    LPP_LARZT(slarzt, float)
    LPP_LARZT(dlarzt, double)

#undef LPP_LARZT


  // The following macro provides the 4 functions 
  /*! fn
   inline void larzt(
       const char* direct,
       const char* storev,
       const long int* n,
       const long int* k,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* tau,
       const std::complex<float>* t,
       const long int* ldt,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larzt(
       const char* direct,
       const char* storev,
       const long int* n,
       const long int* k,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* tau,
       const std::complex<float>* t,
       const long int* ldt)
  */
  /*! fn
   inline void larzt(
       const char* direct,
       const char* storev,
       const long int* n,
       const long int* k,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* tau,
       const std::complex<double>* t,
       const long int* ldt,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larzt(
       const char* direct,
       const char* storev,
       const long int* n,
       const long int* k,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* tau,
       const std::complex<double>* t,
       const long int* ldt)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarzt.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZT(NAME, T, TBASE)\
inline void larzt(\
    const char* direct,\
    const char* storev,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* tau,\
    const T* t,\
    const long int* ldt,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(direct, storev, n, k, v, ldv, tau, t, ldt);\
}\
inline void larzt(\
    const char* direct,\
    const char* storev,\
    const long int* n,\
    const long int* k,\
    const T* v,\
    const long int* ldv,\
    const T* tau,\
    const T* t,\
    const long int* ldt)\
{\
   workspace<T> w;\
   larzt(direct, storev, n, k, v, ldv, tau, t, ldt, w);\
}\

    LPP_LARZT(clarzt, std::complex<float>,  float)
    LPP_LARZT(zlarzt, std::complex<double>, double)

#undef LPP_LARZT



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larzt_itf.hh
// /////////////////////////////////////////////////////////////////////////////
