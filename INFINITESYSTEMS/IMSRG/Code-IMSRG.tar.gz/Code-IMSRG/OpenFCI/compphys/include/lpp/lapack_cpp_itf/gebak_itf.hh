#ifndef __PROJECT__LPP__FILE__GEBAK_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEBAK_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gebak_itf.hh C++ interface to LAPACK (c,d,c,z)gebak
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gebak_itf.hh
    (excerpt adapted from xgebak.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgebak forms the right or left eigenvectors of a DATA TYPE general
    **  matrix by backward transformation on the computed eigenvectors of the
    **  balanced matrix output by cgebal.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies the type of backward transformation required:
    **          = 'n', do nothing, return immediately;
    **          = 'p', do backward transformation for permutation only;
    **          = 's', do backward transformation for scaling only;
    **          = 'b', do backward transformations for both permutation and
    **                 scaling.
    **          job must be the same as the argument job supplied to cgebal.
    **
    **  side    (input) char
    **          = 'r':  v contains right eigenvectors;
    **          = 'l':  v contains left eigenvectors.
    **
    **  n       (input) long int
    **          the number of rows of the matrix v.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          the integers ilo and ihi determined by cgebal.
    **          1 <= ilo <= ihi <= n, if n > 0; ilo=1 and ihi=0, if n=0.
    **
    **  scale   (input) BASE DATA TYPE array, dimension (n)
    **          details of the permutation and scaling factors, as returned
    **          by cgebal.
    **
    **  m       (input) long int
    **          the number of columns of the matrix v.  m >= 0.
    **
    **  v       (input/output) DATA TYPE array, dimension (ldv,m)
    **          on entry, the matrix of right or left eigenvectors to be
    **          transformed, as returned by chsein or ctrevc.
    **          on exit, v is overwritten by the transformed eigenvectors.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v. ldv >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gebak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* scale,
        const long int* m,
        float* v,
        const long int* ldv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gebak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* scale,
        const long int* m,
        float* v,
        const long int* ldv,
        long int* info)
  */
  /*! fn
   inline void gebak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* scale,
        const long int* m,
        double* v,
        const long int* ldv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gebak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* scale,
        const long int* m,
        double* v,
        const long int* ldv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgebak.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEBAK(NAME, T)\
inline void gebak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* scale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, side, n, ilo, ihi, scale, m, v, ldv, info);\
}\
inline void gebak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* scale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info)\
{\
   workspace<T> w;\
   gebak(job, side, n, ilo, ihi, scale, m, v, ldv, info, w);\
}\

    LPP_GEBAK(sgebak, float)
    LPP_GEBAK(dgebak, double)

#undef LPP_GEBAK


  // The following macro provides the 4 functions 
  /*! fn
   inline void gebak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const float* scale,
       const long int* m,
       std::complex<float>* v,
       const long int* ldv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gebak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const float* scale,
       const long int* m,
       std::complex<float>* v,
       const long int* ldv,
       long int* info)
  */
  /*! fn
   inline void gebak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const double* scale,
       const long int* m,
       std::complex<double>* v,
       const long int* ldv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gebak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const double* scale,
       const long int* m,
       std::complex<double>* v,
       const long int* ldv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgebak.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEBAK(NAME, T, TBASE)\
inline void gebak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const TBASE* scale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, side, n, ilo, ihi, scale, m, v, ldv, info);\
}\
inline void gebak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const TBASE* scale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info)\
{\
   workspace<T> w;\
   gebak(job, side, n, ilo, ihi, scale, m, v, ldv, info, w);\
}\

    LPP_GEBAK(cgebak, std::complex<float>, float)
    LPP_GEBAK(zgebak, std::complex<double>, double)

#undef LPP_GEBAK



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gebak_itf.hh
// /////////////////////////////////////////////////////////////////////////////
