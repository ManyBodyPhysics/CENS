#ifndef __PROJECT__LPP__FILE__STEIN_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEIN_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : stein_itf.hh C++ interface to LAPACK (s,d,c,z)stein
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file stein_itf.hh
    (excerpt adapted from xstein.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xstein computes the eigenvectors of a BASE DATA TYPE symmetric tridiagonal
    **  matrix t corresponding to specified eigenvalues, using inverse
    **  iteration.
    **
    **  the maximum number of iterations allowed for each eigenvector is
    **  specified by an internal parameter maxits (currently set to 5).
    **
    **  although the eigenvectors are BASE DATA TYPE, they are stored in a DATA TYPE
    **  array, which may be passed to cunmtr or cupmtr for back
    **  transformation to the eigenvectors of a DATA TYPE hermitian matrix
    **  which was reduced to tridiagonal form.
    **
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the tridiagonal matrix t.
    **
    **  e       (input) BASE DATA TYPE array, dimension (n)
    **          the (n-1) subdiagonal elements of the tridiagonal matrix
    **          t, stored in elements 1 to n-1; e(n) need not be set.
    **
    **  m       (input) long int
    **          the number of eigenvectors to be found.  0 <= m <= n.
    **
    **  w       (input) BASE DATA TYPE array, dimension (n)
    **          the first m elements of w contain the eigenvalues for
    **          which eigenvectors are to be computed.  the eigenvalues
    **          should be grouped by split-off block and ordered from
    **          smallest to largest within the block.  ( the output array
    **          w from sstebz with order = 'b' is expected here. )
    **
    **  iblock  (input) long int array, dimension (n)
    **          the submatrix indices associated with the corresponding
    **          eigenvalues in w; iblock(i)=1 if eigenvalue w(i) belongs to
    **          the first submatrix from the top, =2 if w(i) belongs to
    **          the second submatrix, etc.  ( the output array iblock
    **          from sstebz is expected here. )
    **
    **  isplit  (input) long int array, dimension (n)
    **          the splitting points, at which t breaks up into submatrices.
    **          the first submatrix consists of rows/columns 1 to
    **          isplit( 1 ), the second of rows/columns isplit( 1 )+1
    **          through isplit( 2 ), etc.
    **          ( the output array isplit from sstebz is expected here. )
    **
    **  z       (output) DATA TYPE array, dimension (ldz, m)
    **          the computed eigenvectors.  the eigenvector associated
    **          with the eigenvalue w(i) is stored in the i-th column of
    **          z.  any vector which fails to converge is set to its current
    **          iterate after maxits iterations.
    **          the imaginary parts of the eigenvectors are set to zero.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= max(1,n).
    **
    **
    **
    **  ifail   (output) long int array, dimension (m)
    **          on normal exit, all elements of ifail are zero.
    **          if one or more eigenvectors fail to converge after
    **          maxits iterations, then their indices are stored in
    **          array ifail.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, then i eigenvectors failed to converge
    **               in maxits iterations.  their indices are stored in
    **               array ifail.
    **
    **  internal parameters
    **  ===================
    **
    **  maxits  long int, default = 5
    **          the maximum number of iterations performed.
    **
    **  extra   long int, default = 2
    **          the number of iterations performed after norm growth
    **          criterion is satisfied, should be at least 1.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void stein(
        const long int* n,
        const float* d,
        const float* e,
        const long int* m,
        const float* ws,
        const long int* iblock,
        const long int* isplit,
        float* z,
        const long int* ldz,
        long int* ifail,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void stein(
        const long int* n,
        const float* d,
        const float* e,
        const long int* m,
        const float* ws,
        const long int* iblock,
        const long int* isplit,
        float* z,
        const long int* ldz,
        long int* ifail,
        long int* info)
  */
  /*! fn
   inline void stein(
        const long int* n,
        const double* d,
        const double* e,
        const long int* m,
        const double* ws,
        const long int* iblock,
        const long int* isplit,
        double* z,
        const long int* ldz,
        long int* ifail,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void stein(
        const long int* n,
        const double* d,
        const double* e,
        const long int* m,
        const double* ws,
        const long int* iblock,
        const long int* isplit,
        double* z,
        const long int* ldz,
        long int* ifail,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sstein.f)
  //    *  WORK    (workspace) float array, dimension (5*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEIN(NAME, T)\
inline void stein(\
    const long int* n,\
    const T* d,\
    const T* e,\
    const long int* m,\
    const T* ws,\
    const long int* iblock,\
    const long int* isplit,\
    T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(5*(*n));\
    F77NAME( NAME )(n, d, e, m, ws, iblock, isplit, z, ldz, w.getw(), w.getiw(), ifail, info);\
}\
inline void stein(\
    const long int* n,\
    const T* d,\
    const T* e,\
    const long int* m,\
    const T* ws,\
    const long int* iblock,\
    const long int* isplit,\
    T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info)\
{\
   workspace<T> w;\
   stein(n, d, e, m, ws, iblock, isplit, z, ldz, ifail, info, w);\
}\

    LPP_STEIN(sstein, float)
    LPP_STEIN(dstein, double)

#undef LPP_STEIN


  // The following macro provides the 4 functions 
  /*! fn
   inline void stein(
       const long int* n,
       const float* d,
       const float* e,
       const long int* m,
       const float* ws,
       const long int* iblock,
       const long int* isplit,
       std::complex<float>* z,
       const long int* ldz,
       long int* ifail,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void stein(
       const long int* n,
       const float* d,
       const float* e,
       const long int* m,
       const float* ws,
       const long int* iblock,
       const long int* isplit,
       std::complex<float>* z,
       const long int* ldz,
       long int* ifail,
       long int* info)
  */
  /*! fn
   inline void stein(
       const long int* n,
       const double* d,
       const double* e,
       const long int* m,
       const double* ws,
       const long int* iblock,
       const long int* isplit,
       std::complex<double>* z,
       const long int* ldz,
       long int* ifail,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void stein(
       const long int* n,
       const double* d,
       const double* e,
       const long int* m,
       const double* ws,
       const long int* iblock,
       const long int* isplit,
       std::complex<double>* z,
       const long int* ldz,
       long int* ifail,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cstein.f)
  //    *  WORK    (workspace) float array, dimension (5*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEIN(NAME, T, TBASE)\
inline void stein(\
    const long int* n,\
    const TBASE* d,\
    const TBASE* e,\
    const long int* m,\
    const TBASE* ws,\
    const long int* iblock,\
    const long int* isplit,\
    T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizerw(5*(*n));\
    F77NAME( NAME )(n, d, e, m, ws, iblock, isplit, z, ldz, w.getrw(), w.getiw(), ifail, info);\
}\
inline void stein(\
    const long int* n,\
    const TBASE* d,\
    const TBASE* e,\
    const long int* m,\
    const TBASE* ws,\
    const long int* iblock,\
    const long int* isplit,\
    T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info)\
{\
   workspace<T> w;\
   stein(n, d, e, m, ws, iblock, isplit, z, ldz, ifail, info, w);\
}\

    LPP_STEIN(cstein, std::complex<float>, float)
    LPP_STEIN(zstein, std::complex<double>, double)

#undef LPP_STEIN



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of stein_itf.hh
// /////////////////////////////////////////////////////////////////////////////
