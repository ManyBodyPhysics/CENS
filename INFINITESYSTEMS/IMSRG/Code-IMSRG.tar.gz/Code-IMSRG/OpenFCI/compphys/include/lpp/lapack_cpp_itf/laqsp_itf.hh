#ifndef __PROJECT__LPP__FILE__LAQSP_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQSP_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqsp_itf.hh C++ interface to LAPACK (c,d,c,z)laqsp
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqsp_itf.hh
    (excerpt adapted from xlaqsp.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqsp equilibrates a symmetric matrix a using the scaling factors
    **  in the vector s.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          symmetric matrix a is stored.
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the symmetric matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = a(i,j) for j<=i<=n.
    **
    **          on exit, the equilibrated matrix:  diag(s) * a * diag(s), in
    **          the same storage format as a.
    **
    **  s       (input) BASE DATA TYPE array, dimension (n)
    **          the scale factors for a.
    **
    **  scond   (input) BASE DATA TYPE
    **          ratio of the smallest s(i) to the largest s(i).
    **
    **  amax    (input) BASE DATA TYPE
    **          absolute value of largest matrix entry.
    **
    **  equed   (output) char
    **          specifies whether or not equilibration was done.
    **          = 'n':  no equilibration.
    **          = 'y':  equilibration was done, i.e., a has been replaced by
    **                  diag(s) * a * diag(s).
    **
    **  internal parameters
    **  ===================
    **
    **  thresh is a threshold value used to decide if scaling should be done
    **  based on the ratio of the scaling factors.  if scond < thresh,
    **  scaling is done.
    **
    **  large and small are threshold values used to decide if scaling should
    **  be done based on the absolute size of the largest matrix element.
    **  if amax > large or amax < small, scaling is done.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqsp(
        const char* uplo,
        const long int* n,
        float* ap,
        const float* s,
        const float* scond,
        const float* amax,
        char* equed,
        workspace<float> & w)
  */
  /*! fn
   inline void laqsp(
        const char* uplo,
        const long int* n,
        float* ap,
        const float* s,
        const float* scond,
        const float* amax,
        char* equed)
  */
  /*! fn
   inline void laqsp(
        const char* uplo,
        const long int* n,
        double* ap,
        const double* s,
        const double* scond,
        const double* amax,
        char* equed,
        workspace<double> & w)
  */
  /*! fn
   inline void laqsp(
        const char* uplo,
        const long int* n,
        double* ap,
        const double* s,
        const double* scond,
        const double* amax,
        char* equed)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaqsp.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQSP(NAME, T)\
inline void laqsp(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* s,\
    const T* scond,\
    const T* amax,\
    char* equed,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, ap, s, scond, amax, equed);\
}\
inline void laqsp(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* s,\
    const T* scond,\
    const T* amax,\
    char* equed)\
{\
   workspace<T> w;\
   laqsp(uplo, n, ap, s, scond, amax, equed, w);\
}\

    LPP_LAQSP(slaqsp, float)
    LPP_LAQSP(dlaqsp, double)

#undef LPP_LAQSP


  // The following macro provides the 4 functions 
  /*! fn
   inline void laqsp(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const float* s,
       const float* scond,
       const float* amax,
       char* equed,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laqsp(
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const float* s,
       const float* scond,
       const float* amax,
       char* equed)
  */
  /*! fn
   inline void laqsp(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const double* s,
       const double* scond,
       const double* amax,
       char* equed,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laqsp(
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const double* s,
       const double* scond,
       const double* amax,
       char* equed)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claqsp.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQSP(NAME, T, TBASE)\
inline void laqsp(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const TBASE* s,\
    const TBASE* scond,\
    const TBASE* amax,\
    char* equed,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, ap, s, scond, amax, equed);\
}\
inline void laqsp(\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const TBASE* s,\
    const TBASE* scond,\
    const TBASE* amax,\
    char* equed)\
{\
   workspace<T> w;\
   laqsp(uplo, n, ap, s, scond, amax, equed, w);\
}\

    LPP_LAQSP(claqsp, std::complex<float>,  float)
    LPP_LAQSP(zlaqsp, std::complex<double>, double)

#undef LPP_LAQSP



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqsp_itf.hh
// /////////////////////////////////////////////////////////////////////////////
