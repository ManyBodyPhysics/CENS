#ifndef __PROJECT__LPP__FILE__POEQU_HH__INCLUDED
#define __PROJECT__LPP__FILE__POEQU_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : poequ_itf.hh C++ interface to LAPACK (c,d,c,z)poequ
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file poequ_itf.hh
    (excerpt adapted from xpoequ.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpoequ computes row and column scalings intended to equilibrate a
    **  hermitian positive definite matrix a and reduce its condition number
    **  (with respect to the two-norm).  s contains the scale factors,
    **  s(i) = 1/sqrt(a(i,i)), chosen so that the scaled matrix b with
    **  elements b(i,j) = s(i)*a(i,j)*s(j) has ones on the diagonal.  this
    **  choice of s puts the condition number of b within a factor n of the
    **  smallest possible condition number over all possible diagonal
    **  scalings.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input) DATA TYPE array, dimension (lda,n)
    **          the n-by-n hermitian positive definite matrix whose scaling
    **          factors are to be computed.  only the diagonal elements of a
    **          are referenced.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  s       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, s contains the scale factors for a.
    **
    **  scond   (output) BASE DATA TYPE
    **          if info = 0, s contains the ratio of the smallest s(i) to
    **          the largest s(i).  if scond >= 0.1 and amax is neither too
    **          large nor too small, it is not worth scaling by s.
    **
    **  amax    (output) BASE DATA TYPE
    **          absolute value of largest matrix element.  if amax is very
    **          close to overflow or very close to underflow, the matrix
    **          should be scaled.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, the i-th diagonal element is nonpositive.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void poequ(
        const long int* n,
        const float* a,
        const long int* lda,
        float* s,
        float* scond,
        float* amax,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void poequ(
        const long int* n,
        const float* a,
        const long int* lda,
        float* s,
        float* scond,
        float* amax,
        long int* info)
  */
  /*! fn
   inline void poequ(
        const long int* n,
        const double* a,
        const long int* lda,
        double* s,
        double* scond,
        double* amax,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void poequ(
        const long int* n,
        const double* a,
        const long int* lda,
        double* s,
        double* scond,
        double* amax,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spoequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POEQU(NAME, T)\
inline void poequ(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* s,\
    T* scond,\
    T* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, s, scond, amax, info);\
}\
inline void poequ(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* s,\
    T* scond,\
    T* amax,\
    long int* info)\
{\
   workspace<T> w;\
   poequ(n, a, lda, s, scond, amax, info, w);\
}\

    LPP_POEQU(spoequ, float)
    LPP_POEQU(dpoequ, double)

#undef LPP_POEQU


  // The following macro provides the 4 functions 
  /*! fn
   inline void poequ(
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       float* s,
       float* scond,
       float* amax,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void poequ(
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       float* s,
       float* scond,
       float* amax,
       long int* info)
  */
  /*! fn
   inline void poequ(
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       double* s,
       double* scond,
       double* amax,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void poequ(
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       double* s,
       double* scond,
       double* amax,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpoequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POEQU(NAME, T, TBASE)\
inline void poequ(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    TBASE* s,\
    TBASE* scond,\
    TBASE* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, s, scond, amax, info);\
}\
inline void poequ(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    TBASE* s,\
    TBASE* scond,\
    TBASE* amax,\
    long int* info)\
{\
   workspace<T> w;\
   poequ(n, a, lda, s, scond, amax, info, w);\
}\

    LPP_POEQU(cpoequ, std::complex<float>,  float)
    LPP_POEQU(zpoequ, std::complex<double>, double)

#undef LPP_POEQU



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of poequ_itf.hh
// /////////////////////////////////////////////////////////////////////////////
