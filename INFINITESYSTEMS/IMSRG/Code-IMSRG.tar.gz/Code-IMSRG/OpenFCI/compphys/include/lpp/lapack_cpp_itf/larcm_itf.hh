#ifndef __PROJECT__LPP__FILE__LARCM_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARCM_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larcm_itf.hh C++ interface to LAPACK (s,d,c,z)larcm
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larcm_itf.hh
    (excerpt adapted from xlarcm.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarcm performs a very simple matrix-matrix multiplication:
    **           c := a * b,
    **  where a is m by m and BASE DATA TYPE; b is m by n and DATA TYPE;
    **  c is m by n and DATA TYPE.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a and of the matrix c.
    **          m >= 0.
    **
    **  n       (input) long int
    **          the number of columns and rows of the matrix b and
    **          the number of columns of the matrix c.
    **          n >= 0.
    **
    **  a       (input) BASE DATA TYPE array, dimension (lda, m)
    **          a contains the m by m matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >=max(1,m).
    **
    **  b       (input) BASE DATA TYPE array, dimension (ldb, n)
    **          b contains the m by n matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >=max(1,m).
    **
    **  c       (input) DATA TYPE array, dimension (ldc, n)
    **          c contains the m by n matrix c.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >=max(1,m).
    **
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larcm(
       const long int* m,
       const long int* n,
       const float* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* c,
       const long int* ldc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larcm(
       const long int* m,
       const long int* n,
       const float* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* c,
       const long int* ldc)
  */
  /*! fn
   inline void larcm(
       const long int* m,
       const long int* n,
       const double* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* c,
       const long int* ldc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larcm(
       const long int* m,
       const long int* n,
       const double* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* c,
       const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarcm.f)
  //    *  RWORK   (workspace) float array, dimension (2*M*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARCM(NAME, T, TBASE)\
inline void larcm(\
    const long int* m,\
    const long int* n,\
    const TBASE* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
    w.resizerw(2*(*m)*(*n));\
    F77NAME( NAME )(m, n, a, lda, b, ldb, c, ldc, w.getrw());\
}\
inline void larcm(\
    const long int* m,\
    const long int* n,\
    const TBASE* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larcm(m, n, a, lda, b, ldb, c, ldc, w);\
}\

    LPP_LARCM(clarcm, std::complex<float>, float)
    LPP_LARCM(zlarcm, std::complex<double>, double)

#undef LPP_LARCM



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larcm_itf.hh
// /////////////////////////////////////////////////////////////////////////////
