#ifndef __PROJECT__LPP__FILE__LASD7_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD7_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd7_itf.hh C++ interface to LAPACK (s,d,c,z)lasd7
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd7_itf.hh
    (excerpt adapted from xlasd7.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd7 merges the two sets of singular values together into a single
    **  sorted set. then it tries to deflate the size of the problem. there
    **  are two ways in which deflation can occur:  when two or more singular
    **  values are close together or if there is a tiny entry in the z
    **  vector. for each such occurrence the order of the related
    **  secular equation problem is reduced by one.
    **
    **  xlasd7 is called from dlasd6.
    **
    **  arguments
    **  =========
    **
    **  icompq  (input) long int
    **          specifies whether singular vectors are to be computed
    **          in compact form, as follows:
    **          = 0: compute singular values only.
    **          = 1: compute singular vectors of upper
    **               bidiagonal matrix in compact form.
    **
    **  nl     (input) long int
    **         the row dimension of the upper block. nl >= 1.
    **
    **  nr     (input) long int
    **         the row dimension of the lower block. nr >= 1.
    **
    **  sqre   (input) long int
    **         = 0: the lower block is an nr-by-nr square matrix.
    **         = 1: the lower block is an nr-by-(nr+1) rectangular matrix.
    **
    **         the bidiagonal matrix has
    **         n = nl + nr + 1 rows and
    **         m = n + sqre >= n columns.
    **
    **  k      (output) long int
    **         contains the dimension of the non-deflated matrix, this is
    **         the order of the related secular equation. 1 <= k <=n.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension ( n )
    **         on entry d contains the singular values of the two submatrices
    **         to be combined. on exit d contains the trailing (n-k) updated
    **         singular values (those which were deflated) sorted into
    **         increasing order.
    **
    **  z      (output) BASE DATA TYPE array, dimension ( m )
    **         on exit z contains the updating row vector in the secular
    **         equation.
    **
    **
    **  vf     (input/output) BASE DATA TYPE array, dimension ( m )
    **         on entry, vf(1:nl+1) contains the first components of all
    **         right singular vectors of the upper block; and vf(nl+2:m)
    **         contains the first components of all right singular vectors
    **         of the lower block. on exit, vf contains the first components
    **         of all right singular vectors of the bidiagonal matrix.
    **
    **
    **  vl     (input/output) BASE DATA TYPE array, dimension ( m )
    **         on entry, vl(1:nl+1) contains the  last components of all
    **         right singular vectors of the upper block; and vl(nl+2:m)
    **         contains the last components of all right singular vectors
    **         of the lower block. on exit, vl contains the last components
    **         of all right singular vectors of the bidiagonal matrix.
    **
    **
    **  alpha  (input) BASE DATA TYPE
    **         contains the diagonal element associated with the added row.
    **
    **  beta   (input) BASE DATA TYPE
    **         contains the off-diagonal element associated with the added
    **         row.
    **
    **  dsigma (output) BASE DATA TYPE array, dimension ( n )
    **         contains a copy of the diagonal elements (k-1 singular values
    **         and one zero) in the secular equation.
    **
    **
    **
    **  idxq   (input) long int array, dimension ( n )
    **         this contains the permutation which separately sorts the two
    **         sub-problems in d into ascending order.  note that entries in
    **         the first half of this permutation must first be moved one
    **         position backward; and entries in the second half
    **         must first have nl+1 added to their values.
    **
    **  perm   (output) long int array, dimension ( n )
    **         the permutations (from deflation and sorting) to be applied
    **         to each singular block. not referenced if icompq = 0.
    **
    **  givptr (output) long int
    **         the number of givens rotations which took place in this
    **         subproblem. not referenced if icompq = 0.
    **
    **  givcol (output) long int array, dimension ( ldgcol, 2 )
    **         each pair of numbers indicates a pair of columns to take place
    **         in a givens rotation. not referenced if icompq = 0.
    **
    **  ldgcol (input) long int
    **         the leading dimension of givcol, must be at least n.
    **
    **  givnum (output) BASE DATA TYPE array, dimension ( ldgnum, 2 )
    **         each number indicates the c or s value to be used in the
    **         corresponding givens rotation. not referenced if icompq = 0.
    **
    **  ldgnum (input) long int
    **         the leading dimension of givnum, must be at least n.
    **
    **  c      (output) BASE DATA TYPE
    **         c contains garbage if sqre =0 and the c-value of a givens
    **         rotation related to the right null space if sqre = 1.
    **
    **  s      (output) BASE DATA TYPE
    **         s contains garbage if sqre =0 and the s-value of a givens
    **         rotation related to the right null space if sqre = 1.
    **
    **  info   (output) long int
    **         = 0:  successful exit.
    **         < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd7(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        float* d,
        float* z,
        float* zw,
        float* vf,
        float* vfw,
        float* vl,
        float* vlw,
        const float* alpha,
        const float* beta,
        float* dsigma,
        long int* idx,
        long int* idxp,
        const long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        float* givnum,
        const long int* ldgnum,
        const float* c,
        const float* s,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd7(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        float* d,
        float* z,
        float* zw,
        float* vf,
        float* vfw,
        float* vl,
        float* vlw,
        const float* alpha,
        const float* beta,
        float* dsigma,
        long int* idx,
        long int* idxp,
        const long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        float* givnum,
        const long int* ldgnum,
        const float* c,
        const float* s,
        long int* info)
  */
  /*! fn
   inline void lasd7(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        double* d,
        double* z,
        double* zw,
        double* vf,
        double* vfw,
        double* vl,
        double* vlw,
        const double* alpha,
        const double* beta,
        double* dsigma,
        long int* idx,
        long int* idxp,
        const long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        double* givnum,
        const long int* ldgnum,
        const double* c,
        const double* s,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd7(
        const long int* icompq,
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        long int* k,
        double* d,
        double* z,
        double* zw,
        double* vf,
        double* vfw,
        double* vl,
        double* vlw,
        const double* alpha,
        const double* beta,
        double* dsigma,
        long int* idx,
        long int* idxp,
        const long int* idxq,
        long int* perm,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        double* givnum,
        const long int* ldgnum,
        const double* c,
        const double* s,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd7.f)
  //    *  ZW     (workspace) float array, dimension ( M )
  //    *         Workspace for Z.
  //    *
  //    *  VFW    (workspace) float array, dimension ( M )
  //    *         Workspace for VF.
  //    *
  //    *  VLW    (workspace) float array, dimension ( M )
  //    *         Workspace for VL.
  //    *
  //    *  IDX    (workspace) long int array, dimension ( N )
  //    *         This will contain the permutation used to sort the contents of
  //    *         D into ascending order.
  //    *
  //    *  IDXP   (workspace) long int array, dimension ( N )
  //    *         This will contain the permutation used to place deflated
  //    *         values of D at the end of the array. On output IDXP(2:K)
  //    *         points to the nondeflated D-values and IDXP(K+1:N)
  //    *         points to the deflated singular values.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD7(NAME, T)\
inline void lasd7(\
    const long int* icompq,\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    long int* k,\
    T* d,\
    T* z,\
    T* zw,\
    T* vf,\
    T* vfw,\
    T* vl,\
    T* vlw,\
    const T* alpha,\
    const T* beta,\
    T* dsigma,\
    long int* idx,\
    long int* idxp,\
    const long int* idxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    T* givnum,\
    const long int* ldgnum,\
    const T* c,\
    const T* s,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(icompq, nl, nr, sqre, k, d, z, zw, vf, vfw, vl, vlw, alpha, beta, dsigma, idx, idxp, idxq, perm, givptr, givcol, ldgcol, givnum, ldgnum, c, s, info);\
}\
inline void lasd7(\
    const long int* icompq,\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    long int* k,\
    T* d,\
    T* z,\
    T* zw,\
    T* vf,\
    T* vfw,\
    T* vl,\
    T* vlw,\
    const T* alpha,\
    const T* beta,\
    T* dsigma,\
    long int* idx,\
    long int* idxp,\
    const long int* idxq,\
    long int* perm,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    T* givnum,\
    const long int* ldgnum,\
    const T* c,\
    const T* s,\
    long int* info)\
{\
   workspace<T> w;\
   lasd7(icompq, nl, nr, sqre, k, d, z, zw, vf, vfw, vl, vlw, alpha, beta, dsigma, idx, idxp, idxq, perm, givptr, givcol, ldgcol, givnum, ldgnum, c, s, info, w);\
}\

    LPP_LASD7(slasd7, float)
    LPP_LASD7(dlasd7, double)

#undef LPP_LASD7



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd7_itf.hh
// /////////////////////////////////////////////////////////////////////////////
