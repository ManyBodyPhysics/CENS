#ifndef __PROJECT__LPP__FILE__GESC2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GESC2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gesc2_itf.hh C++ interface to LAPACK (c,d,c,z)gesc2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gesc2_itf.hh
    (excerpt adapted from xgesc2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgesc2 solves a system of linear equations
    **
    **            a * x = scale* rhs
    **
    **  with a general n-by-n matrix a using the lu factorization with
    **  complete pivoting computed by cgetc2.
    **
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.
    **
    **  a       (input) DATA TYPE array, dimension (lda, n)
    **          on entry, the  lu part of the factorization of the n-by-n
    **          matrix a computed by cgetc2:  a = p * l * u * q
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1, n).
    **
    **  rhs     (input/output) DATA TYPE array, dimension n.
    **          on entry, the right hand side vector b.
    **          on exit, the solution vector x.
    **
    **  ipiv    (iput) long int array, dimension (n).
    **          the pivot indices; for 1 <= i <= n, row i of the
    **          matrix has been interchanged with row ipiv(i).
    **
    **  jpiv    (iput) long int array, dimension (n).
    **          the pivot indices; for 1 <= j <= n, column j of the
    **          matrix has been interchanged with column jpiv(j).
    **
    **  scale    (output) BASE DATA TYPE
    **           on exit, scale contains the scale factor. scale is chosen
    **           0 <= scale <= 1 to prevent owerflow in the solution.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gesc2(
        const long int* n,
        const float* a,
        const long int* lda,
        float* rhs,
        long int* ipiv,
        long int* jpiv,
        float* scale,
        workspace<float> & w)
  */
  /*! fn
   inline void gesc2(
        const long int* n,
        const float* a,
        const long int* lda,
        float* rhs,
        long int* ipiv,
        long int* jpiv,
        float* scale)
  */
  /*! fn
   inline void gesc2(
        const long int* n,
        const double* a,
        const long int* lda,
        double* rhs,
        long int* ipiv,
        long int* jpiv,
        double* scale,
        workspace<double> & w)
  */
  /*! fn
   inline void gesc2(
        const long int* n,
        const double* a,
        const long int* lda,
        double* rhs,
        long int* ipiv,
        long int* jpiv,
        double* scale)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgesc2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GESC2(NAME, T)\
inline void gesc2(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* rhs,\
    long int* ipiv,\
    long int* jpiv,\
    T* scale,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, rhs, ipiv, jpiv, scale);\
}\
inline void gesc2(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* rhs,\
    long int* ipiv,\
    long int* jpiv,\
    T* scale)\
{\
   workspace<T> w;\
   gesc2(n, a, lda, rhs, ipiv, jpiv, scale, w);\
}\

    LPP_GESC2(sgesc2, float)
    LPP_GESC2(dgesc2, double)

#undef LPP_GESC2


  // The following macro provides the 4 functions 
  /*! fn
   inline void gesc2(
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* rhs,
       long int* ipiv,
       long int* jpiv,
       float* scale,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gesc2(
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* rhs,
       long int* ipiv,
       long int* jpiv,
       float* scale)
  */
  /*! fn
   inline void gesc2(
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* rhs,
       long int* ipiv,
       long int* jpiv,
       double* scale,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gesc2(
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* rhs,
       long int* ipiv,
       long int* jpiv,
       double* scale)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgesc2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GESC2(NAME, T, TBASE)\
inline void gesc2(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* rhs,\
    long int* ipiv,\
    long int* jpiv,\
    TBASE* scale,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, a, lda, rhs, ipiv, jpiv, scale);\
}\
inline void gesc2(\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* rhs,\
    long int* ipiv,\
    long int* jpiv,\
    TBASE* scale)\
{\
   workspace<T> w;\
   gesc2(n, a, lda, rhs, ipiv, jpiv, scale, w);\
}\

    LPP_GESC2(cgesc2, std::complex<float>,  float)
    LPP_GESC2(zgesc2, std::complex<double>, double)

#undef LPP_GESC2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gesc2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
