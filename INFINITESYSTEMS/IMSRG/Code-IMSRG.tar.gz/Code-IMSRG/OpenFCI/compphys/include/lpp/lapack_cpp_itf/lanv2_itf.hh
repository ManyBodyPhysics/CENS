#ifndef __PROJECT__LPP__FILE__LANV2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LANV2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lanv2_itf.hh C++ interface to LAPACK (s,d,c,z)lanv2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lanv2_itf.hh
    (excerpt adapted from xlanv2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlanv2 computes the schur factorization of a BASE DATA TYPE 2-by-2 nonsymmetric
    **  matrix in standard form:
    **
    **       [ a  b ] = [ cs -sn ] [ aa  bb ] [ cs  sn ]
    **       [ c  d ]   [ sn  cs ] [ cc  dd ] [-sn  cs ]
    **
    **  where either
    **  1) cc = 0 so that aa and dd are BASE DATA TYPE eigenvalues of the matrix, or
    **  2) aa = dd and bb*cc < 0, so that aa + or - sqrt(bb*cc) are DATA TYPE
    **  conjugate eigenvalues.
    **
    **  arguments
    **  =========
    **
    **  a       (input/output) BASE DATA TYPE
    **  b       (input/output) BASE DATA TYPE
    **  c       (input/output) BASE DATA TYPE
    **  d       (input/output) BASE DATA TYPE
    **          on entry, the elements of the input matrix.
    **          on exit, they are overwritten by the elements of the
    **          standardised schur form.
    **
    **  rt1r    (output) BASE DATA TYPE
    **  rt1i    (output) BASE DATA TYPE
    **  rt2r    (output) BASE DATA TYPE
    **  rt2i    (output) BASE DATA TYPE
    **          the BASE DATA TYPE and imaginary parts of the eigenvalues. if the
    **          eigenvalues are a DATA TYPE conjugate pair, rt1i > 0.
    **
    **  cs      (output) BASE DATA TYPE
    **  sn      (output) BASE DATA TYPE
    **          parameters of the rotation matrix.
    **
    **  further details
    **  ===============
    **
    **  modified by v. sima, research institute for informatics, bucharest,
    **  romania, to reduce the risk of cancellation errors,
    **  when computing BASE DATA TYPE eigenvalues, and to ensure, if possible, that
    **  abs(rt1r) >= abs(rt2r).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lanv2(
        float* a,
        float* b,
        float* c,
        float* d,
        float* rt1r,
        float* rt1i,
        float* rt2r,
        float* rt2i,
        float* cs,
        float* sn,
        workspace<float> & w)
  */
  /*! fn
   inline void lanv2(
        float* a,
        float* b,
        float* c,
        float* d,
        float* rt1r,
        float* rt1i,
        float* rt2r,
        float* rt2i,
        float* cs,
        float* sn)
  */
  /*! fn
   inline void lanv2(
        double* a,
        double* b,
        double* c,
        double* d,
        double* rt1r,
        double* rt1i,
        double* rt2r,
        double* rt2i,
        double* cs,
        double* sn,
        workspace<double> & w)
  */
  /*! fn
   inline void lanv2(
        double* a,
        double* b,
        double* c,
        double* d,
        double* rt1r,
        double* rt1i,
        double* rt2r,
        double* rt2i,
        double* cs,
        double* sn)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slanv2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LANV2(NAME, T)\
inline void lanv2(\
    T* a,\
    T* b,\
    T* c,\
    T* d,\
    T* rt1r,\
    T* rt1i,\
    T* rt2r,\
    T* rt2i,\
    T* cs,\
    T* sn,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(a, b, c, d, rt1r, rt1i, rt2r, rt2i, cs, sn);\
}\
inline void lanv2(\
    T* a,\
    T* b,\
    T* c,\
    T* d,\
    T* rt1r,\
    T* rt1i,\
    T* rt2r,\
    T* rt2i,\
    T* cs,\
    T* sn)\
{\
   workspace<T> w;\
   lanv2(a, b, c, d, rt1r, rt1i, rt2r, rt2i, cs, sn, w);\
}\

    LPP_LANV2(slanv2, float)
    LPP_LANV2(dlanv2, double)

#undef LPP_LANV2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lanv2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
