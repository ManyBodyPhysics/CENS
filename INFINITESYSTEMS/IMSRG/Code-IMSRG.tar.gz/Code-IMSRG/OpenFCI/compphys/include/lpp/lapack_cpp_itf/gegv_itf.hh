#ifndef __PROJECT__LPP__FILE__GEGV_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEGV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gegv_itf.hh C++ interface to LAPACK (c,d,c,z)gegv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gegv_itf.hh
    (excerpt adapted from xgegv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this routine is deprecated and has been replaced by routine cggev.
    **
    **  xgegv computes the eigenvalues and, optionally, the left and/or right
    **  eigenvectors of a DATA TYPE matrix pair (a,b).
    **  given two square matrices a and b,
    **  the generalized nonsymmetric eigenvalue problem (gnep) is to find the
    **  eigenvalues lambda and corresponding (non-zero) eigenvectors x such
    **  that
    **     a*x = lambda*b*x.
    **
    **  an alternate form is to find the eigenvalues mu and corresponding
    **  eigenvectors y such that
    **     mu*a*y = b*y.
    **
    **  these two forms are equivalent with mu = 1/lambda and x = y if
    **  neither lambda nor mu is zero.  in order to deal with the case that
    **  lambda or mu is zero or small, two values alpha and beta are returned
    **  for each eigenvalue, such that lambda = alpha/beta and
    **  mu = beta/alpha.
    **  
    **  the vectors x and y in the above equations are right eigenvectors of
    **  the matrix pair (a,b).  vectors u and v satisfying
    **     u**h*a = lambda*u**h*b  or  mu*v**h*a = v**h*b
    **  are left eigenvectors of (a,b).
    **
    **  note: this routine performs "full balancing" on a and b -- see
    **  "further details", below.
    **
    **  arguments
    **  =========
    **
    **  jobvl   (input) char
    **          = 'n':  do not compute the left generalized eigenvectors;
    **          = 'v':  compute the left generalized eigenvectors (returned
    **                  in vl).
    **
    **  jobvr   (input) char
    **          = 'n':  do not compute the right generalized eigenvectors;
    **          = 'v':  compute the right generalized eigenvectors (returned
    **                  in vr).
    **
    **  n       (input) long int
    **          the order of the matrices a, b, vl, and vr.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the matrix a.
    **          if jobvl = 'v' or jobvr = 'v', then on exit a
    **          contains the schur form of a from the generalized schur
    **          factorization of the pair (a,b) after balancing.  if no
    **          eigenvectors were computed, then only the diagonal elements
    **          of the schur form will be correct.  see cgghrd and chgeqz
    **          for details.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the matrix b.
    **          if jobvl = 'v' or jobvr = 'v', then on exit b contains the
    **          upper triangular matrix obtained from b in the generalized
    **          schur factorization of the pair (a,b) after balancing.
    **          if no eigenvectors were computed, then only the diagonal
    **          elements of b will be correct.  see cgghrd and chgeqz for
    **          details.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  ldb >= max(1,n).
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **          the DATA TYPE scalars alpha that define the eigenvalues of
    **          gnep.
    **
    **  beta    (output) DATA TYPE array, dimension (n)
    **          the DATA TYPE scalars beta that define the eigenvalues of gnep.
    **          
    **          together, the quantities alpha = alpha(j) and beta = beta(j)
    **          represent the j-th eigenvalue of the matrix pair (a,b), in
    **          one of the forms lambda = alpha/beta or mu = beta/alpha.
    **          since either lambda or mu may overflow, they should not,
    **          in general, be computed.
    *
    **
    **  vl      (output) DATA TYPE array, dimension (ldvl,n)
    **          if jobvl = 'v', the left eigenvectors u(j) are stored
    **          in the columns of vl, in the same order as their eigenvalues.
    **          each eigenvector is scaled so that its largest component has
    **          abs(BASE DATA TYPE part) + abs(imag. part) = 1, except for eigenvectors
    **          corresponding to an eigenvalue with alpha = beta = 0, which
    **          are set to zero.
    **          not referenced if jobvl = 'n'.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the matrix vl. ldvl >= 1, and
    **          if jobvl = 'v', ldvl >= n.
    **
    **  vr      (output) DATA TYPE array, dimension (ldvr,n)
    **          if jobvr = 'v', the right eigenvectors x(j) are stored
    **          in the columns of vr, in the same order as their eigenvalues.
    **          each eigenvector is scaled so that its largest component has
    **          abs(BASE DATA TYPE part) + abs(imag. part) = 1, except for eigenvectors
    **          corresponding to an eigenvalue with alpha = beta = 0, which
    **          are set to zero.
    **          not referenced if jobvr = 'n'.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the matrix vr. ldvr >= 1, and
    **          if jobvr = 'v', ldvr >= n.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          =1,...,n:
    **                the qz iteration failed.  no eigenvectors have been
    **                calculated, but alpha(j) and beta(j) should be
    **                correct for j=info+1,...,n.
    **          > n:  errors that usually indicate lapack problems:
    **                =n+1: error return from cggbal
    **                =n+2: error return from cgeqrf
    **                =n+3: error return from cunmqr
    **                =n+4: error return from cungqr
    **                =n+5: error return from cgghrd
    **                =n+6: error return from chgeqz (other than failed
    **                                               iteration)
    **                =n+7: error return from ctgevc
    **                =n+8: error return from cggbak (computing vl)
    **                =n+9: error return from cggbak (computing vr)
    **                =n+10: error return from clascl (various calls)
    **
    **  further details
    **  ===============
    **
    **  balancing
    **  ---------
    **
    **  this driver calls cggbal to both permute and scale rows and columns
    **  of a and b.  the permutations pl and pr are chosen so that pl*a*pr
    **  and pl*b*r will be upper triangular except for the diagonal blocks
    **  a(i:j,i:j) and b(i:j,i:j), with i and j as close together as
    **  possible.  the diagonal scaling matrices dl and dr are chosen so
    **  that the pair  dl*pl*a*pr*dr, dl*pl*b*pr*dr have elements close to
    **  one (except for the elements that start out zero.)
    **
    **  after the eigenvalues and eigenvectors of the balanced matrices
    **  have been computed, cggbak transforms the eigenvectors back to what
    **  they would have been (in perfect arithmetic) if they had not been
    **  balanced.
    **
    **  contents of a and b on exit
    **  -------- -- - --- - -- ----
    **
    **  if any eigenvectors are computed (either jobvl='v' or jobvr='v' or
    **  both), then on exit the arrays a and b will contain the DATA TYPE schur
    **  form[*] of the "balanced" versions of a and b.  if no eigenvectors
    **  are computed, then only the diagonal blocks will be correct.
    **
    **  [*] in other words, upper triangular form.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gegv(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gegv(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* info)
  */
  /*! fn
   inline void gegv(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gegv(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgegv.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,8*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *          To compute the optimal value of LWORK, call ILAENV to get
  //    *          blocksizes (for SGEQRF, SORMQR, and SORGQR.)  Then compute:
  //    *          NB  -- MAX of the blocksizes for SGEQRF, SORMQR, and SORGQR;
  //    *          The optimal LWORK is:
  //    *              2*N + MAX( 6*N, N*(NB+1) ).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEGV(NAME, T)\
inline void gegv(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, w.getw(), &w.neededsize(), info);\
}\
inline void gegv(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info)\
{\
   workspace<T> w;\
   gegv(jobvl, jobvr, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, info, w);\
}\

    LPP_GEGV(sgegv, float)
    LPP_GEGV(dgegv, double)

#undef LPP_GEGV


  // The following macro provides the 4 functions 
  /*! fn
   inline void gegv(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gegv(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* info)
  */
  /*! fn
   inline void gegv(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gegv(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgegv.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,2*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *          To compute the optimal value of LWORK, call ILAENV to get
  //    *          blocksizes (for CGEQRF, CUNMQR, and CUNGQR.)  Then compute:
  //    *          NB  -- MAX of the blocksizes for CGEQRF, CUNMQR, and CUNGQR;
  //    *          The optimal LWORK is  MAX( 2*N, N*(NB+1) ).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace/output) float array, dimension (8*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEGV(NAME, T, TBASE)\
inline void gegv(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(8**n);\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void gegv(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info)\
{\
   workspace<T> w;\
   gegv(jobvl, jobvr, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, info, w);\
}\

    LPP_GEGV(cgegv, std::complex<float>,  float)
    LPP_GEGV(zgegv, std::complex<double>, double)

#undef LPP_GEGV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gegv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
