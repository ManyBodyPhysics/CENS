#ifndef __PROJECT__LPP__FILE__SPGV_HH__INCLUDED
#define __PROJECT__LPP__FILE__SPGV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : spgv_itf.hh C++ interface to LAPACK (s,d,c,z)spgv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file spgv_itf.hh
    (excerpt adapted from xspgv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xspgv computes all the eigenvalues and, optionally, the eigenvectors
    **  of a BASE DATA TYPE generalized symmetric-definite eigenproblem, of the form
    **  a*x=(lambda)*b*x,  a*bx=(lambda)*x,  or b*a*x=(lambda)*x.
    **  here a and b are assumed to be symmetric, stored in packed format,
    **  and b is also positive definite.
    **
    **  arguments
    **  =========
    **
    **  itype   (input) long int
    **          specifies the problem type to be solved:
    **          = 1:  a*x = (lambda)*b*x
    **          = 2:  a*b*x = (lambda)*x
    **          = 3:  b*a*x = (lambda)*x
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangles of a and b are stored;
    **          = 'l':  lower triangles of a and b are stored.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ap      (input/output) BASE DATA TYPE array, dimension
    **                            (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the symmetric matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2*n-j)/2) = a(i,j) for j<=i<=n.
    **
    **          on exit, the contents of ap are destroyed.
    **
    **  bp      (input/output) BASE DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the symmetric matrix
    **          b, packed columnwise in a linear array.  the j-th column of b
    **          is stored in the array bp as follows:
    **          if uplo = 'u', bp(i + (j-1)*j/2) = b(i,j) for 1<=i<=j;
    **          if uplo = 'l', bp(i + (j-1)*(2*n-j)/2) = b(i,j) for j<=i<=n.
    **
    **          on exit, the triangular factor u or l from the cholesky
    **          factorization b = u**t*u or b = l*l**t, in the same storage
    **          format as b.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the eigenvalues in ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, n)
    **          if jobz = 'v', then if info = 0, z contains the matrix z of
    **          eigenvectors.  the eigenvectors are normalized as follows:
    **          if itype = 1 or 2, z**t*b*z = i;
    **          if itype = 3, z**t*inv(b)*z = i.
    **          if jobz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  dpptrf or dspev returned an error code:
    **             <= n:  if info = i, dspev failed to converge;
    **                    i off-diagonal elements of an intermediate
    **                    tridiagonal form did not converge to zero.
    **             > n:   if info = n + i, for 1 <= i <= n, then the leading
    **                    minor of order i of b is not positive definite.
    **                    the factorization of b could not be completed and
    **                    no eigenvalues or eigenvectors were computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void spgv(
        const long int* itype,
        const char* jobz,
        const char* uplo,
        const long int* n,
        float* ap,
        float* bp,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void spgv(
        const long int* itype,
        const char* jobz,
        const char* uplo,
        const long int* n,
        float* ap,
        float* bp,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void spgv(
        const long int* itype,
        const char* jobz,
        const char* uplo,
        const long int* n,
        double* ap,
        double* bp,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void spgv(
        const long int* itype,
        const char* jobz,
        const char* uplo,
        const long int* n,
        double* ap,
        double* bp,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sspgv.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPGV(NAME, T)\
inline void spgv(\
    const long int* itype,\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    T* bp,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(3*(*n));\
    F77NAME( NAME )(itype, jobz, uplo, n, ap, bp, ws, z, ldz, w.getw(), info);\
}\
inline void spgv(\
    const long int* itype,\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    T* bp,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   spgv(itype, jobz, uplo, n, ap, bp, ws, z, ldz, info, w);\
}\

    LPP_SPGV(sspgv, float)
    LPP_SPGV(dspgv, double)

#undef LPP_SPGV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of spgv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
