#ifndef __PROJECT__LPP__FILE__GEEV_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEEV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geev_itf.hh C++ interface to LAPACK (c,d,c,z)geev
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geev_itf.hh
    (excerpt adapted from xgeev.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgeev computes for an n-by-n DATA TYPE nonsymmetric matrix a, the
    **  eigenvalues and, optionally, the left and/or right eigenvectors.
    **
    **  the right eigenvector v(j) of a satisfies
    **                   a * v(j) = lambda(j) * v(j)
    **  where lambda(j) is its eigenvalue.
    **  the left eigenvector u(j) of a satisfies
    **                u(j)**h * a = lambda(j) * u(j)**h
    **  where u(j)**h denotes the conjugate transpose of u(j).
    **
    **  the computed eigenvectors are normalized to have euclidean norm
    **  equal to 1 and largest component BASE DATA TYPE.
    **
    **  arguments
    **  =========
    **
    **  jobvl   (input) char
    **          = 'n': left eigenvectors of a are not computed;
    **          = 'v': left eigenvectors of are computed.
    **
    **  jobvr   (input) char
    **          = 'n': right eigenvectors of a are not computed;
    **          = 'v': right eigenvectors of a are computed.
    **
    **  n       (input) long int
    **          the order of the matrix a. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the n-by-n matrix a.
    **          on exit, a has been overwritten.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  w       (output) DATA TYPE array, dimension (n)
    **          w contains the computed eigenvalues.
    **
    **  vl      (output) DATA TYPE array, dimension (ldvl,n)
    **          if jobvl = 'v', the left eigenvectors u(j) are stored one
    **          after another in the columns of vl, in the same order
    **          as their eigenvalues.
    **          if jobvl = 'n', vl is not referenced.
    **          u(j) = vl(:,j), the j-th column of vl.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the array vl.  ldvl >= 1; if
    **          jobvl = 'v', ldvl >= n.
    **
    **  vr      (output) DATA TYPE array, dimension (ldvr,n)
    **          if jobvr = 'v', the right eigenvectors v(j) are stored one
    **          after another in the columns of vr, in the same order
    **          as their eigenvalues.
    **          if jobvr = 'n', vr is not referenced.
    **          v(j) = vr(:,j), the j-th column of vr.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr.  ldvr >= 1; if
    **          jobvr = 'v', ldvr >= n.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = i, the qr algorithm failed to compute all the
    **                eigenvalues, and no eigenvectors have been computed;
    **                elements and i+1:n of w contain eigenvalues which have
    **                converged.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geev(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        float* a,
        const long int* lda,
        float* wr,
        float* wi,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geev(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        float* a,
        const long int* lda,
        float* wr,
        float* wi,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* info)
  */
  /*! fn
   inline void geev(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        double* a,
        const long int* lda,
        double* wr,
        double* wi,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geev(
        const char* jobvl,
        const char* jobvr,
        const long int* n,
        double* a,
        const long int* lda,
        double* wr,
        double* wi,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeev.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,3*N), and
  //    *          if JOBVL = 'V' or JOBVR = 'V', LWORK >= 4*N.  For good
  //    *          performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEEV(NAME, T)\
inline void geev(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* wr,\
    T* wi,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, w.getw(), &w.neededsize(), info);\
}\
inline void geev(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* wr,\
    T* wi,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info)\
{\
   workspace<T> w;\
   geev(jobvl, jobvr, n, a, lda, wr, wi, vl, ldvl, vr, ldvr, info, w);\
}\

    LPP_GEEV(sgeev, float)
    LPP_GEEV(dgeev, double)

#undef LPP_GEEV


  // The following macro provides the 4 functions 
  /*! fn
   inline void geev(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* ws,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geev(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* ws,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* info)
  */
  /*! fn
   inline void geev(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* ws,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geev(
       const char* jobvl,
       const char* jobvr,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* ws,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeev.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,2*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEEV(NAME, T, TBASE)\
inline void geev(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* ws,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizerw(2**n);                                                     \
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, ws, vl, ldvl, vr, ldvr, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvl, jobvr, n, a, lda, ws, vl, ldvl, vr, ldvr, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void geev(\
    const char* jobvl,\
    const char* jobvr,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* ws,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* info)\
{\
   workspace<T> w;\
   geev(jobvl, jobvr, n, a, lda, ws, vl, ldvl, vr, ldvr, info, w);\
}\

    LPP_GEEV(cgeev, std::complex<float>,  float)
    LPP_GEEV(zgeev, std::complex<double>, double)

#undef LPP_GEEV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geev_itf.hh
// /////////////////////////////////////////////////////////////////////////////
