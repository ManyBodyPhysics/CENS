#ifndef __PROJECT__LPP__FILE__HETRI_HH__INCLUDED
#define __PROJECT__LPP__FILE__HETRI_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hetri_itf.hh C++ interface to LAPACK (s,d,c,z)hetri
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hetri_itf.hh
    (excerpt adapted from xhetri.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhetri computes the inverse of a DATA TYPE hermitian indefinite matrix
    **  a using the factorization a = u*d*u**h or a = l*d*l**h computed by
    **  chetrf.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the details of the factorization are stored
    **          as an upper or lower triangular matrix.
    **          = 'u':  upper triangular, form is a = u*d*u**h;
    **          = 'l':  lower triangular, form is a = l*d*l**h.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the block diagonal matrix d and the multipliers
    **          used to obtain the factor u or l as computed by chetrf.
    **
    **          on exit, if info = 0, the (hermitian) inverse of the original
    **          matrix.  if uplo = 'u', the upper triangular part of the
    **          inverse is formed and the part of a below the diagonal is not
    **          referenced; if uplo = 'l' the lower triangular part of the
    **          inverse is formed and the part of a above the diagonal is
    **          not referenced.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  ipiv    (input) long int array, dimension (n)
    **          details of the interchanges and the block structure of d
    **          as determined by chetrf.
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, d(i,i) = 0; the matrix is singular and its
    **               inverse could not be computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hetri(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const long int* ipiv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hetri(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const long int* ipiv,
       long int* info)
  */
  /*! fn
   inline void hetri(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const long int* ipiv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hetri(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const long int* ipiv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chetri.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HETRI(NAME, T, TBASE)\
inline void hetri(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(uplo, n, a, lda, ipiv, w.getw(), info);\
}\
inline void hetri(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   hetri(uplo, n, a, lda, ipiv, info, w);\
}\

    LPP_HETRI(chetri, std::complex<float>, float)
    LPP_HETRI(zhetri, std::complex<double>, double)

#undef LPP_HETRI



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hetri_itf.hh
// /////////////////////////////////////////////////////////////////////////////
