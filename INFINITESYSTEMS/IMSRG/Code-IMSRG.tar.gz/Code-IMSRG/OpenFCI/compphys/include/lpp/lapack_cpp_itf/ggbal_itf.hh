#ifndef __PROJECT__LPP__FILE__GGBAL_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGBAL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggbal_itf.hh C++ interface to LAPACK (c,d,c,z)ggbal
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggbal_itf.hh
    (excerpt adapted from xggbal.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggbal balances a pair of general DATA TYPE matrices (a,b).  this
    **  involves, first, permuting a and b by similarity transformations to
    **  isolate eigenvalues in the first 1 to ilo$-$1 and last ihi+1 to n
    **  elements on the diagonal; and second, applying a diagonal similarity
    **  transformation to rows and columns ilo to ihi to make the rows
    **  and columns as close in norm as possible. both steps are optional.
    **
    **  balancing may reduce the 1-norm of the matrices, and improve the
    **  accuracy of the computed eigenvalues and/or eigenvectors in the
    **  generalized eigenvalue problem a*x = lambda*b*x.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies the operations to be performed on a and b:
    **          = 'n':  none:  simply set ilo = 1, ihi = n, lscale(i) = 1.0
    **                  and rscale(i) = 1.0 for i=1,...,n;
    **          = 'p':  permute only;
    **          = 's':  scale only;
    **          = 'b':  both permute and scale.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the input matrix a.
    **          on exit, a is overwritten by the balanced matrix.
    **          if job = 'n', a is not referenced.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the input matrix b.
    **          on exit, b is overwritten by the balanced matrix.
    **          if job = 'n', b is not referenced.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  ilo     (output) long int
    **  ihi     (output) long int
    **          ilo and ihi are set to integers such that on exit
    **          a(i,j) = 0 and b(i,j) = 0 if i > j and
    **          j = 1,...,ilo-1 or i = ihi+1,...,n.
    **          if job = 'n' or 's', ilo = 1 and ihi = n.
    **
    **  lscale  (output) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and scaling factors applied
    **          to the left side of a and b.  if p(j) is the index of the
    **          row interchanged with row j, and d(j) is the scaling factor
    **          applied to row j, then
    **            lscale(j) = p(j)    for j = 1,...,ilo-1
    **                      = d(j)    for j = ilo,...,ihi
    **                      = p(j)    for j = ihi+1,...,n.
    **          the order in which the interchanges are made is n to ihi+1,
    **          then 1 to ilo-1.
    **
    **  rscale  (output) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and scaling factors applied
    **          to the right side of a and b.  if p(j) is the index of the
    **          column interchanged with column j, and d(j) is the scaling
    **          factor applied to column j, then
    **            rscale(j) = p(j)    for j = 1,...,ilo-1
    **                      = d(j)    for j = ilo,...,ihi
    **                      = p(j)    for j = ihi+1,...,n.
    **          the order in which the interchanges are made is n to ihi+1,
    **          then 1 to ilo-1.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  see r.c. ward, balancing the generalized eigenvalue problem,
    **                 siam j. sci. stat. comp. 2 (1981), 141-152.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggbal(
        const char* job,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* ilo,
        long int* ihi,
        float* lscale,
        float* rscale,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggbal(
        const char* job,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* ilo,
        long int* ihi,
        float* lscale,
        float* rscale,
        long int* info)
  */
  /*! fn
   inline void ggbal(
        const char* job,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* ilo,
        long int* ihi,
        double* lscale,
        double* rscale,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggbal(
        const char* job,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* ilo,
        long int* ihi,
        double* lscale,
        double* rscale,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggbal.f)
  //    *  RWORK    (workspace) BASE DATA array, dimension (6*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGBAL(NAME, T)\
inline void ggbal(\
    const char* job,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* ilo,\
    long int* ihi,\
    T* lscale,\
    T* rscale,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(6**n);\
    F77NAME( NAME )(job, n, a, lda, b, ldb, ilo, ihi, lscale, rscale, w.getrw(), info);\
}\
inline void ggbal(\
    const char* job,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* ilo,\
    long int* ihi,\
    T* lscale,\
    T* rscale,\
    long int* info)\
{\
   workspace<T> w;\
   ggbal(job, n, a, lda, b, ldb, ilo, ihi, lscale, rscale, info, w);\
}\

    LPP_GGBAL(sggbal, float)
    LPP_GGBAL(dggbal, double)

#undef LPP_GGBAL


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggbal(
       const char* job,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* ilo,
       long int* ihi,
       float* lscale,
       float* rscale,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggbal(
       const char* job,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* ilo,
       long int* ihi,
       float* lscale,
       float* rscale,
       long int* info)
  */
  /*! fn
   inline void ggbal(
       const char* job,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* ilo,
       long int* ihi,
       double* lscale,
       double* rscale,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggbal(
       const char* job,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* ilo,
       long int* ihi,
       double* lscale,
       double* rscale,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggbal.f)
  //    *  WORK    (workspace) float array, dimension (6*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGBAL(NAME, T, TBASE)\
inline void ggbal(\
    const char* job,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* ilo,\
    long int* ihi,\
    TBASE* lscale,\
    TBASE* rscale,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(6**n);\
    F77NAME( NAME )(job, n, a, lda, b, ldb, ilo, ihi, lscale, rscale, w.getrw(), info);\
}\
inline void ggbal(\
    const char* job,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* ilo,\
    long int* ihi,\
    TBASE* lscale,\
    TBASE* rscale,\
    long int* info)\
{\
   workspace<T> w;\
   ggbal(job, n, a, lda, b, ldb, ilo, ihi, lscale, rscale, info, w); \
}\

    LPP_GGBAL(cggbal, std::complex<float>,  float)
    LPP_GGBAL(zggbal, std::complex<double>, double)

#undef LPP_GGBAL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggbal_itf.hh
// /////////////////////////////////////////////////////////////////////////////
