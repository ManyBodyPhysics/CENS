#ifndef __PROJECT__LPP__FILE__LATRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__LATRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : latrd_itf.hh C++ interface to LAPACK (c,d,c,z)latrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file latrd_itf.hh
    (excerpt adapted from xlatrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlatrd reduces nb rows and columns of a DATA TYPE hermitian matrix a to
    **  hermitian tridiagonal form by a unitary similarity
    **  transformation q' * a * q, and returns the matrices v and w which are
    **  needed to apply the transformation to the unreduced part of a.
    **
    **  if uplo = 'u', xlatrd reduces the last nb rows and columns of a
    **  matrix, of which the upper triangle is supplied;
    **  if uplo = 'l', xlatrd reduces the first nb rows and columns of a
    **  matrix, of which the lower triangle is supplied.
    **
    **  this is an auxiliary routine called by chetrd.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) character
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is stored:
    **          = 'u': upper triangular
    **          = 'l': lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.
    **
    **  nb      (input) long int
    **          the number of rows and columns to be reduced.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **          on exit:
    **          if uplo = 'u', the last nb columns have been reduced to
    **            tridiagonal form, with the diagonal elements overwriting
    **            the diagonal elements of a; the elements above the diagonal
    **            with the array tau, represent the unitary matrix q as a
    **            product of elementary reflectors;
    **          if uplo = 'l', the first nb columns have been reduced to
    **            tridiagonal form, with the diagonal elements overwriting
    **            the diagonal elements of a; the elements below the diagonal
    **            with the array tau, represent the  unitary matrix q as a
    **            product of elementary reflectors.
    **          see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  e       (output) BASE DATA TYPE array, dimension (n-1)
    **          if uplo = 'u', e(n-nb:n-1) contains the superdiagonal
    **          elements of the last nb columns of the reduced matrix;
    **          if uplo = 'l', e(1:nb) contains the subdiagonal elements of
    **          the first nb columns of the reduced matrix.
    **
    **  tau     (output) DATA TYPE array, dimension (n-1)
    **          the scalar factors of the elementary reflectors, stored in
    **          tau(n-nb:n-1) if uplo = 'u', and in tau(1:nb) if uplo = 'l'.
    **          see further details.
    **
    **  w       (output) DATA TYPE array, dimension (ldw,nb)
    **          the n-by-nb matrix w required to update the unreduced part
    **          of a.
    **
    **  ldw     (input) long int
    **          the leading dimension of the array w. ldw >= max(1,n).
    **
    **  further details
    **  ===============
    **
    **  if uplo = 'u', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(n) h(n-1) . . . h(n-nb+1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(i:n) = 0 and v(i-1) = 1; v(1:i-1) is stored on exit in a(1:i-1,i),
    **  and tau in tau(i-1).
    **
    **  if uplo = 'l', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(1) h(2) . . . h(nb).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i) = 0 and v(i+1) = 1; v(i+1:n) is stored on exit in a(i+1:n,i),
    **  and tau in tau(i).
    **
    **  the elements of the vectors v together form the n-by-nb matrix v
    **  which is needed, with ws, to apply the transformation to the unreduced
    **  part of the matrix, using a hermitian rank-2k update of the form:
    **  a := a - v*w' - w*v'.
    **
    **  the contents of a on exit are illustrated by the following examples
    **  with n = 5 and nb = 2:
    **
    **  if uplo = 'u':                       if uplo = 'l':
    **
    **    (  a   a   a   v4  v5 )              (  d                  )
    **    (      a   a   v4  v5 )              (  1   d              )
    **    (          a   1   v5 )              (  v1  1   a          )
    **    (              d   1  )              (  v1  v2  a   a      )
    **    (                  d  )              (  v1  v2  a   a   a  )
    **
    **  where d denotes a diagonal element of the reduced matrix, a denotes
    **  an element of the original matrix that is unchanged, and vi denotes
    **  an element of the vector defining h(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void latrd(
        const char* uplo,
        const long int* n,
        const long int* nb,
        float* a,
        const long int* lda,
        float* e,
        float* tau,
        float* ws,
        const long int* ldw,
        workspace<float> & w)
  */
  /*! fn
   inline void latrd(
        const char* uplo,
        const long int* n,
        const long int* nb,
        float* a,
        const long int* lda,
        float* e,
        float* tau,
        float* ws,
        const long int* ldw)
  */
  /*! fn
   inline void latrd(
        const char* uplo,
        const long int* n,
        const long int* nb,
        double* a,
        const long int* lda,
        double* e,
        double* tau,
        double* ws,
        const long int* ldw,
        workspace<double> & w)
  */
  /*! fn
   inline void latrd(
        const char* uplo,
        const long int* n,
        const long int* nb,
        double* a,
        const long int* lda,
        double* e,
        double* tau,
        double* ws,
        const long int* ldw)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slatrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATRD(NAME, T)\
inline void latrd(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* e,\
    T* tau,\
    T* ws,\
    const long int* ldw,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nb, a, lda, e, tau, ws, ldw);\
}\
inline void latrd(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    T* e,\
    T* tau,\
    T* ws,\
    const long int* ldw)\
{\
   workspace<T> w;\
   latrd(uplo, n, nb, a, lda, e, tau, ws, ldw, w);\
}\

    LPP_LATRD(slatrd, float)
    LPP_LATRD(dlatrd, double)

#undef LPP_LATRD


  // The following macro provides the 4 functions 
  /*! fn
   inline void latrd(
       const char* uplo,
       const long int* n,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       float* e,
       std::complex<float>* tau,
       std::complex<float>* ws,
       const long int* ldw,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void latrd(
       const char* uplo,
       const long int* n,
       const long int* nb,
       std::complex<float>* a,
       const long int* lda,
       float* e,
       std::complex<float>* tau,
       std::complex<float>* ws,
       const long int* ldw)
  */
  /*! fn
   inline void latrd(
       const char* uplo,
       const long int* n,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       double* e,
       std::complex<double>* tau,
       std::complex<double>* ws,
       const long int* ldw,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void latrd(
       const char* uplo,
       const long int* n,
       const long int* nb,
       std::complex<double>* a,
       const long int* lda,
       double* e,
       std::complex<double>* tau,
       std::complex<double>* ws,
       const long int* ldw)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clatrd.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATRD(NAME, T, TBASE)\
inline void latrd(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    TBASE* e,\
    T* tau,\
    T* ws,\
    const long int* ldw,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nb, a, lda, e, tau, ws, ldw);\
}\
inline void latrd(\
    const char* uplo,\
    const long int* n,\
    const long int* nb,\
    T* a,\
    const long int* lda,\
    TBASE* e,\
    T* tau,\
    T* ws,\
    const long int* ldw)\
{\
   workspace<T> w;\
   latrd(uplo, n, nb, a, lda, e, tau, ws, ldw, w);\
}\

    LPP_LATRD(clatrd, std::complex<float>,  float)
    LPP_LATRD(zlatrd, std::complex<double>, double)

#undef LPP_LATRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of latrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
