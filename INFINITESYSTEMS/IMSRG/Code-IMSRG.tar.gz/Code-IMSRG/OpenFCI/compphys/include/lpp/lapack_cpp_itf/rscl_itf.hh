#ifndef __PROJECT__LPP__FILE__RSCL_HH__INCLUDED
#define __PROJECT__LPP__FILE__RSCL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : rscl_itf.hh C++ interface to LAPACK (s,d,c,z)rscl
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file rscl_itf.hh
    (excerpt adapted from xrscl.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xrscl multiplies an n-element BASE DATA TYPE vector x by the BASE DATA TYPE scalar 1/a.
    **  this is done without overflow or underflow as long as
    **  the final result x/a does not overflow or underflow.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of components of the vector x.
    **
    **  sa      (input) BASE DATA TYPE
    **          the scalar a which is used to divide each component of x.
    **          sa must be >= 0, or the subroutine will divide by zero.
    **
    **  sx      (input/output) BASE DATA TYPE array, dimension
    **                         (1+(n-1)*abs(incx))
    **          the n-element vector x.
    **
    **  incx    (input) long int
    **          the increment between successive values of the vector sx.
    **          > 0:  sx(1) = x(1) and sx(1+(i-1)*incx) = x(i),     1< i<= n
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void rscl(
        const long int* n,
        const float* sa,
        float* sx,
        const long int* incx,
        workspace<float> & w)
  */
  /*! fn
   inline void rscl(
        const long int* n,
        const float* sa,
        float* sx,
        const long int* incx)
  */
  /*! fn
   inline void rscl(
        const long int* n,
        const double* sa,
        double* sx,
        const long int* incx,
        workspace<double> & w)
  */
  /*! fn
   inline void rscl(
        const long int* n,
        const double* sa,
        double* sx,
        const long int* incx)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from srscl.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_RSCL(NAME, T)\
inline void rscl(\
    const long int* n,\
    const T* sa,\
    T* sx,\
    const long int* incx,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, sa, sx, incx);\
}\
inline void rscl(\
    const long int* n,\
    const T* sa,\
    T* sx,\
    const long int* incx)\
{\
   workspace<T> w;\
   rscl(n, sa, sx, incx, w);\
}\

    LPP_RSCL(srscl, float)
    LPP_RSCL(drscl, double)

#undef LPP_RSCL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of rscl_itf.hh
// /////////////////////////////////////////////////////////////////////////////
