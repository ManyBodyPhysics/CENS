#ifndef __PROJECT__LPP__FILE__GEQPF_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEQPF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geqpf_itf.hh C++ interface to LAPACK (c,d,c,z)geqpf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geqpf_itf.hh
    (excerpt adapted from xgeqpf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this routine is deprecated and has been replaced by routine cgeqp3.
    **
    **  xgeqpf computes a qr factorization with column pivoting of a
    **  DATA TYPE m-by-n matrix a: a*p = q*r.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a. n >= 0
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, the upper triangle of the array contains the
    **          min(m,n)-by-n upper triangular matrix r; the elements
    **          below the diagonal, together with the array tau,
    **          represent the unitary matrix q as a product of
    **          min(m,n) elementary reflectors.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  jpvt    (input/output) long int array, dimension (n)
    **          on entry, if jpvt(i) .ne. 0, the i-th column of a is permuted
    **          to the front of a*p (a leading column); if jpvt(i) = 0,
    **          the i-th column of a is a free column.
    **          on exit, if jpvt(i) = k, then the i-th column of a*p
    **          was the k-th column of a.
    **
    **  tau     (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of elementary reflectors
    **
    **     q = h(1) h(2) . . . h(n)
    **
    **  each h(i) has the form
    **
    **     h = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i-1) = 0 and v(i) = 1; v(i+1:m) is stored on exit in a(i+1:m,i).
    **
    **  the matrix p is represented in jpvt as follows: if
    **     jpvt(j) = i
    **  then the jth column of p is the ith canonical unit vector.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geqpf(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geqpf(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void geqpf(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geqpf(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeqpf.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQPF(NAME, T)\
inline void geqpf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(3**n);\
    F77NAME( NAME )(m, n, a, lda, jpvt, tau, w.getw(), info);\
}\
inline void geqpf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geqpf(m, n, a, lda, jpvt, tau, info, w);\
}\

    LPP_GEQPF(sgeqpf, float)
    LPP_GEQPF(dgeqpf, double)

#undef LPP_GEQPF


  // The following macro provides the 4 functions 
  /*! fn
   inline void geqpf(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geqpf(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void geqpf(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geqpf(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeqpf.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQPF(NAME, T, TBASE)\
inline void geqpf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(2**n);\
    w.resizew(*n);\
    F77NAME( NAME )(m, n, a, lda, jpvt, tau, w.getw(), w.getrw(), info);\
}\
inline void geqpf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geqpf(m, n, a, lda, jpvt, tau, info, w);\
}\

    LPP_GEQPF(cgeqpf, std::complex<float>,  float)
    LPP_GEQPF(zgeqpf, std::complex<double>, double)

#undef LPP_GEQPF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geqpf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
