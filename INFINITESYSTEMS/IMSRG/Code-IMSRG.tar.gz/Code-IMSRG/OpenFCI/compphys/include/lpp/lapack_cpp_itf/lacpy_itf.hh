#ifndef __PROJECT__LPP__FILE__LACPY_HH__INCLUDED
#define __PROJECT__LPP__FILE__LACPY_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lacpy_itf.hh C++ interface to LAPACK (c,d,c,z)lacpy
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lacpy_itf.hh
    (excerpt adapted from xlacpy.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlacpy copies all or part of a two-dimensional matrix a to another
    **  matrix b.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies the part of the matrix a to be copied to b.
    **          = 'u':      upper triangular part
    **          = 'l':      lower triangular part
    **          otherwise:  all of the matrix a
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  a       (input) DATA TYPE array, dimension (lda,n)
    **          the m by n matrix a.  if uplo = 'u', only the upper trapezium
    **          is accessed; if uplo = 'l', only the lower trapezium is
    **          accessed.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  b       (output) DATA TYPE array, dimension (ldb,n)
    **          on exit, b = a in the locations specified by uplo.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,m).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lacpy(
        const char* uplo,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        workspace<float> & w)
  */
  /*! fn
   inline void lacpy(
        const char* uplo,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb)
  */
  /*! fn
   inline void lacpy(
        const char* uplo,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        workspace<double> & w)
  */
  /*! fn
   inline void lacpy(
        const char* uplo,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slacpy.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LACPY(NAME, T)\
inline void lacpy(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, m, n, a, lda, b, ldb);\
}\
inline void lacpy(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   lacpy(uplo, m, n, a, lda, b, ldb, w);\
}\

    LPP_LACPY(slacpy, float)
    LPP_LACPY(dlacpy, double)

#undef LPP_LACPY


  // The following macro provides the 4 functions 
  /*! fn
   inline void lacpy(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lacpy(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb)
  */
  /*! fn
   inline void lacpy(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lacpy(
       const char* uplo,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clacpy.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LACPY(NAME, T, TBASE)\
inline void lacpy(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, m, n, a, lda, b, ldb);\
}\
inline void lacpy(\
    const char* uplo,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   lacpy(uplo, m, n, a, lda, b, ldb, w);\
}\

    LPP_LACPY(clacpy, std::complex<float>,  float)
    LPP_LACPY(zlacpy, std::complex<double>, double)

#undef LPP_LACPY



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lacpy_itf.hh
// /////////////////////////////////////////////////////////////////////////////
