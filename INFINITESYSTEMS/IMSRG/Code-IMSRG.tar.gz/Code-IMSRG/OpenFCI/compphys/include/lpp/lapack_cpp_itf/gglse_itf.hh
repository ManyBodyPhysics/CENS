#ifndef __PROJECT__LPP__FILE__GGLSE_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGLSE_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gglse_itf.hh C++ interface to LAPACK (c,d,c,z)gglse
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gglse_itf.hh
    (excerpt adapted from xgglse.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgglse solves the linear equality-constrained least squares (lse)
    **  problem:
    **
    **          minimize || c - a*x ||_2   subject to   b*x = d
    **
    **  where a is an m-by-n matrix, b is a p-by-n matrix, c is a given
    **  m-vector, and d is a given p-vector. it is assumed that
    **  p <= n <= m+p, and
    **
    **           rank(b) = p and  rank( ( a ) ) = n.
    **                                ( ( b ) )
    **
    **  these conditions ensure that the lse problem has a unique solution,
    **  which is obtained using a grq factorization of the matrices b and a.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrices a and b. n >= 0.
    **
    **  p       (input) long int
    **          the number of rows of the matrix b. 0 <= p <= n <= m+p.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, a is destroyed.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the p-by-n matrix b.
    **          on exit, b is destroyed.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,p).
    **
    **  c       (input/output) DATA TYPE array, dimension (m)
    **          on entry, c contains the right hand side vector for the
    **          least squares part of the lse problem.
    **          on exit, the residual sum of squares for the solution
    **          is given by the sum of squares of elements n-p+1 to m of
    **          vector c.
    **
    **  d       (input/output) DATA TYPE array, dimension (p)
    **          on entry, d contains the right hand side vector for the
    **          constrained equation.
    **          on exit, d is destroyed.
    **
    **  x       (output) DATA TYPE array, dimension (n)
    **          on exit, x is the solution of the lse problem.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gglse(
        const long int* m,
        const long int* n,
        const long int* p,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        float* c,
        const float* d,
        float* x,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gglse(
        const long int* m,
        const long int* n,
        const long int* p,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        float* c,
        const float* d,
        float* x,
        long int* info)
  */
  /*! fn
   inline void gglse(
        const long int* m,
        const long int* n,
        const long int* p,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        double* c,
        const double* d,
        double* x,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gglse(
        const long int* m,
        const long int* n,
        const long int* p,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        double* c,
        const double* d,
        double* x,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgglse.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,M+N+P).
  //    *          For optimum performance LWORK >= P+min(M,N)+max(M,N)*NB,
  //    *          where NB is an upper bound for the optimal blocksizes for
  //    *          SGEQRF, SGERQF, SORMQR and SORMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGLSE(NAME, T)\
inline void gglse(\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* c,\
    const T* d,\
    T* x,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, p, a, lda, b, ldb, c, d, x, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, p, a, lda, b, ldb, c, d, x, w.getw(), &w.neededsize(), info);\
}\
inline void gglse(\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* c,\
    const T* d,\
    T* x,\
    long int* info)\
{\
   workspace<T> w;\
   gglse(m, n, p, a, lda, b, ldb, c, d, x, info, w);\
}\

    LPP_GGLSE(sgglse, float)
    LPP_GGLSE(dgglse, double)

#undef LPP_GGLSE


  // The following macro provides the 4 functions 
  /*! fn
   inline void gglse(
       const long int* m,
       const long int* n,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const std::complex<float>* d,
       std::complex<float>* x,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gglse(
       const long int* m,
       const long int* n,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const std::complex<float>* d,
       std::complex<float>* x,
       long int* info)
  */
  /*! fn
   inline void gglse(
       const long int* m,
       const long int* n,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const std::complex<double>* d,
       std::complex<double>* x,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gglse(
       const long int* m,
       const long int* n,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const std::complex<double>* d,
       std::complex<double>* x,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgglse.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,M+N+P).
  //    *          For optimum performance LWORK >= P+min(M,N)+max(M,N)*NB,
  //    *          where NB is an upper bound for the optimal blocksizes for
  //    *          CGEQRF, CGERQF, CUNMQR and CUNMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGLSE(NAME, T, TBASE)\
inline void gglse(\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* c,\
    const T* d,\
    T* x,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, p, a, lda, b, ldb, c, d, x, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, n, p, a, lda, b, ldb, c, d, x, w.getw(), &w.neededsize(), info);\
}\
inline void gglse(\
    const long int* m,\
    const long int* n,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    T* c,\
    const T* d,\
    T* x,\
    long int* info)\
{\
   workspace<T> w;\
   gglse(m, n, p, a, lda, b, ldb, c, d, x, info, w);\
}\

    LPP_GGLSE(cgglse, std::complex<float>,  float)
    LPP_GGLSE(zgglse, std::complex<double>, double)

#undef LPP_GGLSE



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gglse_itf.hh
// /////////////////////////////////////////////////////////////////////////////
