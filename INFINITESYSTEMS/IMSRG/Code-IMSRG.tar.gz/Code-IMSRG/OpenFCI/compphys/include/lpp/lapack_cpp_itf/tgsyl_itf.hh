#ifndef __PROJECT__LPP__FILE__TGSYL_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGSYL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgsyl_itf.hh C++ interface to LAPACK (s,d,c,z)tgsyl
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgsyl_itf.hh
    (excerpt adapted from xtgsyl.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgsyl solves the generalized sylvester equation:
    **
    **              a * r - l * b = scale * c            (1)
    **              d * r - l * e = scale * f
    **
    **  where r and l are unknown m-by-n matrices, (a, d), (b, e) and
    **  (c, f) are given matrix pairs of size m-by-m, n-by-n and m-by-n,
    **  respectively, with DATA TYPE entries. a, b, d and e are upper
    **  triangular (i.e., (a,d) and (b,e) in generalized schur form).
    **
    **  the solution (r, l) overwrites (c, f). 0 <= scale <= 1
    **  is an output scaling factor chosen to avoid overflow.
    **
    **  in matrix notation (1) is equivalent to solve zx = scale*b, where z
    **  is defined as
    **
    **         z = [ kron(in, a)  -kron(b', im) ]        (2)
    **             [ kron(in, d)  -kron(e', im) ],
    **
    **  here ix is the identity matrix of size x and x' is the conjugate
    **  transpose of x. kron(x, y) is the kronecker product between the
    **  matrices x and y.
    **
    **  if trans = 'c', y in the conjugate transposed system z'*y = scale*b
    **  is solved for, which is equivalent to solve for r and l in
    **
    **              a' * r + d' * l = scale * c           (3)
    **              r * b' + l * e' = scale * -f
    **
    **  this case (trans = 'c') is used to compute an one-norm-based estimate
    **  of dif[(a,d), (b,e)], the separation between the matrix pairs (a,d)
    **  and (b,e), using clacon.
    **
    **  if ijob >= 1, xtgsyl computes a frobenius norm-based estimate of
    **  dif[(a,d),(b,e)]. that is, the reciprocal of a lower bound on the
    **  reciprocal of the smallest singular value of z.
    **
    **  this is a level-3 blas algorithm.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) char
    **          = 'n': solve the generalized sylvester equation (1).
    **          = 'c': solve the "conjugate transposed" system (3).
    **
    **  ijob    (input) long int
    **          specifies what kind of functionality to be performed.
    **          =0: solve (1) only.
    **          =1: the functionality of 0 and 3.
    **          =2: the functionality of 0 and 4.
    **          =3: only an estimate of dif[(a,d), (b,e)] is computed.
    **              (look ahead strategy is used).
    **          =4: only an estimate of dif[(a,d), (b,e)] is computed.
    **              (cgecon on sub-systems is used).
    **          not referenced if trans = 'c'.
    **
    **  m       (input) long int
    **          the order of the matrices a and d, and the row dimension of
    **          the matrices c, f, r and l.
    **
    **  n       (input) long int
    **          the order of the matrices b and e, and the column dimension
    **          of the matrices c, f, r and l.
    **
    **  a       (input) DATA TYPE array, dimension (lda, m)
    **          the upper triangular matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1, m).
    **
    **  b       (input) DATA TYPE array, dimension (ldb, n)
    **          the upper triangular matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1, n).
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc, n)
    **          on entry, c contains the right-hand-side of the first matrix
    **          equation in (1) or (3).
    **          on exit, if ijob = 0, 1 or 2, c has been overwritten by
    **          the solution r. if ijob = 3 or 4 and trans = 'n', c holds r,
    **          the solution achieved during the computation of the
    **          dif-estimate.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1, m).
    **
    **  d       (input) DATA TYPE array, dimension (ldd, m)
    **          the upper triangular matrix d.
    **
    **  ldd     (input) long int
    **          the leading dimension of the array d. ldd >= max(1, m).
    **
    **  e       (input) DATA TYPE array, dimension (lde, n)
    **          the upper triangular matrix e.
    **
    **  lde     (input) long int
    **          the leading dimension of the array e. lde >= max(1, n).
    **
    **  f       (input/output) DATA TYPE array, dimension (ldf, n)
    **          on entry, f contains the right-hand-side of the second matrix
    **          equation in (1) or (3).
    **          on exit, if ijob = 0, 1 or 2, f has been overwritten by
    **          the solution l. if ijob = 3 or 4 and trans = 'n', f holds l,
    **          the solution achieved during the computation of the
    **          dif-estimate.
    **
    **  ldf     (input) long int
    **          the leading dimension of the array f. ldf >= max(1, m).
    **
    **  dif     (output) BASE DATA TYPE
    **          on exit dif is the reciprocal of a lower bound of the
    **          reciprocal of the dif-function, i.e. dif is an upper bound of
    **          dif[(a,d), (b,e)] = sigma-min(z), where z as in (2).
    **          if ijob = 0 or trans = 'c', dif is not referenced.
    **
    **  scale   (output) BASE DATA TYPE
    **          on exit scale is the scaling factor in (1) or (3).
    **          if 0 < scale < 1, c and f hold the solutions r and l, resp.,
    **          to a slightly perturbed system but the input matrices a, b,
    **          d and e have not been changed. if scale = 0, r and l will
    **          hold the solutions to the homogenious system with c = f = 0.
    **
    **
    **
    **
    **  info    (output) long int
    **            =0: successful exit
    **            <0: if info = -i, the i-th argument had an illegal value.
    **            >0: (a, d) and (b, e) have common or very close
    **                eigenvalues.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  [1] b. kagstrom and p. poromaa, lapack-style algorithms and software
    **      for solving the generalized sylvester equation and estimating the
    **      separation between regular matrix pairs, report uminf - 93.23,
    **      department of computing science, umea university, s-901 87 umea,
    **      sweden, december 1993, revised april 1994, also as lapack WORKing
    **      note 75.  to appear in acm trans. on math. software, vol 22,
    **      no 1, 1996.
    **
    **  [2] b. kagstrom, a perturbation analysis of the generalized sylvester
    **      equation (ar - lb, dr - le ) = (c, f), siam j. matrix anal.
    **      appl., 15(4):1045-1060, 1994.
    **
    **  [3] b. kagstrom and l. westin, generalized schur methods with
    **      condition estimators for solving the generalized sylvester
    **      equation, ieee transactions on automatic control, vol. 34, no. 7,
    **      july 1989, pp 745-751.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsyl(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        const float* d,
        const long int* ldd,
        const float* e,
        const long int* lde,
        float* f,
        const long int* ldf,
        float* scale,
        float* dif,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgsyl(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        const float* d,
        const long int* ldd,
        const float* e,
        const long int* lde,
        float* f,
        const long int* ldf,
        float* scale,
        float* dif,
        long int* info)
  */
  /*! fn
   inline void tgsyl(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        const double* d,
        const long int* ldd,
        const double* e,
        const long int* lde,
        double* f,
        const long int* ldf,
        double* scale,
        double* dif,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgsyl(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        const double* d,
        const long int* ldd,
        const double* e,
        const long int* lde,
        double* f,
        const long int* ldf,
        double* scale,
        double* dif,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgsyl.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          If IJOB = 0, WORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK > = 1.
  //    *          If IJOB = 1 or 2 and TRANS = 'N', LWORK >= 2*M*N.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (M+N+6)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSYL(NAME, T)\
inline void tgsyl(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    T* scale,\
    T* dif,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*m)+(*n)+6);\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, w.getw(), w.query(), w.getiw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, w.getw(), &w.neededsize(), w.getiw(), info);\
}\
inline void tgsyl(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    T* scale,\
    T* dif,\
    long int* info)\
{\
   workspace<T> w;\
   tgsyl(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, info, w);\
}\

    LPP_TGSYL(stgsyl, float)
    LPP_TGSYL(dtgsyl, double)

#undef LPP_TGSYL


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsyl(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       const std::complex<float>* d,
       const long int* ldd,
       const std::complex<float>* e,
       const long int* lde,
       std::complex<float>* f,
       const long int* ldf,
       float* scale,
       float* dif,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgsyl(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       const std::complex<float>* d,
       const long int* ldd,
       const std::complex<float>* e,
       const long int* lde,
       std::complex<float>* f,
       const long int* ldf,
       float* scale,
       float* dif,
       long int* info)
  */
  /*! fn
   inline void tgsyl(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       const std::complex<double>* d,
       const long int* ldd,
       const std::complex<double>* e,
       const long int* lde,
       std::complex<double>* f,
       const long int* ldf,
       double* scale,
       double* dif,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgsyl(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       const std::complex<double>* d,
       const long int* ldd,
       const std::complex<double>* e,
       const long int* lde,
       std::complex<double>* f,
       const long int* ldf,
       double* scale,
       double* dif,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgsyl.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          IF IJOB = 0, WORK is not referenced.  Otherwise,
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK > = 1.
  //    *          If IJOB = 1 or 2 and TRANS = 'N', LWORK >= 2*M*N.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (M+N+2)
  //    *          If IJOB = 0, IWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSYL(NAME, T, TBASE)\
inline void tgsyl(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    TBASE* scale,\
    TBASE* dif,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*m)+(*n)+2);\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, w.getw(), w.query(), w.getiw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, w.getw(), &w.neededsize(), w.getiw(), info);\
}\
inline void tgsyl(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    TBASE* scale,\
    TBASE* dif,\
    long int* info)\
{\
   workspace<T> w;\
   tgsyl(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, dif, info, w);\
}\

    LPP_TGSYL(ctgsyl, std::complex<float>, float)
    LPP_TGSYL(ztgsyl, std::complex<double>, double)

#undef LPP_TGSYL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgsyl_itf.hh
// /////////////////////////////////////////////////////////////////////////////
