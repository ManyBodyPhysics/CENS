#ifndef __PROJECT__LPP__FILE__LAED5_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED5_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed5_itf.hh C++ interface to LAPACK (s,d,c,z)laed5
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed5_itf.hh
    (excerpt adapted from xlaed5.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this subroutine computes the i-th eigenvalue of a symmetric rank-one
    **  modification of a 2-by-2 diagonal matrix
    **
    **             diag( d )  +  rho *  z * transpose(z) .
    **
    **  the diagonal elements in the array d are assumed to satisfy
    **
    **             d(i) < d(j)  for  i < j .
    **
    **  we also assume rho > 0 and that the euclidean norm of the vector
    **  z is one.
    **
    **  arguments
    **  =========
    **
    **  i      (input) long int
    **         the index of the eigenvalue to be computed.  i = 1 or i = 2.
    **
    **  d      (input) BASE DATA TYPE array, dimension (2)
    **         the original eigenvalues.  we assume d(1) < d(2).
    **
    **  z      (input) BASE DATA TYPE array, dimension (2)
    **         the components of the updating vector.
    **
    **  delta  (output) BASE DATA TYPE array, dimension (2)
    **         the vector delta contains the information necessary
    **         to construct the eigenvectors.
    **
    **  rho    (input) BASE DATA TYPE
    **         the scalar in the symmetric updating formula.
    **
    **  dlam   (output) BASE DATA TYPE
    **         the computed lambda_i, the i-th updated eigenvalue.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ren-cang li, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed5(
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dlam,
        workspace<float> & w)
  */
  /*! fn
   inline void laed5(
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* dlam)
  */
  /*! fn
   inline void laed5(
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dlam,
        workspace<double> & w)
  */
  /*! fn
   inline void laed5(
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* dlam)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed5.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED5(NAME, T)\
inline void laed5(\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dlam,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(i, d, z, delta, rho, dlam);\
}\
inline void laed5(\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* dlam)\
{\
   workspace<T> w;\
   laed5(i, d, z, delta, rho, dlam, w);\
}\

    LPP_LAED5(slaed5, float)
    LPP_LAED5(dlaed5, double)

#undef LPP_LAED5



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed5_itf.hh
// /////////////////////////////////////////////////////////////////////////////
