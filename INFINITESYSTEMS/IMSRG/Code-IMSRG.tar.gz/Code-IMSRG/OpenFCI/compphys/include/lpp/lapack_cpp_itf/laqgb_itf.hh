#ifndef __PROJECT__LPP__FILE__LAQGB_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQGB_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqgb_itf.hh C++ interface to LAPACK (c,d,c,z)laqgb
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqgb_itf.hh
    (excerpt adapted from xlaqgb.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqgb equilibrates a general m by n band matrix a with kl
    **  subdiagonals and ku superdiagonals using the row and scaling factors
    **  in the vectors r and c.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  kl      (input) long int
    **          the number of subdiagonals within the band of a.  kl >= 0.
    **
    **  ku      (input) long int
    **          the number of superdiagonals within the band of a.  ku >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the matrix a in band storage, in rows 1 to kl+ku+1.
    **          the j-th column of a is stored in the j-th column of the
    **          array ab as follows:
    **          ab(ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(m,j+kl)
    **
    **          on exit, the equilibrated matrix, in the same storage format
    **          as a.  see equed for the form of the equilibrated matrix.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  lda >= kl+ku+1.
    **
    **  r       (output) BASE DATA TYPE array, dimension (m)
    **          the row scale factors for a.
    **
    **  c       (output) BASE DATA TYPE array, dimension (n)
    **          the column scale factors for a.
    **
    **  rowcnd  (output) BASE DATA TYPE
    **          ratio of the smallest r(i) to the largest r(i).
    **
    **  colcnd  (output) BASE DATA TYPE
    **          ratio of the smallest c(i) to the largest c(i).
    **
    **  amax    (input) BASE DATA TYPE
    **          absolute value of largest matrix entry.
    **
    **  equed   (output) char
    **          specifies the form of equilibration that was done.
    **          = 'n':  no equilibration
    **          = 'r':  row equilibration, i.e., a has been premultiplied by
    **                  diag(r).
    **          = 'c':  column equilibration, i.e., a has been postmultiplied
    **                  by diag(c).
    **          = 'b':  both row and column equilibration, i.e., a has been
    **                  replaced by diag(r) * a * diag(c).
    **
    **  internal parameters
    **  ===================
    **
    **  thresh is a threshold value used to decide if row or column scaling
    **  should be done based on the ratio of the row or column scaling
    **  factors.  if rowcnd < thresh, row scaling is done, and if
    **  colcnd < thresh, column scaling is done.
    **
    **  large and small are threshold values used to decide if row scaling
    **  should be done based on the absolute size of the largest matrix
    **  element.  if amax > large or amax < small, row scaling is done.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqgb(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        float* ab,
        const long int* ldab,
        float* r,
        float* c,
        float* rowcnd,
        float* colcnd,
        const float* amax,
        char* equed,
        workspace<float> & w)
  */
  /*! fn
   inline void laqgb(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        float* ab,
        const long int* ldab,
        float* r,
        float* c,
        float* rowcnd,
        float* colcnd,
        const float* amax,
        char* equed)
  */
  /*! fn
   inline void laqgb(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        double* ab,
        const long int* ldab,
        double* r,
        double* c,
        double* rowcnd,
        double* colcnd,
        const double* amax,
        char* equed,
        workspace<double> & w)
  */
  /*! fn
   inline void laqgb(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        double* ab,
        const long int* ldab,
        double* r,
        double* c,
        double* rowcnd,
        double* colcnd,
        const double* amax,
        char* equed)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaqgb.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQGB(NAME, T)\
inline void laqgb(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    T* r,\
    T* c,\
    T* rowcnd,\
    T* colcnd,\
    const T* amax,\
    char* equed,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, equed);\
}\
inline void laqgb(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    T* r,\
    T* c,\
    T* rowcnd,\
    T* colcnd,\
    const T* amax,\
    char* equed)\
{\
   workspace<T> w;\
   laqgb(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, equed, w);\
}\

    LPP_LAQGB(slaqgb, float)
    LPP_LAQGB(dlaqgb, double)

#undef LPP_LAQGB


  // The following macro provides the 4 functions 
  /*! fn
   inline void laqgb(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       std::complex<float>* ab,
       const long int* ldab,
       float* r,
       float* c,
       float* rowcnd,
       float* colcnd,
       const float* amax,
       char* equed,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laqgb(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       std::complex<float>* ab,
       const long int* ldab,
       float* r,
       float* c,
       float* rowcnd,
       float* colcnd,
       const float* amax,
       char* equed)
  */
  /*! fn
   inline void laqgb(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       std::complex<double>* ab,
       const long int* ldab,
       double* r,
       double* c,
       double* rowcnd,
       double* colcnd,
       const double* amax,
       char* equed,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laqgb(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       std::complex<double>* ab,
       const long int* ldab,
       double* r,
       double* c,
       double* rowcnd,
       double* colcnd,
       const double* amax,
       char* equed)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claqgb.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQGB(NAME, T, TBASE)\
inline void laqgb(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    TBASE* r,\
    TBASE* c,\
    TBASE* rowcnd,\
    TBASE* colcnd,\
    const TBASE* amax,\
    char* equed,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, equed);\
}\
inline void laqgb(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    T* ab,\
    const long int* ldab,\
    TBASE* r,\
    TBASE* c,\
    TBASE* rowcnd,\
    TBASE* colcnd,\
    const TBASE* amax,\
    char* equed)\
{\
   workspace<T> w;\
   laqgb(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, equed, w);\
}\

    LPP_LAQGB(claqgb, std::complex<float>,  float)
    LPP_LAQGB(zlaqgb, std::complex<double>, double)

#undef LPP_LAQGB



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqgb_itf.hh
// /////////////////////////////////////////////////////////////////////////////
