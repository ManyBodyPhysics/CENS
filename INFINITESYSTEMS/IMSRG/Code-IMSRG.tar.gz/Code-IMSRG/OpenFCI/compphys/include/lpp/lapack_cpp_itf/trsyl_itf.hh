#ifndef __PROJECT__LPP__FILE__TRSYL_HH__INCLUDED
#define __PROJECT__LPP__FILE__TRSYL_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : trsyl_itf.hh C++ interface to LAPACK (c,d,c,z)trsyl
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file trsyl_itf.hh
    (excerpt adapted from xtrsyl.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtrsyl solves the DATA TYPE sylvester matrix equation:
    **
    **     op(a)*x + x*op(b) = scale*c or
    **     op(a)*x - x*op(b) = scale*c,
    **
    **  where op(a) = a or a**h, and a and b are both upper triangular. a is
    **  m-by-m and b is n-by-n; the right hand side c and the solution x are
    **  m-by-n; and scale is an output scale factor, set <= 1 to avoid
    **  overflow in x.
    **
    **  arguments
    **  =========
    **
    **  trana   (input) char
    **          specifies the option op(a):
    **          = 'n': op(a) = a    (no transpose)
    **          = 'c': op(a) = a**h (conjugate transpose)
    **
    **  tranb   (input) char
    **          specifies the option op(b):
    **          = 'n': op(b) = b    (no transpose)
    **          = 'c': op(b) = b**h (conjugate transpose)
    **
    **  isgn    (input) long int
    **          specifies the sign in the equation:
    **          = +1: solve op(a)*x + x*op(b) = scale*c
    **          = -1: solve op(a)*x - x*op(b) = scale*c
    **
    **  m       (input) long int
    **          the order of the matrix a, and the number of rows in the
    **          matrices x and c. m >= 0.
    **
    **  n       (input) long int
    **          the order of the matrix b, and the number of columns in the
    **          matrices x and c. n >= 0.
    **
    **  a       (input) DATA TYPE array, dimension (lda,m)
    **          the upper triangular matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  b       (input) DATA TYPE array, dimension (ldb,n)
    **          the upper triangular matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n right hand side matrix c.
    **          on exit, c is overwritten by the solution matrix x.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m)
    **
    **  scale   (output) BASE DATA TYPE
    **          the scale factor, scale, set <= 1 to avoid overflow in x.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          = 1: a and b have common or very close eigenvalues; perturbed
    **               values were used to solve the equation (but the matrices
    **               a and b are unchanged).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void trsyl(
        const char* trana,
        const char* tranb,
        const long int* isgn,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        float* scale,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void trsyl(
        const char* trana,
        const char* tranb,
        const long int* isgn,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        float* scale,
        long int* info)
  */
  /*! fn
   inline void trsyl(
        const char* trana,
        const char* tranb,
        const long int* isgn,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        double* scale,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void trsyl(
        const char* trana,
        const char* tranb,
        const long int* isgn,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        double* scale,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from strsyl.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSYL(NAME, T)\
inline void trsyl(\
    const char* trana,\
    const char* tranb,\
    const long int* isgn,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    T* scale,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trana, tranb, isgn, m, n, a, lda, b, ldb, c, ldc, scale, info);\
}\
inline void trsyl(\
    const char* trana,\
    const char* tranb,\
    const long int* isgn,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    T* scale,\
    long int* info)\
{\
   workspace<T> w;\
   trsyl(trana, tranb, isgn, m, n, a, lda, b, ldb, c, ldc, scale, info, w);\
}\

    LPP_TRSYL(strsyl, float)
    LPP_TRSYL(dtrsyl, double)

#undef LPP_TRSYL


  // The following macro provides the 4 functions 
  /*! fn
   inline void trsyl(
       const char* trana,
       const char* tranb,
       const long int* isgn,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       float* scale,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void trsyl(
       const char* trana,
       const char* tranb,
       const long int* isgn,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       float* scale,
       long int* info)
  */
  /*! fn
   inline void trsyl(
       const char* trana,
       const char* tranb,
       const long int* isgn,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       double* scale,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void trsyl(
       const char* trana,
       const char* tranb,
       const long int* isgn,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       double* scale,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctrsyl.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSYL(NAME, T, TBASE)\
inline void trsyl(\
    const char* trana,\
    const char* tranb,\
    const long int* isgn,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    TBASE* scale,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trana, tranb, isgn, m, n, a, lda, b, ldb, c, ldc, scale, info);\
}\
inline void trsyl(\
    const char* trana,\
    const char* tranb,\
    const long int* isgn,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    TBASE* scale,\
    long int* info)\
{\
   workspace<T> w;\
   trsyl(trana, tranb, isgn, m, n, a, lda, b, ldb, c, ldc, scale, info, w);\
}\

    LPP_TRSYL(ctrsyl, std::complex<float>,  float)
    LPP_TRSYL(ztrsyl, std::complex<double>, double)

#undef LPP_TRSYL



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of trsyl_itf.hh
// /////////////////////////////////////////////////////////////////////////////
