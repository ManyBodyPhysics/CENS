#ifndef __PROJECT__LPP__FILE__GESDD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GESDD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gesdd_itf.hh C++ interface to LAPACK (c,d,c,z)gesdd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :
//  note        : a bug has been corrected in FORTRAN to the size claimed by
//              : query(),  but it is not available in most compiled LAPACK
//              : package,  so it is set manually if needed
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gesdd_itf.hh
    (excerpt adapted from xgesdd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgesdd computes the singular value decomposition (svd) of a DATA TYPE
    **  m-by-n matrix a, optionally computing the left and/or right singular
    **  vectors, by using divide-and-conquer method. the svd is written
    **
    **       a = u * sigma * conjugate-transpose(v)
    **
    **  where sigma is an m-by-n matrix which is zero except for its
    **  min(m,n) diagonal elements, u is an m-by-m unitary matrix, and
    **  v is an n-by-n unitary matrix.  the diagonal elements of sigma
    **  are the singular values of a; they are BASE DATA TYPE and non-negative, and
    **  are returned in descending order.  the first min(m,n) columns of
    **  u and v are the left and right singular vectors of a.
    **
    **  note that the routine returns vt = v**h, not v.
    **
    **  the divide and conquer algorithm makes very mild assumptions about
    **  floating point arithmetic. it will WORK on machines with a guard
    **  digit in add/subtract, or on those binary machines without guard
    **  digits which subtract like the cray x-mp, cray y-mp, cray c-90, or
    **  cray-2. it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          specifies options for computing all or part of the matrix u:
    **          = 'a':  all m columns of u and all n rows of v**h are
    **                  returned in the arrays u and vt;
    **          = 's':  the first min(m,n) columns of u and the first
    **                  min(m,n) rows of v**h are returned in the arrays u
    **                  and vt;
    **          = 'o':  if m >= n, the first n columns of u are overwritten
    **                  on the array a and all rows of v**h are returned in
    **                  the array vt;
    **                  otherwise, all columns of u are returned in the
    **                  array u and the first m rows of v**h are overwritten
    **                  in the array vt;
    **          = 'n':  no columns of u or rows of v**h are computed.
    **
    **  m       (input) long int
    **          the number of rows of the input matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the input matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit,
    **          if jobz = 'o',  a is overwritten with the first n columns
    **                          of u (the left singular vectors, stored
    **                          columnwise) if m >= n;
    **                          a is overwritten with the first m rows
    **                          of v**h (the right singular vectors, stored
    **                          rowwise) otherwise.
    **          if jobz .ne. 'o', the contents of a are destroyed.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  s       (output) BASE DATA TYPE array, dimension (min(m,n))
    **          the singular values of a, sorted so that s(i) >= s(i+1).
    **
    **  u       (output) DATA TYPE array, dimension (ldu,ucol)
    **          ucol = m if jobz = 'a' or jobz = 'o' and m < n;
    **          ucol = min(m,n) if jobz = 's'.
    **          if jobz = 'a' or jobz = 'o' and m < n, u contains the m-by-m
    **          unitary matrix u;
    **          if jobz = 's', u contains the first min(m,n) columns of u
    **          (the left singular vectors, stored columnwise);
    **          if jobz = 'o' and m >= n, or jobz = 'n', u is not referenced.
    **
    **  ldu     (input) long int
    **          the leading dimension of the array u.  ldu >= 1; if
    **          jobz = 's' or 'a' or jobz = 'o' and m < n, ldu >= m.
    **
    **  vt      (output) DATA TYPE array, dimension (ldvt,n)
    **          if jobz = 'a' or jobz = 'o' and m >= n, vt contains the
    **          n-by-n unitary matrix v**h;
    **          if jobz = 's', vt contains the first min(m,n) rows of
    **          v**h (the right singular vectors, stored rowwise);
    **          if jobz = 'o' and m < n, or jobz = 'n', vt is not referenced.
    **
    **  ldvt    (input) long int
    **          the leading dimension of the array vt.  ldvt >= 1; if
    **          jobz = 'a' or jobz = 'o' and m >= n, ldvt >= n;
    **          if jobz = 's', ldvt >= min(m,n).
    **
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  the updating process of sbdsdc did not converge.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gesdd(
        const char* jobz,
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* s,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gesdd(
        const char* jobz,
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* s,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        long int* info)
  */
  /*! fn
   inline void gesdd(
        const char* jobz,
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* s,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gesdd(
        const char* jobz,
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* s,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgesdd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK;
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= 1.
  //    *          If JOBZ = 'N',
  //    *            LWORK >= max(14*min(M,N)+4, 10*min(M,N)+2+
  //    *                     SMLSIZ*(SMLSIZ+8)) + max(M,N)
  //    *          where SMLSIZ is returned by ILAENV and is equal to the
  //    *          maximum size of the subproblems at the bottom of the
  //    *          computation tree (usually about 25).
  //    *          If JOBZ = 'O',
  //    *            LWORK >= 5*min(M,N)*min(M,N) + max(M,N) + 9*min(M,N).
  //    *          If JOBZ = 'S' or 'A'
  //    *            LWORK >= 4*min(M,N)*min(M,N) + max(M,N) + 9*min(M,N).
  //    *          For good performance, LWORK should generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (8*min(M,N))
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GESDD(NAME, T)\
inline void gesdd(\
    const char* jobz,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* s,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(8*std::min(*m,*n));                                        \
  F77NAME( NAME )(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, w.getw(), w.query(), w.getiw(), info); \
  w.resizew(w.neededsize());\
  w.resizew(std::max(w.neededsize(), (*m+*n)*EnvBlockSize(9, "NAME", "")));                      \
  F77NAME( NAME )(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, w.getw(), &w.neededsize(std::max(w.neededsize(), (*m+*n)*EnvBlockSize(9, "NAME", ""))), w.getiw(), info); \
}\
inline void gesdd(\
    const char* jobz,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* s,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* info)\
{\
   workspace<T> w;\
   gesdd(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, info, w);\
}\

    LPP_GESDD(sgesdd, float)
    LPP_GESDD(dgesdd, double)

#undef LPP_GESDD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gesdd(
       const char* jobz,
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       float* s,
       std::complex<float>* u,
       const long int* ldu,
       std::complex<float>* vt,
       const long int* ldvt,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gesdd(
       const char* jobz,
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       float* s,
       std::complex<float>* u,
       const long int* ldu,
       std::complex<float>* vt,
       const long int* ldvt,
       long int* info)
  */
  /*! fn
   inline void gesdd(
       const char* jobz,
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       double* s,
       std::complex<double>* u,
       const long int* ldu,
       std::complex<double>* vt,
       const long int* ldvt,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gesdd(
       const char* jobz,
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       double* s,
       std::complex<double>* u,
       const long int* ldu,
       std::complex<double>* vt,
       const long int* ldvt,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from xgesdd.f)
  //    *  WORK    (workspace/output) DATA array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= 1.
  //    *          if JOBZ = 'N', LWORK >= 2*min(M,N)+max(M,N).
  //    *          if JOBZ = 'O',
  //    *                LWORK >= 2*min(M,N)*min(M,N)+2*min(M,N)+max(M,N).
  //    *          if JOBZ = 'S' or 'A',
  //    *                LWORK >= min(M,N)*min(M,N)+2*min(M,N)+max(M,N).
  //    *          For good performance, LWORK should generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) DATA BASE array, dimension (LRWORK)
  //    *          If JOBZ = 'N', LRWORK >= 5*min(M,N).
  //    *          Otherwise, LRWORK >= 5*min(M,N)*min(M,N) + 7*min(M,N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (8*min(M,N))
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GESDD(NAME, T, TBASE)\
inline void gesdd(\
    const char* jobz,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    TBASE* s,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizerw((lower(*jobz) == 'n') ? 5*std::min(*m,*n) : (5*std::min(*m, *n)+ 7)*std::min(*m,*n) ); \
  w.resizeiw(8*std::min(*m,*n));                                        \
  F77NAME( NAME )(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, w.getw(), w.query(), w.getrw(), w.getiw(), info); \
  w.resizew(w.neededsize());                                            \
  w.resizew(std::max(w.neededsize(), (*m+*n)*EnvBlockSize(9, "NAME", "")));                      \
  F77NAME( NAME )(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, w.getw(), &w.neededsize(std::max(w.neededsize(), (*m+*n)*EnvBlockSize(9, "NAME", ""))), w.getrw(), w.getiw(), info); \
}\
inline void gesdd(\
    const char* jobz,\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    TBASE* s,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    long int* info)\
{\
   workspace<T> w;\
   gesdd(jobz, m, n, a, lda, s, u, ldu, vt, ldvt, info, w);\
}\

    LPP_GESDD(cgesdd, std::complex<float>,  float)
    LPP_GESDD(zgesdd, std::complex<double>, double)

#undef LPP_GESDD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gesdd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
