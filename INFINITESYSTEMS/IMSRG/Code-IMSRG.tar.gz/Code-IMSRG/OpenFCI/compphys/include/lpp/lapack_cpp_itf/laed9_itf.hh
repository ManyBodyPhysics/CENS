#ifndef __PROJECT__LPP__FILE__LAED9_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED9_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed9_itf.hh C++ interface to LAPACK (s,d,c,z)laed9
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed9_itf.hh
    (excerpt adapted from xlaed9.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed9 finds the roots of the secular equation, as defined by the
    **  values in d, z, and rho, between kstart and kstop.  it makes the
    **  appropriate calls to dlaed4 and then stores the new matrix of
    **  eigenvectors for use in calculating the next level of z vectors.
    **
    **  arguments
    **  =========
    **
    **  k       (input) long int
    **          the number of terms in the rational function to be solved by
    **          dlaed4.  k >= 0.
    **
    **  kstart  (input) long int
    **  kstop   (input) long int
    **          the updated eigenvalues lambda(i), kstart <= i <= kstop
    **          are to be computed.  1 <= kstart <= kstop <= k.
    **
    **  n       (input) long int
    **          the number of rows and columns in the q matrix.
    **          n >= k (delation may result in n > k).
    **
    **  d       (output) BASE DATA TYPE array, dimension (n)
    **          d(i) contains the updated eigenvalues
    **          for kstart <= i <= kstop.
    **
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.  ldq >= max( 1, n ).
    **
    **  rho     (input) BASE DATA TYPE
    **          the value of the parameter in the rank one update equation.
    **          rho >= 0 required.
    **
    **  dlamda  (input) BASE DATA TYPE array, dimension (k)
    **          the first k elements of this array contain the old roots
    **          of the deflated updating problem.  these are the poles
    **          of the secular equation.
    **
    **  w       (input) BASE DATA TYPE array, dimension (k)
    **          the first k elements of this array contain the components
    **          of the deflation-adjusted updating vector.
    **
    **  s       (output) BASE DATA TYPE array, dimension (lds, k)
    **          will contain the eigenvectors of the repaired matrix which
    **          will be stored for subsequent z vector calculation and
    **          multiplied by the previously accumulated eigenvectors
    **          to update the system.
    **
    **  lds     (input) long int
    **          the leading dimension of s.  lds >= max( 1, k ).
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an eigenvalue did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed9(
        const long int* k,
        const long int* kstart,
        const long int* kstop,
        const long int* n,
        float* d,
        float* q,
        const long int* ldq,
        const float* rho,
        const float* dlamda,
        const float* ws,
        const float* s,
        const long int* lds,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed9(
        const long int* k,
        const long int* kstart,
        const long int* kstop,
        const long int* n,
        float* d,
        float* q,
        const long int* ldq,
        const float* rho,
        const float* dlamda,
        const float* ws,
        const float* s,
        const long int* lds,
        long int* info)
  */
  /*! fn
   inline void laed9(
        const long int* k,
        const long int* kstart,
        const long int* kstop,
        const long int* n,
        double* d,
        double* q,
        const long int* ldq,
        const double* rho,
        const double* dlamda,
        const double* ws,
        const double* s,
        const long int* lds,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed9(
        const long int* k,
        const long int* kstart,
        const long int* kstop,
        const long int* n,
        double* d,
        double* q,
        const long int* ldq,
        const double* rho,
        const double* dlamda,
        const double* ws,
        const double* s,
        const long int* lds,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed9.f)
  //    *  Q       (workspace) float array, dimension (LDQ,N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED9(NAME, T)\
inline void laed9(\
    const long int* k,\
    const long int* kstart,\
    const long int* kstop,\
    const long int* n,\
    T* d,\
    T* q,\
    const long int* ldq,\
    const T* rho,\
    const T* dlamda,\
    const T* ws,\
    const T* s,\
    const long int* lds,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(k, kstart, kstop, n, d, q, ldq, rho, dlamda, ws, s, lds, info);\
}\
inline void laed9(\
    const long int* k,\
    const long int* kstart,\
    const long int* kstop,\
    const long int* n,\
    T* d,\
    T* q,\
    const long int* ldq,\
    const T* rho,\
    const T* dlamda,\
    const T* ws,\
    const T* s,\
    const long int* lds,\
    long int* info)\
{\
   workspace<T> w;\
   laed9(k, kstart, kstop, n, d, q, ldq, rho, dlamda, ws, s, lds, info, w);\
}\

    LPP_LAED9(slaed9, float)
    LPP_LAED9(dlaed9, double)

#undef LPP_LAED9



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed9_itf.hh
// /////////////////////////////////////////////////////////////////////////////
