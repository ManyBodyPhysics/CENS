#ifndef __PROJECT__LPP__FILE__LANSY_HH__INCLUDED
#define __PROJECT__LPP__FILE__LANSY_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lansy_itf.hh C++ interface to LAPACK (s,d,c,z)lansy
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lansy_itf.hh
    (excerpt adapted from xlansy.f file commentaries)
    
    DATA TYPE can mean float, double, complex<float>, complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlansy  returns the value of the one norm,  or the frobenius norm, or
    **  the  infinity norm,  or the  element of  largest absolute value  of a
    **  DATA TYPE symmetric matrix a.
    **
    **  description
    **  ===========
    **
    **  xlansy returns the value
    **
    **     xlansy = ( max(abs(a(i,j))), norm = 'm' or 'm'
    **              (
    **              ( norm1(a),         norm = '1', 'o' or 'o'
    **              (
    **              ( normi(a),         norm = 'i' or 'i'
    **              (
    **              ( normf(a),         norm = 'f', 'f', 'e' or 'e'
    **
    **  where  norm1  denotes the  one norm of a matrix (maximum column sum),
    **  normi  denotes the  infinity norm  of a matrix  (maximum row sum) and
    **  normf  denotes the  frobenius norm of a matrix (square root of sum of
    **  squares).  note that  max(abs(a(i,j)))  is not a  matrix norm.
    **
    **  arguments
    **  =========
    **
    **  norm    (input) char
    **          specifies the value to be returned in xlansy as described
    **          above.
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          symmetric matrix a is to be referenced.
    **          = 'u':  upper triangular part of a is referenced
    **          = 'l':  lower triangular part of a is referenced
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.  when n = 0, xlansy is
    **          set to zero.
    **
    **  a       (input) DATA TYPE array, dimension (lda,n)
    **          the symmetric matrix a.  if uplo = 'u', the leading n by n
    **          upper triangular part of a contains the upper triangular part
    **          of the matrix a, and the strictly lower triangular part of a
    **          is not referenced.  if uplo = 'l', the leading n by n lower
    **          triangular part of a contains the lower triangular part of
    **          the matrix a, and the strictly upper triangular part of a is
    **          not referenced.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(n,1).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 8 functions 
  /*! fn
   inline float lansy(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const float* ab,
        const long int* ldab,
        workspace<float> & w)
  */
  /*! fn
   inline float lansy(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const float* ab,
        const long int* ldab)
  */
  /*! fn
   inline double lansy(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const double* ab,
        const long int* ldab,
        workspace<double> & w)
  */
  /*! fn
   inline double lansy(
        const char* norm,
        const char* uplo,
        const long int* n,
        const long int* k,
        const double* ab,
        const long int* ldab)
  */
  /*! fn
   inline void lansy(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<float>* ab,
       const long int* ldab,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lansy(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<float>* ab,
       const long int* ldab)
  */
  /*! fn
   inline void lansy(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<double>* ab,
       const long int* ldab,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lansy(
       const char* norm,
       const char* uplo,
       const long int* n,
       const long int* k,
       const complex<double>* ab,
       const long int* ldab)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from xlansy.f)
  //    *  WORK    (workspace) DATA array, dimension (LWORK),
  //    *          where LWORK >= N when NORM = 'I' or '1' or 'O'; otherwise,
  //    *          WORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LANSY(NAME, T,  TBASE)\
inline TBASE lansy(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const T* ab,\
    const long int* ldab,\
    workspace<T> & w)\
{\
  w.resizerw((lower(*norm) == 'i'|| *norm ==  '1'  || *norm == '0')?*n:0); \
  return F77NAME( NAME )(norm, uplo, n, ab, ldab, w.getrw());         \
}\
inline TBASE lansy(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const T* ab,\
    const long int* ldab)                       \
{\
   workspace<T> w;\
   return lansy(norm, uplo, n, ab, ldab, w);\
}\

    LPP_LANSY(slansy, float             , float)
    LPP_LANSY(dlansy, double            , double)
    LPP_LANSY(clansy, std::complex < float > , float)
    LPP_LANSY(zlansy, std::complex < double >, double)


#undef LPP_LANSY


}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lansy_itf.hh
// /////////////////////////////////////////////////////////////////////////////
