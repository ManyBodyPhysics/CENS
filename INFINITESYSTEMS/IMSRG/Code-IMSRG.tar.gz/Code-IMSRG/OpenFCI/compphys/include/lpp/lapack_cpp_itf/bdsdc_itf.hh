#ifndef __PROJECT__LPP__FILE__BDSDC_HH__INCLUDED
#define __PROJECT__LPP__FILE__BDSDC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : bdsdc_itf.hh C++ interface to LAPACK (s,d,c,z)bdsdc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file bdsdc_itf.hh
    (excerpt adapted from xbdsdc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xbdsdc computes the singular value decomposition (svd) of a BASE DATA TYPE
    **  n-by-n (upper or lower) bidiagonal matrix b:  b = u * s * vt,
    **  using a divide and conquer method, where s is a diagonal matrix
    **  with non-negative diagonal elements (the singular values of b), and
    **  u and vt are orthogonal matrices of left and right singular vectors,
    **  respectively. xbdsdc can be used to compute all singular values,
    **  and optionally, singular vectors or singular vectors in compact form.
    **
    **  this code makes very mild assumptions about floating point
    **  arithmetic. it will WORK on machines with a guard digit in
    **  add/subtract, or on those binary machines without guard digits
    **  which subtract like the cray x-mp, cray y-mp, cray c-90, or cray-2.
    **  it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.  see dlasd3 for details.
    **
    **  the code currently call dlasdq if singular values only are desired.
    **  however, it can be slightly modified to compute singular values
    **  using the divide and conquer method.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  b is upper bidiagonal.
    **          = 'l':  b is lower bidiagonal.
    **
    **  compq   (input) char
    **          specifies whether singular vectors are to be computed
    **          as follows:
    **          = 'n':  compute singular values only;
    **          = 'p':  compute singular values and compute singular
    **                  vectors in compact form;
    **          = 'i':  compute singular values and singular vectors.
    **
    **  n       (input) long int
    **          the order of the matrix b.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the bidiagonal matrix b.
    **          on exit, if info=0, the singular values of b.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the elements of e contain the offdiagonal
    **          elements of the bidiagonal matrix whose svd is desired.
    **          on exit, e has been destroyed.
    **
    **  u       (output) BASE DATA TYPE array, dimension (ldu,n)
    **          if  compq = 'i', then:
    **             on exit, if info = 0, u contains the left singular vectors
    **             of the bidiagonal matrix.
    **          for other values of compq, u is not referenced.
    **
    **  ldu     (input) long int
    **          the leading dimension of the array u.  ldu >= 1.
    **          if singular vectors are desired, then ldu >= max( 1, n ).
    **
    **  vt      (output) BASE DATA TYPE array, dimension (ldvt,n)
    **          if  compq = 'i', then:
    **             on exit, if info = 0, vt' contains the right singular
    **             vectors of the bidiagonal matrix.
    **          for other values of compq, vt is not referenced.
    **
    **  ldvt    (input) long int
    **          the leading dimension of the array vt.  ldvt >= 1.
    **          if singular vectors are desired, then ldvt >= max( 1, n ).
    **
    **  q       (output) BASE DATA TYPE array, dimension (ldq)
    **          if  compq = 'p', then:
    **             on exit, if info = 0, q and iq contain the left
    **             and right singular vectors in a compact form,
    **             requiring o(n log n) space instead of 2*n**2.
    **             in particular, q contains all the BASE DATA TYPE data in
    **             ldq >= n*(11 + 2*smlsiz + 8*int(log_2(n/(smlsiz+1))))
    **             words of memory, where smlsiz is returned by ilaenv and
    **             is equal to the maximum size of the subproblems at the
    **             bottom of the computation tree (usually about 25).
    **          for other values of compq, q is not referenced.
    **
    **  iq      (output) long int array, dimension (ldiq)
    **          if  compq = 'p', then:
    **             on exit, if info = 0, q and iq contain the left
    **             and right singular vectors in a compact form,
    **             requiring o(n log n) space instead of 2*n**2.
    **             in particular, iq contains all long int data in
    **             ldiq >= n*(3 + 3*int(log_2(n/(smlsiz+1))))
    **             words of memory, where smlsiz is returned by ilaenv and
    **             is equal to the maximum size of the subproblems at the
    **             bottom of the computation tree (usually about 25).
    **          for other values of compq, iq is not referenced.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  the algorithm failed to compute an singular value.
    **                the update process of divide and conquer failed.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void bdsdc(
        const char* uplo,
        const char* compq,
        long int* n,
        float* d,
        float* e,
        const float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        const float* q,
        long int* iq,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void bdsdc(
        const char* uplo,
        const char* compq,
        long int* n,
        float* d,
        float* e,
        const float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        const float* q,
        long int* iq,
        long int* info)
  */
  /*! fn
   inline void bdsdc(
        const char* uplo,
        const char* compq,
        long int* n,
        double* d,
        double* e,
        const double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        const double* q,
        long int* iq,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void bdsdc(
        const char* uplo,
        const char* compq,
        long int* n,
        double* d,
        double* e,
        const double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        const double* q,
        long int* iq,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sbdsdc.f)
  //    *  WORK    (workspace) float array, dimension (LWORK)
  //    *          If COMPQ = 'N' then LWORK >= (4 * N).
  //    *          If COMPQ = 'P' then LWORK >= (6 * N).
  //    *          If COMPQ = 'I' then LWORK >= (3 * N**2 + 4 * N).
  //    *
  //    *  IWORK   (workspace) long int array, dimension (8*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_BDSDC(NAME, T)\
inline void bdsdc(\
    const char* uplo,\
    const char* compq,\
    long int* n,\
    T* d,\
    T* e,\
    const T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    const T* q,\
    long int* iq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(8**n);\
    long int ldw = (lower(*compq) == 'n') ? 4**n : ((lower(*compq) == 'p') ? 6**n : (3*(*n)+4)*(*n)); \
     w.resizew(ldw);\
    F77NAME( NAME )(uplo, compq, n, d, e, u, ldu, vt, ldvt, q, iq, w.getw(), w.getiw(), info);\
}\
inline void bdsdc(\
    const char* uplo,\
    const char* compq,\
    long int* n,\
    T* d,\
    T* e,\
    const T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    const T* q,\
    long int* iq,\
    long int* info)\
{\
   workspace<T> w;\
   bdsdc(uplo, compq, n, d, e, u, ldu, vt, ldvt, q, iq, info, w);\
}\

    LPP_BDSDC(sbdsdc, float)
    LPP_BDSDC(dbdsdc, double)

#undef LPP_BDSDC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of bdsdc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
