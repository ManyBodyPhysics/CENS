#ifndef __PROJECT__LPP__FILE__GBEQU_HH__INCLUDED
#define __PROJECT__LPP__FILE__GBEQU_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gbequ_itf.hh C++ interface to LAPACK (c,d,c,z)gbequ
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gbequ_itf.hh
    (excerpt adapted from xgbequ.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgbequ computes row and column scalings intended to equilibrate an
    **  m-by-n band matrix a and reduce its condition number.  r returns the
    **  row scale factors and c the column scale factors, chosen to try to
    **  make the largest element in each row and column of the matrix b with
    **  elements b(i,j)=r(i)*a(i,j)*c(j) have absolute value 1.
    **
    **  r(i) and c(j) are restricted to be between smlnum = smallest safe
    **  number and bignum = largest safe number.  use of these scaling
    **  factors is not guaranteed to reduce the condition number of a but
    **  WORKs well in practice.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  kl      (input) long int
    **          the number of subdiagonals within the band of a.  kl >= 0.
    **
    **  ku      (input) long int
    **          the number of superdiagonals within the band of a.  ku >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the band matrix a, stored in rows 1 to kl+ku+1.  the j-th
    **          column of a is stored in the j-th column of the array ab as
    **          follows:
    **          ab(ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(m,j+kl).
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kl+ku+1.
    **
    **  r       (output) BASE DATA TYPE array, dimension (m)
    **          if info = 0, or info > m, r contains the row scale factors
    **          for a.
    **
    **  c       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, c contains the column scale factors for a.
    **
    **  rowcnd  (output) BASE DATA TYPE
    **          if info = 0 or info > m, rowcnd contains the ratio of the
    **          smallest r(i) to the largest r(i).  if rowcnd >= 0.1 and
    **          amax is neither too large nor too small, it is not worth
    **          scaling by r.
    **
    **  colcnd  (output) BASE DATA TYPE
    **          if info = 0, colcnd contains the ratio of the smallest
    **          c(i) to the largest c(i).  if colcnd >= 0.1, it is not
    **          worth scaling by c.
    **
    **  amax    (output) BASE DATA TYPE
    **          absolute value of largest matrix element.  if amax is very
    **          close to overflow or very close to underflow, the matrix
    **          should be scaled.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, and i is
    **                <= m:  the i-th row of a is exactly zero
    **                >  m:  the (i-m)-th column of a is exactly zero
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gbequ(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const float* ab,
        const long int* ldab,
        float* r,
        float* c,
        float* rowcnd,
        float* colcnd,
        float* amax,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gbequ(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const float* ab,
        const long int* ldab,
        float* r,
        float* c,
        float* rowcnd,
        float* colcnd,
        float* amax,
        long int* info)
  */
  /*! fn
   inline void gbequ(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const double* ab,
        const long int* ldab,
        double* r,
        double* c,
        double* rowcnd,
        double* colcnd,
        double* amax,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gbequ(
        const long int* m,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const double* ab,
        const long int* ldab,
        double* r,
        double* c,
        double* rowcnd,
        double* colcnd,
        double* amax,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgbequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBEQU(NAME, T)\
inline void gbequ(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const T* ab,\
    const long int* ldab,\
    T* r,\
    T* c,\
    T* rowcnd,\
    T* colcnd,\
    T* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, info);\
}\
inline void gbequ(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const T* ab,\
    const long int* ldab,\
    T* r,\
    T* c,\
    T* rowcnd,\
    T* colcnd,\
    T* amax,\
    long int* info)\
{\
   workspace<T> w;\
   gbequ(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, info, w);\
}\

    LPP_GBEQU(sgbequ, float)
    LPP_GBEQU(dgbequ, double)

#undef LPP_GBEQU


  // The following macro provides the 4 functions 
  /*! fn
   inline void gbequ(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const std::complex<float>* ab,
       const long int* ldab,
       float* r,
       float* c,
       float* rowcnd,
       float* colcnd,
       float* amax,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gbequ(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const std::complex<float>* ab,
       const long int* ldab,
       float* r,
       float* c,
       float* rowcnd,
       float* colcnd,
       float* amax,
       long int* info)
  */
  /*! fn
   inline void gbequ(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const std::complex<double>* ab,
       const long int* ldab,
       double* r,
       double* c,
       double* rowcnd,
       double* colcnd,
       double* amax,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gbequ(
       const long int* m,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const std::complex<double>* ab,
       const long int* ldab,
       double* r,
       double* c,
       double* rowcnd,
       double* colcnd,
       double* amax,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgbequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBEQU(NAME, T, TBASE)\
inline void gbequ(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const T* ab,\
    const long int* ldab,\
    TBASE* r,\
    TBASE* c,\
    TBASE* rowcnd,\
    TBASE* colcnd,\
    TBASE* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, info);\
}\
inline void gbequ(\
    const long int* m,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const T* ab,\
    const long int* ldab,\
    TBASE* r,\
    TBASE* c,\
    TBASE* rowcnd,\
    TBASE* colcnd,\
    TBASE* amax,\
    long int* info)\
{\
   workspace<T> w;\
   gbequ(m, n, kl, ku, ab, ldab, r, c, rowcnd, colcnd, amax, info, w);\
}\

    LPP_GBEQU(cgbequ, std::complex<float>, float)
    LPP_GBEQU(zgbequ, std::complex<double>, double)

#undef LPP_GBEQU



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gbequ_itf.hh
// /////////////////////////////////////////////////////////////////////////////
