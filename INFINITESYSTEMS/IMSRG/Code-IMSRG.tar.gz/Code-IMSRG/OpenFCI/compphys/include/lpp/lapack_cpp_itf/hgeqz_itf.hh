#ifndef __PROJECT__LPP__FILE__HGEQZ_HH__INCLUDED
#define __PROJECT__LPP__FILE__HGEQZ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hgeqz_itf.hh C++ interface to LAPACK (s,d,c,z)hgeqz
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hgeqz_itf.hh
    (excerpt adapted from xhgeqz.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhgeqz computes the eigenvalues of a DATA TYPE matrix pair (h,t),
    **  where h is an upper hessenberg matrix and t is upper triangular,
    **  using the single-shift qz method.
    **  matrix pairs of this type are produced by the reduction to
    **  generalized upper hessenberg form of a DATA TYPE matrix pair (a,b):
    **  
    **     a = q1*h*z1**h,  b = q1*t*z1**h,
    **  
    **  as computed by cgghrd.
    **  
    **  if job='s', then the hessenberg-triangular pair (h,t) is
    **  also reduced to generalized schur form,
    **  
    **     h = q*s*z**h,  t = q*p*z**h,
    **  
    **  where q and z are unitary matrices and s and p are upper triangular.
    **  
    **  optionally, the unitary matrix q from the generalized schur
    **  factorization may be postmultiplied into an input matrix q1, and the
    **  unitary matrix z may be postmultiplied into an input matrix z1.
    **  if q1 and z1 are the unitary matrices from cgghrd that reduced
    **  the matrix pair (a,b) to generalized hessenberg form, then the output
    **  matrices q1*q and z1*z are the unitary factors from the generalized
    **  schur factorization of (a,b):
    **  
    **     a = (q1*q)*s*(z1*z)**h,  b = (q1*q)*p*(z1*z)**h.
    **  
    **  to avoid overflow, eigenvalues of the matrix pair (h,t)
    **  (equivalently, of (a,b)) are computed as a pair of DATA TYPE values
    **  (alpha,beta).  if beta is nonzero, lambda = alpha / beta is an
    **  eigenvalue of the generalized nonsymmetric eigenvalue problem (gnep)
    **     a*x = lambda*b*x
    **  and if alpha is nonzero, mu = beta / alpha is an eigenvalue of the
    **  alternate form of the gnep
    **     mu*a*y = b*y.
    **  the values of alpha and beta for the i-th eigenvalue can be read
    **  directly from the generalized schur form:  alpha = s(i,i),
    **  beta = p(i,i).
    **
    **  ref: c.b. moler & g.w. stewart, "an algorithm for generalized matrix
    **       eigenvalue problems", siam j. numer. anal., 10(1973),
    **       pp. 241--256.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          = 'e': compute eigenvalues only;
    **          = 's': computer eigenvalues and the schur form.
    **
    **  compq   (input) char
    **          = 'n': left schur vectors (q) are not computed;
    **          = 'i': q is initialized to the unit matrix and the matrix q
    **                 of left schur vectors of (h,t) is returned;
    **          = 'v': q must contain a unitary matrix q1 on entry and
    **                 the product q1*q is returned.
    **
    **  compz   (input) char
    **          = 'n': right schur vectors (z) are not computed;
    **          = 'i': q is initialized to the unit matrix and the matrix z
    **                 of right schur vectors of (h,t) is returned;
    **          = 'v': z must contain a unitary matrix z1 on entry and
    **                 the product z1*z is returned.
    **
    **  n       (input) long int
    **          the order of the matrices h, t, q, and z.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          ilo and ihi mark the rows and columns of h which are in
    **          hessenberg form.  it is assumed that a is already upper
    **          triangular in rows and columns 1:ilo-1 and ihi+1:n.
    **          if n > 0, 1 <= ilo <= ihi <= n; if n = 0, ilo=1 and ihi=0.
    **
    **  h       (input/output) DATA TYPE array, dimension (ldh, n)
    **          on entry, the n-by-n upper hessenberg matrix h.
    **          on exit, if job = 's', h contains the upper triangular
    **          matrix s from the generalized schur factorization.
    **          if job = 'e', the diagonal of h matches that of s, but
    **          the rest of h is unspecified.
    **
    **  ldh     (input) long int
    **          the leading dimension of the array h.  ldh >= max( 1, n ).
    **
    **  t       (input/output) DATA TYPE array, dimension (ldt, n)
    **          on entry, the n-by-n upper triangular matrix t.
    **          on exit, if job = 's', t contains the upper triangular
    **          matrix p from the generalized schur factorization.
    **          if job = 'e', the diagonal of t matches that of p, but
    **          the rest of t is unspecified.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t.  ldt >= max( 1, n ).
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **          the DATA TYPE scalars alpha that define the eigenvalues of
    **          gnep.  alpha(i) = s(i,i) in the generalized schur
    **          factorization.
    **
    **  beta    (output) DATA TYPE array, dimension (n)
    **          the BASE DATA TYPE non-negative scalars beta that define the
    **          eigenvalues of gnep.  beta(i) = p(i,i) in the generalized
    **          schur factorization.
    **
    **          together, the quantities alpha = alpha(j) and beta = beta(j)
    **          represent the j-th eigenvalue of the matrix pair (a,b), in
    **          one of the forms lambda = alpha/beta or mu = beta/alpha.
    **          since either lambda or mu may overflow, they should not,
    **          in general, be computed.
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq, n)
    **          on entry, if compz = 'v', the unitary matrix q1 used in the
    **          reduction of (a,b) to generalized hessenberg form.
    **          on exit, if compz = 'i', the unitary matrix of left schur
    **          vectors of (h,t), and if compz = 'v', the unitary matrix of
    **          left schur vectors of (a,b).
    **          not referenced if compz = 'n'.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.  ldq >= 1.
    **          if compq='v' or 'i', then ldq >= n.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz, n)
    **          on entry, if compz = 'v', the unitary matrix z1 used in the
    **          reduction of (a,b) to generalized hessenberg form.
    **          on exit, if compz = 'i', the unitary matrix of right schur
    **          vectors of (h,t), and if compz = 'v', the unitary matrix of
    **          right schur vectors of (a,b).
    **          not referenced if compz = 'n'.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1.
    **          if compz='v' or 'i', then ldz >= n.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          = 1,...,n: the qz iteration did not converge.  (h,t) is not
    **                     in schur form, but alpha(i) and beta(i),
    **                     i=info+1,...,n should be correct.
    **          = n+1,...,2*n: the shift calculation failed.  (h,t) is not
    **                     in schur form, but alpha(i) and beta(i),
    **                     i=info-n+1,...,n should be correct.
    **
    **  further details
    **  ===============
    **
    **  we assume that DATA TYPE abs WORKs as long as its value is less than
    **  overflow.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hgeqz(
        const char* job,
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* t,
        const long int* ldt,
        float* alphar,
        float* alphai,
        float* beta,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void hgeqz(
        const char* job,
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* h,
        const long int* ldh,
        float* t,
        const long int* ldt,
        float* alphar,
        float* alphai,
        float* beta,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void hgeqz(
        const char* job,
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* t,
        const long int* ldt,
        double* alphar,
        double* alphai,
        double* beta,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void hgeqz(
        const char* job,
        const char* compq,
        const char* compz,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* h,
        const long int* ldh,
        double* t,
        const long int* ldt,
        double* alphar,
        double* alphai,
        double* beta,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from shgeqz.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO >= 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,N).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HGEQZ(NAME, T)\
inline void hgeqz(\
    const char* job,\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* t,\
    const long int* ldt,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alphar, alphai, beta, q, ldq, z, ldz, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alphar, alphai, beta, q, ldq, z, ldz, w.getw(), &w.neededsize(), info);\
}\
inline void hgeqz(\
    const char* job,\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* t,\
    const long int* ldt,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   hgeqz(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alphar, alphai, beta, q, ldq, z, ldz, info, w);\
}\

    LPP_HGEQZ(shgeqz, float)
    LPP_HGEQZ(dhgeqz, double)

#undef LPP_HGEQZ


  // The following macro provides the 4 functions 
  /*! fn
   inline void hgeqz(
       const char* job,
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* t,
       const long int* ldt,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hgeqz(
       const char* job,
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* t,
       const long int* ldt,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void hgeqz(
       const char* job,
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* t,
       const long int* ldt,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hgeqz(
       const char* job,
       const char* compq,
       const char* compz,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* t,
       const long int* ldt,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chgeqz.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO >= 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,N).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HGEQZ(NAME, T, TBASE)\
inline void hgeqz(\
    const char* job,\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* t,\
    const long int* ldt,\
    T* alpha,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    F77NAME( NAME )(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alpha, beta, q, ldq, z, ldz, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alpha, beta, q, ldq, z, ldz, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void hgeqz(\
    const char* job,\
    const char* compq,\
    const char* compz,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* h,\
    const long int* ldh,\
    T* t,\
    const long int* ldt,\
    T* alpha,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   hgeqz(job, compq, compz, n, ilo, ihi, h, ldh, t, ldt, alpha, beta, q, ldq, z, ldz, info, w);\
}\

    LPP_HGEQZ(chgeqz, std::complex<float>, float)
    LPP_HGEQZ(zhgeqz, std::complex<double>, double)

#undef LPP_HGEQZ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hgeqz_itf.hh
// /////////////////////////////////////////////////////////////////////////////
