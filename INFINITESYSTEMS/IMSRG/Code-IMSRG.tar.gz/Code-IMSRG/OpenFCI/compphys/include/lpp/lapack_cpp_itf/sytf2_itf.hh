#ifndef __PROJECT__LPP__FILE__SYTF2_HH__INCLUDED
#define __PROJECT__LPP__FILE__SYTF2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sytf2_itf.hh C++ interface to LAPACK (c,d,c,z)sytf2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sytf2_itf.hh
    (excerpt adapted from xsytf2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsytf2 computes the factorization of a DATA TYPE symmetric matrix a
    **  using the bunch-kaufman diagonal pivoting method:
    **
    **     a = u*d*u'  or  a = l*d*l'
    **
    **  where u (or l) is a product of permutation and unit upper (lower)
    **  triangular matrices, u' is the transpose of u, and d is symmetric and
    **  block diagonal with 1-by-1 and 2-by-2 diagonal blocks.
    **
    **  this is the unblocked version of the algorithm, calling level 2 blas.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          symmetric matrix a is stored:
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the symmetric matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, the block diagonal matrix d and the multipliers used
    **          to obtain the factor u or l (see below for further details).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  ipiv    (output) long int array, dimension (n)
    **          details of the interchanges and the block structure of d.
    **          if ipiv(k) > 0, then rows and columns k and ipiv(k) were
    **          interchanged and d(k,k) is a 1-by-1 diagonal block.
    **          if uplo = 'u' and ipiv(k) = ipiv(k-1) < 0, then rows and
    **          columns k-1 and -ipiv(k) were interchanged and d(k-1:k,k-1:k)
    **          is a 2-by-2 diagonal block.  if uplo = 'l' and ipiv(k) =
    **          ipiv(k+1) < 0, then rows and columns k+1 and -ipiv(k) were
    **          interchanged and d(k:k+1,k:k+1) is a 2-by-2 diagonal block.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -k, the k-th argument had an illegal value
    **          > 0: if info = k, d(k,k) is exactly zero.  the factorization
    **               has been completed, but the block diagonal matrix d is
    **               exactly singular, and division by zero will occur if it
    **               is used to solve a system of equations.
    **
    **  further details
    **  ===============
    **
    **  1-96 - based on modifications by j. lewis, boeing computer services
    **         company
    **
    **  if uplo = 'u', then a = u*d*u', where
    **     u = p(n)*u(n)* ... *p(k)u(k)* ...,
    **  i.e., u is a product of terms p(k)*u(k), where k decreases from n to
    **  1 in steps of 1 or 2, and d is a block diagonal matrix with 1-by-1
    **  and 2-by-2 diagonal blocks d(k).  p(k) is a permutation matrix as
    **  defined by ipiv(k), and u(k) is a unit upper triangular matrix, such
    **  that if the diagonal block d(k) is of order s (s = 1 or 2), then
    **
    **             (   i    v    0   )   k-s
    **     u(k) =  (   0    i    0   )   s
    **             (   0    0    i   )   n-k
    **                k-s   s   n-k
    **
    **  if s = 1, d(k) overwrites a(k,k), and v overwrites a(1:k-1,k).
    **  if s = 2, the upper triangle of d(k) overwrites a(k-1,k-1), a(k-1,k),
    **  and a(k,k), and v overwrites a(1:k-2,k-1:k).
    **
    **  if uplo = 'l', then a = l*d*l', where
    **     l = p(1)*l(1)* ... *p(k)*l(k)* ...,
    **  i.e., l is a product of terms p(k)*l(k), where k increases from 1 to
    **  n in steps of 1 or 2, and d is a block diagonal matrix with 1-by-1
    **  and 2-by-2 diagonal blocks d(k).  p(k) is a permutation matrix as
    **  defined by ipiv(k), and l(k) is a unit lower triangular matrix, such
    **  that if the diagonal block d(k) is of order s (s = 1 or 2), then
    **
    **             (   i    0     0   )  k-1
    **     l(k) =  (   0    i     0   )  s
    **             (   0    v     i   )  n-k-s+1
    **                k-1   s  n-k-s+1
    **
    **  if s = 1, d(k) overwrites a(k,k), and v overwrites a(k+1:n,k).
    **  if s = 2, the lower triangle of d(k) overwrites a(k,k), a(k+1,k),
    **  and a(k+1,k+1), and v overwrites a(k+2:n,k:k+1).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sytf2(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sytf2(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        long int* ipiv,
        long int* info)
  */
  /*! fn
   inline void sytf2(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sytf2(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        long int* ipiv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssytf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_SYTF2(NAME, T)\
inline void sytf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, ipiv, info);\
}\
inline void sytf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   sytf2(uplo, n, a, lda, ipiv, info, w);\
}\

    LPP_SYTF2(ssytf2, float)
    LPP_SYTF2(dsytf2, double)

#undef LPP_SYTF2


  // The following macro provides the 4 functions 
  /*! fn
   inline void sytf2(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void sytf2(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       long int* info)
  */
  /*! fn
   inline void sytf2(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void sytf2(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from csytf2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_SYTF2(NAME, T, TBASE)\
inline void sytf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, ipiv, info);\
}\
inline void sytf2(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    long int* info)\
{\
   workspace<T> w;\
   sytf2(uplo, n, a, lda, ipiv, info, w);\
}\

    LPP_SYTF2(csytf2, std::complex<float>,  float)
    LPP_SYTF2(zsytf2, std::complex<double>, double)

#undef LPP_SYTF2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sytf2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
