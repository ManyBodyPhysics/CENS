#ifndef __PROJECT__LPP__FILE__TGSEN_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGSEN_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgsen_itf.hh C++ interface to LAPACK (s,d,c,z)tgsen
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgsen_itf.hh
    (excerpt adapted from xtgsen.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgsen reorders the generalized schur decomposition of a DATA TYPE
    **  matrix pair (a, b) (in terms of an unitary equivalence trans-
    **  formation q' * (a, b) * z), so that a selected cluster of eigenvalues
    **  appears in the leading diagonal blocks of the pair (a,b). the leading
    **  columns of q and z form unitary bases of the corresponding left and
    **  right eigenspaces (deflating subspaces). (a, b) must be in
    **  generalized schur canonical form, that is, a and b are both upper
    **  triangular.
    **
    **  xtgsen also computes the generalized eigenvalues
    **
    **           w(j)= alpha(j) / beta(j)
    **
    **  of the reordered matrix pair (a, b).
    **
    **  optionally, the routine computes estimates of reciprocal condition
    **  numbers for eigenvalues and eigenspaces. these are difu[(a11,b11),
    **  (a22,b22)] and difl[(a11,b11), (a22,b22)], i.e. the separation(s)
    **  between the matrix pairs (a11, b11) and (a22,b22) that correspond to
    **  the selected cluster and the eigenvalues outside the cluster, resp.,
    **  and norms of "projections" onto left and right eigenspaces w.r.t.
    **  the selected cluster in the (1,1)-block.
    **
    **
    **  arguments
    **  =========
    **
    **  ijob    (input) integer
    **          specifies whether condition numbers are required for the
    **          cluster of eigenvalues (pl and pr) or the deflating subspaces
    **          (difu and difl):
    **           =0: only reorder w.r.t. select. no extras.
    **           =1: reciprocal of norms of "projections" onto left and right
    **               eigenspaces w.r.t. the selected cluster (pl and pr).
    **           =2: upper bounds on difu and difl. f-norm-based estimate
    **               (dif(1:2)).
    **           =3: estimate of difu and difl. 1-norm-based estimate
    **               (dif(1:2)).
    **               about 5 times as expensive as ijob = 2.
    **           =4: compute pl, pr and dif (i.e. 0, 1 and 2 above): economic
    **               version to get it all.
    **           =5: compute pl, pr and dif (i.e. 0, 1 and 3 above)
    **
    **  wantq   (input) logical
    **          .true. : update the left transformation matrix q;
    **          .false.: do not update q.
    **
    **  wantz   (input) logical
    **          .true. : update the right transformation matrix z;
    **          .false.: do not update z.
    **
    **  select  (input) logical array, dimension (n)
    **          select specifies the eigenvalues in the selected cluster. to
    **          select an eigenvalue w(j), select(j) must be set to
    **          .true..
    **
    **  n       (input) long int
    **          the order of the matrices a and b. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension(lda,n)
    **          on entry, the upper triangular matrix a, in generalized
    **          schur canonical form.
    **          on exit, a is overwritten by the reordered matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension(ldb,n)
    **          on entry, the upper triangular matrix b, in generalized
    **          schur canonical form.
    **          on exit, b is overwritten by the reordered matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **  beta    (output) DATA TYPE array, dimension (n)
    **          the diagonal elements of a and b, respectively,
    **          when the pair (a,b) has been reduced to generalized schur
    **          form.  alpha(i)/beta(i) i=1,...,n are the generalized
    **          eigenvalues.
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq,n)
    **          on entry, if wantq = .true., q is an n-by-n matrix.
    **          on exit, q has been postmultiplied by the left unitary
    **          transformation matrix which reorder (a, b); the leading m
    **          columns of q form orthonormal bases for the specified pair of
    **          left eigenspaces (deflating subspaces).
    **          if wantq = .false., q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q. ldq >= 1.
    **          if wantq = .true., ldq >= n.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          on entry, if wantz = .true., z is an n-by-n matrix.
    **          on exit, z has been postmultiplied by the left unitary
    **          transformation matrix which reorder (a, b); the leading m
    **          columns of z form orthonormal bases for the specified pair of
    **          left eigenspaces (deflating subspaces).
    **          if wantz = .false., z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z. ldz >= 1.
    **          if wantz = .true., ldz >= n.
    **
    **  m       (output) long int
    **          the dimension of the specified pair of left and right
    **          eigenspaces, (deflating subspaces) 0 <= m <= n.
    **
    **  pl, pr  (output) BASE DATA TYPE
    **          if ijob = 1, 4 or 5, pl, pr are lower bounds on the
    **          reciprocal  of the norm of "projections" onto left and right
    **          eigenspace with respect to the selected cluster.
    **          0 < pl, pr <= 1.
    **          if m = 0 or m = n, pl = pr  = 1.
    **          if ijob = 0, 2 or 3 pl, pr are not referenced.
    **
    **  dif     (output) BASE DATA TYPE array, dimension (2).
    **          if ijob >= 2, dif(1:2) store the estimates of difu and difl.
    **          if ijob = 2 or 4, dif(1:2) are f-norm-based upper bounds on
    **          difu and difl. if ijob = 3 or 5, dif(1:2) are 1-norm-based
    **          estimates of difu and difl, computed using reversed
    **          communication with clacon.
    **          if m = 0 or n, dif(1:2) = f-norm([a, b]).
    **          if ijob = 0 or 1, dif is not referenced.
    **
    **
    **  info    (output) long int
    **            =0: successful exit.
    **            <0: if info = -i, the i-th argument had an illegal value.
    **            =1: reordering of (a, b) failed because the transformed
    **                matrix pair (a, b) would be too far from generalized
    **                schur form; the problem is very ill-conditioned.
    **                (a, b) may have been partially reordered.
    **                if requested, 0 is returned in dif(*), pl and pr.
    **
    **
    **  further details
    **  ===============
    **
    **  xtgsen first collects the selected eigenvalues by computing unitary
    **  u and w that move them to the top left corner of (a, b). in other
    **  words, the selected eigenvalues are the eigenvalues of (a11, b11) in
    **
    **                u'*(a, b)*w = (a11 a12) (b11 b12) n1
    **                              ( 0  a22),( 0  b22) n2
    **                                n1  n2    n1  n2
    **
    **  where n = n1+n2 and u' means the conjugate transpose of u. the first
    **  n1 columns of u and w span the specified pair of left and right
    **  eigenspaces (deflating subspaces) of (a, b).
    **
    **  if (a, b) has been obtained from the generalized BASE DATA TYPE schur
    **  decomposition of a matrix pair (c, d) = q*(a, b)*z', then the
    **  reordered generalized schur form of (c, d) is given by
    **
    **           (c, d) = (q*u)*(u'*(a, b)*w)*(z*w)',
    **
    **  and the first n1 columns of q*u and z*w span the corresponding
    **  deflating subspaces of (c, d) (q and z store q*u and z*w, resp.).
    **
    **  note that if the selected eigenvalue is sufficiently ill-conditioned,
    **  then its value may differ significantly from its value before
    **  reordering.
    **
    **  the reciprocal condition numbers of the left and right eigenspaces
    **  spanned by the first n1 columns of u and w (or q*u and z*w) may
    **  be returned in dif(1:2), corresponding to difu and difl, resp.
    **
    **  the difu and difl are defined as:
    **
    **       difu[(a11, b11), (a22, b22)] = sigma-min( zu )
    **  and
    **       difl[(a11, b11), (a22, b22)] = difu[(a22, b22), (a11, b11)],
    **
    **  where sigma-min(zu) is the smallest singular value of the
    **  (2*n1*n2)-by-(2*n1*n2) matrix
    **
    **       zu = [ kron(in2, a11)  -kron(a22', in1) ]
    **            [ kron(in2, b11)  -kron(b22', in1) ].
    **
    **  here, inx is the identity matrix of size nx and a22' is the
    **  transpose of a22. kron(x, y) is the kronecker product between
    **  the matrices x and y.
    **
    **  when dif(2) is small, small changes in (a, b) can cause large changes
    **  in the deflating subspace. an approximate (asymptotic) bound on the
    **  maximum angular error in the computed deflating subspaces is
    **
    **       eps * norm((a, b)) / dif(2),
    **
    **  where eps is the machine precision.
    **
    **  the reciprocal norm of the projectors on the left and right
    **  eigenspaces associated with (a11, b11) may be returned in pl and pr.
    **  they are computed as follows. first we compute l and r so that
    **  p*(a, b)*q is block diagonal, where
    **
    **       p = ( i -l ) n1           q = ( i r ) n1
    **           ( 0  i ) n2    and        ( 0 i ) n2
    **             n1 n2                    n1 n2
    **
    **  and (l, r) is the solution to the generalized sylvester equation
    **
    **       a11*r - l*a22 = -a12
    **       b11*r - l*b22 = -b12
    **
    **  then pl = (f-norm(l)**2+1)**(-1/2) and pr = (f-norm(r)**2+1)**(-1/2).
    **  an approximate (asymptotic) bound on the average absolute error of
    **  the selected eigenvalues is
    **
    **       eps * norm((a, b)) / pl.
    **
    **  there are also global error bounds which valid for perturbations up
    **  to a certain restriction:  a lower bound (x) on the smallest
    **  f-norm(e,f) for which an eigenvalue of (a11, b11) may move and
    **  coalesce with an eigenvalue of (a22, b22) under perturbation (e,f),
    **  (i.e. (a + e, b + f), is
    **
    **   x = min(difu,difl)/((1/(pl*pl)+1/(pr*pr))**(1/2)+2*max(1/pl,1/pr)).
    **
    **  an approximate bound on x can be computed from dif(1:2), pl and pr.
    **
    **  if y = ( f-norm(e,f) / x) <= 1, the angles between the perturbed
    **  (l', r') and unperturbed (l, r) left and right deflating subspaces
    **  associated with the selected cluster in the (1,1)-blocks can be
    **  bounded as
    **
    **   max-angle(l, l') <= arctan( y * pl / (1 - y * (1 - pl * pl)**(1/2))
    **   max-angle(r, r') <= arctan( y * pr / (1 - y * (1 - pr * pr)**(1/2))
    **
    **  see lapack user's guide section 4.11 or the following references
    **  for more information.
    **
    **  note that if the default method for computing the frobenius-norm-
    **  based estimate dif is not wanted (see clatdf), then the parameter
    **  idifjb (see below) should be changed from 3 to 4 (routine clatdf
    **  (ijob = 2 will be used)). see ctgsyl for more details.
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  references
    **  ==========
    **
    **  [1] b. kagstrom; a direct method for reordering eigenvalues in the
    **      generalized BASE DATA TYPE schur form of a regular matrix pair (a, b), in
    **      m.s. moonen et al (eds), linear algebra for large scale and
    **      BASE DATA TYPE-time applications, kluwer academic publ. 1993, pp 195-218.
    **
    **  [2] b. kagstrom and p. poromaa; computing eigenspaces with specified
    **      eigenvalues of a regular matrix pair (a, b) and condition
    **      estimation: theory, algorithms and software, report
    **      uminf - 94.04, department of computing science, umea university,
    **      s-901 87 umea, sweden, 1994. also as lapack WORKing note 87.
    **      to appear in numerical algorithms, 1996.
    **
    **  [3] b. kagstrom and p. poromaa, lapack-style algorithms and software
    **      for solving the generalized sylvester equation and estimating the
    **      separation between regular matrix pairs, report uminf - 93.23,
    **      department of computing science, umea university, s-901 87 umea,
    **      sweden, december 1993, revised april 1994, also as lapack WORKing
    **      note 75. to appear in acm trans. on math. software, vol 22, no 1,
    **      1996.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsen(
        const long int* ijob,
        const long int* wantq,
        const long int* wantz,
        const long int* select,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* m,
        float* pl,
        float* pr,
        float* dif,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgsen(
        const long int* ijob,
        const long int* wantq,
        const long int* wantz,
        const long int* select,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* m,
        float* pl,
        float* pr,
        float* dif,
        long int* info)
  */
  /*! fn
   inline void tgsen(
        const long int* ijob,
        const long int* wantq,
        const long int* wantz,
        const long int* select,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* m,
        double* pl,
        double* pr,
        double* dif,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgsen(
        const long int* ijob,
        const long int* wantq,
        const long int* wantz,
        const long int* select,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* m,
        double* pl,
        double* pr,
        double* dif,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgsen.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          IF IJOB = 0, WORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >=  4*N+16.
  //    *          If IJOB = 1, 2 or 4, LWORK >= MAX(4*N+16, 2*M*(N-M)).
  //    *          If IJOB = 3 or 5, LWORK >= MAX(4*N+16, 4*M*(N-M)).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          IF IJOB = 0, IWORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK. lIWORK >= 1.
  //    *          if ijob = 1, 2 or 4, lIWORK >=  n+2;
  //    *          if ijob = 3 or 5, lIWORK >= max(n+2, 2*m*(n-m));
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSEN(NAME, T)\
inline void tgsen(\
    const long int* ijob,\
    const long int* wantq,\
    const long int* wantz,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* m,\
    T* pl,\
    T* pr,\
    T* dif,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ijob, wantq, wantz, select, n, a, lda, b, ldb, alphar, alphai, beta, q, ldq, z, ldz, m, pl, pr, dif, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizew(w.neededsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(ijob, wantq, wantz, select, n, a, lda, b, ldb, alphar, alphai, beta, q, ldq, z, ldz, m, pl, pr, dif, w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void tgsen(\
    const long int* ijob,\
    const long int* wantq,\
    const long int* wantz,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* m,\
    T* pl,\
    T* pr,\
    T* dif,\
    long int* info)\
{\
   workspace<T> w;\
   tgsen(ijob, wantq, wantz, select, n, a, lda, b, ldb, alphar, alphai, beta, q, ldq, z, ldz, m, pl, pr, dif, info, w);\
}\

    LPP_TGSEN(stgsen, float)
    LPP_TGSEN(dtgsen, double)

#undef LPP_TGSEN


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsen(
       const long int* ijob,
       const long int* wantq,
       const long int* wantz,
       const long int* select,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* m,
       float* pl,
       float* pr,
       float* dif,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgsen(
       const long int* ijob,
       const long int* wantq,
       const long int* wantz,
       const long int* select,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* m,
       float* pl,
       float* pr,
       float* dif,
       long int* info)
  */
  /*! fn
   inline void tgsen(
       const long int* ijob,
       const long int* wantq,
       const long int* wantz,
       const long int* select,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* m,
       double* pl,
       double* pr,
       double* dif,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgsen(
       const long int* ijob,
       const long int* wantq,
       const long int* wantz,
       const long int* select,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* m,
       double* pl,
       double* pr,
       double* dif,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgsen.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          IF IJOB = 0, WORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >=  1
  //    *          If IJOB = 1, 2 or 4, LWORK >=  2*M*(N-M)
  //    *          If IJOB = 3 or 5, LWORK >=  4*M*(N-M)
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int, dimension (LIWORK)
  //    *          IF IJOB = 0, IWORK is not referenced.  Otherwise,
  //    *          on exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK. lIWORK >= 1.
  //    *          if ijob = 1, 2 or 4, lIWORK >=  n+2;
  //    *          if ijob = 3 or 5, lIWORK >= max(n+2, 2*m*(n-m));
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  //    *
  //    *  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSEN(NAME, T, TBASE)\
inline void tgsen(\
    const long int* ijob,\
    const long int* wantq,\
    const long int* wantz,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* m,\
    TBASE* pl,\
    TBASE* pr,\
    TBASE* dif,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ijob, wantq, wantz, select, n, a, lda, b, ldb, alpha, beta, q, ldq, z, ldz, m, pl, pr, dif, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizew(w.neededsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(ijob, wantq, wantz, select, n, a, lda, b, ldb, alpha, beta, q, ldq, z, ldz, m, pl, pr, dif, w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void tgsen(\
    const long int* ijob,\
    const long int* wantq,\
    const long int* wantz,\
    const long int* select,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* m,\
    TBASE* pl,\
    TBASE* pr,\
    TBASE* dif,\
    long int* info)\
{\
   workspace<T> w;\
   tgsen(ijob, wantq, wantz, select, n, a, lda, b, ldb, alpha, beta, q, ldq, z, ldz, m, pl, pr, dif, info, w);\
}\

    LPP_TGSEN(ctgsen, std::complex<float>, float)
    LPP_TGSEN(ztgsen, std::complex<double>, double)

#undef LPP_TGSEN



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgsen_itf.hh
// /////////////////////////////////////////////////////////////////////////////
