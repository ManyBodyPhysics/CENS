#ifndef __PROJECT__LPP__FILE__HPGST_HH__INCLUDED
#define __PROJECT__LPP__FILE__HPGST_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hpgst_itf.hh C++ interface to LAPACK (c,d,c,z)hpgst
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hpgst_itf.hh
    (excerpt adapted from xhpgst.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhpgst reduces a DATA TYPE hermitian-definite generalized
    **  eigenproblem to standard form, using packed storage.
    **
    **  if itype = 1, the problem is a*x = lambda*b*x,
    **  and a is overwritten by inv(u**h)*a*inv(u) or inv(l)*a*inv(l**h)
    **
    **  if itype = 2 or 3, the problem is a*b*x = lambda*x or
    **  b*a*x = lambda*x, and a is overwritten by u*a*u**h or l**h*a*l.
    **
    **  b must have been previously factorized as u**h*u or l*l**h by cpptrf.
    **
    **  arguments
    **  =========
    **
    **  itype   (input) long int
    **          = 1: compute inv(u**h)*a*inv(u) or inv(l)*a*inv(l**h);
    **          = 2 or 3: compute u*a*u**h or l**h*a*l.
    **
    **  uplo    (input) character
    **          = 'u':  upper triangle of a is stored and b is factored as
    **                  u**h*u;
    **          = 'l':  lower triangle of a is stored and b is factored as
    **                  l*l**h.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the hermitian matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = a(i,j) for j<=i<=n.
    **
    **          on exit, if info = 0, the transformed matrix, stored in the
    **          same format as a.
    **
    **  bp      (input) DATA TYPE array, dimension (n*(n+1)/2)
    **          the triangular factor from the cholesky factorization of b,
    **          stored in the same format as a, as returned by cpptrf.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hpgst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const std::complex<float>* bp,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hpgst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<float>* ap,
       const std::complex<float>* bp,
       long int* info)
  */
  /*! fn
   inline void hpgst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const std::complex<double>* bp,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hpgst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<double>* ap,
       const std::complex<double>* bp,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chpgst.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_HPGST(NAME, T, TBASE)\
inline void hpgst(\
    const long int* itype,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* bp,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(itype, uplo, n, ap, bp, info);\
}\
inline void hpgst(\
    const long int* itype,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* bp,\
    long int* info)\
{\
   workspace<T> w;\
   hpgst(itype, uplo, n, ap, bp, info, w);\
}\

    LPP_HPGST(chpgst, std::complex<float>,  float)
    LPP_HPGST(zhpgst, std::complex<double>, double)

#undef LPP_HPGST



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hpgst_itf.hh
// /////////////////////////////////////////////////////////////////////////////
