#ifndef __PROJECT__LPP__FILE__TGSJA_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGSJA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgsja_itf.hh C++ interface to LAPACK (s,d,c,z)tgsja
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgsja_itf.hh
    (excerpt adapted from xtgsja.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgsja computes the generalized singular value decomposition (gsvd)
    **  of two DATA TYPE upper triangular (or trapezoidal) matrices a and b.
    **
    **  on entry, it is assumed that matrices a and b have the following
    **  forms, which may be obtained by the preprocessing subroutine cggsvp
    **  from a general m-by-n matrix a and p-by-n matrix b:
    **
    **               n-k-l  k    l
    **     a =    k ( 0    a12  a13 ) if m-k-l >= 0;
    **            l ( 0     0   a23 )
    **        m-k-l ( 0     0    0  )
    **
    **             n-k-l  k    l
    **     a =  k ( 0    a12  a13 ) if m-k-l < 0;
    **        m-k ( 0     0   a23 )
    **
    **             n-k-l  k    l
    **     b =  l ( 0     0   b13 )
    **        p-l ( 0     0    0  )
    **
    **  where the k-by-k matrix a12 and l-by-l matrix b13 are nonsingular
    **  upper triangular; a23 is l-by-l upper triangular if m-k-l >= 0,
    **  otherwise a23 is (m-k)-by-l upper trapezoidal.
    **
    **  on exit,
    **
    **         u'*a*q = d1*( 0 r ),    v'*b*q = d2*( 0 r ),
    **
    **  where u, v and q are unitary matrices, z' denotes the conjugate
    **  transpose of z, r is a nonsingular upper triangular matrix, and d1
    **  and d2 are ``diagonal'' matrices, which are of the following
    **  structures:
    **
    **  if m-k-l >= 0,
    **
    **                      k  l
    **         d1 =     k ( i  0 )
    **                  l ( 0  c )
    **              m-k-l ( 0  0 )
    **
    **                     k  l
    **         d2 = l   ( 0  s )
    **              p-l ( 0  0 )
    **
    **                 n-k-l  k    l
    **    ( 0 r ) = k (  0   r11  r12 ) k
    **              l (  0    0   r22 ) l
    **
    **  where
    **
    **    c = diag( alpha(k+1), ... , alpha(k+l) ),
    **    s = diag( beta(k+1),  ... , beta(k+l) ),
    **    c**2 + s**2 = i.
    **
    **    r is stored in a(1:k+l,n-k-l+1:n) on exit.
    **
    **  if m-k-l < 0,
    **
    **                 k m-k k+l-m
    **      d1 =   k ( i  0    0   )
    **           m-k ( 0  c    0   )
    **
    **                   k m-k k+l-m
    **      d2 =   m-k ( 0  s    0   )
    **           k+l-m ( 0  0    i   )
    **             p-l ( 0  0    0   )
    **
    **                 n-k-l  k   m-k  k+l-m
    ** ( 0 r ) =    k ( 0    r11  r12  r13  )
    **            m-k ( 0     0   r22  r23  )
    **          k+l-m ( 0     0    0   r33  )
    **
    **  where
    **  c = diag( alpha(k+1), ... , alpha(m) ),
    **  s = diag( beta(k+1),  ... , beta(m) ),
    **  c**2 + s**2 = i.
    **
    **  r = ( r11 r12 r13 ) is stored in a(1:m, n-k-l+1:n) and r33 is stored
    **      (  0  r22 r23 )
    **  in b(m-k+1:l,n+m-k-l+1:n) on exit.
    **
    **  the computation of the unitary transformation matrices u, v or q
    **  is optional.  these matrices may either be formed explicitly, or they
    **  may be postmultiplied into input matrices u1, v1, or q1.
    **
    **  arguments
    **  =========
    **
    **  jobu    (input) char
    **          = 'u':  u must contain a unitary matrix u1 on entry, and
    **                  the product u1*u is returned;
    **          = 'i':  u is initialized to the unit matrix, and the
    **                  unitary matrix u is returned;
    **          = 'n':  u is not computed.
    **
    **  jobv    (input) char
    **          = 'v':  v must contain a unitary matrix v1 on entry, and
    **                  the product v1*v is returned;
    **          = 'i':  v is initialized to the unit matrix, and the
    **                  unitary matrix v is returned;
    **          = 'n':  v is not computed.
    **
    **  jobq    (input) char
    **          = 'q':  q must contain a unitary matrix q1 on entry, and
    **                  the product q1*q is returned;
    **          = 'i':  q is initialized to the unit matrix, and the
    **                  unitary matrix q is returned;
    **          = 'n':  q is not computed.
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  p       (input) long int
    **          the number of rows of the matrix b.  p >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrices a and b.  n >= 0.
    **
    **  k       (input) long int
    **  l       (input) long int
    **          k and l specify the subblocks in the input matrices a and b:
    **          a23 = a(k+1:min(k+l,m),n-l+1:n) and b13 = b(1:l,,n-l+1:n)
    **          of a and b, whose gsvd is going to be computed by xtgsja.
    **          see further details.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, a(n-k+1:n,1:min(k+l,m) ) contains the triangular
    **          matrix r or part of r.  see purpose for details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the p-by-n matrix b.
    **          on exit, if necessary, b(m-k+1:l,n+m-k-l+1:n) contains
    **          a part of r.  see purpose for details.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,p).
    **
    **  tola    (input) BASE DATA TYPE
    **  tolb    (input) BASE DATA TYPE
    **          tola and tolb are the convergence criteria for the jacobi-
    **          kogbetliantz iteration procedure. generally, they are the
    **          same as used in the preprocessing step, say
    **              tola = max(m,n)*norm(a)*macheps,
    **              tolb = max(p,n)*norm(b)*macheps.
    **
    **  alpha   (output) BASE DATA TYPE array, dimension (n)
    **  beta    (output) BASE DATA TYPE array, dimension (n)
    **          on exit, alpha and beta contain the generalized singular
    **          value pairs of a and b;
    **            alpha(1:k) = 1,
    **            beta(1:k)  = 0,
    **          and if m-k-l >= 0,
    **            alpha(k+1:k+l) = diag(c),
    **            beta(k+1:k+l)  = diag(s),
    **          or if m-k-l < 0,
    **            alpha(k+1:m)= c, alpha(m+1:k+l)= 0
    **            beta(k+1:m) = s, beta(m+1:k+l) = 1.
    **          furthermore, if k+l < n,
    **            alpha(k+l+1:n) = 0
    **            beta(k+l+1:n)  = 0.
    **
    **  u       (input/output) DATA TYPE array, dimension (ldu,m)
    **          on entry, if jobu = 'u', u must contain a matrix u1 (usually
    **          the unitary matrix returned by cggsvp).
    **          on exit,
    **          if jobu = 'i', u contains the unitary matrix u;
    **          if jobu = 'u', u contains the product u1*u.
    **          if jobu = 'n', u is not referenced.
    **
    **  ldu     (input) long int
    **          the leading dimension of the array u. ldu >= max(1,m) if
    **          jobu = 'u'; ldu >= 1 otherwise.
    **
    **  v       (input/output) DATA TYPE array, dimension (ldv,p)
    **          on entry, if jobv = 'v', v must contain a matrix v1 (usually
    **          the unitary matrix returned by cggsvp).
    **          on exit,
    **          if jobv = 'i', v contains the unitary matrix v;
    **          if jobv = 'v', v contains the product v1*v.
    **          if jobv = 'n', v is not referenced.
    **
    **  ldv     (input) long int
    **          the leading dimension of the array v. ldv >= max(1,p) if
    **          jobv = 'v'; ldv >= 1 otherwise.
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq,n)
    **          on entry, if jobq = 'q', q must contain a matrix q1 (usually
    **          the unitary matrix returned by cggsvp).
    **          on exit,
    **          if jobq = 'i', q contains the unitary matrix q;
    **          if jobq = 'q', q contains the product q1*q.
    **          if jobq = 'n', q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q. ldq >= max(1,n) if
    **          jobq = 'q'; ldq >= 1 otherwise.
    **
    **
    **  ncycle  (output) long int
    **          the number of cycles required for convergence.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          = 1:  the procedure does not converge after maxit cycles.
    **
    **  internal parameters
    **  ===================
    **
    **  maxit   long int
    **          maxit specifies the total loops that the iterative procedure
    **          may take. if after maxit cycles, the routine fails to
    **          converge, we return info = 1.
    **
    **  further details
    **  ===============
    **
    **  xtgsja essentially uses a variant of kogbetliantz algorithm to reduce
    **  min(l,m-k)-by-l triangular (or trapezoidal) matrix a23 and l-by-l
    **  matrix b13 to the form:
    **
    **           u1'*a13*q1 = c1*r1; v1'*b13*q1 = s1*r1,
    **
    **  where u1, v1 and q1 are unitary matrix, and z' is the conjugate
    **  transpose of z.  c1 and s1 are diagonal matrices satisfying
    **
    **                c1**2 + s1**2 = i,
    **
    **  and r1 is an l-by-l nonsingular upper triangular matrix.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsja(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        long int* m,
        long int* p,
        const long int* n,
        const long int* k,
        const long int* l,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* tola,
        const float* tolb,
        float* alpha,
        float* beta,
        const float* u,
        const long int* ldu,
        const float* v,
        const long int* ldv,
        const float* q,
        const long int* ldq,
        long int* ncycle,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgsja(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        long int* m,
        long int* p,
        const long int* n,
        const long int* k,
        const long int* l,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        const float* tola,
        const float* tolb,
        float* alpha,
        float* beta,
        const float* u,
        const long int* ldu,
        const float* v,
        const long int* ldv,
        const float* q,
        const long int* ldq,
        long int* ncycle,
        long int* info)
  */
  /*! fn
   inline void tgsja(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        long int* m,
        long int* p,
        const long int* n,
        const long int* k,
        const long int* l,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* tola,
        const double* tolb,
        double* alpha,
        double* beta,
        const double* u,
        const long int* ldu,
        const double* v,
        const long int* ldv,
        const double* q,
        const long int* ldq,
        long int* ncycle,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgsja(
        const char* jobu,
        const char* jobv,
        const char* jobq,
        long int* m,
        long int* p,
        const long int* n,
        const long int* k,
        const long int* l,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        const double* tola,
        const double* tolb,
        double* alpha,
        double* beta,
        const double* u,
        const long int* ldu,
        const double* v,
        const long int* ldv,
        const double* q,
        const long int* ldq,
        long int* ncycle,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgsja.f)
  //    *  WORK    (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSJA(NAME, T)\
inline void tgsja(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    long int* m,\
    long int* p,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* tola,\
    const T* tolb,\
    T* alpha,\
    T* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* ncycle,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(2*(*n));\
    F77NAME( NAME )(jobu, jobv, jobq, m, p, n, k, l, a, lda, b, ldb, tola, tolb, alpha, beta, u, ldu, v, ldv, q, ldq, w.getw(), ncycle, info);\
}\
inline void tgsja(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    long int* m,\
    long int* p,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const T* tola,\
    const T* tolb,\
    T* alpha,\
    T* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* ncycle,\
    long int* info)\
{\
   workspace<T> w;\
   tgsja(jobu, jobv, jobq, m, p, n, k, l, a, lda, b, ldb, tola, tolb, alpha, beta, u, ldu, v, ldv, q, ldq, ncycle, info, w);\
}\

    LPP_TGSJA(stgsja, float)
    LPP_TGSJA(dtgsja, double)

#undef LPP_TGSJA


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsja(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       long int* m,
       long int* p,
       const long int* n,
       const long int* k,
       const long int* l,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const float* tola,
       const float* tolb,
       float* alpha,
       float* beta,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* q,
       const long int* ldq,
       long int* ncycle,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgsja(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       long int* m,
       long int* p,
       const long int* n,
       const long int* k,
       const long int* l,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       const float* tola,
       const float* tolb,
       float* alpha,
       float* beta,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* v,
       const long int* ldv,
       const std::complex<float>* q,
       const long int* ldq,
       long int* ncycle,
       long int* info)
  */
  /*! fn
   inline void tgsja(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       long int* m,
       long int* p,
       const long int* n,
       const long int* k,
       const long int* l,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const double* tola,
       const double* tolb,
       double* alpha,
       double* beta,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* q,
       const long int* ldq,
       long int* ncycle,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgsja(
       const char* jobu,
       const char* jobv,
       const char* jobq,
       long int* m,
       long int* p,
       const long int* n,
       const long int* k,
       const long int* l,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       const double* tola,
       const double* tolb,
       double* alpha,
       double* beta,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* v,
       const long int* ldv,
       const std::complex<double>* q,
       const long int* ldq,
       long int* ncycle,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgsja.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSJA(NAME, T, TBASE)\
inline void tgsja(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    long int* m,\
    long int* p,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const TBASE* tola,\
    const TBASE* tolb,\
    TBASE* alpha,\
    TBASE* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* ncycle,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(2*(*n));\
    F77NAME( NAME )(jobu, jobv, jobq, m, p, n, k, l, a, lda, b, ldb, tola, tolb, alpha, beta, u, ldu, v, ldv, q, ldq, w.getw(), ncycle, info);\
}\
inline void tgsja(\
    const char* jobu,\
    const char* jobv,\
    const char* jobq,\
    long int* m,\
    long int* p,\
    const long int* n,\
    const long int* k,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    const TBASE* tola,\
    const TBASE* tolb,\
    TBASE* alpha,\
    TBASE* beta,\
    const T* u,\
    const long int* ldu,\
    const T* v,\
    const long int* ldv,\
    const T* q,\
    const long int* ldq,\
    long int* ncycle,\
    long int* info)\
{\
   workspace<T> w;\
   tgsja(jobu, jobv, jobq, m, p, n, k, l, a, lda, b, ldb, tola, tolb, alpha, beta, u, ldu, v, ldv, q, ldq, ncycle, info, w);\
}\

    LPP_TGSJA(ctgsja, std::complex<float>, float)
    LPP_TGSJA(ztgsja, std::complex<double>, double)

#undef LPP_TGSJA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgsja_itf.hh
// /////////////////////////////////////////////////////////////////////////////
