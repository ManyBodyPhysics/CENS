#ifndef __PROJECT__LPP__FILE__STEGR_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEGR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : stegr_itf.hh C++ interface to LAPACK (s,d,c,z)stegr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file stegr_itf.hh
    (excerpt adapted from xstegr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    ** xstegr computes selected eigenvalues and, optionally, eigenvectors
    ** of a BASE DATA TYPE symmetric tridiagonal matrix t.  eigenvalues and
    ** eigenvectors can be selected by specifying either a range of values
    ** or a range of indices for the desired eigenvalues. the eigenvalues
    ** are computed by the dqds algorithm, while orthogonal eigenvectors are
    ** computed from various ``good'' l d l^t representations (also known as
    ** relatively robust representations). gram-schmidt orthogonalization is
    ** avoided as far as possible. more specifically, the various steps of
    ** the algorithm are as follows. for the i-th unreduced block of t,
    **     (a) compute t - sigma_i = l_i d_i l_i^t, such that l_i d_i l_i^t
    **         is a relatively robust representation,
    **     (b) compute the eigenvalues, lambda_j, of l_i d_i l_i^t to high
    **         relative accuracy by the dqds algorithm,
    **     (c) if there is a cluster of close eigenvalues, "choose" sigma_i
    **         close to the cluster, and go to step (a),
    **     (d) given the approximate eigenvalue lambda_j of l_i d_i l_i^t,
    **         compute the corresponding eigenvector by forming a
    **         rank-revealing twisted factorization.
    **  the desired accuracy of the output can be specified by the input
    **  parameter abstol.
    **
    **  for more details, see "a new o(n^2) algorithm for the symmetric
    **  tridiagonal eigenvalue/eigenvector problem", by inderjit dhillon,
    **  computer science division technical report no. ucb/csd-97-971,
    **  uc berkeley, may 1997.
    **
    **  note 1 : currently xstegr is only set up to find all the n
    **  eigenvalues and eigenvectors of t in o(n^2) time
    **  note 2 : currently the routine cstein is called when an appropriate
    **  sigma_i cannot be chosen in step (c) above. cstein invokes modified
    **  gram-schmidt when eigenvalues are close.
    **  note 3 : xstegr WORKs only on machines which follow ieee-754
    **  floating-point standard in their handling of infinities and nans.
    **  normal execution of xstegr may create nans and infinities and hence
    **  may abort due to a floating point exception in environments which
    **  do not conform to the ieee standard.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  range   (input) char
    **          = 'a': all eigenvalues will be found.
    **          = 'v': all eigenvalues in the half-open interval (vl,vu]
    **                 will be found.
    **          = 'i': the il-th through iu-th eigenvalues will be found.
    *********** only range = 'a' is currently supported *********************
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal matrix
    **          t. on exit, d is overwritten.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix t in elements 1 to n-1 of e; e(n) need not be set.
    **          on exit, e is overwritten.
    **
    **  vl      (input) BASE DATA TYPE
    **  vu      (input) BASE DATA TYPE
    **          if range='v', the lower and upper bounds of the interval to
    **          be searched for eigenvalues. vl < vu.
    **          not referenced if range = 'a' or 'i'.
    **
    **  il      (input) long int
    **  iu      (input) long int
    **          if range='i', the indices (in ascending order) of the
    **          smallest and largest eigenvalues to be returned.
    **          1 <= il <= iu <= n, if n > 0; il = 1 and iu = 0 if n = 0.
    **          not referenced if range = 'a' or 'v'.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the absolute error tolerance for the
    **          eigenvalues/eigenvectors. if jobz = 'v', the eigenvalues and
    **          eigenvectors output have residual norms bounded by abstol,
    **          and the dot products between different eigenvectors are
    **          bounded by abstol. if abstol is less than n*eps*|t|, then
    **          n*eps*|t| will be used in its place, where eps is the
    **          machine precision and |t| is the 1-norm of the tridiagonal
    **          matrix. the eigenvalues are computed to an accuracy of
    **          eps*|t| irrespective of abstol. if high relative accuracy
    **          is important, set abstol to dlamch( 'safe minimum' ).
    **          see barlow and demmel "computing accurate eigensystems of
    **          scaled diagonally dominant matrices", lapack WORKing note #7
    **          for a discussion of which matrices define their eigenvalues
    **          to high relative accuracy.
    **
    **  m       (output) long int
    **          the total number of eigenvalues found.  0 <= m <= n.
    **          if range = 'a', m = n, and if range = 'i', m = iu-il+1.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          the first m elements contain the selected eigenvalues in
    **          ascending order.
    **
    **  z       (output) DATA TYPE array, dimension (ldz, max(1,m) )
    **          if jobz = 'v', then if info = 0, the first m columns of z
    **          contain the orthonormal eigenvectors of the matrix t
    **          corresponding to the selected eigenvalues, with the i-th
    **          column of z holding the eigenvector associated with w(i).
    **          if jobz = 'n', then z is not referenced.
    **          note: the user must ensure that at least max(1,m) columns are
    **          supplied in the array z; if range = 'v', the exact value of m
    **          is not known in advance and an upper bound must be used.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **  isuppz  (output) long int array, dimension ( 2*max(1,m) )
    **          the support of the eigenvectors in z, i.e., the indices
    **          indicating the nonzero elements in z. the i-th eigenvector
    **          is nonzero only in elements isuppz( 2*i-1 ) through
    **          isuppz( 2*i ).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = 1, internal error in slarre,
    **                if info = 2, internal error in clarrv.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **     ken stanley, computer science division, university of
    **       california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void stegr(
        const char* jobz,
        const char* range,
        const long int* n,
        float* d,
        const float* e,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void stegr(
        const char* jobz,
        const char* range,
        const long int* n,
        float* d,
        const float* e,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */
  /*! fn
   inline void stegr(
        const char* jobz,
        const char* range,
        const long int* n,
        double* d,
        const double* e,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void stegr(
        const char* jobz,
        const char* range,
        const long int* n,
        double* d,
        const double* e,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sstegr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal
  //    *          (and minimal) LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,18*N)
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK.  lIWORK >= max(1,10*n)
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEGR(NAME, T)\
inline void stegr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, w.getw(),\
                    w.query(), w.getiw(), w.query(), info);             \
    w.resizew(w.neededsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz,\
                    w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info); \
}\
inline void stegr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info)\
{\
   workspace<T> w;\
   stegr(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, info, w);\
}\

    LPP_STEGR(sstegr, float)
    LPP_STEGR(dstegr, double)

#undef LPP_STEGR


  // The following macro provides the 4 functions 
  /*! fn
   inline void stegr(
       const char* jobz,
       const char* range,
       const long int* n,
       float* d,
       const float* e,
       const float* vl,
       const float* vu,
       const long int* il,
       const long int* iu,
       const float* abstol,
       long int* m,
       float* ws,
       const std::complex<float>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void stegr(
       const char* jobz,
       const char* range,
       const long int* n,
       float* d,
       const float* e,
       const float* vl,
       const float* vu,
       const long int* il,
       const long int* iu,
       const float* abstol,
       long int* m,
       float* ws,
       const std::complex<float>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info)
  */
  /*! fn
   inline void stegr(
       const char* jobz,
       const char* range,
       const long int* n,
       double* d,
       const double* e,
       const double* vl,
       const double* vu,
       const long int* il,
       const long int* iu,
       const double* abstol,
       long int* m,
       double* ws,
       const std::complex<double>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void stegr(
       const char* jobz,
       const char* range,
       const long int* n,
       double* d,
       const double* e,
       const double* vl,
       const double* vu,
       const long int* il,
       const long int* iu,
       const double* abstol,
       long int* m,
       double* ws,
       const std::complex<double>* z,
       const long int* ldz,
       long int* isuppz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cstegr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal
  //    *          (and minimal) LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,18*N)
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK.  lIWORK >= max(1,10*n)
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEGR(NAME, T, TBASE)\
inline void stegr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    TBASE* d,\
    const TBASE* e,\
    const TBASE* vl,\
    const TBASE* vu,\
    const long int* il,\
    const long int* iu,\
    const TBASE* abstol,\
    long int* m,\
    TBASE* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz,\
                    w.getrw(), w.query(), w.getiw(), w.query(), info);   \
    w.resizew(w.neededrsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz,\
                    w.getrw(), &w.neededsize(), w.getiw(), &w.neededisize(), info); \
}\
inline void stegr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    TBASE* d,\
    const TBASE* e,\
    const TBASE* vl,\
    const TBASE* vu,\
    const long int* il,\
    const long int* iu,\
    const TBASE* abstol,\
    long int* m,\
    TBASE* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info)\
{\
   workspace<T> w;\
   stegr(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, info, w);\
}\

    LPP_STEGR(cstegr, std::complex<float>, float)
    LPP_STEGR(zstegr, std::complex<double>, double)

#undef LPP_STEGR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of stegr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
