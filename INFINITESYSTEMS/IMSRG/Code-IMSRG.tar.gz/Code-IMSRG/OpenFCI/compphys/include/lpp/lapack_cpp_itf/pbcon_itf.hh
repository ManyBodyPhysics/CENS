#ifndef __PROJECT__LPP__FILE__PBCON_HH__INCLUDED
#define __PROJECT__LPP__FILE__PBCON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pbcon_itf.hh C++ interface to LAPACK (s,d,c,z)pbcon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pbcon_itf.hh
    (excerpt adapted from xpbcon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpbcon estimates the reciprocal of the condition number (in the
    **  1-norm) of a DATA TYPE hermitian positive definite band matrix using
    **  the cholesky factorization a = u**h*u or a = l*l**h computed by
    **  cpbtrf.
    **
    **  an estimate is obtained for norm(inv(a)), and the reciprocal of the
    **  condition number is computed as rcond = 1 / (anorm * norm(inv(a))).
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangular factor stored in ab;
    **          = 'l':  lower triangular factor stored in ab.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of sub-diagonals if uplo = 'l'.  kd >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the triangular factor u or l from the cholesky factorization
    **          a = u**h*u or a = l*l**h of the band matrix a, stored in the
    **          first kd+1 rows of the array.  the j-th column of u or l is
    **          stored in the j-th column of the array ab as follows:
    **          if uplo ='u', ab(kd+1+i-j,j) = u(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo ='l', ab(1+i-j,j)    = l(i,j) for j<=i<=min(n,j+kd).
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  anorm   (input) BASE DATA TYPE
    **          the 1-norm (or infinity-norm) of the hermitian band matrix a.
    **
    **  rcond   (output) BASE DATA TYPE
    **          the reciprocal of the condition number of the matrix a,
    **          computed as rcond = 1/(anorm * ainvnm), where ainvnm is an
    **          estimate of the 1-norm of inv(a) computed in this routine.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pbcon(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        const float* anorm,
        float* rcond,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pbcon(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        const float* anorm,
        float* rcond,
        long int* info)
  */
  /*! fn
   inline void pbcon(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        const double* anorm,
        double* rcond,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pbcon(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        const double* anorm,
        double* rcond,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spbcon.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBCON(NAME, T)\
inline void pbcon(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    const T* anorm,\
    T* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(3*(*n));\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, anorm, rcond, w.getw(), w.getiw(), info);\
}\
inline void pbcon(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    const T* anorm,\
    T* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   pbcon(uplo, n, kd, ab, ldab, anorm, rcond, info, w);\
}\

    LPP_PBCON(spbcon, float)
    LPP_PBCON(dpbcon, double)

#undef LPP_PBCON


  // The following macro provides the 4 functions 
  /*! fn
   inline void pbcon(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       const float* anorm,
       float* rcond,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pbcon(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       const float* anorm,
       float* rcond,
       long int* info)
  */
  /*! fn
   inline void pbcon(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       const double* anorm,
       double* rcond,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pbcon(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       const double* anorm,
       double* rcond,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpbcon.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBCON(NAME, T, TBASE)\
inline void pbcon(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, anorm, rcond, w.getw(), w.getrw(), info);\
}\
inline void pbcon(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   pbcon(uplo, n, kd, ab, ldab, anorm, rcond, info, w);\
}\

    LPP_PBCON(cpbcon, std::complex<float>, float)
    LPP_PBCON(zpbcon, std::complex<double>, double)

#undef LPP_PBCON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pbcon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
