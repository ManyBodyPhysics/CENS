#ifndef __PROJECT__LPP__FILE__LAGTM_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAGTM_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lagtm_itf.hh C++ interface to LAPACK (c,d,c,z)lagtm
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lagtm_itf.hh
    (excerpt adapted from xlagtm.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlagtm performs a matrix-vector product of the form
    **
    **     b := alpha * a * x + beta * b
    **
    **  where a is a tridiagonal matrix of order n, b and x are n by nrhs
    **  matrices, and alpha and beta are BASE DATA TYPE scalars, each of which may be
    **  0., 1., or -1.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) character
    **          specifies the operation applied to a.
    **          = 'n':  no transpose, b := alpha * a * x + beta * b
    **          = 't':  transpose,    b := alpha * a**t * x + beta * b
    **          = 'c':  conjugate transpose, b := alpha * a**h * x + beta * b
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrices x and b.
    **
    **  alpha   (input) BASE DATA TYPE
    **          the scalar alpha.  alpha must be 0., 1., or -1.; otherwise,
    **          it is assumed to be 0.
    **
    **  dl      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) sub-diagonal elements of t.
    **
    **  d       (input) DATA TYPE array, dimension (n)
    **          the diagonal elements of t.
    **
    **  du      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) super-diagonal elements of t.
    **
    **  x       (input) DATA TYPE array, dimension (ldx,nrhs)
    **          the n by nrhs matrix x.
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(n,1).
    **
    **  beta    (input) BASE DATA TYPE
    **          the scalar beta.  beta must be 0., 1., or -1.; otherwise,
    **          it is assumed to be 1.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n by nrhs matrix b.
    **          on exit, b is overwritten by the matrix expression
    **          b := alpha * a * x + beta * b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(n,1).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lagtm(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* alpha,
        const float* dl,
        const float* d,
        const float* du,
        const float* x,
        const long int* ldx,
        const float* beta,
        const float* b,
        const long int* ldb,
        workspace<float> & w)
  */
  /*! fn
   inline void lagtm(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const float* alpha,
        const float* dl,
        const float* d,
        const float* du,
        const float* x,
        const long int* ldx,
        const float* beta,
        const float* b,
        const long int* ldb)
  */
  /*! fn
   inline void lagtm(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* alpha,
        const double* dl,
        const double* d,
        const double* du,
        const double* x,
        const long int* ldx,
        const double* beta,
        const double* b,
        const long int* ldb,
        workspace<double> & w)
  */
  /*! fn
   inline void lagtm(
        const char* trans,
        const long int* n,
        const long int* nrhs,
        const double* alpha,
        const double* dl,
        const double* d,
        const double* du,
        const double* x,
        const long int* ldx,
        const double* beta,
        const double* b,
        const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slagtm.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGTM(NAME, T)\
inline void lagtm(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* alpha,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* x,\
    const long int* ldx,\
    const T* beta,\
    const T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, n, nrhs, alpha, dl, d, du, x, ldx, beta, b, ldb);\
}\
inline void lagtm(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const T* alpha,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* x,\
    const long int* ldx,\
    const T* beta,\
    const T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   lagtm(trans, n, nrhs, alpha, dl, d, du, x, ldx, beta, b, ldb, w);\
}\

    LPP_LAGTM(slagtm, float)
    LPP_LAGTM(dlagtm, double)

#undef LPP_LAGTM


  // The following macro provides the 4 functions 
  /*! fn
   inline void lagtm(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const float* alpha,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* x,
       const long int* ldx,
       const float* beta,
       const std::complex<float>* b,
       const long int* ldb,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lagtm(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const float* alpha,
       const std::complex<float>* dl,
       const std::complex<float>* d,
       const std::complex<float>* du,
       const std::complex<float>* x,
       const long int* ldx,
       const float* beta,
       const std::complex<float>* b,
       const long int* ldb)
  */
  /*! fn
   inline void lagtm(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const double* alpha,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* x,
       const long int* ldx,
       const double* beta,
       const std::complex<double>* b,
       const long int* ldb,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lagtm(
       const char* trans,
       const long int* n,
       const long int* nrhs,
       const double* alpha,
       const std::complex<double>* dl,
       const std::complex<double>* d,
       const std::complex<double>* du,
       const std::complex<double>* x,
       const long int* ldx,
       const double* beta,
       const std::complex<double>* b,
       const long int* ldb)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clagtm.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGTM(NAME, T, TBASE)\
inline void lagtm(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* alpha,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* x,\
    const long int* ldx,\
    const TBASE* beta,\
    const T* b,\
    const long int* ldb,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, n, nrhs, alpha, dl, d, du, x, ldx, beta, b, ldb);\
}\
inline void lagtm(\
    const char* trans,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* alpha,\
    const T* dl,\
    const T* d,\
    const T* du,\
    const T* x,\
    const long int* ldx,\
    const TBASE* beta,\
    const T* b,\
    const long int* ldb)\
{\
   workspace<T> w;\
   lagtm(trans, n, nrhs, alpha, dl, d, du, x, ldx, beta, b, ldb, w);\
}\

    LPP_LAGTM(clagtm, std::complex<float>,  float)
    LPP_LAGTM(zlagtm, std::complex<double>, double)

#undef LPP_LAGTM



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lagtm_itf.hh
// /////////////////////////////////////////////////////////////////////////////
