#ifndef __PROJECT__LPP__FILE__STEDC_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEDC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : stedc_itf.hh C++ interface to LAPACK (s,d,c,z)stedc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file stedc_itf.hh
    (excerpt adapted from xstedc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xstedc computes all eigenvalues and, optionally, eigenvectors of a
    **  symmetric tridiagonal matrix using the divide and conquer method.
    **  the eigenvectors of a full or band DATA TYPE hermitian matrix can also
    **  be found if chetrd or chptrd or chbtrd has been used to reduce this
    **  matrix to tridiagonal form.
    **
    **  this code makes very mild assumptions about floating point
    **  arithmetic. it will WORK on machines with a guard digit in
    **  add/subtract, or on those binary machines without guard digits
    **  which subtract like the cray x-mp, cray y-mp, cray c-90, or cray-2.
    **  it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.  see slaed3 for details.
    **
    **  arguments
    **  =========
    **
    **  compz   (input) char
    **          = 'n':  compute eigenvalues only.
    **          = 'i':  compute eigenvectors of tridiagonal matrix also.
    **          = 'v':  compute eigenvectors of original hermitian matrix
    **                  also.  on entry, z contains the unitary matrix used
    **                  to reduce the original matrix to tridiagonal form.
    **
    **  n       (input) long int
    **          the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the diagonal elements of the tridiagonal matrix.
    **          on exit, if info = 0, the eigenvalues in ascending order.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n-1)
    **          on entry, the subdiagonal elements of the tridiagonal matrix.
    **          on exit, e has been destroyed.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          on entry, if compz = 'v', then z contains the unitary
    **          matrix used in the reduction to tridiagonal form.
    **          on exit, if info = 0, then if compz = 'v', z contains the
    **          orthonormal eigenvectors of the original hermitian matrix,
    **          and if compz = 'i', z contains the orthonormal eigenvectors
    **          of the symmetric tridiagonal matrix.
    **          if  compz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1.
    **          if eigenvectors are desired, then ldz >= max(1,n).
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  the algorithm failed to compute an eigenvalue while
    **                WORKing on the submatrix lying in rows and columns
    **                info/(n+1) through mod(info,n+1).
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void stedc(
        const char* compz,
        const long int* n,
        float* d,
        float* e,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void stedc(
        const char* compz,
        const long int* n,
        float* d,
        float* e,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void stedc(
        const char* compz,
        const long int* n,
        double* d,
        double* e,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void stedc(
        const char* compz,
        const long int* n,
        double* d,
        double* e,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sstedc.f)
  //    *  WORK    (workspace/output) float array,
  //    *                                         dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If COMPZ = 'N' or N <= 1 then LWORK must be at least 1.
  //    *          If COMPZ = 'V' and N > 1 then LWORK must be at least
  //    *                         ( 1 + 3*N + 2*N*lg N + 3*N**2 ),
  //    *                         where lg( N ) = smallest integer k such
  //    *                         that 2**k >= N.
  //    *          If COMPZ = 'I' and N > 1 then LWORK must be at least
  //    *                         ( 1 + 4*N + N**2 ).
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  //    *
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK.
  //    *          if compz = 'n' or n <= 1, lIWORK must be at least 1.
  //    *          if compz = 'v' or n > 1,  lIWORK must be at least
  //    *                                    6 + 6*n + 5*n*lg n.
  //    *          if compz = 'i' or n > 1,  lIWORK must be at least
  //    *                                    3 + 5*n .
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
    /////////////////////////////////////////////////////////////////////////

#define LPP_STEDC(NAME, T)\
inline void stedc(\
    const char* compz,\
    const long int* n,\
    T* d,\
    T* e,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizew(w.neededsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void stedc(\
    const char* compz,\
    const long int* n,\
    T* d,\
    T* e,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   stedc(compz, n, d, e, z, ldz, info, w);\
}\

    LPP_STEDC(sstedc, float)
    LPP_STEDC(dstedc, double)

#undef LPP_STEDC


  // The following macro provides the 4 functions 
  /*! fn
   inline void stedc(
       const char* compz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void stedc(
       const char* compz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* z,
       const long int* ldz,
       long int* info)
  */
  /*! fn
   inline void stedc(
       const char* compz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void stedc(
       const char* compz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* z,
       const long int* ldz,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cstedc.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If COMPZ = 'N' or 'I', or N <= 1, LWORK must be at least 1.
  //    *          If COMPZ = 'V' and N > 1, LWORK must be at least N*N.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace/output) float array,
  //    *                                         dimension (LRWORK)
  //    *          On exit, if INFO = 0, RWORK(1) returns the optimal LRWORK.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal LIWORK.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEDC(NAME, T, TBASE)\
inline void stedc(\
    const char* compz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getw(), w.query(), w.getrw(), w.query(), w.getiw(), w.query(), info);\
    w.resizew(w.neededsize());\
    w.resizerw(w.neededrsize());\
    w.resizeiw(w.neededisize());\
    F77NAME( NAME )(compz, n, d, e, z, ldz, w.getw(), &w.neededsize(), w.getrw(), &w.neededrsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void stedc(\
    const char* compz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   stedc(compz, n, d, e, z, ldz, info, w);\
}\

    LPP_STEDC(cstedc, std::complex<float>, float)
    LPP_STEDC(zstedc, std::complex<double>, double)

#undef LPP_STEDC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of stedc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
