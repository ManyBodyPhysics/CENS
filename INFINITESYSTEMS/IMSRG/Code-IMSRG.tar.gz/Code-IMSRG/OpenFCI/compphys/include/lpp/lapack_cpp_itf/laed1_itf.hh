#ifndef __PROJECT__LPP__FILE__LAED1_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED1_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed1_itf.hh C++ interface to LAPACK (s,d,c,z)laed1
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed1_itf.hh
    (excerpt adapted from xlaed1.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed1 computes the updated eigensystem of a diagonal
    **  matrix after modification by a rank-one symmetric matrix.  this
    **  routine is used only for the eigenproblem which requires all
    **  eigenvalues and eigenvectors of a tridiagonal matrix.  dlaed7 handles
    **  the case in which eigenvalues only or eigenvalues and eigenvectors
    **  of a full symmetric matrix (which was reduced to tridiagonal form)
    **  are desired.
    **
    **    t = q(in) ( d(in) + rho * z*z' ) q'(in) = q(out) * d(out) * q'(out)
    **
    **     where z = q'u, u is a vector of length n with ones in the
    **     cutpnt and cutpnt + 1 th elements and zeros elsewhere.
    **
    **     the eigenvectors of the original matrix are stored in q, and the
    **     eigenvalues are in d.  the algorithm consists of three stages:
    **
    **        the first stage consists of deflating the size of the problem
    **        when there are multiple eigenvalues or if there is a zero in
    **        the z vector.  for each such occurence the dimension of the
    **        secular equation problem is reduced by one.  this stage is
    **        performed by the routine dlaed2.
    **
    **        the second stage consists of calculating the updated
    **        eigenvalues. this is done by finding the roots of the secular
    **        equation via the routine dlaed4 (as called by dlaed3).
    **        this routine also calculates the eigenvectors of the current
    **        problem.
    **
    **        the final stage consists of computing the updated eigenvectors
    **        directly using the updated eigenvalues.  the eigenvectors for
    **        the current problem are multiplied with the eigenvectors from
    **        the overall problem.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry, the eigenvalues of the rank-1-perturbed matrix.
    **         on exit, the eigenvalues of the repaired matrix.
    **
    **  q      (input/output) BASE DATA TYPE array, dimension (ldq,n)
    **         on entry, the eigenvectors of the rank-1-perturbed matrix.
    **         on exit, the eigenvectors of the repaired tridiagonal matrix.
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  indxq  (input/output) long int array, dimension (n)
    **         on entry, the permutation which separately sorts the two
    **         subproblems in d into ascending order.
    **         on exit, the permutation which will reintegrate the
    **         subproblems back into sorted order,
    **         i.e. d( indxq( i = 1, n ) ) will be in ascending order.
    **
    **  rho    (input) BASE DATA TYPE
    **         the subdiagonal entry used to create the rank-1 modification.
    **
    **  cutpnt (input) long int
    **         the location of the last eigenvalue in the leading sub-matrix.
    **         min(1,n) <= cutpnt <= n/2.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an eigenvalue did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **  modified by francoise tisseur, university of tennessee.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed1(
        const long int* n,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        const float* rho,
        const long int* cutpnt,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed1(
        const long int* n,
        float* d,
        float* q,
        const long int* ldq,
        long int* indxq,
        const float* rho,
        const long int* cutpnt,
        long int* info)
  */
  /*! fn
   inline void laed1(
        const long int* n,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        const double* rho,
        const long int* cutpnt,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed1(
        const long int* n,
        double* d,
        double* q,
        const long int* ldq,
        long int* indxq,
        const double* rho,
        const long int* cutpnt,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed1.f)
  //    *  WORK   (workspace) float array, dimension (4*N + N**2)
  //    *
  //    *  IWORK  (workspace) long int array, dimension (4*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED1(NAME, T)\
inline void laed1(\
    const long int* n,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    const T* rho,\
    const long int* cutpnt,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(4**n);\
    w.resizew(4*(*n) + (*n)*(*n));                                      \
    F77NAME( NAME )(n, d, q, ldq, indxq, rho, cutpnt, w.getw(), w.getiw(), info);\
}\
inline void laed1(\
    const long int* n,\
    T* d,\
    T* q,\
    const long int* ldq,\
    long int* indxq,\
    const T* rho,\
    const long int* cutpnt,\
    long int* info)\
{\
   workspace<T> w;\
   laed1(n, d, q, ldq, indxq, rho, cutpnt, info, w);\
}\

    LPP_LAED1(slaed1, float)
    LPP_LAED1(dlaed1, double)

#undef LPP_LAED1



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed1_itf.hh
// /////////////////////////////////////////////////////////////////////////////
