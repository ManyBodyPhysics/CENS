#ifndef __PROJECT__LPP__FILE__LAED6_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED6_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed6_itf.hh C++ interface to LAPACK (s,d,c,z)laed6
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed6_itf.hh
    (excerpt adapted from xlaed6.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed6 computes the positive or negative root (closest to the origin)
    **  of
    **                   z(1)        z(2)        z(3)
    **  f(x) =   rho + --------- + ---------- + ---------
    **                  d(1)-x      d(2)-x      d(3)-x
    **
    **  it is assumed that
    **
    **        if orgati = .true. the root is between d(2) and d(3);
    **        otherwise it is between d(1) and d(2)
    **
    **  this routine will be called by dlaed4 when necessary. in most cases,
    **  the root sought is the smallest in magnitude, though it might not be
    **  in some extremely rare situations.
    **
    **  arguments
    **  =========
    **
    **  kniter       (input) long int
    **               refer to dlaed4 for its significance.
    **
    **  orgati       (input) logical
    **               if orgati is true, the needed root is between d(2) and
    **               d(3); otherwise it is between d(1) and d(2).  see
    **               dlaed4 for further details.
    **
    **  rho          (input) BASE DATA TYPE
    **               refer to the equation f(x) above.
    **
    **  d            (input) BASE DATA TYPE array, dimension (3)
    **               d satisfies d(1) < d(2) < d(3).
    **
    **  z            (input) BASE DATA TYPE array, dimension (3)
    **               each of the elements in z must be positive.
    **
    **  finit        (input) BASE DATA TYPE
    **               the value of f at 0. it is more accurate than the one
    **               evaluated inside this routine (if someone wants to do
    **               so).
    **
    **  tau          (output) BASE DATA TYPE
    **               the root of the equation f(x).
    **
    **  info         (output) long int
    **               = 0: successful exit
    **               > 0: if info = 1, failure to converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ren-cang li, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed6(
        const long int* kniter,
        const long int* orgati,
        const float* rho,
        const float* d,
        const float* z,
        const float* finit,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed6(
        const long int* kniter,
        const long int* orgati,
        const float* rho,
        const float* d,
        const float* z,
        const float* finit,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void laed6(
        const long int* kniter,
        const long int* orgati,
        const double* rho,
        const double* d,
        const double* z,
        const double* finit,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed6(
        const long int* kniter,
        const long int* orgati,
        const double* rho,
        const double* d,
        const double* z,
        const double* finit,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed6.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED6(NAME, T)\
inline void laed6(\
    const long int* kniter,\
    const long int* orgati,\
    const T* rho,\
    const T* d,\
    const T* z,\
    const T* finit,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(kniter, orgati, rho, d, z, finit, tau, info);\
}\
inline void laed6(\
    const long int* kniter,\
    const long int* orgati,\
    const T* rho,\
    const T* d,\
    const T* z,\
    const T* finit,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   laed6(kniter, orgati, rho, d, z, finit, tau, info, w);\
}\

    LPP_LAED6(slaed6, float)
    LPP_LAED6(dlaed6, double)

#undef LPP_LAED6



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed6_itf.hh
// /////////////////////////////////////////////////////////////////////////////
