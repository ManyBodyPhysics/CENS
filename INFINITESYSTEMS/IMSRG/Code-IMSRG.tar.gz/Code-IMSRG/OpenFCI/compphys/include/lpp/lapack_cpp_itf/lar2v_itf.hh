#ifndef __PROJECT__LPP__FILE__LAR2V_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAR2V_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lar2v_itf.hh C++ interface to LAPACK (c,d,c,z)lar2v
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lar2v_itf.hh
    (excerpt adapted from xlar2v.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlar2v applies a vector of DATA TYPE plane rotations with BASE DATA TYPE cosines
    **  from both sides to a sequence of 2-by-2 DATA TYPE hermitian matrices,
    **  defined by the elements of the vectors x, y and z. for i = 1,2,...,n
    **
    **     (       x(i)  z(i) ) :=
    **     ( conjg(z(i)) y(i) )
    **
    **       (  c(i) conjg(s(i)) ) (       x(i)  z(i) ) ( c(i) -conjg(s(i)) )
    **       ( -s(i)       c(i)  ) ( conjg(z(i)) y(i) ) ( s(i)        c(i)  )
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of plane rotations to be applied.
    **
    **  x       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          the vector x; the elements of x are assumed to be BASE DATA TYPE.
    **
    **  y       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          the vector y; the elements of y are assumed to be BASE DATA TYPE.
    **
    **  z       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          the vector z.
    **
    **  incx    (input) long int
    **          the increment between elements of x, y and z. incx > 0.
    **
    **  c       (input) BASE DATA TYPE array, dimension (1+(n-1)*incc)
    **          the cosines of the plane rotations.
    **
    **  s       (input) DATA TYPE array, dimension (1+(n-1)*incc)
    **          the sines of the plane rotations.
    **
    **  incc    (input) long int
    **          the increment between elements of c and s. incc > 0.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lar2v(
        const long int* n,
        float* x,
        float* y,
        float* z,
        const long int* incx,
        const float* c,
        const float* s,
        const long int* incc,
        workspace<float> & w)
  */
  /*! fn
   inline void lar2v(
        const long int* n,
        float* x,
        float* y,
        float* z,
        const long int* incx,
        const float* c,
        const float* s,
        const long int* incc)
  */
  /*! fn
   inline void lar2v(
        const long int* n,
        double* x,
        double* y,
        double* z,
        const long int* incx,
        const double* c,
        const double* s,
        const long int* incc,
        workspace<double> & w)
  */
  /*! fn
   inline void lar2v(
        const long int* n,
        double* x,
        double* y,
        double* z,
        const long int* incx,
        const double* c,
        const double* s,
        const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slar2v.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAR2V(NAME, T)\
inline void lar2v(\
    const long int* n,\
    T* x,\
    T* y,\
    T* z,\
    const long int* incx,\
    const T* c,\
    const T* s,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, y, z, incx, c, s, incc);\
}\
inline void lar2v(\
    const long int* n,\
    T* x,\
    T* y,\
    T* z,\
    const long int* incx,\
    const T* c,\
    const T* s,\
    const long int* incc)\
{\
   workspace<T> w;\
   lar2v(n, x, y, z, incx, c, s, incc, w);\
}\

    LPP_LAR2V(slar2v, float)
    LPP_LAR2V(dlar2v, double)

#undef LPP_LAR2V


  // The following macro provides the 4 functions 
  /*! fn
   inline void lar2v(
       const long int* n,
       std::complex<float>* x,
       std::complex<float>* y,
       std::complex<float>* z,
       const long int* incx,
       const float* c,
       const std::complex<float>* s,
       const long int* incc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lar2v(
       const long int* n,
       std::complex<float>* x,
       std::complex<float>* y,
       std::complex<float>* z,
       const long int* incx,
       const float* c,
       const std::complex<float>* s,
       const long int* incc)
  */
  /*! fn
   inline void lar2v(
       const long int* n,
       std::complex<double>* x,
       std::complex<double>* y,
       std::complex<double>* z,
       const long int* incx,
       const double* c,
       const std::complex<double>* s,
       const long int* incc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lar2v(
       const long int* n,
       std::complex<double>* x,
       std::complex<double>* y,
       std::complex<double>* z,
       const long int* incx,
       const double* c,
       const std::complex<double>* s,
       const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clar2v.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAR2V(NAME, T, TBASE)\
inline void lar2v(\
    const long int* n,\
    T* x,\
    T* y,\
    T* z,\
    const long int* incx,\
    const TBASE* c,\
    const T* s,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, y, z, incx, c, s, incc);\
}\
inline void lar2v(\
    const long int* n,\
    T* x,\
    T* y,\
    T* z,\
    const long int* incx,\
    const TBASE* c,\
    const T* s,\
    const long int* incc)\
{\
   workspace<T> w;\
   lar2v(n, x, y, z, incx, c, s, incc, w);\
}\

    LPP_LAR2V(clar2v, std::complex<float>,  float)
    LPP_LAR2V(zlar2v, std::complex<double>, double)

#undef LPP_LAR2V



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lar2v_itf.hh
// /////////////////////////////////////////////////////////////////////////////
