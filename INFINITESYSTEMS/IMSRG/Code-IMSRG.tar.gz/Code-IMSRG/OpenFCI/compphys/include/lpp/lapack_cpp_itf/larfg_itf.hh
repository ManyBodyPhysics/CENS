#ifndef __PROJECT__LPP__FILE__LARFG_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARFG_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larfg_itf.hh C++ interface to LAPACK (c,d,c,z)larfg
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larfg_itf.hh
    (excerpt adapted from xlarfg.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarfg generates a DATA TYPE elementary reflector h of order n, such
    **  that
    **
    **        h' * ( alpha ) = ( beta ),   h' * h = i.
    **             (   x   )   (   0  )
    **
    **  where alpha and beta are scalars, with beta BASE DATA TYPE, and x is an
    **  (n-1)-element DATA TYPE vector. h is represented in the form
    **
    **        h = i - tau * ( 1 ) * ( 1 v' ) ,
    **                      ( v )
    **
    **  where tau is a DATA TYPE scalar and v is a DATA TYPE (n-1)-element
    **  vector. note that h is not hermitian.
    **
    **  if the elements of x are all zero and alpha is BASE DATA TYPE, then tau = 0
    **  and h is taken to be the unit matrix.
    **
    **  otherwise  1 <= BASE DATA TYPE(tau) <= 2  and  abs(tau-1) <= 1 .
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the elementary reflector.
    **
    **  alpha   (input/output) DATA TYPE
    **          on entry, the value alpha.
    **          on exit, it is overwritten with the value beta.
    **
    **  x       (input/output) DATA TYPE array, dimension
    **                         (1+(n-2)*abs(incx))
    **          on entry, the vector x.
    **          on exit, it is overwritten with the vector v.
    **
    **  incx    (input) long int
    **          the increment between elements of x. incx > 0.
    **
    **  tau     (output) DATA TYPE
    **          the value tau.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larfg(
        const long int* n,
        float* alpha,
        float* x,
        const long int* incx,
        float* tau,
        workspace<float> & w)
  */
  /*! fn
   inline void larfg(
        const long int* n,
        float* alpha,
        float* x,
        const long int* incx,
        float* tau)
  */
  /*! fn
   inline void larfg(
        const long int* n,
        double* alpha,
        double* x,
        const long int* incx,
        double* tau,
        workspace<double> & w)
  */
  /*! fn
   inline void larfg(
        const long int* n,
        double* alpha,
        double* x,
        const long int* incx,
        double* tau)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarfg.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARFG(NAME, T)\
inline void larfg(\
    const long int* n,\
    T* alpha,\
    T* x,\
    const long int* incx,\
    T* tau,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, alpha, x, incx, tau);\
}\
inline void larfg(\
    const long int* n,\
    T* alpha,\
    T* x,\
    const long int* incx,\
    T* tau)\
{\
   workspace<T> w;\
   larfg(n, alpha, x, incx, tau, w);\
}\

    LPP_LARFG(slarfg, float)
    LPP_LARFG(dlarfg, double)

#undef LPP_LARFG


  // The following macro provides the 4 functions 
  /*! fn
   inline void larfg(
       const long int* n,
       std::complex<float>* alpha,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* tau,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larfg(
       const long int* n,
       std::complex<float>* alpha,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* tau)
  */
  /*! fn
   inline void larfg(
       const long int* n,
       std::complex<double>* alpha,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* tau,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larfg(
       const long int* n,
       std::complex<double>* alpha,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* tau)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarfg.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARFG(NAME, T, TBASE)\
inline void larfg(\
    const long int* n,\
    T* alpha,\
    T* x,\
    const long int* incx,\
    T* tau,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, alpha, x, incx, tau);\
}\
inline void larfg(\
    const long int* n,\
    T* alpha,\
    T* x,\
    const long int* incx,\
    T* tau)\
{\
   workspace<T> w;\
   larfg(n, alpha, x, incx, tau, w);\
}\

    LPP_LARFG(clarfg, std::complex<float>,  float)
    LPP_LARFG(zlarfg, std::complex<double>, double)

#undef LPP_LARFG



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larfg_itf.hh
// /////////////////////////////////////////////////////////////////////////////
