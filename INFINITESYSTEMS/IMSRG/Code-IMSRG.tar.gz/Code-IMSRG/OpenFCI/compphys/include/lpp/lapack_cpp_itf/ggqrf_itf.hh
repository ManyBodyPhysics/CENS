#ifndef __PROJECT__LPP__FILE__GGQRF_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGQRF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggqrf_itf.hh C++ interface to LAPACK (c,d,c,z)ggqrf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggqrf_itf.hh
    (excerpt adapted from xggqrf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggqrf computes a generalized qr factorization of an n-by-m matrix a
    **  and an n-by-p matrix b:
    **
    **              a = q*r,        b = q*t*z,
    **
    **  where q is an n-by-n unitary matrix, z is a p-by-p unitary matrix,
    **  and r and t assume one of the forms:
    **
    **  if n >= m,  r = ( r11 ) m  ,   or if n < m,  r = ( r11  r12 ) n,
    **                  (  0  ) n-m                         n   m-n
    **                     m
    **
    **  where r11 is upper triangular, and
    **
    **  if n <= p,  t = ( 0  t12 ) n,   or if n > p,  t = ( t11 ) n-p,
    **                   p-n  n                           ( t21 ) p
    **                                                       p
    **
    **  where t12 or t21 is upper triangular.
    **
    **  in particular, if b is square and nonsingular, the gqr factorization
    **  of a and b implicitly gives the qr factorization of inv(b)*a:
    **
    **               inv(b)*a = z'*(inv(t)*r)
    **
    **  where inv(b) denotes the inverse of the matrix b, and z' denotes the
    **  conjugate transpose of matrix z.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of rows of the matrices a and b. n >= 0.
    **
    **  m       (input) long int
    **          the number of columns of the matrix a.  m >= 0.
    **
    **  p       (input) long int
    **          the number of columns of the matrix b.  p >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,m)
    **          on entry, the n-by-m matrix a.
    **          on exit, the elements on and above the diagonal of the array
    **          contain the min(n,m)-by-m upper trapezoidal matrix r (r is
    **          upper triangular if n >= m); the elements below the diagonal,
    **          with the array taua, represent the unitary matrix q as a
    **          product of min(n,m) elementary reflectors (see further
    **          details).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  taua    (output) DATA TYPE array, dimension (min(n,m))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix q (see further details).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,p)
    **          on entry, the n-by-p matrix b.
    **          on exit, if n <= p, the upper triangle of the subarray
    **          b(1:n,p-n+1:p) contains the n-by-n upper triangular matrix t;
    **          if n > p, the elements on and above the (n-p)-th subdiagonal
    **          contain the n-by-p upper trapezoidal matrix t; the remaining
    **          elements, with the array taub, represent the unitary
    **          matrix z as a product of elementary reflectors (see further
    **          details).
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  taub    (output) DATA TYPE array, dimension (min(n,p))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix z (see further details).
    **
    **
    **
    **  info    (output) long int
    **           = 0:  successful exit
    **           < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of elementary reflectors
    **
    **     q = h(1) h(2) . . . h(k), where k = min(n,m).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - taua * v * v'
    **
    **  where taua is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i-1) = 0 and v(i) = 1; v(i+1:n) is stored on exit in a(i+1:n,i),
    **  and taua in taua(i).
    **  to form q explicitly, use lapack subroutine cungqr.
    **  to use q to update another matrix, use lapack subroutine cunmqr.
    **
    **  the matrix z is represented as a product of elementary reflectors
    **
    **     z = h(1) h(2) . . . h(k), where k = min(n,p).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - taub * v * v'
    **
    **  where taub is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(p-k+i+1:p) = 0 and v(p-k+i) = 1; v(1:p-k+i-1) is stored on exit in
    **  b(n-k+i,1:p-k+i-1), and taub in taub(i).
    **  to form z explicitly, use lapack subroutine cungrq.
    **  to use z to update another matrix, use lapack subroutine cunmrq.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggqrf(
        const long int* n,
        const long int* m,
        const long int* p,
        float* a,
        const long int* lda,
        float* taua,
        float* b,
        const long int* ldb,
        float* taub,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggqrf(
        const long int* n,
        const long int* m,
        const long int* p,
        float* a,
        const long int* lda,
        float* taua,
        float* b,
        const long int* ldb,
        float* taub,
        long int* info)
  */
  /*! fn
   inline void ggqrf(
        const long int* n,
        const long int* m,
        const long int* p,
        double* a,
        const long int* lda,
        double* taua,
        double* b,
        const long int* ldb,
        double* taub,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggqrf(
        const long int* n,
        const long int* m,
        const long int* p,
        double* a,
        const long int* lda,
        double* taua,
        double* b,
        const long int* ldb,
        double* taub,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggqrf.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N,M,P).
  //    *          For optimum performance LWORK >= max(N,M,P)*max(NB1,NB2,NB3),
  //    *          where NB1 is the optimal blocksize for the QR factorization
  //    *          of an N-by-M matrix, NB2 is the optimal blocksize for the
  //    *          RQ factorization of an N-by-P matrix, and NB3 is the optimal
  //    *          blocksize for a call of SORMQR.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGQRF(NAME, T)\
inline void ggqrf(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, m, p, a, lda, taua, b, ldb, taub, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, m, p, a, lda, taua, b, ldb, taub, w.getw(), &w.neededsize(), info);\
}\
inline void ggqrf(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info)\
{\
   workspace<T> w;\
   ggqrf(n, m, p, a, lda, taua, b, ldb, taub, info, w);\
}\

    LPP_GGQRF(sggqrf, float)
    LPP_GGQRF(dggqrf, double)

#undef LPP_GGQRF


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggqrf(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* taua,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* taub,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggqrf(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* taua,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* taub,
       long int* info)
  */
  /*! fn
   inline void ggqrf(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* taua,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* taub,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggqrf(
       const long int* n,
       const long int* m,
       const long int* p,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* taua,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* taub,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggqrf.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N,M,P).
  //    *          For optimum performance LWORK >= max(N,M,P)*max(NB1,NB2,NB3),
  //    *          where NB1 is the optimal blocksize for the QR factorization
  //    *          of an N-by-M matrix, NB2 is the optimal blocksize for the
  //    *          RQ factorization of an N-by-P matrix, and NB3 is the optimal
  //    *          blocksize for a call of CUNMQR.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGQRF(NAME, T, TBASE)\
inline void ggqrf(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, m, p, a, lda, taua, b, ldb, taub, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(n, m, p, a, lda, taua, b, ldb, taub, w.getw(), &w.neededsize(), info);\
}\
inline void ggqrf(\
    const long int* n,\
    const long int* m,\
    const long int* p,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info)\
{\
   workspace<T> w;\
   ggqrf(n, m, p, a, lda, taua, b, ldb, taub, info, w);\
}\

    LPP_GGQRF(cggqrf, std::complex<float>,  float)
    LPP_GGQRF(zggqrf, std::complex<double>, double)

#undef LPP_GGQRF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggqrf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
