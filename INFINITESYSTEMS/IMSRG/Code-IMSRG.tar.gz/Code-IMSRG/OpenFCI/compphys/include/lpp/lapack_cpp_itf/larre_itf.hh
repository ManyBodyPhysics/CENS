#ifndef __PROJECT__LPP__FILE__LARRE_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARRE_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larre_itf.hh C++ interface to LAPACK (s,d,c,z)larre
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larre_itf.hh
    (excerpt adapted from xlarre.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  given the tridiagonal matrix t, xlarre sets "small" off-diagonal
    **  elements to zero, and for each unreduced block t_i, it finds
    **  (i) the numbers sigma_i
    **  (ii) the base t_i - sigma_i i = l_i d_i l_i^t representations and
    **  (iii) eigenvalues of each l_i d_i l_i^t.
    **  the representations and eigenvalues found are then used by
    **  dstegr to compute the eigenvectors of a symmetric tridiagonal
    **  matrix. currently, the base representations are limited to being
    **  positive or negative definite, and the eigenvalues of the definite
    **  matrices are found by the dqds algorithm (subroutine dlasq2). as
    **  an added benefit, xlarre also outputs the n gerschgorin
    **  intervals for each l_i d_i l_i^t.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal
    **          matrix t.
    **          on exit, the n diagonal elements of the diagonal
    **          matrices d_i.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix t; e(n) need not be set.
    **          on exit, the subdiagonal elements of the unit bidiagonal
    **          matrices l_i.
    **
    **  tol     (input) BASE DATA TYPE
    **          the threshold for splitting. if on input |e(i)| < tol, then
    **          the matrix t is split into smaller blocks.
    **
    **  nsplit  (input) long int
    **          the number of blocks t splits into. 1 <= nsplit <= n.
    **
    **  isplit  (output) long int array, dimension (2*n)
    **          the splitting points, at which t breaks up into submatrices.
    **          the first submatrix consists of rows/columns 1 to isplit(1),
    **          the second of rows/columns isplit(1)+1 through isplit(2),
    **          etc., and the nsplit-th consists of rows/columns
    **          isplit(nsplit-1)+1 through isplit(nsplit)=n.
    **
    **  m       (output) long int
    **          the total number of eigenvalues (of all the l_i d_i l_i^t)
    **          found.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          the first m elements contain the eigenvalues. the
    **          eigenvalues of each of the blocks, l_i d_i l_i^t, are
    **          sorted in ascending order.
    **
    **  woff    (output) BASE DATA TYPE array, dimension (n)
    **          the nsplit base points sigma_i.
    **
    **  gersch  (output) BASE DATA TYPE array, dimension (2*n)
    **          the n gerschgorin intervals.
    **
    **  info    (output) long int
    **          output error code from dlasq2
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larre(
        const long int* n,
        float* d,
        float* e,
        const float* tol,
        const long int* nsplit,
        long int* isplit,
        long int* m,
        float* ws,
        float* woff,
        float* gersch,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void larre(
        const long int* n,
        float* d,
        float* e,
        const float* tol,
        const long int* nsplit,
        long int* isplit,
        long int* m,
        float* ws,
        float* woff,
        float* gersch,
        long int* info)
  */
  /*! fn
   inline void larre(
        const long int* n,
        double* d,
        double* e,
        const double* tol,
        const long int* nsplit,
        long int* isplit,
        long int* m,
        double* ws,
        double* woff,
        double* gersch,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void larre(
        const long int* n,
        double* d,
        double* e,
        const double* tol,
        const long int* nsplit,
        long int* isplit,
        long int* m,
        double* ws,
        double* woff,
        double* gersch,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarre.f)
  //    **  WORK    (input) BASE DATA TYPE array, dimension (4*n???)
  //    **          WORKspace.
  //    **
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARRE(NAME, T)\
inline void larre(\
    const long int* n,\
    T* d,\
    T* e,\
    const T* tol,\
    const long int* nsplit,\
    long int* isplit,\
    long int* m,\
    T* ws,\
    T* woff,\
    T* gersch,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(4**n);\
    F77NAME( NAME )(n, d, e, tol, nsplit, isplit, m, ws, woff, gersch, w.getw(), info);\
}\
inline void larre(\
    const long int* n,\
    T* d,\
    T* e,\
    const T* tol,\
    const long int* nsplit,\
    long int* isplit,\
    long int* m,\
    T* ws,\
    T* woff,\
    T* gersch,\
    long int* info)\
{\
   workspace<T> w;\
   larre(n, d, e, tol, nsplit, isplit, m, ws, woff, gersch, info, w);\
}\

    LPP_LARRE(slarre, float)
    LPP_LARRE(dlarre, double)

#undef LPP_LARRE



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larre_itf.hh
// /////////////////////////////////////////////////////////////////////////////
