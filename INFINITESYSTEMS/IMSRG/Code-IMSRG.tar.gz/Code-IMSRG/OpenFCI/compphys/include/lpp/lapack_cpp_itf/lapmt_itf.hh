#ifndef __PROJECT__LPP__FILE__LAPMT_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAPMT_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lapmt_itf.hh C++ interface to LAPACK (c,d,c,z)lapmt
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lapmt_itf.hh
    (excerpt adapted from xlapmt.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlapmt rearranges the columns of the m by n matrix x as specified
    **  by the permutation k(1),k(2),...,k(n) of the integers 1,...,n.
    **  if forwrd = .true.,  forward permutation:
    **
    **       x(*,k(j)) is moved x(*,j) for j = 1,2,...,n.
    **
    **  if forwrd = .false., backward permutation:
    **
    **       x(*,j) is moved to x(*,k(j)) for j = 1,2,...,n.
    **
    **  arguments
    **  =========
    **
    **  forwrd  (input) logical
    **          = .true., forward permutation
    **          = .false., backward permutation
    **
    **  m       (input) long int
    **          the number of rows of the matrix x. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix x. n >= 0.
    **
    **  x       (input/output) DATA TYPE array, dimension (ldx,n)
    **          on entry, the m by n matrix x.
    **          on exit, x contains the permuted matrix x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x, ldx >= max(1,m).
    **
    **  k       (input) long int array, dimension (n)
    **          on entry, k contains the permutation vector.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lapmt(
        const long int* forwrd,
        const long int* m,
        const long int* n,
        float* x,
        const long int* ldx,
        const long int* k,
        workspace<float> & w)
  */
  /*! fn
   inline void lapmt(
        const long int* forwrd,
        const long int* m,
        const long int* n,
        float* x,
        const long int* ldx,
        const long int* k)
  */
  /*! fn
   inline void lapmt(
        const long int* forwrd,
        const long int* m,
        const long int* n,
        double* x,
        const long int* ldx,
        const long int* k,
        workspace<double> & w)
  */
  /*! fn
   inline void lapmt(
        const long int* forwrd,
        const long int* m,
        const long int* n,
        double* x,
        const long int* ldx,
        const long int* k)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slapmt.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPMT(NAME, T)\
inline void lapmt(\
    const long int* forwrd,\
    const long int* m,\
    const long int* n,\
    T* x,\
    const long int* ldx,\
    const long int* k,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(forwrd, m, n, x, ldx, k);\
}\
inline void lapmt(\
    const long int* forwrd,\
    const long int* m,\
    const long int* n,\
    T* x,\
    const long int* ldx,\
    const long int* k)\
{\
   workspace<T> w;\
   lapmt(forwrd, m, n, x, ldx, k, w);\
}\

    LPP_LAPMT(slapmt, float)
    LPP_LAPMT(dlapmt, double)

#undef LPP_LAPMT


  // The following macro provides the 4 functions 
  /*! fn
   inline void lapmt(
       const long int* forwrd,
       const long int* m,
       const long int* n,
       std::complex<float>* x,
       const long int* ldx,
       const long int* k,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lapmt(
       const long int* forwrd,
       const long int* m,
       const long int* n,
       std::complex<float>* x,
       const long int* ldx,
       const long int* k)
  */
  /*! fn
   inline void lapmt(
       const long int* forwrd,
       const long int* m,
       const long int* n,
       std::complex<double>* x,
       const long int* ldx,
       const long int* k,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lapmt(
       const long int* forwrd,
       const long int* m,
       const long int* n,
       std::complex<double>* x,
       const long int* ldx,
       const long int* k)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clapmt.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPMT(NAME, T, TBASE)\
inline void lapmt(\
    const long int* forwrd,\
    const long int* m,\
    const long int* n,\
    T* x,\
    const long int* ldx,\
    const long int* k,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(forwrd, m, n, x, ldx, k);\
}\
inline void lapmt(\
    const long int* forwrd,\
    const long int* m,\
    const long int* n,\
    T* x,\
    const long int* ldx,\
    const long int* k)\
{\
   workspace<T> w;\
   lapmt(forwrd, m, n, x, ldx, k, w);\
}\

    LPP_LAPMT(clapmt, std::complex<float>,  float)
    LPP_LAPMT(zlapmt, std::complex<double>, double)

#undef LPP_LAPMT



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lapmt_itf.hh
// /////////////////////////////////////////////////////////////////////////////
