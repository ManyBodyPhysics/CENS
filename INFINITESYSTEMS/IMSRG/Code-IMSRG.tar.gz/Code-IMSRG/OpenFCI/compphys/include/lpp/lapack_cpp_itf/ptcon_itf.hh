#ifndef __PROJECT__LPP__FILE__PTCON_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTCON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ptcon_itf.hh C++ interface to LAPACK (s,d,c,z)ptcon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ptcon_itf.hh
    (excerpt adapted from xptcon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xptcon computes the reciprocal of the condition number (in the
    **  1-norm) of a DATA TYPE hermitian positive definite tridiagonal matrix
    **  using the factorization a = l*d*l**h or a = u**h*d*u computed by
    **  cpttrf.
    **
    **  norm(inv(a)) is computed by a direct method, and the reciprocal of
    **  the condition number is computed as
    **                   rcond = 1 / (anorm * norm(inv(a))).
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d from the
    **          factorization of a, as computed by cpttrf.
    **
    **  e       (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) off-diagonal elements of the unit bidiagonal factor
    **          u or l from the factorization of a, as computed by cpttrf.
    **
    **  anorm   (input) BASE DATA TYPE
    **          the 1-norm of the original matrix a.
    **
    **  rcond   (output) BASE DATA TYPE
    **          the reciprocal of the condition number of the matrix a,
    **          computed as rcond = 1/(anorm * ainvnm), where ainvnm is the
    **          1-norm of inv(a) computed in this routine.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the method used is described in nicholas j. higham, "efficient
    **  algorithms for computing the condition number of a tridiagonal
    **  matrix", siam j. sci. stat. comput., vol. 7, no. 1, january 1986.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ptcon(
        const long int* n,
        const float* d,
        const float* e,
        const float* anorm,
        float* rcond,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ptcon(
        const long int* n,
        const float* d,
        const float* e,
        const float* anorm,
        float* rcond,
        long int* info)
  */
  /*! fn
   inline void ptcon(
        const long int* n,
        const double* d,
        const double* e,
        const double* anorm,
        double* rcond,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ptcon(
        const long int* n,
        const double* d,
        const double* e,
        const double* anorm,
        double* rcond,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sptcon.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTCON(NAME, T)\
inline void ptcon(\
    const long int* n,\
    const T* d,\
    const T* e,\
    const T* anorm,\
    T* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(n, d, e, anorm, rcond, w.getw(), info);\
}\
inline void ptcon(\
    const long int* n,\
    const T* d,\
    const T* e,\
    const T* anorm,\
    T* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   ptcon(n, d, e, anorm, rcond, info, w);\
}\

    LPP_PTCON(sptcon, float)
    LPP_PTCON(dptcon, double)

#undef LPP_PTCON


  // The following macro provides the 4 functions 
  /*! fn
   inline void ptcon(
       const long int* n,
       const float* d,
       const std::complex<float>* e,
       const float* anorm,
       float* rcond,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ptcon(
       const long int* n,
       const float* d,
       const std::complex<float>* e,
       const float* anorm,
       float* rcond,
       long int* info)
  */
  /*! fn
   inline void ptcon(
       const long int* n,
       const double* d,
       const std::complex<double>* e,
       const double* anorm,
       double* rcond,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ptcon(
       const long int* n,
       const double* d,
       const std::complex<double>* e,
       const double* anorm,
       double* rcond,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cptcon.f)
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTCON(NAME, T, TBASE)\
inline void ptcon(\
    const long int* n,\
    const TBASE* d,\
    const T* e,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    F77NAME( NAME )(n, d, e, anorm, rcond, w.getrw(), info);\
}\
inline void ptcon(\
    const long int* n,\
    const TBASE* d,\
    const T* e,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   ptcon(n, d, e, anorm, rcond, info, w);\
}\

    LPP_PTCON(cptcon, std::complex<float>, float)
    LPP_PTCON(zptcon, std::complex<double>, double)

#undef LPP_PTCON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ptcon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
