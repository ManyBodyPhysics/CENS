#ifndef __PROJECT__LPP__FILE__LANHP_HH__INCLUDED
#define __PROJECT__LPP__FILE__LANHP_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lanhp_itf.hh C++ interface to LAPACK (s,d,c,z)lanhp
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lanhp_itf.hh
    (excerpt adapted from xlanhp.f file commentaries)
    
    DATA TYPE can mean complex<float>, complex<double>
    
    BASE TYPE can mean respectively  float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlanhp  returns the value of the one norm,  or the frobenius norm, or
    **  the  infinity norm,  or the  element of  largest absolute value  of a
    **  DATA TYPE hermitian matrix a,  supplied in packed form.
    **
    **  description
    **  ===========
    **
    **  xlanhp returns the value
    **
    **     xlanhp = ( max(abs(a(i,j))), norm = 'm' or 'm'
    **              (
    **              ( norm1(a),         norm = '1', 'o' or 'o'
    **              (
    **              ( normi(a),         norm = 'i' or 'i'
    **              (
    **              ( normf(a),         norm = 'f', 'f', 'e' or 'e'
    **
    **  where  norm1  denotes the  one norm of a matrix (maximum column sum),
    **  normi  denotes the  infinity norm  of a matrix  (maximum row sum) and
    **  normf  denotes the  frobenius norm of a matrix (square root of sum of
    **  squares).  note that  max(abs(a(i,j)))  is not a  matrix norm.
    **
    **  arguments
    **  =========
    **
    **  norm    (input) char
    **          specifies the value to be returned in xlanhp as described
    **          above.
    **
    **  uplo    (input) char
    **          specifies whether the upper or lower triangular part of the
    **          hermitian matrix a is supplied.
    **          = 'u':  upper triangular part of a is supplied
    **          = 'l':  lower triangular part of a is supplied
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.  when n = 0, xlanhp is
    **          set to zero.
    **
    **  ap      (input) DATA TYPE array, dimension (n*(n+1)/2)
    **          the upper or lower triangle of the hermitian matrix a, packed
    **          columnwise in a linear array.  the j-th column of a is stored
    **          in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = a(i,j) for j<=i<=n.
    **          note that the  imaginary parts of the diagonal elements need
    **          not be set and are assumed to be zero.
    **
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline float lanhp(
       const char* norm,
       const char* uplo,
       const long int* n,
       const complex<float>* ap,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline float lanhp(
       const char* norm,
       const char* uplo,
       const long int* n,
       const complex<float>* ap)
  */
  /*! fn
   inline double lanhp(
       const char* norm,
       const char* uplo,
       const long int* n,
       const complex<double>* ap,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline double lanhp(
       const char* norm,
       const char* uplo,
       const long int* n,
       const complex<double>* ap)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clanhp.f)
  //    *  WORK    (workspace) BASE DATA array, dimension (LWORK),
  //    *          where LWORK >= N when NORM = 'I' or '1' or 'O'; otherwise,
  //    *          WORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LANHP(NAME, T, TBASE)\
inline TBASE lanhp(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    workspace<T> & w)\
{\
  w.resizerw((lower(*norm) == 'i'|| *norm ==  '1'  || *norm == '0')?*n:0); \
    return F77NAME( NAME )(norm, uplo, n, ap, w.getrw());\
}\
inline TBASE lanhp(\
    const char* norm,\
    const char* uplo,\
    const long int* n,\
    const T* ap)      \
{\
   workspace<T> w;\
   return lanhp(norm, uplo, n, ap, w);\
}\

    LPP_LANHP(clanhp, std::complex < float > , float)
    LPP_LANHP(zlanhp, std::complex < double >, double)

#undef LPP_LANHP



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lanhp_itf.hh
// /////////////////////////////////////////////////////////////////////////////
