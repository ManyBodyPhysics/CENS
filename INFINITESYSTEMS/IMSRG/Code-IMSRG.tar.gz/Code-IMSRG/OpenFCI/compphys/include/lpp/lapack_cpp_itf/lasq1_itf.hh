#ifndef __PROJECT__LPP__FILE__LASQ1_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASQ1_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasq1_itf.hh C++ interface to LAPACK (s,d,c,z)lasq1
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasq1_itf.hh
    (excerpt adapted from xlasq1.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasq1 computes the singular values of a BASE DATA TYPE n-by-n bidiagonal
    **  matrix with diagonal d and off-diagonal e. the singular values
    **  are computed to high relative accuracy, in the absence of
    **  denormalization, underflow and overflow. the algorithm was first
    **  presented in
    **
    **  "accurate singular values and differential qd algorithms" by k. v.
    **  fernando and b. n. parlett, numer. math., vol-67, no. 2, pp. 191-230,
    **  1994,
    **
    **  and the present implementation is described in "an implementation of
    **  the dqds algorithm (positive case)", lapack WORKing note.
    **
    **  arguments
    **  =========
    **
    **  n     (input) long int
    **        the number of rows and columns in the matrix. n >= 0.
    **
    **  d     (input/output) BASE DATA TYPE array, dimension (n)
    **        on entry, d contains the diagonal elements of the
    **        bidiagonal matrix whose svd is desired. on normal exit,
    **        d contains the singular values in decreasing order.
    **
    **  e     (input/output) BASE DATA TYPE array, dimension (n)
    **        on entry, elements e(1:n-1) contain the off-diagonal elements
    **        of the bidiagonal matrix whose svd is desired.
    **        on exit, e is overwritten.
    **
    **
    **  info  (output) long int
    **        = 0: successful exit
    **        < 0: if info = -i, the i-th argument had an illegal value
    **        > 0: the algorithm failed
    **             = 1, a split was marked by a positive value in e
    **             = 2, current block of z not diagonalized after 30*n
    **                  iterations (in inner while loop)
    **             = 3, termination criterion of outer while loop not met 
    **                  (program created more than n unreduced blocks)
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasq1(
        const long int* n,
        float* d,
        float* e,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasq1(
        const long int* n,
        float* d,
        float* e,
        long int* info)
  */
  /*! fn
   inline void lasq1(
        const long int* n,
        double* d,
        double* e,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasq1(
        const long int* n,
        double* d,
        double* e,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasq1.f)
  //    *  WORK  (workspace) float array, dimension (4*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASQ1(NAME, T)\
inline void lasq1(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(4*(*n));\
    F77NAME( NAME )(n, d, e, w.getw(), info);\
}\
inline void lasq1(\
    const long int* n,\
    T* d,\
    T* e,\
    long int* info)\
{\
   workspace<T> w;\
   lasq1(n, d, e, info, w);\
}\

    LPP_LASQ1(slasq1, float)
    LPP_LASQ1(dlasq1, double)

#undef LPP_LASQ1



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasq1_itf.hh
// /////////////////////////////////////////////////////////////////////////////
