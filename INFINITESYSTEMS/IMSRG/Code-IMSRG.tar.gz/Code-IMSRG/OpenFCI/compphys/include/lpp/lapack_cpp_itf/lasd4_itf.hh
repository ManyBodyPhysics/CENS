#ifndef __PROJECT__LPP__FILE__LASD4_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD4_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd4_itf.hh C++ interface to LAPACK (s,d,c,z)lasd4
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd4_itf.hh
    (excerpt adapted from xlasd4.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this subroutine computes the square root of the i-th updated
    **  eigenvalue of a positive symmetric rank-one modification to
    **  a positive diagonal matrix whose entries are given as the squares
    **  of the corresponding entries in the array d, and that
    **
    **         0 <= d(i) < d(j)  for  i < j
    **
    **  and that rho > 0. this is arranged by the calling routine, and is
    **  no loss in generality.  the rank-one modified system is thus
    **
    **         diag( d ) * diag( d ) +  rho *  z * z_transpose.
    **
    **  where we assume the euclidean norm of z is 1.
    **
    **  the method consists of approximating the rational functions in the
    **  secular equation by simpler interpolating rational functions.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the length of all arrays.
    **
    **  i      (input) long int
    **         the index of the eigenvalue to be computed.  1 <= i <= n.
    **
    **  d      (input) BASE DATA TYPE array, dimension ( n )
    **         the original eigenvalues.  it is assumed that they are in
    **         order, 0 <= d(i) < d(j)  for i < j.
    **
    **  z      (input) BASE DATA TYPE array, dimension ( n )
    **         the components of the updating vector.
    **
    **  delta  (output) BASE DATA TYPE array, dimension ( n )
    **         if n .ne. 1, delta contains (d(j) - sigma_i) in its  j-th
    **         component.  if n = 1, then delta(1) = 1.  the vector delta
    **         contains the information necessary to construct the
    **         (singular) eigenvectors.
    **
    **  rho    (input) BASE DATA TYPE
    **         the scalar in the symmetric updating formula.
    **
    **  sigma  (output) BASE DATA TYPE
    **         the computed lambda_i, the i-th updated eigenvalue.
    **
    **
    **  info   (output) long int
    **         = 0:  successful exit
    **         > 0:  if info = 1, the updating process failed.
    **
    **  internal parameters
    **  ===================
    **
    **  logical variable orgati (origin-at-i?) is used for distinguishing
    **  whether d(i) or d(i+1) is treated as the origin.
    **
    **            orgati = .true.    origin at i
    **            orgati = .false.   origin at i+1
    **
    **  logical variable swtch3 (switch-for-3-poles?) is for noting
    **  if we are WORKing with three poles!
    **
    **  maxit is the maximum number of iterations allowed for each
    **  eigenvalue.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ren-cang li, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd4(
        const long int* n,
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* sigma,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd4(
        const long int* n,
        const long int* i,
        const float* d,
        const float* z,
        float* delta,
        const float* rho,
        float* sigma,
        long int* info)
  */
  /*! fn
   inline void lasd4(
        const long int* n,
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* sigma,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd4(
        const long int* n,
        const long int* i,
        const double* d,
        const double* z,
        double* delta,
        const double* rho,
        double* sigma,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd4.f)
  //    *  WORK   (workspace) float array, dimension ( N )
  //    *         If N .ne. 1, WORK contains (D(j) + sigma_I) in its  j-th
  //    *         component.  If N = 1, then WORK( 1 ) = 1.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD4(NAME, T)\
inline void lasd4(\
    const long int* n,\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* sigma,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew( (*n) );\
    F77NAME( NAME )(n, i, d, z, delta, rho, sigma, w.getw(), info);\
}\
inline void lasd4(\
    const long int* n,\
    const long int* i,\
    const T* d,\
    const T* z,\
    T* delta,\
    const T* rho,\
    T* sigma,\
    long int* info)\
{\
   workspace<T> w;\
   lasd4(n, i, d, z, delta, rho, sigma, info, w);\
}\

    LPP_LASD4(slasd4, float)
    LPP_LASD4(dlasd4, double)

#undef LPP_LASD4



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd4_itf.hh
// /////////////////////////////////////////////////////////////////////////////
