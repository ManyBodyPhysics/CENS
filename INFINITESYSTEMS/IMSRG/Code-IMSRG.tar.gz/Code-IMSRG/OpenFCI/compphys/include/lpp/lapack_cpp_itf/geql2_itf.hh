#ifndef __PROJECT__LPP__FILE__GEQL2_HH__INCLUDED
#define __PROJECT__LPP__FILE__GEQL2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : geql2_itf.hh C++ interface to LAPACK (c,d,c,z)geql2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file geql2_itf.hh
    (excerpt adapted from xgeql2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgeql2 computes a ql factorization of a DATA TYPE m by n matrix a:
    **  a = q * l.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m by n matrix a.
    **          on exit, if m >= n, the lower triangle of the subarray
    **          a(m-n+1:m,1:n) contains the n by n lower triangular matrix l;
    **          if m <= n, the elements on and below the (n-m)-th
    **          superdiagonal contain the m by n lower trapezoidal matrix l;
    **          the remaining elements, with the array tau, represent the
    **          unitary matrix q as a product of elementary reflectors
    **          (see further details).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  tau     (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors (see further
    **          details).
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of elementary reflectors
    **
    **     q = h(k) . . . h(2) h(1), where k = min(m,n).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(m-k+i+1:m) = 0 and v(m-k+i) = 1; v(1:m-k+i-1) is stored on exit in
    **  a(1:m-k+i-1,n-k+i), and tau in tau(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void geql2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void geql2(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void geql2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void geql2(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgeql2.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQL2(NAME, T)\
inline void geql2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(*n);\
    F77NAME( NAME )(m, n, a, lda, tau, w.getw(), info);\
}\
inline void geql2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geql2(m, n, a, lda, tau, info, w);\
}\

    LPP_GEQL2(sgeql2, float)
    LPP_GEQL2(dgeql2, double)

#undef LPP_GEQL2


  // The following macro provides the 4 functions 
  /*! fn
   inline void geql2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void geql2(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void geql2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void geql2(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgeql2.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GEQL2(NAME, T, TBASE)\
inline void geql2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(*n);\
    F77NAME( NAME )(m, n, a, lda, tau, w.getw(), info);\
}\
inline void geql2(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   geql2(m, n, a, lda, tau, info, w);\
}\

    LPP_GEQL2(cgeql2, std::complex<float>,  float)
    LPP_GEQL2(zgeql2, std::complex<double>, double)

#undef LPP_GEQL2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of geql2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
