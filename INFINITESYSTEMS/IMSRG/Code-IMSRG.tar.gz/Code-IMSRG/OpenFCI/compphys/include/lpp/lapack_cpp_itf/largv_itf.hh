#ifndef __PROJECT__LPP__FILE__LARGV_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARGV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : largv_itf.hh C++ interface to LAPACK (c,d,c,z)largv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file largv_itf.hh
    (excerpt adapted from xlargv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlargv generates a vector of DATA TYPE plane rotations with BASE DATA TYPE
    **  cosines, determined by elements of the DATA TYPE vectors x and y.
    **  for i = 1,2,...,n
    **
    **     (        c(i)   s(i) ) ( x(i) ) = ( r(i) )
    **     ( -conjg(s(i))  c(i) ) ( y(i) ) = (   0  )
    **
    **     where c(i)**2 + abs(s(i))**2 = 1
    **
    **  the following conventions are used (these are the same as in clartg,
    **  but differ from the blas1 routine crotg):
    **     if y(i)=0, then c(i)=1 and s(i)=0.
    **     if x(i)=0, then c(i)=0 and s(i) is chosen so that r(i) is BASE DATA TYPE.
    **
    **  arguments
    **  =========
    **
    **  n       (input) long int
    **          the number of plane rotations to be generated.
    **
    **  x       (input/output) DATA TYPE array, dimension (1+(n-1)*incx)
    **          on entry, the vector x.
    **          on exit, x(i) is overwritten by r(i), for i = 1,...,n.
    **
    **  incx    (input) long int
    **          the increment between elements of x. incx > 0.
    **
    **  y       (input/output) DATA TYPE array, dimension (1+(n-1)*incy)
    **          on entry, the vector y.
    **          on exit, the sines of the plane rotations.
    **
    **  incy    (input) long int
    **          the increment between elements of y. incy > 0.
    **
    **  c       (output) BASE DATA TYPE array, dimension (1+(n-1)*incc)
    **          the cosines of the plane rotations.
    **
    **  incc    (input) long int
    **          the increment between elements of c. incc > 0.
    **
    **  further details
    **  ======= =======
    **
    **  6-6-96 - modified with a new algorithm by w. kahan and j. demmel
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void largv(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        const float* c,
        const long int* incc,
        workspace<float> & w)
  */
  /*! fn
   inline void largv(
        const long int* n,
        float* x,
        const long int* incx,
        float* y,
        const long int* incy,
        const float* c,
        const long int* incc)
  */
  /*! fn
   inline void largv(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        const double* c,
        const long int* incc,
        workspace<double> & w)
  */
  /*! fn
   inline void largv(
        const long int* n,
        double* x,
        const long int* incx,
        double* y,
        const long int* incy,
        const double* c,
        const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slargv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARGV(NAME, T)\
inline void largv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const T* c,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, c, incc);\
}\
inline void largv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const T* c,\
    const long int* incc)\
{\
   workspace<T> w;\
   largv(n, x, incx, y, incy, c, incc, w);\
}\

    LPP_LARGV(slargv, float)
    LPP_LARGV(dlargv, double)

#undef LPP_LARGV


  // The following macro provides the 4 functions 
  /*! fn
   inline void largv(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       const float* c,
       const long int* incc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void largv(
       const long int* n,
       std::complex<float>* x,
       const long int* incx,
       std::complex<float>* y,
       const long int* incy,
       const float* c,
       const long int* incc)
  */
  /*! fn
   inline void largv(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       const double* c,
       const long int* incc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void largv(
       const long int* n,
       std::complex<double>* x,
       const long int* incx,
       std::complex<double>* y,
       const long int* incy,
       const double* c,
       const long int* incc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clargv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARGV(NAME, T, TBASE)\
inline void largv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const TBASE* c,\
    const long int* incc,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, x, incx, y, incy, c, incc);\
}\
inline void largv(\
    const long int* n,\
    T* x,\
    const long int* incx,\
    T* y,\
    const long int* incy,\
    const TBASE* c,\
    const long int* incc)\
{\
   workspace<T> w;\
   largv(n, x, incx, y, incy, c, incc, w);\
}\

    LPP_LARGV(clargv, std::complex<float>,  float)
    LPP_LARGV(zlargv, std::complex<double>, double)

#undef LPP_LARGV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of largv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
