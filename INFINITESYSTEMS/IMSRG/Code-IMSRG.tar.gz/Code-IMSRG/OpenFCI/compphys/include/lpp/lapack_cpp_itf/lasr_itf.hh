#ifndef __PROJECT__LPP__FILE__LASR_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasr_itf.hh C++ interface to LAPACK (c,d,c,z)lasr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasr_itf.hh
    (excerpt adapted from xlasr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasr applies a sequence of BASE DATA TYPE plane rotations to a DATA TYPE matrix
    **  a, from either the left or the right.
    **
    **  when side = 'l', the transformation takes the form
    **
    **     a := p*a
    **
    **  and when side = 'r', the transformation takes the form
    **
    **     a := a*p**t
    **
    **  where p is an orthogonal matrix consisting of a sequence of z plane
    **  rotations, with z = m when side = 'l' and z = n when side = 'r',
    **  and p**t is the transpose of p.
    **  
    **  when direct = 'f' (forward sequence), then
    **  
    **     p = p(z-1) * ... * p(2) * p(1)
    **  
    **  and when direct = 'b' (backward sequence), then
    **  
    **     p = p(1) * p(2) * ... * p(z-1)
    **  
    **  where p(k) is a plane rotation matrix defined by the 2-by-2 rotation
    **  
    **     r(k) = (  c(k)  s(k) )
    **          = ( -s(k)  c(k) ).
    **  
    **  when pivot = 'v' (variable pivot), the rotation is performed
    **  for the plane (k,k+1), i.e., p(k) has the form
    **  
    **     p(k) = (  1                                            )
    **            (       ...                                     )
    **            (              1                                )
    **            (                   c(k)  s(k)                  )
    **            (                  -s(k)  c(k)                  )
    **            (                                1              )
    **            (                                     ...       )
    **            (                                            1  )
    **  
    **  where r(k) appears as a rank-2 modification to the identity matrix in
    **  rows and columns k and k+1.
    **  
    **  when pivot = 't' (top pivot), the rotation is performed for the
    **  plane (1,k+1), so p(k) has the form
    **  
    **     p(k) = (  c(k)                    s(k)                 )
    **            (         1                                     )
    **            (              ...                              )
    **            (                     1                         )
    **            ( -s(k)                    c(k)                 )
    **            (                                 1             )
    **            (                                      ...      )
    **            (                                             1 )
    **  
    **  where r(k) appears in rows and columns 1 and k+1.
    **  
    **  similarly, when pivot = 'b' (bottom pivot), the rotation is
    **  performed for the plane (k,z), giving p(k) the form
    **  
    **     p(k) = ( 1                                             )
    **            (      ...                                      )
    **            (             1                                 )
    **            (                  c(k)                    s(k) )
    **            (                         1                     )
    **            (                              ...              )
    **            (                                     1         )
    **            (                 -s(k)                    c(k) )
    **  
    **  where r(k) appears in rows and columns k and z.  the rotations are
    **  performed without ever forming p(k) explicitly.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          specifies whether the plane rotation matrix p is applied to
    **          a on the left or the right.
    **          = 'l':  left, compute a := p*a
    **          = 'r':  right, compute a:= a*p**t
    **
    **  direct  (input) char
    **          specifies whether p is a forward or backward sequence of
    **          plane rotations.
    **          = 'f':  forward, p = p(z-1)*...*p(2)*p(1)
    **          = 'b':  backward, p = p(1)*p(2)*...*p(z-1)
    **
    **  pivot   (input) char
    **          specifies the plane for which p(k) is a plane rotation
    **          matrix.
    **          = 'v':  variable pivot, the plane (k,k+1)
    **          = 't':  top pivot, the plane (1,k+1)
    **          = 'b':  bottom pivot, the plane (k,z)
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  if m <= 1, an immediate
    **          return is effected.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  if n <= 1, an
    **          immediate return is effected.
    **
    **  c       (input) BASE DATA TYPE array, dimension
    **                  (m-1) if side = 'l'
    **                  (n-1) if side = 'r'
    **          the cosines c(k) of the plane rotations.
    **
    **  s       (input) BASE DATA TYPE array, dimension
    **                  (m-1) if side = 'l'
    **                  (n-1) if side = 'r'
    **          the sines s(k) of the plane rotations.  the 2-by-2 plane
    **          rotation part of the matrix p(k), r(k), has the form
    **          r(k) = (  c(k)  s(k) )
    **                 ( -s(k)  c(k) ).
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          the m-by-n matrix a.  on exit, a is overwritten by p*a if
    **          side = 'r' or by a*p**t if side = 'l'.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasr(
        const char* side,
        const char* pivot,
        const char* direct,
        const long int* m,
        const long int* n,
        const float* c,
        const float* s,
        float* a,
        const long int* lda,
        workspace<float> & w)
  */
  /*! fn
   inline void lasr(
        const char* side,
        const char* pivot,
        const char* direct,
        const long int* m,
        const long int* n,
        const float* c,
        const float* s,
        float* a,
        const long int* lda)
  */
  /*! fn
   inline void lasr(
        const char* side,
        const char* pivot,
        const char* direct,
        const long int* m,
        const long int* n,
        const double* c,
        const double* s,
        double* a,
        const long int* lda,
        workspace<double> & w)
  */
  /*! fn
   inline void lasr(
        const char* side,
        const char* pivot,
        const char* direct,
        const long int* m,
        const long int* n,
        const double* c,
        const double* s,
        double* a,
        const long int* lda)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasr.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASR(NAME, T)\
inline void lasr(\
    const char* side,\
    const char* pivot,\
    const char* direct,\
    const long int* m,\
    const long int* n,\
    const T* c,\
    const T* s,\
    T* a,\
    const long int* lda,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, pivot, direct, m, n, c, s, a, lda);\
}\
inline void lasr(\
    const char* side,\
    const char* pivot,\
    const char* direct,\
    const long int* m,\
    const long int* n,\
    const T* c,\
    const T* s,\
    T* a,\
    const long int* lda)\
{\
   workspace<T> w;\
   lasr(side, pivot, direct, m, n, c, s, a, lda, w);\
}\

    LPP_LASR(slasr, float)
    LPP_LASR(dlasr, double)

#undef LPP_LASR


  // The following macro provides the 4 functions 
  /*! fn
   inline void lasr(
       const char* side,
       const char* pivot,
       const char* direct,
       const long int* m,
       const long int* n,
       const float* c,
       const float* s,
       std::complex<float>* a,
       const long int* lda,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lasr(
       const char* side,
       const char* pivot,
       const char* direct,
       const long int* m,
       const long int* n,
       const float* c,
       const float* s,
       std::complex<float>* a,
       const long int* lda)
  */
  /*! fn
   inline void lasr(
       const char* side,
       const char* pivot,
       const char* direct,
       const long int* m,
       const long int* n,
       const double* c,
       const double* s,
       std::complex<double>* a,
       const long int* lda,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lasr(
       const char* side,
       const char* pivot,
       const char* direct,
       const long int* m,
       const long int* n,
       const double* c,
       const double* s,
       std::complex<double>* a,
       const long int* lda)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clasr.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASR(NAME, T, TBASE)\
inline void lasr(\
    const char* side,\
    const char* pivot,\
    const char* direct,\
    const long int* m,\
    const long int* n,\
    const TBASE* c,\
    const TBASE* s,\
    T* a,\
    const long int* lda,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(side, pivot, direct, m, n, c, s, a, lda);\
}\
inline void lasr(\
    const char* side,\
    const char* pivot,\
    const char* direct,\
    const long int* m,\
    const long int* n,\
    const TBASE* c,\
    const TBASE* s,\
    T* a,\
    const long int* lda)\
{\
   workspace<T> w;\
   lasr(side, pivot, direct, m, n, c, s, a, lda, w);\
}\

    LPP_LASR(clasr, std::complex<float>,  float)
    LPP_LASR(zlasr, std::complex<double>, double)

#undef LPP_LASR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
