#ifndef __PROJECT__LPP__FILE__LAQTR_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQTR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqtr_itf.hh C++ interface to LAPACK (s,d,c,z)laqtr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqtr_itf.hh
    (excerpt adapted from xlaqtr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqtr solves the BASE DATA TYPE quasi-triangular system
    **
    **               op(t)*p = scale*c,               if lBASE DATA TYPE = .true.
    **
    **  or the DATA TYPE quasi-triangular systems
    **
    **             op(t + ib)*(p+iq) = scale*(c+id),  if lBASE DATA TYPE = .false.
    **
    **  in BASE DATA TYPE arithmetic, where t is upper quasi-triangular.
    **  if lBASE DATA TYPE = .false., then the first diagonal block of t must be
    **  1 by 1, b is the specially structured matrix
    **
    **                 b = [ b(1) b(2) ... b(n) ]
    **                     [       w            ]
    **                     [           w        ]
    **                     [              .     ]
    **                     [                 w  ]
    **
    **  op(a) = a or a', a' denotes the conjugate transpose of
    **  matrix a.
    **
    **  on input, x = [ c ].  on output, x = [ p ].
    **                [ d ]                  [ q ]
    **
    **  this subroutine is designed for the condition number estimation
    **  in routine dtrsna.
    **
    **  arguments
    **  =========
    **
    **  ltran   (input) logical
    **          on entry, ltran specifies the option of conjugate transpose:
    **             = .false.,    op(t+i*b) = t+i*b,
    **             = .true.,     op(t+i*b) = (t+i*b)'.
    **
    **  lBASE DATA TYPE   (input) logical
    **          on entry, lBASE DATA TYPE specifies the input matrix structure:
    **             = .false.,    the input is DATA TYPE
    **             = .true.,     the input is BASE DATA TYPE
    **
    **  n       (input) long int
    **          on entry, n specifies the order of t+i*b. n >= 0.
    **
    **  t       (input) BASE DATA TYPE array, dimension (ldt,n)
    **          on entry, t contains a matrix in schur canonical form.
    **          if lBASE DATA TYPE = .false., then the first diagonal block of t mu
    **          be 1 by 1.
    **
    **  ldt     (input) long int
    **          the leading dimension of the matrix t. ldt >= max(1,n).
    **
    **  b       (input) BASE DATA TYPE array, dimension (n)
    **          on entry, b contains the elements to form the matrix
    **          b as described above.
    **          if lBASE DATA TYPE = .true., b is not referenced.
    **
    **  w       (input) BASE DATA TYPE
    **          on entry, w is the diagonal element of the matrix b.
    **          if lBASE DATA TYPE = .true., w is not referenced.
    **
    **  scale   (output) BASE DATA TYPE
    **          on exit, scale is the scale factor.
    **
    **  x       (input/output) BASE DATA TYPE array, dimension (2*n)
    **          on entry, x contains the right hand side of the system.
    **          on exit, x is overwritten by the solution.
    **
    **
    **  info    (output) long int
    **          on exit, info is set to
    **             0: successful exit.
    **               1: the some diagonal 1 by 1 block has been perturbed by
    **                  a small number smin to keep nonsingularity.
    **               2: the some diagonal 2 by 2 block has been perturbed by
    **                  a small number in dlaln2 to keep nonsingularity.
    **          note: in the interests of speed, this routine does not
    **                check the inputs for errors.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqtr(
        const long int* ltran,
        const long int* lreal,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* b,
        const float* ws,
        float* scale,
        float* x,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laqtr(
        const long int* ltran,
        const long int* lreal,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* b,
        const float* ws,
        float* scale,
        float* x,
        long int* info)
  */
  /*! fn
   inline void laqtr(
        const long int* ltran,
        const long int* lreal,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* b,
        const double* ws,
        double* scale,
        double* x,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laqtr(
        const long int* ltran,
        const long int* lreal,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* b,
        const double* ws,
        double* scale,
        double* x,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaqtr.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQTR(NAME, T)\
inline void laqtr(\
    const long int* ltran,\
    const long int* lreal,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* b,\
    const T* ws,\
    T* scale,\
    T* x,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(ltran, lreal, n, t, ldt, b, ws, scale, x, w.getw(), info);\
}\
inline void laqtr(\
    const long int* ltran,\
    const long int* lreal,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* b,\
    const T* ws,\
    T* scale,\
    T* x,\
    long int* info)\
{\
   workspace<T> w;\
   laqtr(ltran, lreal, n, t, ldt, b, ws, scale, x, info, w);\
}\

    LPP_LAQTR(slaqtr, float)
    LPP_LAQTR(dlaqtr, double)

#undef LPP_LAQTR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqtr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
