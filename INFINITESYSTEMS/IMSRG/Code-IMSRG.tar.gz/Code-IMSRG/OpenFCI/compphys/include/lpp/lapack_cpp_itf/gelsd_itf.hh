#ifndef __PROJECT__LPP__FILE__GELSD_HH__INCLUDED
#define __PROJECT__LPP__FILE__GELSD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gelsd_itf.hh C++ interface to LAPACK (c,d,c,z)gelsd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gelsd_itf.hh
    (excerpt adapted from xgelsd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgelsd computes the minimum-norm solution to a BASE DATA TYPE linear least
    **  squares problem:
    **      minimize 2-norm(| b - a*x |)
    **  using the singular value decomposition (svd) of a. a is an m-by-n
    **  matrix which may be rank-deficient.
    **
    **  several right hand side vectors b and solution vectors x can be
    **  handled in a single call; they are stored as the columns of the
    **  m-by-nrhs right hand side matrix b and the n-by-nrhs solution
    **  matrix x.
    **
    **  the problem is solved in three steps:
    **  (1) reduce the coefficient matrix a to bidiagonal form with
    **      householder tranformations, reducing the original problem
    **      into a "bidiagonal least squares problem" (bls)
    **  (2) solve the bls using a divide and conquer approach.
    **  (3) apply back all the householder tranformations to solve
    **      the original least squares problem.
    **
    **  the effective rank of a is determined by treating as zero those
    **  singular values which are less than rcond times the largest singular
    **  value.
    **
    **  the divide and conquer algorithm makes very mild assumptions about
    **  floating point arithmetic. it will WORK on machines with a guard
    **  digit in add/subtract, or on those binary machines without guard
    **  digits which subtract like the cray x-mp, cray y-mp, cray c-90, or
    **  cray-2. it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a. n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrices b and x. nrhs >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, the first min(m,n) rows of a are overwritten with
    **          its right singular vectors, stored rowwise.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the m-by-nrhs right hand side matrix b.
    **          on exit, b is overwritten by the n-by-nrhs solution matrix x.
    **          if m >= n and rank = n, the residual sum-of-squares for
    **          the solution in the i-th column is given by the sum of
    **          squares of elements n+1:m in that column.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,m,n).
    **
    **  s       (output) BASE DATA TYPE array, dimension (min(m,n))
    **          the singular values of a in decreasing order.
    **          the condition number of a in the 2-norm = s(1)/s(min(m,n)).
    **
    **  rcond   (input) BASE DATA TYPE
    **          rcond is used to determine the effective rank of a.
    **          singular values s(i) <= rcond*s(1) are treated as zero.
    **          if rcond < 0, machine precision is used instead.
    **
    **  rank    (output) long int
    **          the effective rank of a, i.e., the number of singular values
    **          which are greater than rcond*s(1).
    **
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value.
    **          > 0:  the algorithm for computing the svd failed to converge;
    **                if info = i, i off-diagonal elements of an intermediate
    **                bidiagonal form did not converge to zero.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and ren-cang li, computer science division, university of
    **       california at berkeley, usa
    **     osni marques, lbnl/nersc, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////

    struct gelsdUtils
    {
      static inline long int nlvl(const std::string & name, long int minnm, long int nrsh)
      {
        std::string blank =  " ";
        minnm = std::max(minnm, 1l);
        long int smlsiz = EnvBlockSize(9, name.c_str(), blank,0, 0, 0, 0);
        return (long int)std::max( int(std::log(double(minnm))/ double(smlsiz+1))/std::log(2.0)+1,0.0);
      }      
    
      static inline size_t liwork(const std::string & name, long int n,  long int m, long int nrsh)
      {
        long int minnm = std::min(n, m); 
        return (3*nlvl(name, minnm, nrsh)+11)*minnm; 
      }      
      
      static inline long int lrwork(const std::string & name, long int n,  long int m, long int nrsh)
      {
        std::string blank =  " ";
        long int maxnm = std::max(n, m);
        long int minnm = std::min(n, m); 
        long int nl = nlvl(name, minnm, nrsh); 
        long int smlsiz = EnvBlockSize(9, name.c_str(), blank,0, 0, 0, 0);
        return 10*maxnm + 2*maxnm*smlsiz + 8*m*nl + 3*smlsiz*nrsh +  (smlsiz+1)*(smlsiz+1); 
      }      
    };    
    



  // The following macro provides the 4 functions 
  /*! fn
   inline void gelsd(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* s,
        const float* rcond,
        long int* rank,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gelsd(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* s,
        const float* rcond,
        long int* rank,
        long int* info)
  */
  /*! fn
   inline void gelsd(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* s,
        const double* rcond,
        long int* rank,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gelsd(
        const long int* m,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* s,
        const double* rcond,
        long int* rank,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgelsd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= 1.
  //    *          The exact minimum amount of workspace needed depends on M,
  //    *          N and NRHS.
  //    *          If M >= N, LWORK >=  11*N + 2*N*SMLSIZ + 8*N*NLVL + N*NRHS.
  //    *          If M < N, LWORK >=  11*M + 2*M*SMLSIZ + 8*M*NLVL + M*NRHS.
  //    *          SMLSIZ is returned by ILAENV and is equal to the maximum
  //    *          size of the subproblems at the bottom of the computation
  //    *          tree (usually about 25), and
  //    *              NLVL = INT( LOG_2( MIN( M,N )/(SMLSIZ+1) ) ) + 1
  //    *          For good performance, LWORK should generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (LIWORK)
  //    *          LIWORK >= 3 * MINMN * NLVL + 11 * MINMN,
  //    *          where MINMN = MIN( M,N ).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELSD(NAME, T)\
inline void gelsd(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* s,\
    const T* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(gelsdUtils::liwork("AME", *n, *m, *nrhs));              \
  F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, w.getw(), w.query(), w.getiw(), info); \
  w.resizew(w.neededsize());                                            \
  F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, w.getw(), &w.neededsize(), w.getiw(), info); \
}\
inline void gelsd(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* s,\
    const T* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   gelsd(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, info, w);\
}\

    LPP_GELSD(sgelsd, float)
    LPP_GELSD(dgelsd, double)

#undef LPP_GELSD


  // The following macro provides the 4 functions 
  /*! fn
   inline void gelsd(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const float* s,
       const float* rcond,
       long int* rank,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gelsd(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const float* s,
       const float* rcond,
       long int* rank,
       long int* info)
  */
  /*! fn
   inline void gelsd(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const double* s,
       const double* rcond,
       long int* rank,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gelsd(
       const long int* m,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const double* s,
       const double* rcond,
       long int* rank,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgelsd.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= 1.
  //    *          The exact minimum amount of workspace needed depends on M,
  //    *          N and NRHS.
  //    *          If M >= N, LWORK >= 2*N + N*NRHS.
  //    *          If M < N, LWORK >= 2*M + M*NRHS.
  //    *          For good performance, LWORK should generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (LRWORK)
  //    *          If M >= N, LRWORK >= 8*N + 2*N*SMLSIZ + 8*N*NLVL + N*NRHS.
  //    *          If M < N, LRWORK >= 8*M + 2*M*SMLSIZ + 8*M*NLVL + M*NRHS.
  //    *          SMLSIZ is returned by ILAENV and is equal to the maximum
  //    *          size of the subproblems at the bottom of the computation
  //    *          tree (usually about 25), and
  //    *              NLVL = INT( LOG_2( MIN( M,N )/(SMLSIZ+1) ) ) + 1
  //    *
  //    *  IWORK   (workspace) long int array, dimension (LIWORK)
  //    *          LIWORK >= 3 * MINMN * NLVL + 11 * MINMN,
  //    *          where MINMN = MIN( M,N ).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELSD(NAME, T, TBASE)\
inline void gelsd(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const TBASE* s,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(gelsdUtils::liwork("NAME", *n, *m, *nrhs));              \
  w.resizerw(gelsdUtils::lrwork("NAME", *n, *m, *nrhs));              \
  F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, w.getw(), w.query(), w.getrw(), w.getiw(), info); \
  w.resizew(w.neededsize());                                            \
  F77NAME( NAME )(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, w.getw(), &w.neededsize(), w.getrw(), w.getiw(), info); \
}\
inline void gelsd(\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const TBASE* s,\
    const TBASE* rcond,\
    long int* rank,\
    long int* info)\
{\
   workspace<T> w;\
   gelsd(m, n, nrhs, a, lda, b, ldb, s, rcond, rank, info, w);\
}\

    LPP_GELSD(cgelsd, std::complex<float>,  float)
    LPP_GELSD(zgelsd, std::complex<double>, double)

#undef LPP_GELSD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gelsd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
