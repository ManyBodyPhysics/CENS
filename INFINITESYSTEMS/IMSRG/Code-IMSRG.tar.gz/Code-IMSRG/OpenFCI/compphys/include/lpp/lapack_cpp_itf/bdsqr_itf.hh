#ifndef __PROJECT__LPP__FILE__BDSQR_HH__INCLUDED
#define __PROJECT__LPP__FILE__BDSQR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : bdsqr_itf.hh C++ interface to LAPACK (c,d,c,z)bdsqr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file bdsqr_itf.hh
    (excerpt adapted from xbdsqr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xbdsqr computes the singular values and, optionally, the right and/or
    **  left singular vectors from the singular value decomposition (svd) of
    **  a BASE DATA TYPE n-by-n (upper or lower) bidiagonal matrix b using the implicit
    **  zero-shift qr algorithm.  the svd of b has the form
    **  
    **     b = q * s * p**h
    **  
    **  where s is the diagonal matrix of singular values, q is an orthogonal
    **  matrix of left singular vectors, and p is an orthogonal matrix of
    **  right singular vectors.  if left singular vectors are requested, this
    **  subroutine actually returns u*q instead of q, and, if right singular
    **  vectors are requested, this subroutine returns p**h*vt instead of
    **  p**h, for given DATA TYPE input matrices u and vt.  when u and vt are
    **  the unitary matrices that reduce a general matrix a to bidiagonal
    **  form: a = u*b*vt, as computed by cgebrd, then
    **  
    **     a = (u*q) * s * (p**h*vt)
    **  
    **  is the svd of a.  optionally, the subroutine may also compute q**h*c
    **  for a given DATA TYPE input matrix c.
    **
    **  see "computing  small singular values of bidiagonal matrices with
    **  guaranteed high relative accuracy," by j. demmel and w. kahan,
    **  lapack WORKing note #3 (or siam j. sci. statist. comput. vol. 11,
    **  no. 5, pp. 873-912, sept 1990) and
    **  "accurate singular values and differential qd algorithms," by
    **  b. parlett and v. fernando, technical report cpam-554, mathematics
    **  department, university of california at berkeley, july 1992
    **  for a detailed description of the algorithm.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  b is upper bidiagonal;
    **          = 'l':  b is lower bidiagonal.
    **
    **  n       (input) long int
    **          the order of the matrix b.  n >= 0.
    **
    **  ncvt    (input) long int
    **          the number of columns of the matrix vt. ncvt >= 0.
    **
    **  nru     (input) long int
    **          the number of rows of the matrix u. nru >= 0.
    **
    **  ncc     (input) long int
    **          the number of columns of the matrix c. ncc >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the bidiagonal matrix b.
    **          on exit, if info=0, the singular values of b in decreasing
    **          order.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n-1 offdiagonal elements of the bidiagonal
    **          matrix b.
    **          on exit, if info = 0, e is destroyed; if info > 0, d and e
    **          will contain the diagonal and superdiagonal elements of a
    **          bidiagonal matrix orthogonally equivalent to the one given
    **          as input. e(n) is used for WORKspace.
    **
    **  vt      (input/output) DATA TYPE array, dimension (ldvt, ncvt)
    **          on entry, an n-by-ncvt matrix vt.
    **          on exit, vt is overwritten by p**h * vt.
    **          not referenced if ncvt = 0.
    **
    **  ldvt    (input) long int
    **          the leading dimension of the array vt.
    **          ldvt >= max(1,n) if ncvt > 0; ldvt >= 1 if ncvt = 0.
    **
    **  u       (input/output) DATA TYPE array, dimension (ldu, n)
    **          on entry, an nru-by-n matrix u.
    **          on exit, u is overwritten by u * q.
    **          not referenced if nru = 0.
    **
    **  ldu     (input) long int
    **          the leading dimension of the array u.  ldu >= max(1,nru).
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc, ncc)
    **          on entry, an n-by-ncc matrix c.
    **          on exit, c is overwritten by q**h * c.
    **          not referenced if ncc = 0.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c.
    **          ldc >= max(1,n) if ncc > 0; ldc >=1 if ncc = 0.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  the algorithm did not converge; d and e contain the
    **                elements of a bidiagonal matrix which is orthogonally
    **                similar to the input matrix b;  if info = i, i
    **                elements of e have not converged to zero.
    **
    **  internal parameters
    **  ===================
    **
    **  tolmul  BASE DATA TYPE, default = max(10,min(100,eps**(-1/8)))
    **          tolmul controls the convergence criterion of the qr loop.
    **          if it is positive, tolmul*eps is the desired relative
    **             precision in the computed singular values.
    **          if it is negative, abs(tolmul*eps*sigma_max) is the
    **             desired absolute accuracy in the computed singular
    **             values (corresponds to relative accuracy
    **             abs(tolmul*eps) in the largest singular value.
    **          abs(tolmul) should be between 1 and 1/eps, and preferably
    **             between 10 (for fast convergence) and .1/eps
    **             (for there to be some accuracy in the results).
    **          default is to lose at either one eighth or 2 of the
    **             available decimal digits in each computed singular value
    **             (whichever is smaller).
    **
    **  maxitr  long int, default = 6
    **          maxitr controls the maximum number of passes of the
    **          algorithm through its inner loop. the algorithms stops
    **          (and so fails to converge) if the number of passes
    **          through the inner loop exceeds maxitr*n**2.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void bdsqr(
        const char* uplo,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        float* d,
        float* e,
        const float* vt,
        const long int* ldvt,
        const float* u,
        const long int* ldu,
        const float* c,
        const long int* ldc,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void bdsqr(
        const char* uplo,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        float* d,
        float* e,
        const float* vt,
        const long int* ldvt,
        const float* u,
        const long int* ldu,
        const float* c,
        const long int* ldc,
        long int* info)
  */
  /*! fn
   inline void bdsqr(
        const char* uplo,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        double* d,
        double* e,
        const double* vt,
        const long int* ldvt,
        const double* u,
        const long int* ldu,
        const double* c,
        const long int* ldc,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void bdsqr(
        const char* uplo,
        const long int* n,
        const long int* ncvt,
        const long int* nru,
        const long int* ncc,
        double* d,
        double* e,
        const double* vt,
        const long int* ldvt,
        const double* u,
        const long int* ldu,
        const double* c,
        const long int* ldc,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sbdsqr.f)
  //    *  WORK    (workspace) float array, dimension (2*N)
  //    *          if NCVT = NRU = NCC = 0, (max(1, 4*N-4)) otherwise
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_BDSQR(NAME, T)\
inline void bdsqr(\
    const char* uplo,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    T* d,\
    T* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
  long int ldw = (!*ncvt && !*nru && !*ncc)? 2**n : std::max(1l,  4**n-4); \
    w.resizew(ldw);\
    F77NAME( NAME )(uplo, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, w.getw(), info);\
}\
inline void bdsqr(\
    const char* uplo,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    T* d,\
    T* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   bdsqr(uplo, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, info, w);\
}\

    LPP_BDSQR(sbdsqr, float)
    LPP_BDSQR(dbdsqr, double)

#undef LPP_BDSQR


  // The following macro provides the 4 functions 
  /*! fn
   inline void bdsqr(
       const char* uplo,
       const long int* n,
       const long int* ncvt,
       const long int* nru,
       const long int* ncc,
       float* d,
       float* e,
       const std::complex<float>* vt,
       const long int* ldvt,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* c,
       const long int* ldc,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void bdsqr(
       const char* uplo,
       const long int* n,
       const long int* ncvt,
       const long int* nru,
       const long int* ncc,
       float* d,
       float* e,
       const std::complex<float>* vt,
       const long int* ldvt,
       const std::complex<float>* u,
       const long int* ldu,
       const std::complex<float>* c,
       const long int* ldc,
       long int* info)
  */
  /*! fn
   inline void bdsqr(
       const char* uplo,
       const long int* n,
       const long int* ncvt,
       const long int* nru,
       const long int* ncc,
       double* d,
       double* e,
       const std::complex<double>* vt,
       const long int* ldvt,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* c,
       const long int* ldc,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void bdsqr(
       const char* uplo,
       const long int* n,
       const long int* ncvt,
       const long int* nru,
       const long int* ncc,
       double* d,
       double* e,
       const std::complex<double>* vt,
       const long int* ldvt,
       const std::complex<double>* u,
       const long int* ldu,
       const std::complex<double>* c,
       const long int* ldc,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cbdsqr.f)
  //    *  RWORK   (workspace) float array, dimension (2*N) 
  //    *          if NCVT = NRU = NCC = 0, (max(1, 4*N-4)) otherwise
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_BDSQR(NAME, T, TBASE)\
inline void bdsqr(\
    const char* uplo,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    TBASE* d,\
    TBASE* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info,\
    workspace<T> & w)\
{\
  long int ldw = (!*ncvt && !*nru && !*ncc)? 2**n : std::max(1l,  4**n-4); \
    w.resizerw(ldw);\
    F77NAME( NAME )(uplo, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, w.getrw(), info);\
}\
inline void bdsqr(\
    const char* uplo,\
    const long int* n,\
    const long int* ncvt,\
    const long int* nru,\
    const long int* ncc,\
    TBASE* d,\
    TBASE* e,\
    const T* vt,\
    const long int* ldvt,\
    const T* u,\
    const long int* ldu,\
    const T* c,\
    const long int* ldc,\
    long int* info)\
{\
   workspace<T> w;\
   bdsqr(uplo, n, ncvt, nru, ncc, d, e, vt, ldvt, u, ldu, c, ldc, info, w);\
}\

      LPP_BDSQR(cbdsqr, std::complex<float>, float)
        LPP_BDSQR(zbdsqr, std::complex<double>, double)

#undef LPP_BDSQR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of bdsqr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
