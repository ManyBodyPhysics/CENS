#ifndef __PROJECT__LPP__FILE__HPSV_HH__INCLUDED
#define __PROJECT__LPP__FILE__HPSV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hpsv_itf.hh C++ interface to LAPACK (c,d,c,z)hpsv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hpsv_itf.hh
    (excerpt adapted from xhpsv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhpsv computes the solution to a DATA TYPE system of linear equations
    **     a * x = b,
    **  where a is an n-by-n hermitian matrix stored in packed format and x
    **  and b are n-by-nrhs matrices.
    **
    **  the diagonal pivoting method is used to factor a as
    **     a = u * d * u**h,  if uplo = 'u', or
    **     a = l * d * l**h,  if uplo = 'l',
    **  where u (or l) is a product of permutation and unit upper (lower)
    **  triangular matrices, d is hermitian and block diagonal with 1-by-1
    **  and 2-by-2 diagonal blocks.  the factored form of a is then used to
    **  solve the system of equations a * x = b.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the hermitian matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = a(i,j) for j<=i<=n.
    **          see below for further details.
    **
    **          on exit, the block diagonal matrix d and the multipliers used
    **          to obtain the factor u or l from the factorization
    **          a = u*d*u**h or a = l*d*l**h as computed by chptrf, stored as
    **          a packed triangular matrix in the same storage format as a.
    **
    **  ipiv    (output) long int array, dimension (n)
    **          details of the interchanges and the block structure of d, as
    **          determined by chptrf.  if ipiv(k) > 0, then rows and columns
    **          k and ipiv(k) were interchanged, and d(k,k) is a 1-by-1
    **          diagonal block.  if uplo = 'u' and ipiv(k) = ipiv(k-1) < 0,
    **          then rows and columns k-1 and -ipiv(k) were interchanged and
    **          d(k-1:k,k-1:k) is a 2-by-2 diagonal block.  if uplo = 'l' and
    **          ipiv(k) = ipiv(k+1) < 0, then rows and columns k+1 and
    **          -ipiv(k) were interchanged and d(k:k+1,k:k+1) is a 2-by-2
    **          diagonal block.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if info = 0, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, d(i,i) is exactly zero.  the factorization
    **                has been completed, but the block diagonal matrix d is
    **                exactly singular, so the solution could not be
    **                computed.
    **
    **  further details
    **  ===============
    **
    **  the packed storage scheme is illustrated by the following example
    **  when n = 4, uplo = 'u':
    **
    **  two-dimensional storage of the hermitian matrix a:
    **
    **     a11 a12 a13 a14
    **         a22 a23 a24
    **             a33 a34     (aij = conjg(aji))
    **                 a44
    **
    **  packed storage of the upper triangle of a:
    **
    **  ap = [ a11, a12, a22, a13, a23, a33, a14, a24, a34, a44 ]
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hpsv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* ap,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hpsv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* ap,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void hpsv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* ap,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hpsv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* ap,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chpsv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_HPSV(NAME, T, TBASE)\
inline void hpsv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* ap,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, ap, ipiv, b, ldb, info);\
}\
inline void hpsv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* ap,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   hpsv(uplo, n, nrhs, ap, ipiv, b, ldb, info, w);\
}\

    LPP_HPSV(chpsv, std::complex<float>,  float)
    LPP_HPSV(zhpsv, std::complex<double>, double)

#undef LPP_HPSV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hpsv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
