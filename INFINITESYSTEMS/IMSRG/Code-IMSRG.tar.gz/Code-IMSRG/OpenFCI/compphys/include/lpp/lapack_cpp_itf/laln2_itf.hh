#ifndef __PROJECT__LPP__FILE__LALN2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LALN2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laln2_itf.hh C++ interface to LAPACK (s,d,c,z)laln2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laln2_itf.hh
    (excerpt adapted from xlaln2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaln2 solves a system of the form  (ca a - w d ) x = s b
    **  or (ca a' - w d) x = s b   with possible scaling ("s") and
    **  perturbation of a.  (a' means a-transpose.)
    **
    **  a is an na x na BASE DATA TYPE matrix, ca is a BASE DATA TYPE scalar, d is an na x na
    **  BASE DATA TYPE diagonal matrix, w is a BASE DATA TYPE or DATA TYPE value, and x and b are
    **  na x 1 matrices -- BASE DATA TYPE if w is BASE DATA TYPE, DATA TYPE if w is DATA TYPE.  na
    **  may be 1 or 2.
    **
    **  if w is DATA TYPE, x and b are represented as na x 2 matrices,
    **  the first column of each being the BASE DATA TYPE part and the second
    **  being the imaginary part.
    **
    **  "s" is a scaling factor (.le. 1), computed by xlaln2, which is
    **  so chosen that x can be computed without overflow.  x is further
    **  scaled if necessary to assure that norm(ca a - w d)*norm(x) is less
    **  than overflow.
    **
    **  if both singular values of (ca a - w d) are less than smin,
    **  smin*identity will be used instead of (ca a - w d).  if only one
    **  singular value is less than smin, one element of (ca a - w d) will be
    **  perturbed enough to make the smallest singular value roughly smin.
    **  if both singular values are at least smin, (ca a - w d) will not be
    **  perturbed.  in any case, the perturbation will be at most some small
    **  multiple of max( smin, ulp*norm(ca a - w d) ).  the singular values
    **  are computed by infinity-norm approximations, and thus will only be
    **  correct to a factor of 2 or so.
    **
    **  note: all input quantities are assumed to be smaller than overflow
    **  by a reasonable factor.  (see bignum.)
    **
    **  arguments
    **  ==========
    **
    **  ltrans  (input) logical
    **          =.true.:  a-transpose will be used.
    **          =.false.: a will be used (not transposed.)
    **
    **  na      (input) long int
    **          the size of the matrix a.  it may (only) be 1 or 2.
    **
    **  nw      (input) long int
    **          1 if "w" is BASE DATA TYPE, 2 if "w" is DATA TYPE.  it may only be 1
    **          or 2.
    **
    **  smin    (input) BASE DATA TYPE
    **          the desired lower bound on the singular values of a.  this
    **          should be a safe distance away from underflow or overflow,
    **          say, between (underflow/machine precision) and  (machine
    **          precision * overflow ).  (see bignum and ulp.)
    **
    **  ca      (input) BASE DATA TYPE
    **          the coefficient c, which a is multiplied by.
    **
    **  a       (input) BASE DATA TYPE array, dimension (lda,na)
    **          the na x na matrix a.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  it must be at least na.
    **
    **  d1      (input) BASE DATA TYPE
    **          the 1,1 element in the diagonal matrix d.
    **
    **  d2      (input) BASE DATA TYPE
    **          the 2,2 element in the diagonal matrix d.  not used if nw=1.
    **
    **  b       (input) BASE DATA TYPE array, dimension (ldb,nw)
    **          the na x nw matrix b (right-hand side).  if nw=2 ("w" is
    **          DATA TYPE), column 1 contains the BASE DATA TYPE part of b and column 2
    **          contains the imaginary part.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  it must be at least na.
    **
    **  wr      (input) BASE DATA TYPE
    **          the BASE DATA TYPE part of the scalar "w".
    **
    **  wi      (input) BASE DATA TYPE
    **          the imaginary part of the scalar "w".  not used if nw=1.
    **
    **  x       (output) BASE DATA TYPE array, dimension (ldx,nw)
    **          the na x nw matrix x (unknowns), as computed by xlaln2.
    **          if nw=2 ("w" is DATA TYPE), on exit, column 1 will contain
    **          the BASE DATA TYPE part of x and column 2 will contain the imaginary
    **          part.
    **
    **  ldx     (input) long int
    **          the leading dimension of x.  it must be at least na.
    **
    **  scale   (output) BASE DATA TYPE
    **          the scale factor that b must be multiplied by to insure
    **          that overflow does not occur when computing x.  thus,
    **          (ca a - w d) x  will be scale*b, not b (ignoring
    **          perturbations of a.)  it will be at most 1.
    **
    **  xnorm   (output) BASE DATA TYPE
    **          the infinity-norm of x, when x is regarded as an na x nw
    **          BASE DATA TYPE matrix.
    **
    **  info    (output) long int
    **          an error flag.  it will be set to zero if no error occurs,
    **          a negative number if an argument is in error, or a positive
    **          number if  ca a - w d  had to be perturbed.
    **          the possible values are:
    **          = 0: no error occurred, and (ca a - w d) did not have to be
    **                 perturbed.
    **          = 1: (ca a - w d) had to be perturbed to make its smallest
    **               (or only) singular value greater than smin.
    **          note: in the interests of speed, this routine does not
    **                check the inputs for errors.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laln2(
        const long int* ltrans,
        const long int* na,
        const long int* nw,
        const float* smin,
        const float* ca,
        const float* a,
        const long int* lda,
        const float* d1,
        const float* d2,
        const float* b,
        const long int* ldb,
        const float* wr,
        const float* wi,
        float* x,
        const long int* ldx,
        float* scale,
        float* xnorm,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laln2(
        const long int* ltrans,
        const long int* na,
        const long int* nw,
        const float* smin,
        const float* ca,
        const float* a,
        const long int* lda,
        const float* d1,
        const float* d2,
        const float* b,
        const long int* ldb,
        const float* wr,
        const float* wi,
        float* x,
        const long int* ldx,
        float* scale,
        float* xnorm,
        long int* info)
  */
  /*! fn
   inline void laln2(
        const long int* ltrans,
        const long int* na,
        const long int* nw,
        const double* smin,
        const double* ca,
        const double* a,
        const long int* lda,
        const double* d1,
        const double* d2,
        const double* b,
        const long int* ldb,
        const double* wr,
        const double* wi,
        double* x,
        const long int* ldx,
        double* scale,
        double* xnorm,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laln2(
        const long int* ltrans,
        const long int* na,
        const long int* nw,
        const double* smin,
        const double* ca,
        const double* a,
        const long int* lda,
        const double* d1,
        const double* d2,
        const double* b,
        const long int* ldb,
        const double* wr,
        const double* wi,
        double* x,
        const long int* ldx,
        double* scale,
        double* xnorm,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaln2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LALN2(NAME, T)\
inline void laln2(\
    const long int* ltrans,\
    const long int* na,\
    const long int* nw,\
    const T* smin,\
    const T* ca,\
    const T* a,\
    const long int* lda,\
    const T* d1,\
    const T* d2,\
    const T* b,\
    const long int* ldb,\
    const T* wr,\
    const T* wi,\
    T* x,\
    const long int* ldx,\
    T* scale,\
    T* xnorm,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ltrans, na, nw, smin, ca, a, lda, d1, d2, b, ldb, wr, wi, x, ldx, scale, xnorm, info);\
}\
inline void laln2(\
    const long int* ltrans,\
    const long int* na,\
    const long int* nw,\
    const T* smin,\
    const T* ca,\
    const T* a,\
    const long int* lda,\
    const T* d1,\
    const T* d2,\
    const T* b,\
    const long int* ldb,\
    const T* wr,\
    const T* wi,\
    T* x,\
    const long int* ldx,\
    T* scale,\
    T* xnorm,\
    long int* info)\
{\
   workspace<T> w;\
   laln2(ltrans, na, nw, smin, ca, a, lda, d1, d2, b, ldb, wr, wi, x, ldx, scale, xnorm, info, w);\
}\

    LPP_LALN2(slaln2, float)
    LPP_LALN2(dlaln2, double)

#undef LPP_LALN2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laln2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
