#ifndef __PROJECT__LPP__FILE__LARF_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larf_itf.hh C++ interface to LAPACK (s,d,c,z)larf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larf_itf.hh
    (excerpt adapted from xlarf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarf applies a DATA TYPE elementary reflector h to a DATA TYPE m-by-n
    **  matrix c, from either the left or the right. h is represented in the
    **  form
    **
    **        h = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar and v is a DATA TYPE vector.
    **
    **  if tau = 0, then h is taken to be the unit matrix.
    **
    **  to apply h' (the conjugate transpose of h), supply conjg(tau) instead
    **  tau.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'l': form  h * c
    **          = 'r': form  c * h
    **
    **  m       (input) long int
    **          the number of rows of the matrix c.
    **
    **  n       (input) long int
    **          the number of columns of the matrix c.
    **
    **  v       (input) DATA TYPE array, dimension
    **                     (1 + (m-1)*abs(incv)) if side = 'l'
    **                  or (1 + (n-1)*abs(incv)) if side = 'r'
    **          the vector v in the representation of h. v is not used if
    **          tau = 0.
    **
    **  incv    (input) long int
    **          the increment between elements of v. incv <> 0.
    **
    **  tau     (input) DATA TYPE
    **          the value tau in the representation of h.
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n matrix c.
    **          on exit, c is overwritten by the matrix h * c if side = 'l',
    **          or c * h if side = 'r'.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m).
    **
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larf(
        const char* side,
        const long int* m,
        const long int* n,
        const float* v,
        const long int* incv,
        const float* tau,
        const float* c,
        const long int* ldc,
        workspace<float> & w)
  */
  /*! fn
   inline void larf(
        const char* side,
        const long int* m,
        const long int* n,
        const float* v,
        const long int* incv,
        const float* tau,
        const float* c,
        const long int* ldc)
  */
  /*! fn
   inline void larf(
        const char* side,
        const long int* m,
        const long int* n,
        const double* v,
        const long int* incv,
        const double* tau,
        const double* c,
        const long int* ldc,
        workspace<double> & w)
  */
  /*! fn
   inline void larf(
        const char* side,
        const long int* m,
        const long int* n,
        const double* v,
        const long int* incv,
        const double* tau,
        const double* c,
        const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarf.f)
  //    *  WORK    (workspace) float array, dimension
  //    *                         (N) if SIDE = 'L'
  //    *                      or (M) if SIDE = 'R'
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARF(NAME, T)\
inline void larf(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{                                                                       \
  w.resizew((lower(*side) == 'l') ? *n : *m);                           \
  F77NAME( NAME )(side, m, n, v, incv, tau, c, ldc, w.getw());          \
}                                                                       \
inline void larf(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larf(side, m, n, v, incv, tau, c, ldc, w);\
}\

    LPP_LARF(slarf, float)
    LPP_LARF(dlarf, double)

#undef LPP_LARF


  // The following macro provides the 4 functions 
  /*! fn
   inline void larf(
       const char* side,
       const long int* m,
       const long int* n,
       const std::complex<float>* v,
       const long int* incv,
       const std::complex<float>* tau,
       const std::complex<float>* c,
       const long int* ldc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larf(
       const char* side,
       const long int* m,
       const long int* n,
       const std::complex<float>* v,
       const long int* incv,
       const std::complex<float>* tau,
       const std::complex<float>* c,
       const long int* ldc)
  */
  /*! fn
   inline void larf(
       const char* side,
       const long int* m,
       const long int* n,
       const std::complex<double>* v,
       const long int* incv,
       const std::complex<double>* tau,
       const std::complex<double>* c,
       const long int* ldc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larf(
       const char* side,
       const long int* m,
       const long int* n,
       const std::complex<double>* v,
       const long int* incv,
       const std::complex<double>* tau,
       const std::complex<double>* c,
       const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarf.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension
  //    *                         (N) if SIDE = 'L'
  //    *                      or (M) if SIDE = 'R'
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARF(NAME, T, TBASE)\
inline void larf(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{                                                                     \
  w.resizew((lower(*side) == 'l') ? *n : *m);                         \
  F77NAME( NAME )(side, m, n, v, incv, tau, c, ldc, w.getw());        \
}                                                                     \
inline void larf(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larf(side, m, n, v, incv, tau, c, ldc, w);\
}\

    LPP_LARF(clarf, std::complex<float>, float)
    LPP_LARF(zlarf, std::complex<double>, double)

#undef LPP_LARF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
