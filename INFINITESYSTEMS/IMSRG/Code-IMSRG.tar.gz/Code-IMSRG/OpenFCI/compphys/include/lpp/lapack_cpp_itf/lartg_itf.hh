#ifndef __PROJECT__LPP__FILE__LARTG_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARTG_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lartg_itf.hh C++ interface to LAPACK (c,d,c,z)lartg
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lartg_itf.hh
    (excerpt adapted from xlartg.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlartg generates a plane rotation so that
    **
    **     [  cs  sn  ]     [ f ]     [ r ]
    **     [  __      ]  .  [   ]  =  [   ]   where cs**2 + |sn|**2 = 1.
    **     [ -sn  cs  ]     [ g ]     [ 0 ]
    **
    **  this is a faster version of the blas1 routine crotg, except for
    **  the following differences:
    **     f and g are unchanged on return.
    **     if g=0, then cs=1 and sn=0.
    **     if f=0, then cs=0 and sn is chosen so that r is BASE DATA TYPE.
    **
    **  arguments
    **  =========
    **
    **  f       (input) DATA TYPE
    **          the first component of vector to be rotated.
    **
    **  g       (input) DATA TYPE
    **          the second component of vector to be rotated.
    **
    **  cs      (output) BASE DATA TYPE
    **          the cosine of the rotation.
    **
    **  sn      (output) DATA TYPE
    **          the sine of the rotation.
    **
    **  r       (output) DATA TYPE
    **          the nonzero component of the rotated vector.
    **
    **  further details
    **  ======= =======
    **
    **  3-5-96 - modified with a new algorithm by w. kahan and j. demmel
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lartg(
        const float* f,
        const float* g,
        float* cs,
        float* sn,
        float* r,
        workspace<float> & w)
  */
  /*! fn
   inline void lartg(
        const float* f,
        const float* g,
        float* cs,
        float* sn,
        float* r)
  */
  /*! fn
   inline void lartg(
        const double* f,
        const double* g,
        double* cs,
        double* sn,
        double* r,
        workspace<double> & w)
  */
  /*! fn
   inline void lartg(
        const double* f,
        const double* g,
        double* cs,
        double* sn,
        double* r)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slartg.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARTG(NAME, T)\
inline void lartg(\
    const T* f,\
    const T* g,\
    T* cs,\
    T* sn,\
    T* r,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(f, g, cs, sn, r);\
}\
inline void lartg(\
    const T* f,\
    const T* g,\
    T* cs,\
    T* sn,\
    T* r)\
{\
   workspace<T> w;\
   lartg(f, g, cs, sn, r, w);\
}\

    LPP_LARTG(slartg, float)
    LPP_LARTG(dlartg, double)

#undef LPP_LARTG


  // The following macro provides the 4 functions 
  /*! fn
   inline void lartg(
       const std::complex<float>* f,
       const std::complex<float>* g,
       float* cs,
       std::complex<float>* sn,
       std::complex<float>* r,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lartg(
       const std::complex<float>* f,
       const std::complex<float>* g,
       float* cs,
       std::complex<float>* sn,
       std::complex<float>* r)
  */
  /*! fn
   inline void lartg(
       const std::complex<double>* f,
       const std::complex<double>* g,
       double* cs,
       std::complex<double>* sn,
       std::complex<double>* r,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lartg(
       const std::complex<double>* f,
       const std::complex<double>* g,
       double* cs,
       std::complex<double>* sn,
       std::complex<double>* r)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clartg.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARTG(NAME, T, TBASE)\
inline void lartg(\
    const T* f,\
    const T* g,\
    TBASE* cs,\
    T* sn,\
    T* r,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(f, g, cs, sn, r);\
}\
inline void lartg(\
    const T* f,\
    const T* g,\
    TBASE* cs,\
    T* sn,\
    T* r)\
{\
   workspace<T> w;\
   lartg(f, g, cs, sn, r, w);\
}\

    LPP_LARTG(clartg, std::complex<float>,  float)
    LPP_LARTG(zlartg, std::complex<double>, double)

#undef LPP_LARTG



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lartg_itf.hh
// /////////////////////////////////////////////////////////////////////////////
