#ifndef __PROJECT__LPP__FILE__TZRQF_HH__INCLUDED
#define __PROJECT__LPP__FILE__TZRQF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tzrqf_itf.hh C++ interface to LAPACK (c,d,c,z)tzrqf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tzrqf_itf.hh
    (excerpt adapted from xtzrqf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  this routine is deprecated and has been replaced by routine ctzrzf.
    **
    **  xtzrqf reduces the m-by-n ( m<=n ) DATA TYPE upper trapezoidal matrix a
    **  to upper triangular form by means of unitary transformations.
    **
    **  the upper trapezoidal matrix a is factored as
    **
    **     a = ( r  0 ) * z,
    **
    **  where z is an n-by-n unitary matrix and r is an m-by-m upper
    **  triangular matrix.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= m.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the leading m-by-n upper trapezoidal part of the
    **          array a must contain the matrix to be factorized.
    **          on exit, the leading m-by-m upper triangular part of a
    **          contains the upper triangular matrix r, and elements m+1 to
    **          n of the first m rows of a, with the array tau, represent the
    **          unitary matrix z as a product of m elementary reflectors.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  tau     (output) DATA TYPE array, dimension (m)
    **          the scalar factors of the elementary reflectors.
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the  factorization is obtained by householder's method.  the kth
    **  transformation matrix, z( k ), whose conjugate transpose is used to
    **  introduce zeros into the (m - k + 1)th row of a, is given in the form
    **
    **     z( k ) = ( i     0   ),
    **              ( 0  t( k ) )
    **
    **  where
    **
    **     t( k ) = i - tau*u( k )*u( k )',   u( k ) = (   1    ),
    **                                                 (   0    )
    **                                                 ( z( k ) )
    **
    **  tau is a scalar and z( k ) is an ( n - m ) element vector.
    **  tau and z( k ) are chosen to annihilate the elements of the kth row
    **  of x.
    **
    **  the scalar tau is returned in the kth element of tau and the vector
    **  u( k ) in the kth row of a, such that the elements of z( k ) are
    **  in  a( k, m + 1 ), ..., a( k, n ). the elements of r are returned in
    **  the upper triangular part of a.
    **
    **  z is given by
    **
    **     z =  z( 1 ) * z( 2 ) * ... * z( m ).
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tzrqf(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tzrqf(
        const long int* m,
        const long int* n,
        float* a,
        const long int* lda,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void tzrqf(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tzrqf(
        const long int* m,
        const long int* n,
        double* a,
        const long int* lda,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stzrqf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TZRQF(NAME, T)\
inline void tzrqf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, tau, info);\
}\
inline void tzrqf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   tzrqf(m, n, a, lda, tau, info, w);\
}\

    LPP_TZRQF(stzrqf, float)
    LPP_TZRQF(dtzrqf, double)

#undef LPP_TZRQF


  // The following macro provides the 4 functions 
  /*! fn
   inline void tzrqf(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tzrqf(
       const long int* m,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void tzrqf(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tzrqf(
       const long int* m,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctzrqf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TZRQF(NAME, T, TBASE)\
inline void tzrqf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, a, lda, tau, info);\
}\
inline void tzrqf(\
    const long int* m,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   tzrqf(m, n, a, lda, tau, info, w);\
}\

    LPP_TZRQF(ctzrqf, std::complex<float>,  float)
    LPP_TZRQF(ztzrqf, std::complex<double>, double)

#undef LPP_TZRQF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tzrqf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
