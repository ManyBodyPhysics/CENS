#ifndef __PROJECT__LPP__FILE__GELS_HH__INCLUDED
#define __PROJECT__LPP__FILE__GELS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gels_itf.hh C++ interface to LAPACK (c,d,c,z)gels
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gels_itf.hh
    (excerpt adapted from xgels.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgels solves overdetermined or underdetermined DATA TYPE linear systems
    **  involving an m-by-n matrix a, or its conjugate-transpose, using a qr
    **  or lq factorization of a.  it is assumed that a has full rank.
    **
    **  the following options are provided:
    **
    **  1. if trans = 'n' and m >= n:  find the least squares solution of
    **     an overdetermined system, i.e., solve the least squares problem
    **                  minimize || b - a*x ||.
    **
    **  2. if trans = 'n' and m < n:  find the minimum norm solution of
    **     an underdetermined system a * x = b.
    **
    **  3. if trans = 'c' and m >= n:  find the minimum norm solution of
    **     an undetermined system a**h * x = b.
    **
    **  4. if trans = 'c' and m < n:  find the least squares solution of
    **     an overdetermined system, i.e., solve the least squares problem
    **                  minimize || b - a**h * x ||.
    **
    **  several right hand side vectors b and solution vectors x can be
    **  handled in a single call; they are stored as the columns of the
    **  m-by-nrhs right hand side matrix b and the n-by-nrhs solution
    **  matrix x.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) character
    **          = 'n': the linear system involves a;
    **          = 'c': the linear system involves a**h.
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of
    **          columns of the matrices b and x. nrhs >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **            if m >= n, a is overwritten by details of its qr
    **                       factorization as returned by cgeqrf;
    **            if m <  n, a is overwritten by details of its lq
    **                       factorization as returned by cgelqf.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the matrix b of right hand side vectors, stored
    **          columnwise; b is m-by-nrhs if trans = 'n', or n-by-nrhs
    **          if trans = 'c'.
    **          on exit, b is overwritten by the solution vectors, stored
    **          columnwise:
    **          if trans = 'n' and m >= n, rows 1 to n of b contain the least
    **          squares solution vectors; the residual sum of squares for the
    **          solution in each column is given by the sum of squares of
    **          elements n+1 to m in that column;
    **          if trans = 'n' and m < n, rows 1 to n of b contain the
    **          minimum norm solution vectors;
    **          if trans = 'c' and m >= n, rows 1 to m of b contain the
    **          minimum norm solution vectors;
    **          if trans = 'c' and m < n, rows 1 to m of b contain the
    **          least squares solution vectors; the residual sum of squares
    **          for the solution in each column is given by the sum of
    **          squares of elements m+1 to n in that column.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,m,n).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gels(
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* nrhs,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gels(
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* nrhs,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void gels(
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* nrhs,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gels(
        const char* trans,
        const long int* m,
        const long int* n,
        const long int* nrhs,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgels.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          LWORK >= max( 1, MN + max( MN, NRHS ) ).
  //    *          For optimal performance,
  //    *          LWORK >= max( 1, MN + max( MN, NRHS )*NB ).
  //    *          where MN = min(M,N) and NB is the optimum block size.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELS(NAME, T)\
inline void gels(\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, m, n, nrhs, a, lda, b, ldb, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(trans, m, n, nrhs, a, lda, b, ldb, w.getw(), &w.neededsize(), info);\
}\
inline void gels(\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gels(trans, m, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_GELS(sgels, float)
    LPP_GELS(dgels, double)

#undef LPP_GELS


  // The following macro provides the 4 functions 
  /*! fn
   inline void gels(
       const char* trans,
       const long int* m,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gels(
       const char* trans,
       const long int* m,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void gels(
       const char* trans,
       const long int* m,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gels(
       const char* trans,
       const long int* m,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgels.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          LWORK >= max( 1, MN + max( MN, NRHS ) ).
  //    *          For optimal performance,
  //    *          LWORK >= max( 1, MN + max( MN, NRHS )*NB ).
  //    *          where MN = min(M,N) and NB is the optimum block size.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GELS(NAME, T, TBASE)\
inline void gels(\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, m, n, nrhs, a, lda, b, ldb, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(trans, m, n, nrhs, a, lda, b, ldb, w.getw(), &w.neededsize(), info);\
}\
inline void gels(\
    const char* trans,\
    const long int* m,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   gels(trans, m, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_GELS(cgels, std::complex<float>,  float)
    LPP_GELS(zgels, std::complex<double>, double)

#undef LPP_GELS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gels_itf.hh
// /////////////////////////////////////////////////////////////////////////////
