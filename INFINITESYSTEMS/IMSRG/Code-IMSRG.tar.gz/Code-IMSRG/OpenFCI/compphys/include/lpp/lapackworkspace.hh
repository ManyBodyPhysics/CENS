#ifndef __PROJECT__LPP__SAT_JAN_14_13_20_11_2006__FILE__LAPACKWORKSPACE_HH__INCLUDED
#define __PROJECT__LPP__SAT_JAN_14_13_20_11_2006__FILE__LAPACKWORKSPACE_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2006 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////
/*! \file lapackworkspace.hh
  \brief Use of LAPAACK workspace.
  
  LAPACK routines use from one to 4  workspace arrays
  - work    is an array of the primary element type (d, s, z, c) the size of
            which can be determined by a call with parameter ldwork set to -1
  - rwork   is an array of the base primary element, (d, s, d, s)
  - iwork   is an array of long int
  - bwork   is an array of long int (logical)
  
  This class allows to reuse a workspace allocated once for all.
  
  Each interface (_itf.hh files) provides two kinds of C++ eqivalent calls to
  LAPACK routines :
  
  The first contains no workspace parameter and do all allocations/destructions
  internally,  and of course at each call.
  
  The second has a last parameter w which is a workspace reference that can be
  passed allocated or not. The routine first reallocate the workspace (which
  means to do nothing if the sizes already allocated are greater  than needs)
  While in scope the workspace grows and is less and less really resized.
  
  To optimize reallocation one can in a learning stage  declare a void
  workspace for each  used type of data used, to use it constantly and to
  issue calls to showstate at the end of the program. Then to change the
  workspace initial construction with the obtained sizes.
  
  The constructors of the factorization class of lpp::algebra also have a
  reference workspace optionnal parameter. These classes can use it instead
  of their own internal workspace. In fact,  all calls can share the same
  unique workspace.
  
  The interface has been written to be used with nt2 library, but it is
  independant from nt2 (http://nt2.sourceforge.net)
  std::vector has been choosen as storage,  but the scheme can be  easily
  adapted to put storage in any container class as soon as :
  - storage is contiguous, 
  - actual size and allocation are separate notions (i.e. reallocation is not
  done when actual size is bigger than needed).
  
*/


////////////////////////////////////////////////////////////////////////////////
//  what        : lapackworkspace.hh                                 
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Sat Jan 14 13:20:11 2006                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
#include <complex>
#include <vector>
#include <iostream>


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{

/**
 *  This struct and its specialization are made to cast result returned by
 *  LAPACK with the wrong type
 */

  template < class T > struct base{
    typedef T type_t; 
    typedef T base_t;
    static long int Getval(const type_t & v){
      return (long int)(v); 
    }
  }; 
    
  template <class T > struct base <std::complex<T> > {
    typedef std::complex < T > type_t; 
    typedef T base_t;
    static long int Getval(const type_t & v){
      return (long int)(v.real()); 
    }
  }; 
  
/**
 *  This class allows to use easily LAPACK workspace features
 */

  template < class T > class workspace{
  public :
    typedef typename base < T >::type_t   type_t;
    typedef typename base < T >::base_t   base_t;
    typedef std::vector < type_t > m_t;
    typedef std::vector < base_t > mb_t;
    typedef std::vector < long int > mi_t;
    /**
     * Sized constructor.
     * It allows to provide workspace memory from the beginning 
     */
   workspace(size_t wsiz, size_t rwsiz, size_t iwsiz, size_t bwsiz = 0):
     w(std::max(wsiz, size_t(1))), 
     rw(std::max(rwsiz, size_t(1))), 
     iw(std::max(iwsiz, size_t(1))),
     bw(std::max(bwsiz, size_t(1))),
     mquery(-1)
    {}
    /**
     * Trivial constructor.
     * Only the main work area get a necessary small provision.
     * The other will be allocated on demand.
     */
    workspace():w(1), rw(1), iw(1), bw(1), mquery(-1){ }
    ~workspace(){}
    //! to resize the main work area
    void resizew (size_t size){ w.reserve(size); } 
    //! to resize the real work area
    void resizerw(size_t size){rw.reserve(size); }    
    //! to resize the integer work area 
    void resizeiw(size_t size){iw.reserve(size); }  
    //! to resize the logical work area 
    void resizebw(size_t size){bw.reserve(size); }  

    bool isok(size_t wsiz, size_t rwsiz, size_t iwsiz, size_t bwsiz)const{ //! is the workspace sufficiently large
      return (wsiz >= w.size()) && (rwsiz >= rw.size())
        && (iwsiz >= iw.size()) && (bwsiz >= bw.size()); 
    }
    void realloc(size_t wsiz, size_t rwsiz, size_t iwsiz, size_t bwsiz = 0){
      if(wsiz >   w.size())  w.reserve(wsiz);
      if(rwsiz > rw.size()) rw.reserve(rwsiz);
      if(iwsiz > iw.size()) iw.reserve(iwsiz);
      if(bwsiz > bw.size()) bw.reserve(bwsiz);
    }
    type_t   * getw(){return &w[0]; }
    base_t   * getrw(){return &rw[0]; }
    long int * getiw(){return &iw[0]; }
    long int * getbw(){return &bw[0]; }
    const long int & neededsize(long int siz = 0){
      return (mldw =  siz ? siz : (base < type_t > ::Getval(w[0])));
    }
    const long int & neededisize(long int siz = 0){
      return mldiw = siz ? siz : iw[0];
    }
    const long int & neededrsize(long int siz = 0){
      return mldrw = siz ? siz : (long int)rw[0];
    }
    const long int & neededbsize(long int siz = 0){
      return mldbw = siz ? siz : bw[0];
    }
    const long int * query()const{return &mquery; } 
    void showstate(char unit =  'B')const{
      size_t total = w.size()*sizeof(T)+rw.size()*sizeof(base_t)+iw.size()*sizeof(long int);
      size_t ext = w.capacity()*sizeof(T)+rw.capacity()*sizeof(base_t)+
        iw.capacity()*sizeof(long int)+bw.capacity()*sizeof(long int);
      std::cout << "workspace is using a total amount of: ";
      std::cout << total/factor(unit) << " " << name(unit) << std::endl;
      std::cout <<  w.size() << " in w,  " << std::endl;
      std::cout << rw.size() << " in rw, " << std::endl;
      std::cout << iw.size() << " in iw, " << std::endl;
      std::cout << bw.size() << " in bw, " << std::endl;
      std::cout << "Total capacity workspace up to now is  : ";
      std::cout << ext/factor(unit) << " " << name(unit) << std::endl; 
      std::cout <<  w.capacity() << " in w,  " << std::endl;
      std::cout << rw.capacity() << " in rw, " << std::endl;
      std::cout << iw.capacity() << " in iw, " << std::endl;
      std::cout << bw.capacity() << " in bw, " << std::endl;
    }
  private :
    m_t w;
    mb_t rw;
    mi_t iw;
    mi_t bw;
    long int mldw, mldiw, mldrw, mldbw;
    const long int mquery;
    static inline size_t factor(char unit)
    {
      switch (unit){
      case 'M' :
      case 'm' :
        return(1024*1024); 
        break; 
      case 'B' :
      case 'b' :
      case 'O' :
      case 'o' :
        return 1;
        break; 
      case 'K' :
      case 'k' :
      default :
        return 1024; 
      }
      return 1024; 
    }
    static inline std::string name(char unit)
    {
      switch (unit){
      case 'M' :
      case 'm' :
        return("Megabytes"); 
        break; 
      case 'B' :
      case 'b' :
      case 'O' :
      case 'o' :
        return("Bytes"); 
        break; 
      case 'K' :
      case 'k' :
      default :
        return("Kilobytes"); 
      }
      return("Kilobytes"); 
    }
  };
  
}

// /////////////////////////////////////////////////////////////////////////////
//  End of lpp namespace
// /////////////////////////////////////////////////////////////////////////////


#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lapackworkspace.hh
// /////////////////////////////////////////////////////////////////////////////
