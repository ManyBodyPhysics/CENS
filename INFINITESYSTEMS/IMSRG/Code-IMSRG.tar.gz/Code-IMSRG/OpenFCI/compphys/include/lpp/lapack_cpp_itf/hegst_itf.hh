#ifndef __PROJECT__LPP__FILE__HEGST_HH__INCLUDED
#define __PROJECT__LPP__FILE__HEGST_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hegst_itf.hh C++ interface to LAPACK (c,d,c,z)hegst
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hegst_itf.hh
    (excerpt adapted from xhegst.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhegst reduces a DATA TYPE hermitian-definite generalized
    **  eigenproblem to standard form.
    **
    **  if itype = 1, the problem is a*x = lambda*b*x,
    **  and a is overwritten by inv(u**h)*a*inv(u) or inv(l)*a*inv(l**h)
    **
    **  if itype = 2 or 3, the problem is a*b*x = lambda*x or
    **  b*a*x = lambda*x, and a is overwritten by u*a*u**h or l**h*a*l.
    **
    **  b must have been previously factorized as u**h*u or l*l**h by cpotrf.
    **
    **  arguments
    **  =========
    **
    **  itype   (input) long int
    **          = 1: compute inv(u**h)*a*inv(u) or inv(l)*a*inv(l**h);
    **          = 2 or 3: compute u*a*u**h or l**h*a*l.
    **
    **  uplo    (input) character
    **          = 'u':  upper triangle of a is stored and b is factored as
    **                  u**h*u;
    **          = 'l':  lower triangle of a is stored and b is factored as
    **                  l*l**h.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, if info = 0, the transformed matrix, stored in the
    **          same format as a.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  b       (input) DATA TYPE array, dimension (ldb,n)
    **          the triangular factor from the cholesky factorization of b,
    **          as returned by cpotrf.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hegst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hegst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void hegst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hegst(
       const long int* itype,
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chegst.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_HEGST(NAME, T, TBASE)\
inline void hegst(\
    const long int* itype,\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(itype, uplo, n, a, lda, b, ldb, info);\
}\
inline void hegst(\
    const long int* itype,\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   hegst(itype, uplo, n, a, lda, b, ldb, info, w);\
}\

    LPP_HEGST(chegst, std::complex<float>,  float)
    LPP_HEGST(zhegst, std::complex<double>, double)

#undef LPP_HEGST



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hegst_itf.hh
// /////////////////////////////////////////////////////////////////////////////
