#ifndef __PROJECT__LPP__FILE__LASQ6_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASQ6_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasq6_itf.hh C++ interface to LAPACK (s,d,c,z)lasq6
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasq6_itf.hh
    (excerpt adapted from xlasq6.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasq6 computes one dqd (shift equal to zero) transform in
    **  ping-pong form, with protection against underflow and overflow.
    **
    **  arguments
    **  =========
    **
    **  i0    (input) long int
    **        first index.
    **
    **  n0    (input) long int
    **        last index.
    **
    **  z     (input) BASE DATA TYPE array, dimension ( 4*n )
    **        z holds the qd array. emin is stored in z(4*n0) to avoid
    **        an extra argument.
    **
    **  pp    (input) long int
    **        pp=0 for ping, pp=1 for pong.
    **
    **  dmin  (output) BASE DATA TYPE
    **        minimum value of d.
    **
    **  dmin1 (output) BASE DATA TYPE
    **        minimum value of d, excluding d( n0 ).
    **
    **  dmin2 (output) BASE DATA TYPE
    **        minimum value of d, excluding d( n0 ) and d( n0-1 ).
    **
    **  dn    (output) BASE DATA TYPE
    **        d(n0), the last value of d.
    **
    **  dnm1  (output) BASE DATA TYPE
    **        d(n0-1).
    **
    **  dnm2  (output) BASE DATA TYPE
    **        d(n0-2).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasq6(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        float* dmin,
        float* dmin1,
        float* dmin2,
        float* dn,
        float* dnm1,
        float* dnm2,
        workspace<float> & w)
  */
  /*! fn
   inline void lasq6(
        const long int* i0,
        const long int* n0,
        const float* z,
        const long int* pp,
        float* dmin,
        float* dmin1,
        float* dmin2,
        float* dn,
        float* dnm1,
        float* dnm2)
  */
  /*! fn
   inline void lasq6(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        double* dmin,
        double* dmin1,
        double* dmin2,
        double* dn,
        double* dnm1,
        double* dnm2,
        workspace<double> & w)
  */
  /*! fn
   inline void lasq6(
        const long int* i0,
        const long int* n0,
        const double* z,
        const long int* pp,
        double* dmin,
        double* dmin1,
        double* dmin2,
        double* dn,
        double* dnm1,
        double* dnm2)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasq6.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASQ6(NAME, T)\
inline void lasq6(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    T* dmin,\
    T* dmin1,\
    T* dmin2,\
    T* dn,\
    T* dnm1,\
    T* dnm2,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(i0, n0, z, pp, dmin, dmin1, dmin2, dn, dnm1, dnm2);\
}\
inline void lasq6(\
    const long int* i0,\
    const long int* n0,\
    const T* z,\
    const long int* pp,\
    T* dmin,\
    T* dmin1,\
    T* dmin2,\
    T* dn,\
    T* dnm1,\
    T* dnm2)\
{\
   workspace<T> w;\
   lasq6(i0, n0, z, pp, dmin, dmin1, dmin2, dn, dnm1, dnm2, w);\
}\

    LPP_LASQ6(slasq6, float)
    LPP_LASQ6(dlasq6, double)

#undef LPP_LASQ6



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasq6_itf.hh
// /////////////////////////////////////////////////////////////////////////////
