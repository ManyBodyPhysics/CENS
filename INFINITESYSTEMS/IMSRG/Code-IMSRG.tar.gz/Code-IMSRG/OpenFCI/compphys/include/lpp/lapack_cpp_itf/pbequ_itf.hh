#ifndef __PROJECT__LPP__FILE__PBEQU_HH__INCLUDED
#define __PROJECT__LPP__FILE__PBEQU_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pbequ_itf.hh C++ interface to LAPACK (c,d,c,z)pbequ
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pbequ_itf.hh
    (excerpt adapted from xpbequ.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpbequ computes row and column scalings intended to equilibrate a
    **  hermitian positive definite band matrix a and reduce its condition
    **  number (with respect to the two-norm).  s contains the scale factors,
    **  s(i) = 1/sqrt(a(i,i)), chosen so that the scaled matrix b with
    **  elements b(i,j) = s(i)*a(i,j)*s(j) has ones on the diagonal.  this
    **  choice of s puts the condition number of b within a factor n of the
    **  smallest possible condition number over all possible diagonal
    **  scalings.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangular of a is stored;
    **          = 'l':  lower triangular of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kd >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the upper or lower triangle of the hermitian band matrix a,
    **          stored in the first kd+1 rows of the array.  the j-th column
    **          of a is stored in the j-th column of the array ab as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **
    **  ldab     (input) long int
    **          the leading dimension of the array a.  ldab >= kd+1.
    **
    **  s       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, s contains the scale factors for a.
    **
    **  scond   (output) BASE DATA TYPE
    **          if info = 0, s contains the ratio of the smallest s(i) to
    **          the largest s(i).  if scond >= 0.1 and amax is neither too
    **          large nor too small, it is not worth scaling by s.
    **
    **  amax    (output) BASE DATA TYPE
    **          absolute value of largest matrix element.  if amax is very
    **          close to overflow or very close to underflow, the matrix
    **          should be scaled.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = i, the i-th diagonal element is nonpositive.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pbequ(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* s,
        float* scond,
        float* amax,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pbequ(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* s,
        float* scond,
        float* amax,
        long int* info)
  */
  /*! fn
   inline void pbequ(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* s,
        double* scond,
        double* amax,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pbequ(
        const char* uplo,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* s,
        double* scond,
        double* amax,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spbequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBEQU(NAME, T)\
inline void pbequ(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* s,\
    T* scond,\
    T* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, s, scond, amax, info);\
}\
inline void pbequ(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* s,\
    T* scond,\
    T* amax,\
    long int* info)\
{\
   workspace<T> w;\
   pbequ(uplo, n, kd, ab, ldab, s, scond, amax, info, w);\
}\

    LPP_PBEQU(spbequ, float)
    LPP_PBEQU(dpbequ, double)

#undef LPP_PBEQU


  // The following macro provides the 4 functions 
  /*! fn
   inline void pbequ(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       float* s,
       float* scond,
       float* amax,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pbequ(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       float* s,
       float* scond,
       float* amax,
       long int* info)
  */
  /*! fn
   inline void pbequ(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       double* s,
       double* scond,
       double* amax,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pbequ(
       const char* uplo,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       double* s,
       double* scond,
       double* amax,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpbequ.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBEQU(NAME, T, TBASE)\
inline void pbequ(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    TBASE* s,\
    TBASE* scond,\
    TBASE* amax,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, kd, ab, ldab, s, scond, amax, info);\
}\
inline void pbequ(\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    TBASE* s,\
    TBASE* scond,\
    TBASE* amax,\
    long int* info)\
{\
   workspace<T> w;\
   pbequ(uplo, n, kd, ab, ldab, s, scond, amax, info, w);\
}\

    LPP_PBEQU(cpbequ, std::complex<float>,  float)
    LPP_PBEQU(zpbequ, std::complex<double>, double)

#undef LPP_PBEQU



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pbequ_itf.hh
// /////////////////////////////////////////////////////////////////////////////
