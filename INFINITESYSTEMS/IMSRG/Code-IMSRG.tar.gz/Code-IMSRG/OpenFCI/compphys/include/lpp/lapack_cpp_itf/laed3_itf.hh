#ifndef __PROJECT__LPP__FILE__LAED3_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED3_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed3_itf.hh C++ interface to LAPACK (s,d,c,z)laed3
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed3_itf.hh
    (excerpt adapted from xlaed3.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaed3 finds the roots of the secular equation, as defined by the
    **  values in d, ws, and rho, between 1 and k.  it makes the
    **  appropriate calls to dlaed4 and then updates the eigenvectors by
    **  multiplying the matrix of eigenvectors of the pair of eigensystems
    **  being combined by the matrix of eigenvectors of the k-by-k system
    **  which is solved here.
    **
    **  this code makes very mild assumptions about floating point
    **  arithmetic. it will WORK on machines with a guard digit in
    **  add/subtract, or on those binary machines without guard digits
    **  which subtract like the cray x-mp, cray y-mp, cray c-90, or cray-2.
    **  it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  arguments
    **  =========
    **
    **  k       (input) long int
    **          the number of terms in the rational function to be solved by
    **          dlaed4.  k >= 0.
    **
    **  n       (input) long int
    **          the number of rows and columns in the q matrix.
    **          n >= k (deflation may result in n>k).
    **
    **  n1      (input) long int
    **          the location of the last eigenvalue in the leading submatrix.
    **          min(1,n) <= n1 <= n/2.
    **
    **  d       (output) BASE DATA TYPE array, dimension (n)
    **          d(i) contains the updated eigenvalues for
    **          1 <= i <= k.
    **
    **  q       (output) BASE DATA TYPE array, dimension (ldq,n)
    **          initially the first k columns are used as WORKspace.
    **          on output the columns 1 to k contain
    **          the updated eigenvectors.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  rho     (input) BASE DATA TYPE
    **          the value of the parameter in the rank one update equation.
    **          rho >= 0 required.
    **
    **  dlamda  (input/output) BASE DATA TYPE array, dimension (k)
    **          the first k elements of this array contain the old roots
    **          of the deflated updating problem.  these are the poles
    **          of the secular equation. may be changed on output by
    **          having lowest order bit set to zero on cray x-mp, cray y-mp,
    **          cray-2, or cray c-90, as described above.
    **
    **  q2      (input) BASE DATA TYPE array, dimension (ldq2, n)
    **          the first k columns of this matrix contain the non-deflated
    **          eigenvectors for the split problem.
    **
    **  indx    (input) long int array, dimension (n)
    **          the permutation used to arrange the columns of the deflated
    **          q matrix into three groups (see dlaed2).
    **          the rows of the eigenvectors found by dlaed4 must be likewise
    **          permuted before the matrix multiply can take place.
    **
    **  ctot    (input) long int array, dimension (4)
    **          a count of the total number of the various types of columns
    **          in q, as described in indx.  the fourth column type is any
    **          column which has been deflated.
    **
    **  w       (input/output) BASE DATA TYPE array, dimension (k)
    **          the first k elements of this array contain the components
    **          of the deflation-adjusted updating vector. destroyed on
    **          output.
    **
    **
    **  lds     (input) long int
    **          the leading dimension of s.  lds >= max(1,k).
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an eigenvalue did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **  modified by francoise tisseur, university of tennessee.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed3(
        const long int* k,
        const long int* n,
        const long int* n1,
        float* d,
        float* q,
        const long int* ldq,
        const float* rho,
        float* dlamda,
        const float* q2,
        const long int* indx,
        const long int* ctot,
        float* ws,
        float* s,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed3(
        const long int* k,
        const long int* n,
        const long int* n1,
        float* d,
        float* q,
        const long int* ldq,
        const float* rho,
        float* dlamda,
        const float* q2,
        const long int* indx,
        const long int* ctot,
        float* ws,
        float* s,
        long int* info)
  */
  /*! fn
   inline void laed3(
        const long int* k,
        const long int* n,
        const long int* n1,
        double* d,
        double* q,
        const long int* ldq,
        const double* rho,
        double* dlamda,
        const double* q2,
        const long int* indx,
        const long int* ctot,
        double* ws,
        double* s,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed3(
        const long int* k,
        const long int* n,
        const long int* n1,
        double* d,
        double* q,
        const long int* ldq,
        const double* rho,
        double* dlamda,
        const double* q2,
        const long int* indx,
        const long int* ctot,
        double* ws,
        double* s,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed3.f)
  //    *  S       (workspace) float array, dimension (N1 + 1)*K
  //    *          Will contain the eigenvectors of the repaired matrix which
  //    *          will be multiplied by the previously accumulated eigenvectors
  //    *          to update the system.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED3(NAME, T)\
inline void laed3(\
    const long int* k,\
    const long int* n,\
    const long int* n1,\
    T* d,\
    T* q,\
    const long int* ldq,\
    const T* rho,\
    T* dlamda,\
    const T* q2,\
    const long int* indx,\
    const long int* ctot,\
    T* ws,\
    T* s,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(k, n, n1, d, q, ldq, rho, dlamda, q2, indx, ctot, ws, s, info);\
}\
inline void laed3(\
    const long int* k,\
    const long int* n,\
    const long int* n1,\
    T* d,\
    T* q,\
    const long int* ldq,\
    const T* rho,\
    T* dlamda,\
    const T* q2,\
    const long int* indx,\
    const long int* ctot,\
    T* ws,\
    T* s,\
    long int* info)\
{\
   workspace<T> w;\
   laed3(k, n, n1, d, q, ldq, rho, dlamda, q2, indx, ctot, ws, s, info, w);\
}\

    LPP_LAED3(slaed3, float)
    LPP_LAED3(dlaed3, double)

#undef LPP_LAED3



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed3_itf.hh
// /////////////////////////////////////////////////////////////////////////////
