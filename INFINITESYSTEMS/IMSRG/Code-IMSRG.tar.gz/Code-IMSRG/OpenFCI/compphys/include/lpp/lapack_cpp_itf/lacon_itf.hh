#ifndef __PROJECT__LPP__FILE__LACON_HH__INCLUDED
#define __PROJECT__LPP__FILE__LACON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lacon_itf.hh C++ interface to LAPACK (c,d,c,z)lacon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lacon_itf.hh
    (excerpt adapted from xlacon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlacon estimates the 1-norm of a square, DATA TYPE matrix a.
    **  reverse communication is used for evaluating matrix-vector products.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the order of the matrix.  n >= 1.
    **
    **
    **  x      (input/output) DATA TYPE array, dimension (n)
    **         on an intermediate return, x should be overwritten by
    **               a * x,   if kase=1,
    **               a' * x,  if kase=2,
    **         where a' is the conjugate transpose of a, and xlacon must be
    **         re-called with all the other parameters unchanged.
    **
    **  est    (output) BASE DATA TYPE
    **         an estimate (a lower bound) for norm(a).
    **
    **  kase   (input/output) long int
    **         on the initial call to xlacon, kase should be 0.
    **         on an intermediate return, kase will be 1 or 2, indicating
    **         whether x should be overwritten by a * x  or a' * x.
    **         on the final return from xlacon, kase will again be 0.
    **
    **  further details
    **  ======= =======
    **
    **  contributed by nick higham, university of manchester.
    **  originally named conest, dated march 16, 1988.
    **
    **  reference: n.j. higham, "fortran codes for estimating the one-norm of
    **  a BASE DATA TYPE or DATA TYPE matrix, with applications to condition estimation",
    **  acm trans. math. soft., vol. 14, no. 4, pp. 381-396, december 1988.
    **
    **  last modified:  april, 1999
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lacon(
        const long int* n,
        float* v,
        float* x,
        long int* isgn,
        float* est,
        long int* kase,
        workspace<float> & w)
  */
  /*! fn
   inline void lacon(
        const long int* n,
        float* v,
        float* x,
        long int* isgn,
        float* est,
        long int* kase)
  */
  /*! fn
   inline void lacon(
        const long int* n,
        double* v,
        double* x,
        long int* isgn,
        double* est,
        long int* kase,
        workspace<double> & w)
  */
  /*! fn
   inline void lacon(
        const long int* n,
        double* v,
        double* x,
        long int* isgn,
        double* est,
        long int* kase)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slacon.f)
  //    *  V      (workspace) float array, dimension (N)
  //    *         On the final return, V = A*W,  where  EST = norm(V)/norm(W)
  //    *         (W is not returned).
  //    *
  //    *  ISGN   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LACON(NAME, T)\
inline void lacon(\
    const long int* n,\
    T* v,\
    T* x,\
    long int* isgn,\
    T* est,\
    long int* kase,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, v, x, isgn, est, kase);\
}\
inline void lacon(\
    const long int* n,\
    T* v,\
    T* x,\
    long int* isgn,\
    T* est,\
    long int* kase)\
{\
   workspace<T> w;\
   lacon(n, v, x, isgn, est, kase, w);\
}\

    LPP_LACON(slacon, float)
    LPP_LACON(dlacon, double)

#undef LPP_LACON


  // The following macro provides the 4 functions 
  /*! fn
   inline void lacon(
       const long int* n,
       std::complex<float>* v,
       std::complex<float>* x,
       float* est,
       long int* kase,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void lacon(
       const long int* n,
       std::complex<float>* v,
       std::complex<float>* x,
       float* est,
       long int* kase)
  */
  /*! fn
   inline void lacon(
       const long int* n,
       std::complex<double>* v,
       std::complex<double>* x,
       double* est,
       long int* kase,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void lacon(
       const long int* n,
       std::complex<double>* v,
       std::complex<double>* x,
       double* est,
       long int* kase)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clacon.f)
  //    *  V      (workspace) std::complex<float> array, dimension (N)
  //    *         On the final return, V = A*W,  where  EST = norm(V)/norm(W)
  //    *         (W is not returned).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LACON(NAME, T, TBASE)\
inline void lacon(\
    const long int* n,\
    T* v,\
    T* x,\
    TBASE* est,\
    long int* kase,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, v, x, est, kase);\
}\
inline void lacon(\
    const long int* n,\
    T* v,\
    T* x,\
    TBASE* est,\
    long int* kase)\
{\
   workspace<T> w;\
   lacon(n, v, x, est, kase, w);\
}\

    LPP_LACON(clacon, std::complex<float>,  float)
    LPP_LACON(zlacon, std::complex<double>, double)

#undef LPP_LACON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lacon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
