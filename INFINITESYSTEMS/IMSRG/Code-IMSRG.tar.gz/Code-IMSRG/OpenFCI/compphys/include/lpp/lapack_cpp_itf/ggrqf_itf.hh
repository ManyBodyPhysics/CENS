#ifndef __PROJECT__LPP__FILE__GGRQF_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGRQF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggrqf_itf.hh C++ interface to LAPACK (c,d,c,z)ggrqf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggrqf_itf.hh
    (excerpt adapted from xggrqf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggrqf computes a generalized rq factorization of an m-by-n matrix a
    **  and a p-by-n matrix b:
    **
    **              a = r*q,        b = z*t*q,
    **
    **  where q is an n-by-n unitary matrix, z is a p-by-p unitary
    **  matrix, and r and t assume one of the forms:
    **
    **  if m <= n,  r = ( 0  r12 ) m,   or if m > n,  r = ( r11 ) m-n,
    **                   n-m  m                           ( r21 ) n
    **                                                       n
    **
    **  where r12 or r21 is upper triangular, and
    **
    **  if p >= n,  t = ( t11 ) n  ,   or if p < n,  t = ( t11  t12 ) p,
    **                  (  0  ) p-n                         p   n-p
    **                     n
    **
    **  where t11 is upper triangular.
    **
    **  in particular, if b is square and nonsingular, the grq factorization
    **  of a and b implicitly gives the rq factorization of a*inv(b):
    **
    **               a*inv(b) = (r*inv(t))*z'
    **
    **  where inv(b) denotes the inverse of the matrix b, and z' denotes the
    **  conjugate transpose of the matrix z.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  p       (input) long int
    **          the number of rows of the matrix b.  p >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrices a and b. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, if m <= n, the upper triangle of the subarray
    **          a(1:m,n-m+1:n) contains the m-by-m upper triangular matrix r;
    **          if m > n, the elements on and above the (m-n)-th subdiagonal
    **          contain the m-by-n upper trapezoidal matrix r; the remaining
    **          elements, with the array taua, represent the unitary
    **          matrix q as a product of elementary reflectors (see further
    **          details).
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  taua    (output) DATA TYPE array, dimension (min(m,n))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix q (see further details).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the p-by-n matrix b.
    **          on exit, the elements on and above the diagonal of the array
    **          contain the min(p,n)-by-n upper trapezoidal matrix t (t is
    **          upper triangular if p >= n); the elements below the diagonal,
    **          with the array taub, represent the unitary matrix z as a
    **          product of elementary reflectors (see further details).
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b. ldb >= max(1,p).
    **
    **  taub    (output) DATA TYPE array, dimension (min(p,n))
    **          the scalar factors of the elementary reflectors which
    **          represent the unitary matrix z (see further details).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info=-i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  the matrix q is represented as a product of elementary reflectors
    **
    **     q = h(1) h(2) . . . h(k), where k = min(m,n).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - taua * v * v'
    **
    **  where taua is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(n-k+i+1:n) = 0 and v(n-k+i) = 1; v(1:n-k+i-1) is stored on exit in
    **  a(m-k+i,1:n-k+i-1), and taua in taua(i).
    **  to form q explicitly, use lapack subroutine cungrq.
    **  to use q to update another matrix, use lapack subroutine cunmrq.
    **
    **  the matrix z is represented as a product of elementary reflectors
    **
    **     z = h(1) h(2) . . . h(k), where k = min(p,n).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - taub * v * v'
    **
    **  where taub is a DATA TYPE scalar, and v is a DATA TYPE vector with
    **  v(1:i-1) = 0 and v(i) = 1; v(i+1:p) is stored on exit in b(i+1:p,i),
    **  and taub in taub(i).
    **  to form z explicitly, use lapack subroutine cungqr.
    **  to use z to update another matrix, use lapack subroutine cunmqr.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggrqf(
        const long int* m,
        const long int* p,
        const long int* n,
        float* a,
        const long int* lda,
        float* taua,
        float* b,
        const long int* ldb,
        float* taub,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggrqf(
        const long int* m,
        const long int* p,
        const long int* n,
        float* a,
        const long int* lda,
        float* taua,
        float* b,
        const long int* ldb,
        float* taub,
        long int* info)
  */
  /*! fn
   inline void ggrqf(
        const long int* m,
        const long int* p,
        const long int* n,
        double* a,
        const long int* lda,
        double* taua,
        double* b,
        const long int* ldb,
        double* taub,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggrqf(
        const long int* m,
        const long int* p,
        const long int* n,
        double* a,
        const long int* lda,
        double* taua,
        double* b,
        const long int* ldb,
        double* taub,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggrqf.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N,M,P).
  //    *          For optimum performance LWORK >= max(N,M,P)*max(NB1,NB2,NB3),
  //    *          where NB1 is the optimal blocksize for the RQ factorization
  //    *          of an M-by-N matrix, NB2 is the optimal blocksize for the
  //    *          QR factorization of a P-by-N matrix, and NB3 is the optimal
  //    *          blocksize for a call of SORMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGRQF(NAME, T)\
inline void ggrqf(\
    const long int* m,\
    const long int* p,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, p, n, a, lda, taua, b, ldb, taub, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, p, n, a, lda, taua, b, ldb, taub, w.getw(), &w.neededsize(), info);\
}\
inline void ggrqf(\
    const long int* m,\
    const long int* p,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info)\
{\
   workspace<T> w;\
   ggrqf(m, p, n, a, lda, taua, b, ldb, taub, info, w);\
}\

    LPP_GGRQF(sggrqf, float)
    LPP_GGRQF(dggrqf, double)

#undef LPP_GGRQF


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggrqf(
       const long int* m,
       const long int* p,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* taua,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* taub,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggrqf(
       const long int* m,
       const long int* p,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* taua,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* taub,
       long int* info)
  */
  /*! fn
   inline void ggrqf(
       const long int* m,
       const long int* p,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* taua,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* taub,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggrqf(
       const long int* m,
       const long int* p,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* taua,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* taub,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggrqf.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,N,M,P).
  //    *          For optimum performance LWORK >= max(N,M,P)*max(NB1,NB2,NB3),
  //    *          where NB1 is the optimal blocksize for the RQ factorization
  //    *          of an M-by-N matrix, NB2 is the optimal blocksize for the
  //    *          QR factorization of a P-by-N matrix, and NB3 is the optimal
  //    *          blocksize for a call of CUNMRQ.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGRQF(NAME, T, TBASE)\
inline void ggrqf(\
    const long int* m,\
    const long int* p,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, p, n, a, lda, taua, b, ldb, taub, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(m, p, n, a, lda, taua, b, ldb, taub, w.getw(), &w.neededsize(), info);\
}\
inline void ggrqf(\
    const long int* m,\
    const long int* p,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    T* taua,\
    T* b,\
    const long int* ldb,\
    T* taub,\
    long int* info)\
{\
   workspace<T> w;\
   ggrqf(m, p, n, a, lda, taua, b, ldb, taub, info, w);\
}\

    LPP_GGRQF(cggrqf, std::complex<float>,  float)
    LPP_GGRQF(zggrqf, std::complex<double>, double)

#undef LPP_GGRQF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggrqf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
