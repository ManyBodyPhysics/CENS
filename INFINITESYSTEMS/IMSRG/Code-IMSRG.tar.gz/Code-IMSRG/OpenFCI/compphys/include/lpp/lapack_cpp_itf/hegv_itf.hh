#ifndef __PROJECT__LPP__FILE__HEGV_HH__INCLUDED
#define __PROJECT__LPP__FILE__HEGV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hegv_itf.hh C++ interface to LAPACK (s,d,c,z)hegv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hegv_itf.hh
    (excerpt adapted from xhegv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhegv computes all the eigenvalues, and optionally, the eigenvectors
    **  of a DATA TYPE generalized hermitian-definite eigenproblem, of the form
    **  a*x=(lambda)*b*x,  a*bx=(lambda)*x,  or b*a*x=(lambda)*x.
    **  here a and b are assumed to be hermitian and b is also
    **  positive definite.
    **
    **  arguments
    **  =========
    **
    **  itype   (input) long int
    **          specifies the problem type to be solved:
    **          = 1:  a*x = (lambda)*b*x
    **          = 2:  a*b*x = (lambda)*x
    **          = 3:  b*a*x = (lambda)*x
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangles of a and b are stored;
    **          = 'l':  lower triangles of a and b are stored.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the
    **          leading n-by-n upper triangular part of a contains the
    **          upper triangular part of the matrix a.  if uplo = 'l',
    **          the leading n-by-n lower triangular part of a contains
    **          the lower triangular part of the matrix a.
    **
    **          on exit, if jobz = 'v', then if info = 0, a contains the
    **          matrix z of eigenvectors.  the eigenvectors are normalized
    **          as follows:
    **          if itype = 1 or 2, z**h*b*z = i;
    **          if itype = 3, z**h*inv(b)*z = i.
    **          if jobz = 'n', then on exit the upper triangle (if uplo='u')
    **          or the lower triangle (if uplo='l') of a, including the
    **          diagonal, is destroyed.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the hermitian positive definite matrix b.
    **          if uplo = 'u', the leading n-by-n upper triangular part of b
    **          contains the upper triangular part of the matrix b.
    **          if uplo = 'l', the leading n-by-n lower triangular part of b
    **          contains the lower triangular part of the matrix b.
    **
    **          on exit, if info <= n, the part of b containing the matrix is
    **          overwritten by the triangular factor u or l from the cholesky
    **          factorization b = u**h*u or b = l*l**h.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the eigenvalues in ascending order.
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  cpotrf or cheev returned an error code:
    **             <= n:  if info = i, cheev failed to converge;
    **                    i off-diagonal elements of an intermediate
    **                    tridiagonal form did not converge to zero;
    **             > n:   if info = n + i, for 1 <= i <= n, then the leading
    **                    minor of order i of b is not positive definite.
    **                    the factorization of b could not be completed and
    **                    no eigenvalues or eigenvectors were computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hegv(
       const long int* itype,
       const char* jobz,
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       float* ws,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hegv(
       const long int* itype,
       const char* jobz,
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       float* ws,
       long int* info)
  */
  /*! fn
   inline void hegv(
       const long int* itype,
       const char* jobz,
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       double* ws,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hegv(
       const long int* itype,
       const char* jobz,
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       double* ws,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chegv.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of the array WORK.  LWORK >= max(1,2*N-1).
  //    *          For optimal efficiency, LWORK >= (NB+1)*N,
  //    *          where NB is the blocksize for CHETRD returned by ILAENV.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  RWORK   (workspace) float array, dimension (max(1, 3*N-2))
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HEGV(NAME, T, TBASE)\
inline void hegv(\
    const long int* itype,\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    TBASE* ws,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizerw(std::max(1l, 3**n-2));                                      \
    F77NAME( NAME )(itype, jobz, uplo, n, a, lda, b, ldb, ws, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(itype, jobz, uplo, n, a, lda, b, ldb, ws, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void hegv(\
    const long int* itype,\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    TBASE* ws,\
    long int* info)\
{\
   workspace<T> w;\
   hegv(itype, jobz, uplo, n, a, lda, b, ldb, ws, info, w);\
}\

    LPP_HEGV(chegv, std::complex<float>, float)
    LPP_HEGV(zhegv, std::complex<double>, double)

#undef LPP_HEGV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hegv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
