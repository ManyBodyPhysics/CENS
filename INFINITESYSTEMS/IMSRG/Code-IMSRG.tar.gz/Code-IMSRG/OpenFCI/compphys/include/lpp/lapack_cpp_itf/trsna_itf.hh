#ifndef __PROJECT__LPP__FILE__TRSNA_HH__INCLUDED
#define __PROJECT__LPP__FILE__TRSNA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : trsna_itf.hh C++ interface to LAPACK (s,d,c,z)trsna
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file trsna_itf.hh
    (excerpt adapted from xtrsna.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtrsna estimates reciprocal condition numbers for specified
    **  eigenvalues and/or right eigenvectors of a DATA TYPE upper triangular
    **  matrix t (or of any matrix q*t*q**h with q unitary).
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies whether condition numbers are required for
    **          eigenvalues (s) or eigenvectors (sep):
    **          = 'e': for eigenvalues only (s);
    **          = 'v': for eigenvectors only (sep);
    **          = 'b': for both eigenvalues and eigenvectors (s and sep).
    **
    **  howmny  (input) char
    **          = 'a': compute condition numbers for all eigenpairs;
    **          = 's': compute condition numbers for selected eigenpairs
    **                 specified by the array select.
    **
    **  select  (input) logical array, dimension (n)
    **          if howmny = 's', select specifies the eigenpairs for which
    **          condition numbers are required. to select condition numbers
    **          for the j-th eigenpair, select(j) must be set to .true..
    **          if howmny = 'a', select is not referenced.
    **
    **  n       (input) long int
    **          the order of the matrix t. n >= 0.
    **
    **  t       (input) DATA TYPE array, dimension (ldt,n)
    **          the upper triangular matrix t.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= max(1,n).
    **
    **  vl      (input) DATA TYPE array, dimension (ldvl,m)
    **          if job = 'e' or 'b', vl must contain left eigenvectors of t
    **          (or of any q*t*q**h with q unitary), corresponding to the
    **          eigenpairs specified by howmny and select. the eigenvectors
    **          must be stored in consecutive columns of vl, as returned by
    **          chsein or ctrevc.
    **          if job = 'v', vl is not referenced.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the array vl.
    **          ldvl >= 1; and if job = 'e' or 'b', ldvl >= n.
    **
    **  vr      (input) DATA TYPE array, dimension (ldvr,m)
    **          if job = 'e' or 'b', vr must contain right eigenvectors of t
    **          (or of any q*t*q**h with q unitary), corresponding to the
    **          eigenpairs specified by howmny and select. the eigenvectors
    **          must be stored in consecutive columns of vr, as returned by
    **          chsein or ctrevc.
    **          if job = 'v', vr is not referenced.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr.
    **          ldvr >= 1; and if job = 'e' or 'b', ldvr >= n.
    **
    **  s       (output) BASE DATA TYPE array, dimension (mm)
    **          if job = 'e' or 'b', the reciprocal condition numbers of the
    **          selected eigenvalues, stored in consecutive elements of the
    **          array. thus s(j), sep(j), and the j-th columns of vl and vr
    **          all correspond to the same eigenpair (but not in general the
    **          j-th eigenpair, unless all eigenpairs are selected).
    **          if job = 'v', s is not referenced.
    **
    **  sep     (output) BASE DATA TYPE array, dimension (mm)
    **          if job = 'v' or 'b', the estimated reciprocal condition
    **          numbers of the selected eigenvectors, stored in consecutive
    **          elements of the array.
    **          if job = 'e', sep is not referenced.
    **
    **  mm      (input) long int
    **          the number of elements in the arrays s (if job = 'e' or 'b')
    **           and/or sep (if job = 'v' or 'b'). mm >= m.
    **
    **  m       (output) long int
    **          the number of elements of the arrays s and/or sep actually
    **          used to store the estimated condition numbers.
    **          if howmny = 'a', m is set to n.
    **
    **
    **  ldWORK  (input) long int
    **          the leading dimension of the array WORK.
    **          ldWORK >= 1; and if job = 'v' or 'b', ldWORK >= n.
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  the reciprocal of the condition number of an eigenvalue lambda is
    **  defined as
    **
    **          s(lambda) = |v'*u| / (norm(u)*norm(v))
    **
    **  where u and v are the right and left eigenvectors of t corresponding
    **  to lambda; v' denotes the conjugate transpose of v, and norm(u)
    **  denotes the euclidean norm. these reciprocal condition numbers always
    **  lie between zero (very badly conditioned) and one (very well
    **  conditioned). if n = 1, s(lambda) is defined to be 1.
    **
    **  an approximate error bound for a computed eigenvalue w(i) is given by
    **
    **                      eps * norm(t) / s(i)
    **
    **  where eps is the machine precision.
    **
    **  the reciprocal of the condition number of the right eigenvector u
    **  corresponding to lambda is defined as follows. suppose
    **
    **              t = ( lambda  c  )
    **                  (   0    t22 )
    **
    **  then the reciprocal condition number is
    **
    **          sep( lambda, t22 ) = sigma-min( t22 - lambda*i )
    **
    **  where sigma-min denotes the smallest singular value. we approximate
    **  the smallest singular value by the reciprocal of an estimate of the
    **  one-norm of the inverse of t22 - lambda*i. if n = 1, sep(1) is
    **  defined to be abs(t(1,1)).
    **
    **  an approximate error bound for a computed right eigenvector vr(i)
    **  is given by
    **
    **                      eps * norm(t) / sep(i)
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void trsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        const float* s,
        float* sep,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void trsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        const float* s,
        float* sep,
        const long int* mm,
        const long int* m,
        long int* info)
  */
  /*! fn
   inline void trsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        const double* s,
        double* sep,
        const long int* mm,
        const long int* m,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void trsna(
        const char* job,
        const char* howmny,
        const long int* select,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        const double* s,
        double* sep,
        const long int* mm,
        const long int* m,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from strsna.f)
  //    *  WORK    (workspace) float array, dimension (LDWORK,N+6)
  //    *          If JOB = 'E', WORK is not referenced.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (2*(N-1))
  //    *          If JOB = 'E', IWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSNA(NAME, T)\
inline void trsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const T* s,\
    T* sep,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(2*((*n)-1));                                               \
  F77NAME( NAME )(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, \
                  w.getw(), w.query(), w.getiw(), info);                \
  w.resizew(w.neededsize());                                            \
  F77NAME( NAME )(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, \
                    w.getw(), &w.neededsize(), w.getiw(), info);        \
}\
inline void trsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const T* s,\
    T* sep,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   trsna(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, info, w);\
}\

    LPP_TRSNA(strsna, float)
    LPP_TRSNA(dtrsna, double)

#undef LPP_TRSNA


  // The following macro provides the 4 functions 
  /*! fn
   inline void trsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       const float* s,
       float* sep,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void trsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       const float* s,
       float* sep,
       const long int* mm,
       const long int* m,
       long int* info)
  */
  /*! fn
   inline void trsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       const double* s,
       double* sep,
       const long int* mm,
       const long int* m,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void trsna(
       const char* job,
       const char* howmny,
       const long int* select,
       const long int* n,
       const std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       const double* s,
       double* sep,
       const long int* mm,
       const long int* m,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctrsna.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (LDWORK,N+6)
  //    *          If JOB = 'E', WORK is not referenced.
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *          If JOB = 'E', RWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRSNA(NAME, T, TBASE)\
inline void trsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const TBASE* s,\
    TBASE* sep,\
    const long int* mm,\
    const long int* m,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    F77NAME( NAME )(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, w.getw(), w.query(), w.getrw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, w.getw(), &w.neededsize(), w.getrw(), info);\
}\
inline void trsna(\
    const char* job,\
    const char* howmny,\
    const long int* select,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    const TBASE* s,\
    TBASE* sep,\
    const long int* mm,\
    const long int* m,\
    long int* info)\
{\
   workspace<T> w;\
   trsna(job, howmny, select, n, t, ldt, vl, ldvl, vr, ldvr, s, sep, mm, m, info, w);\
}\

    LPP_TRSNA(ctrsna, std::complex<float>, float)
    LPP_TRSNA(ztrsna, std::complex<double>, double)

#undef LPP_TRSNA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of trsna_itf.hh
// /////////////////////////////////////////////////////////////////////////////
