#ifndef __PROJECT__LPP__FILE__GGES_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGES_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gges_itf.hh C++ interface to LAPACK (c,d,c,z)gges
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gges_itf.hh
    (excerpt adapted from xgges.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgges computes for a pair of n-by-n DATA TYPE nonsymmetric matrices
    **  (a,b), the generalized eigenvalues, the generalized DATA TYPE schur
    **  form (s, t), and optionally left and/or right schur vectors (vsl
    **  and vsr). this gives the generalized schur factorization
    **
    **          (a,b) = ( (vsl)*s*(vsr)**h, (vsl)*t*(vsr)**h )
    **
    **  where (vsr)**h is the conjugate-transpose of vsr.
    **
    **  optionally, it also orders the eigenvalues so that a selected cluster
    **  of eigenvalues appears in the leading diagonal blocks of the upper
    **  triangular matrix s and the upper triangular matrix t. the leading
    **  columns of vsl and vsr then form an unitary basis for the
    **  corresponding left and right eigenspaces (zeflating subspaces).
    **
    **  (if only the generalized eigenvalues are needed, use the driver
    **  cggev instead, which is faster.)
    **
    **  a generalized eigenvalue for a pair of matrices (a,b) is a scalar w
    **  or a ratio alpha/beta = ws, such that  a - w*b is singular.  it is
    **  usually represented as the pair (alpha,beta), as there is a
    **  reasonable interpretation for beta=0, and even for both being zero.
    **
    **  a pair of matrices (s,t) is in generalized DATA TYPE schur form if s
    **  and t are upper triangular and, in addition, the diagonal elements
    **  of t are non-negative BASE DATA TYPE numbers.
    **
    **  arguments
    **  =========
    **
    **  jobvsl  (input) char
    **          = 'n':  do not compute the left schur vectors;
    **          = 'v':  compute the left schur vectors.
    **
    **  jobvsr  (input) char
    **          = 'n':  do not compute the right schur vectors;
    **          = 'v':  compute the right schur vectors.
    **
    **  sort    (input) char
    **          specifies whether or not to order the eigenvalues on the
    **          diagonal of the generalized schur form.
    **          = 'n':  eigenvalues are not ordered;
    **          = 's':  eigenvalues are ordered (see selctg).
    **
    **  selctg  (input) logical function of two DATA TYPE arguments
    **          selctg must be declared external in the calling subroutine.
    **          if sort = 'n', selctg is not referenced.
    **          if sort = 's', selctg is used to select eigenvalues to sort
    **          to the top left of the schur form.
    **          an eigenvalue alpha(j)/beta(j) is selected if
    **          selctg(alpha(j),beta(j)) is true.
    **
    **          note that a selected DATA TYPE eigenvalue may no longer satisfy
    **          selctg(alpha(j),beta(j)) = .true. after ordering, since
    **          ordering may change the value of DATA TYPE eigenvalues
    **          (especially if the eigenvalue is ill-conditioned), in this
    **          case info is set to n+2 (see info below).
    **
    **  n       (input) long int
    **          the order of the matrices a, b, vsl, and vsr.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the first of the pair of matrices.
    **          on exit, a has been overwritten by its generalized schur
    **          form s.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the second of the pair of matrices.
    **          on exit, b has been overwritten by its generalized schur
    **          form t.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  ldb >= max(1,n).
    **
    **  sdim    (output) long int
    **          if sort = 'n', sdim = 0.
    **          if sort = 's', sdim = number of eigenvalues (after sorting)
    **          for which selctg is true.
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **  beta    (output) DATA TYPE array, dimension (n)
    **          on exit,  alpha(j)/beta(j), j=1,...,n, will be the
    **          generalized eigenvalues.  alpha(j), j=1,...,n  and  beta(j),
    **          j=1,...,n  are the diagonals of the DATA TYPE schur form (a,b)
    **          output by xgges. the  beta(j) will be non-negative BASE DATA TYPE.
    **
    **          note: the quotients alpha(j)/beta(j) may easily over- or
    **          underflow, and beta(j) may even be zero.  thus, the user
    **          should avoid naively computing the ratio alpha/beta.
    **          however, alpha will be always less than and usually
    **          comparable with norm(a) in magnitude, and beta always less
    **          than and usually comparable with norm(b).
    **
    **  vsl     (output) DATA TYPE array, dimension (ldvsl,n)
    **          if jobvsl = 'v', vsl will contain the left schur vectors.
    **          not referenced if jobvsl = 'n'.
    **
    **  ldvsl   (input) long int
    **          the leading dimension of the matrix vsl. ldvsl >= 1, and
    **          if jobvsl = 'v', ldvsl >= n.
    **
    **  vsr     (output) DATA TYPE array, dimension (ldvsr,n)
    **          if jobvsr = 'v', vsr will contain the right schur vectors.
    **          not referenced if jobvsr = 'n'.
    **
    **  ldvsr   (input) long int
    **          the leading dimension of the matrix vsr. ldvsr >= 1, and
    **          if jobvsr = 'v', ldvsr >= n.
    **
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          =1,...,n:
    **                the qz iteration failed.  (a,b) are not in schur
    **                form, but alpha(j) and beta(j) should be correct for
    **                j=info+1,...,n.
    **          > n:  =n+1: other than qz iteration failed in chgeqz
    **                =n+2: after reordering, roundoff changed values of
    **                      some DATA TYPE eigenvalues so that leading
    **                      eigenvalues in the generalized schur form no
    **                      longer satisfy selctg=.true.  this could also
    **                      be caused due to scaling.
    **                =n+3: reordering falied in ctgsen.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gges(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* sdim,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gges(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const long int* n,
        float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        long int* sdim,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vsl,
        const long int* ldvsl,
        const float* vsr,
        const long int* ldvsr,
        long int* info)
  */
  /*! fn
   inline void gges(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* sdim,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gges(
        const char* jobvsl,
        const char* jobvsr,
        const char* sort,
        const long int* selctg,
        const long int* n,
        double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        long int* sdim,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vsl,
        const long int* ldvsl,
        const double* vsr,
        const long int* ldvsr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgges.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= 8*N+16.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGES(NAME, T)\
inline void gges(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* selctg,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizebw(lower(*sort) == 'n'?0:*n);                               \
    F77NAME( NAME )(jobvsl, jobvsr, sort, selctg, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), w.query(), w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvsl, jobvsr, sort, selctg, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), &w.neededsize(), w.getbw(), info);\
}\
inline void gges(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* selctg,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info)\
{\
   workspace<T> w;\
   gges(jobvsl, jobvsr, sort, selctg, n, a, lda, b, ldb, sdim, alphar, alphai, beta, vsl, ldvsl, vsr, ldvsr, info, w);\
}\

    LPP_GGES(sgges, float)
    LPP_GGES(dgges, double)

#undef LPP_GGES


  // The following macro provides the 4 functions 
  /*! fn
   inline void gges(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gges(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vsl,
       const long int* ldvsl,
       const std::complex<float>* vsr,
       const long int* ldvsr,
       long int* info)
  */
  /*! fn
   inline void gges(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gges(
       const char* jobvsl,
       const char* jobvsr,
       const char* sort,
       const long int* delctg,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       long int* sdim,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vsl,
       const long int* ldvsl,
       const std::complex<double>* vsr,
       const long int* ldvsr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgges.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= max(1,2*N).
  //    *          For good performance, LWORK must generally be larger.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (8*N)
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          Not referenced if SORT = 'N'.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGES(NAME, T, TBASE)\
inline void gges(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* delctg,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(8**n);\
    w.resizebw(lower(*sort) == 'n'?0:*n);\
    F77NAME( NAME )(jobvsl, jobvsr, sort, delctg, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), w.query(), w.getrw(), w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobvsl, jobvsr, sort, delctg, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, w.getw(), &w.neededsize(), w.getrw(), w.getbw(), info);\
}\
inline void gges(\
    const char* jobvsl,\
    const char* jobvsr,\
    const char* sort,\
    const long int* delctg,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    long int* sdim,\
    T* alpha,\
    T* beta,\
    const T* vsl,\
    const long int* ldvsl,\
    const T* vsr,\
    const long int* ldvsr,\
    long int* info)\
{\
   workspace<T> w;\
   gges(jobvsl, jobvsr, sort, delctg, n, a, lda, b, ldb, sdim, alpha, beta, vsl, ldvsl, vsr, ldvsr, info, w);\
}\

    LPP_GGES(cgges, std::complex<float>,  float)
    LPP_GGES(zgges, std::complex<double>, double)

#undef LPP_GGES



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gges_itf.hh
// /////////////////////////////////////////////////////////////////////////////
