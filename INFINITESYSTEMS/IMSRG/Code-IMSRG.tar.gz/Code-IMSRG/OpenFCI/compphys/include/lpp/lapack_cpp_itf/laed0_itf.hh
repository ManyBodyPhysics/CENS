#ifndef __PROJECT__LPP__FILE__LAED0_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAED0_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laed0_itf.hh C++ interface to LAPACK (s,d,c,z)laed0
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laed0_itf.hh
    (excerpt adapted from xlaed0.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  using the divide and conquer method, xlaed0 computes all eigenvalues
    **  of a symmetric tridiagonal matrix which is one diagonal block of
    **  those from reducing a dense or band hermitian matrix and
    **  corresponding eigenvectors of the dense or band matrix.
    **
    **  arguments
    **  =========
    **
    **  qsiz   (input) long int
    **         the dimension of the unitary matrix used to reduce
    **         the full matrix to tridiagonal form.  qsiz >= n if icompq = 1.
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry, the diagonal elements of the tridiagonal matrix.
    **         on exit, the eigenvalues in ascending order.
    **
    **  e      (input/output) BASE DATA TYPE array, dimension (n-1)
    **         on entry, the off-diagonal elements of the tridiagonal matrix.
    **         on exit, e has been destroyed.
    **
    **  q      (input/output) DATA TYPE array, dimension (ldq,n)
    **         on entry, q must contain an qsiz x n matrix whose columns
    **         unitarily orthonormal. it is a part of the unitary matrix
    **         that reduces the full dense hermitian matrix to a
    **         (reducible) symmetric tridiagonal matrix.
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  the algorithm failed to compute an eigenvalue while
    **                WORKing on the submatrix lying in rows and columns
    **                info/(n+1) through mod(info,n+1).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laed0(
        const long int* icompq,
        const long int* qsiz,
        const long int* n,
        float* d,
        const float* e,
        const float* q,
        const long int* ldq,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laed0(
        const long int* icompq,
        const long int* qsiz,
        const long int* n,
        float* d,
        const float* e,
        const float* q,
        const long int* ldq,
        long int* info)
  */
  /*! fn
   inline void laed0(
        const long int* icompq,
        const long int* qsiz,
        const long int* n,
        double* d,
        const double* e,
        const double* q,
        const long int* ldq,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laed0(
        const long int* icompq,
        const long int* qsiz,
        const long int* n,
        double* d,
        const double* e,
        const double* q,
        const long int* ldq,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaed0.f)
  //    *  QSTORE (workspace) float array, dimension (LDQS, N)
  //    *         Referenced only when ICOMPQ = 1.  Used to store parts of
  //    *         the eigenvector matrix when the updating matrix multiplies
  //    *         take place.
  //    *
  //    *  WORK   (workspace) float array,
  //    *         If ICOMPQ = 0 or 1, the dimension of WORK must be at least
  //    *                     1 + 3*N + 2*N*lg N + 2*N**2
  //    *                     ( lg( N ) = smallest integer k
  //    *                                 such that 2^k >= N )
  //    *         If ICOMPQ = 2, the dimension of WORK must be at least
  //    *                     4*N + N**2.
  //    *
  //    *  IWORK  (workspace) long int array,
  //    *         If ICOMPQ = 0 or 1, the dimension of IWORK must be at least
  //    *                        6 + 6*N + 5*N*lg N.
  //    *                        ( lg( N ) = smallest integer k
  //    *                                    such that 2^k >= N )
  //    *         If ICOMPQ = 2, the dimension of IWORK must be at least
  //    *                        3 + 5*N.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED0(NAME, T)\
inline void laed0(\
    const long int* icompq,\
    const long int* qsiz,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* q,\
    const long int* ldq,\
    long int* info,\
    workspace<T> & w)\
{\
  long int ldw = ((*icompq == 2) ? (4 + (*n))*(*n) : 1 + (*n)*(3 + 2*(long int)(log(float(*n))/log(2.0f) + 2*(*n)))); \
  long int ldiw =((*icompq == 2) ? (3+5**n) : 6 + (*n)*(6 + 5*(long int)(log(float(*n))/log(2.0f) ))); \
  w.resizeiw(ldiw);                                                     \
  w.resizew(ldw);                                                       \
  w.resizerw(*n);                                                       \
  F77NAME( NAME )(icompq, qsiz, n, d, e, q, ldq, w.getrw(), n, w.getw(), w.getiw(), info); \
}\
inline void laed0(\
    const long int* icompq,\
    const long int* qsiz,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* q,\
    const long int* ldq,\
    T* qstore,\
    const long int* ldqs,\
    long int* info)\
{\
   workspace<T> w;\
   laed0(icompq, qsiz, n, d, e, q, ldq, info, w);\
}\

    LPP_LAED0(slaed0, float)
    LPP_LAED0(dlaed0, double)

#undef LPP_LAED0


  // The following macro provides the 4 functions 
  /*! fn
   inline void laed0(
       const long int* qsiz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laed0(
       const long int* qsiz,
       const long int* n,
       float* d,
       float* e,
       const std::complex<float>* q,
       const long int* ldq,
       long int* info)
  */
  /*! fn
   inline void laed0(
       const long int* qsiz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* q,
       const long int* ldq,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laed0(
       const long int* qsiz,
       const long int* n,
       double* d,
       double* e,
       const std::complex<double>* q,
       const long int* ldq,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claed0.f)
  //    *  IWORK  (workspace) long int array,
  //    *         the dimension of IWORK must be at least
  //    *                      6 + 6*N + 5*N*lg N
  //    *                      ( lg( N ) = smallest integer k
  //    *                                  such that 2^k >= N )
  //    *
  //    *  RWORK  (workspace) float array,
  //    *                               dimension (1 + 3*N + 2*N*lg N + 3*N**2)
  //    *                        ( lg( N ) = smallest integer k
  //    *                                    such that 2^k >= N )
  //    *
  //    *  QSTORE (workspace) std::complex<float> array, dimension (LDQS, N)
  //    *         Used to store parts of
  //    *         the eigenvector matrix when the updating matrix multiplies
  //    *         take place.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAED0(NAME, T, TBASE)\
inline void laed0(\
    const long int* qsiz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* q,\
    const long int* ldq,\
    long int* info,\
    workspace<T> & w)\
{\
  long int ldw =  6 + (*n)*(6 + 5*(long int)( log(float(*n)) /log(2.0f) ) ); \
  long int ldiw = 1 + (*n)*( 3 + 2*(long int) (log(float(*n))/log(2.0f)) + 3*(*n) ); \
  w.resizeiw(ldiw);                                                     \
  w.resizew(ldw);                                                       \
  w.resizerw(*n);                                                       \
  F77NAME( NAME )(qsiz, n, d, e, q, ldq, w.getw(), n, w.getrw(), w.getiw(), info); \
}\
inline void laed0(\
    const long int* qsiz,\
    const long int* n,\
    TBASE* d,\
    TBASE* e,\
    const T* q,\
    const long int* ldq,\
    long int* info)\
{\
   workspace<T> w;\
   laed0(qsiz, n, d, e, q, ldq, info, w);\
}\

    LPP_LAED0(claed0, std::complex<float>, float)
    LPP_LAED0(zlaed0, std::complex<double>, double)

#undef LPP_LAED0



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laed0_itf.hh
// /////////////////////////////////////////////////////////////////////////////
