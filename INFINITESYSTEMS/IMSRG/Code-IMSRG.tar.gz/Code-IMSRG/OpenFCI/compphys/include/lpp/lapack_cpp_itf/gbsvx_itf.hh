#ifndef __PROJECT__LPP__FILE__GBSVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GBSVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : gbsvx_itf.hh C++ interface to LAPACK (c,d,c,z)gbsvx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file gbsvx_itf.hh
    (excerpt adapted from xgbsvx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xgbsvx uses the lu factorization to compute the solution to a DATA TYPE
    **  system of linear equations a * x = b, a**t * x = b, or a**h * x = b,
    **  where a is a band matrix of order n with kl subdiagonals and ku
    **  superdiagonals, and x and b are n-by-nrhs matrices.
    **
    **  error bounds on the solution and a condition estimate are also
    **  provided.
    **
    **  description
    **  ===========
    **
    **  the following steps are performed by this subroutine:
    **
    **  1. if fact = 'e', BASE DATA TYPE scaling factors are computed to equilibrate
    **     the system:
    **        trans = 'n':  diag(r)*a*diag(c)     *inv(ziag(c))*x = diag(r)*b
    **        trans = 't': (diag(r)*a*diag(c))**t *inv(diag(r))*x = diag(c)*b
    **        trans = 'c': (diag(r)*a*diag(c))**h *inv(diag(r))*x = diag(c)*b
    **     whether or not the system will be equilibrated depends on the
    **     scaling of the matrix a, but if equilibration is used, a is
    **     overwritten by diag(r)*a*diag(c) and b by diag(r)*b (if trans='n')
    **     or diag(c)*b (if trans = 't' or 'c').
    **
    **  2. if fact = 'n' or 'e', the lu decomposition is used to factor the
    **     matrix a (after equilibration if fact = 'e') as
    **        a = l * u,
    **     where l is a product of permutation and unit lower triangular
    **     matrices with kl subdiagonals, and u is upper triangular with
    **     kl+ku superdiagonals.
    **
    **  3. if some u(i,i)=0, so that u is exactly singular, then the routine
    **     returns with info = i. otherwise, the factored form of a is used
    **     to estimate the condition number of the matrix a.  if the
    **     reciprocal of the condition number is less than machine precision,
    **     info = n+1 is returned as a warning, but the routine still goes on
    **     to solve for x and compute error bounds as described below.
    **
    **  4. the system of equations is solved for x using the factored form
    **     of a.
    **
    **  5. iterative refinement is applied to improve the computed solution
    **     matrix and calculate error bounds and backward error estimates
    **     for it.
    **
    **  6. if equilibration was used, the matrix x is premultiplied by
    **     diag(c) (if trans = 'n') or diag(r) (if trans = 't' or 'c') so
    **     that it solves the original system before equilibration.
    **
    **  arguments
    **  =========
    **
    **  fact    (input) char
    **          specifies whether or not the factored form of the matrix a is
    **          supplied on entry, and if not, whether the matrix a should be
    **          equilibrated before it is factored.
    **          = 'f':  on entry, afb and ipiv contain the factored form of
    **                  a.  if equed is not 'n', the matrix a has been
    **                  equilibrated with scaling factors given by r and c.
    **                  ab, afb, and ipiv are not modified.
    **          = 'n':  the matrix a will be copied to afb and factored.
    **          = 'e':  the matrix a will be equilibrated if necessary, then
    **                  copied to afb and factored.
    **
    **  trans   (input) char
    **          specifies the form of the system of equations.
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  kl      (input) long int
    **          the number of subdiagonals within the band of a.  kl >= 0.
    **
    **  ku      (input) long int
    **          the number of superdiagonals within the band of a.  ku >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrices b and x.  nrhs >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the matrix a in band storage, in rows 1 to kl+ku+1.
    **          the j-th column of a is stored in the j-th column of the
    **          array ab as follows:
    **          ab(ku+1+i-j,j) = a(i,j) for max(1,j-ku)<=i<=min(n,j+kl)
    **
    **          if fact = 'f' and equed is not 'n', then a must have been
    **          equilibrated by the scaling factors in r and/or c.  ab is not
    **          modified if fact = 'f' or 'n', or if fact = 'e' and
    **          equed = 'n' on exit.
    **
    **          on exit, if equed .ne. 'n', a is scaled as follows:
    **          equed = 'r':  a := diag(r) * a
    **          equed = 'c':  a := a * diag(c)
    **          equed = 'b':  a := diag(r) * a * diag(c).
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kl+ku+1.
    **
    **  afb     (input or output) DATA TYPE array, dimension (ldafb,n)
    **          if fact = 'f', then afb is an input argument and on entry
    **          contains details of the lu factorization of the band matrix
    **          a, as computed by cgbtrf.  u is stored as an upper triangular
    **          band matrix with kl+ku superdiagonals in rows 1 to kl+ku+1,
    **          and the multipliers used during the factorization are stored
    **          in rows kl+ku+2 to 2*kl+ku+1.  if equed .ne. 'n', then afb is
    **          the factored form of the equilibrated matrix a.
    **
    **          if fact = 'n', then afb is an output argument and on exit
    **          returns details of the lu factorization of a.
    **
    **          if fact = 'e', then afb is an output argument and on exit
    **          returns details of the lu factorization of the equilibrated
    **          matrix a (see the description of ab for the form of the
    **          equilibrated matrix).
    **
    **  ldafb   (input) long int
    **          the leading dimension of the array afb.  ldafb >= 2*kl+ku+1.
    **
    **  ipiv    (input or output) long int array, dimension (n)
    **          if fact = 'f', then ipiv is an input argument and on entry
    **          contains the pivot indices from the factorization a = l*u
    **          as computed by cgbtrf; row i of the matrix was interchanged
    **          with row ipiv(i).
    **
    **          if fact = 'n', then ipiv is an output argument and on exit
    **          contains the pivot indices from the factorization a = l*u
    **          of the original matrix a.
    **
    **          if fact = 'e', then ipiv is an output argument and on exit
    **          contains the pivot indices from the factorization a = l*u
    **          of the equilibrated matrix a.
    **
    **  equed   (input or output) char
    **          specifies the form of equilibration that was done.
    **          = 'n':  no equilibration (always true if fact = 'n').
    **          = 'r':  row equilibration, i.e., a has been premultiplied by
    **                  diag(r).
    **          = 'c':  column equilibration, i.e., a has been postmultiplied
    **                  by diag(c).
    **          = 'b':  both row and column equilibration, i.e., a has been
    **                  replaced by diag(r) * a * diag(c).
    **          equed is an input argument if fact = 'f'; otherwise, it is an
    **          output argument.
    **
    **  r       (input or output) BASE DATA TYPE array, dimension (n)
    **          the row scale factors for a.  if equed = 'r' or 'b', a is
    **          multiplied on the left by diag(r); if equed = 'n' or 'c', r
    **          is not accessed.  r is an input argument if fact = 'f';
    **          otherwise, r is an output argument.  if fact = 'f' and
    **          equed = 'r' or 'b', each element of r must be positive.
    **
    **  c       (input or output) BASE DATA TYPE array, dimension (n)
    **          the column scale factors for a.  if equed = 'c' or 'b', a is
    **          multiplied on the right by diag(c); if equed = 'n' or 'r', c
    **          is not accessed.  c is an input argument if fact = 'f';
    **          otherwise, c is an output argument.  if fact = 'f' and
    **          equed = 'c' or 'b', each element of c must be positive.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the right hand side matrix b.
    **          on exit,
    **          if equed = 'n', b is not modified;
    **          if trans = 'n' and equed = 'r' or 'b', b is overwritten by
    **          diag(r)*b;
    **          if trans = 't' or 'c' and equed = 'c' or 'b', b is
    **          overwritten by diag(c)*b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (output) DATA TYPE array, dimension (ldx,nrhs)
    **          if info = 0 or info = n+1, the n-by-nrhs solution matrix x
    **          to the original system of equations.  note that a and b are
    **          modified on exit if equed .ne. 'n', and the solution to the
    **          equilibrated system is inv(diag(c))*x if trans = 'n' and
    **          equed = 'c' or 'b', or inv(diag(r))*x if trans = 't' or 'c'
    **          and equed = 'r' or 'b'.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  rcond   (output) BASE DATA TYPE
    **          the estimate of the reciprocal condition number of the matrix
    **          a after equilibration (if done).  if rcond is less than the
    **          machine precision (in particular, if rcond = 0), the matrix
    **          is singular to WORKing precision.  this condition is
    **          indicated by a return code of info > 0.
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the estimated forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).  the estimate is as reliable as
    **          the estimate for rcond, and is almost always a slight
    **          overestimate of the true error.
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, and i is
    **                <= n:  u(i,i) is exactly zero.  the factorization
    **                       has been completed, but the factor u is exactly
    **                       singular, so the solution and error bounds
    **                       could not be computed. rcond = 0 is returned.
    **                = n+1: u is nonsingular, but rcond is less than machine
    **                       precision, meaning that the matrix is singular
    **                       to WORKing precision.  nevertheless, the
    **                       solution and error bounds are computed because
    **                       there are a number of situations where the
    **                       computed solution can be more accurate than the
    **                       value of rcond would suggest.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void gbsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        float* afb,
        const long int* ldafb,
        long int* ipiv,
        char* equed,
        const float* r,
        const float* c,
        float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void gbsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        float* afb,
        const long int* ldafb,
        long int* ipiv,
        char* equed,
        const float* r,
        const float* c,
        float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void gbsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        double* afb,
        const long int* ldafb,
        long int* ipiv,
        char* equed,
        const double* r,
        const double* c,
        double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void gbsvx(
        const char* fact,
        const char* trans,
        const long int* n,
        const long int* kl,
        const long int* ku,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        double* afb,
        const long int* ldafb,
        long int* ipiv,
        char* equed,
        const double* r,
        const double* c,
        double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sgbsvx.f)
  //    *  WORK    (workspace/output) float array, dimension (3*N)
  //    *          On exit, WORK(1) contains the reciprocal pivot growth
  //    *          factor norm(A)/norm(U). The "max absolute element" norm is
  //    *          used. If WORK(1) is much less than 1, then the stability
  //    *          of the LU factorization of the (equilibrated) matrix A
  //    *          could be poor. This also means that the solution X, condition
  //    *          estimator RCOND, and forward error bound FERR could be
  //    *          unreliable. If factorization fails with 0<INFO<=N, then
  //    *          WORK(1) contains the reciprocal pivot growth factor for the
  //    *          leading INFO columns of A.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBSVX(NAME, T)\
inline T gbsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    long int* ipiv,\
    char* equed,\
    const T* r,\
    const T* c,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw(*n);    \
  w.resizew(3**n);                                                      \
  F77NAME( NAME )(fact, trans, n, kl, ku, nrhs, ab, ldab, afb, ldafb, ipiv, equed, r, c, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getiw(), info); \
  return w.getw()[0]; \
}\
inline T gbsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    long int* ipiv,\
    char* equed,\
    const T* r,\
    const T* c,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   return gbsvx(fact, trans, n, kl, ku, nrhs, ab, ldab, afb, ldafb, ipiv, equed, r, c, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_GBSVX(sgbsvx, float)
    LPP_GBSVX(dgbsvx, double)

#undef LPP_GBSVX


  // The following macro provides the 4 functions 
  /*! fn
   inline void gbsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* afb,
       const long int* ldafb,
       long int* ipiv,
       char* equed,
       const float* r,
       const float* c,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void gbsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* afb,
       const long int* ldafb,
       long int* ipiv,
       char* equed,
       const float* r,
       const float* c,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void gbsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* afb,
       const long int* ldafb,
       long int* ipiv,
       char* equed,
       const double* r,
       const double* c,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void gbsvx(
       const char* fact,
       const char* trans,
       const long int* n,
       const long int* kl,
       const long int* ku,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* afb,
       const long int* ldafb,
       long int* ipiv,
       char* equed,
       const double* r,
       const double* c,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cgbsvx.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace/output) float array, dimension (N)
  //    *          On exit, RWORK(1) contains the reciprocal pivot growth
  //    *          factor norm(A)/norm(U). The "max absolute element" norm is
  //    *          used. If RWORK(1) is much less than 1, then the stability
  //    *          of the LU factorization of the (equilibrated) matrix A
  //    *          could be poor. This also means that the solution X, condition
  //    *          estimator RCOND, and forward error bound FERR could be
  //    *          unreliable. If factorization fails with 0<INFO<=N, then
  //    *          RWORK(1) contains the reciprocal pivot growth factor for the
  //    *          leading INFO columns of A.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GBSVX(NAME, T, TBASE)\
inline TBASE gbsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    long int* ipiv,\
    char* equed,\
    const TBASE* r,\
    const TBASE* c,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(*n);\
    w.resizew(2**n);\
    F77NAME( NAME )(fact, trans, n, kl, ku, nrhs, ab, ldab, afb, ldafb, ipiv, equed, r, c, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getrw(), info);\
  return w.getrw()[0]; \
}\
inline TBASE gbsvx(\
    const char* fact,\
    const char* trans,\
    const long int* n,\
    const long int* kl,\
    const long int* ku,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    long int* ipiv,\
    char* equed,\
    const TBASE* r,\
    const TBASE* c,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   return gbsvx(fact, trans, n, kl, ku, nrhs, ab, ldab, afb, ldafb, ipiv, equed, r, c, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_GBSVX(cgbsvx, std::complex<float>, float)
    LPP_GBSVX(zgbsvx, std::complex<double>, double)

#undef LPP_GBSVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of gbsvx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
