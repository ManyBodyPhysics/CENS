#ifndef __PROJECT__LPP__FILE__TGSY2_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGSY2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgsy2_itf.hh C++ interface to LAPACK (s,d,c,z)tgsy2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgsy2_itf.hh
    (excerpt adapted from xtgsy2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgsy2 solves the generalized sylvester equation
    **
    **              a * r - l * b = scale *   c               (1)
    **              d * r - l * e = scale * f
    **
    **  using level 1 and 2 blas, where r and l are unknown m-by-n matrices,
    **  (a, d), (b, e) and (c, f) are given matrix pairs of size m-by-m,
    **  n-by-n and m-by-n, respectively. a, b, d and e are upper triangular
    **  (i.e., (a,d) and (b,e) in generalized schur form).
    **
    **  the solution (r, l) overwrites (c, f). 0 <= scale <= 1 is an output
    **  scaling factor chosen to avoid overflow.
    **
    **  in matrix notation solving equation (1) corresponds to solve
    **  zx = scale * b, where z is defined as
    **
    **         z = [ kron(in, a)  -kron(b', im) ]             (2)
    **             [ kron(in, d)  -kron(e', im) ],
    **
    **  ik is the identity matrix of size k and x' is the transpose of x.
    **  kron(x, y) is the kronecker product between the matrices x and y.
    **
    **  if trans = 'c', y in the conjugate transposed system z'y = scale*b
    **  is solved for, which is equivalent to solve for r and l in
    **
    **              a' * r  + d' * l   = scale *  c           (3)
    **              r  * b' + l  * e'  = scale * -f
    **
    **  this case is used to compute an estimate of dif[(a, d), (b, e)] =
    **  = sigma_min(z) using reverse communicaton with clacon.
    **
    **  xtgsy2 also (ijob >= 1) contributes to the computation in ctgsyl
    **  of an upper bound on the separation between to matrix pairs. then
    **  the input (a, d), (b, e) are sub-pencils of two matrix pairs in
    **  ctgsyl.
    **
    **  arguments
    **  =========
    **
    **  trans   (input) character
    **          = 'n', solve the generalized sylvester equation (1).
    **          = 't': solve the 'transposed' system (3).
    **
    **  ijob    (input) long int
    **          specifies what kind of functionality to be performed.
    **          =0: solve (1) only.
    **          =1: a contribution from this subsystem to a frobenius
    **              norm-based estimate of the separation between two matrix
    **              pairs is computed. (look ahead strategy is used).
    **          =2: a contribution from this subsystem to a frobenius
    **              norm-based estimate of the separation between two matrix
    **              pairs is computed. (sgecon on sub-systems is used.)
    **          not referenced if trans = 't'.
    **
    **  m       (input) long int
    **          on entry, m specifies the order of a and d, and the row
    **          dimension of c, f, r and l.
    **
    **  n       (input) long int
    **          on entry, n specifies the order of b and e, and the column
    **          dimension of c, f, r and l.
    **
    **  a       (input) DATA TYPE array, dimension (lda, m)
    **          on entry, a contains an upper triangular matrix.
    **
    **  lda     (input) long int
    **          the leading dimension of the matrix a. lda >= max(1, m).
    **
    **  b       (input) DATA TYPE array, dimension (ldb, n)
    **          on entry, b contains an upper triangular matrix.
    **
    **  ldb     (input) long int
    **          the leading dimension of the matrix b. ldb >= max(1, n).
    **
    **  c       (input/ output) DATA TYPE array, dimension (ldc, n)
    **          on entry, c contains the right-hand-side of the first matrix
    **          equation in (1).
    **          on exit, if ijob = 0, c has been overwritten by the solution
    **          r.
    **
    **  ldc     (input) long int
    **          the leading dimension of the matrix c. ldc >= max(1, m).
    **
    **  d       (input) DATA TYPE array, dimension (ldd, m)
    **          on entry, d contains an upper triangular matrix.
    **
    **  ldd     (input) long int
    **          the leading dimension of the matrix d. ldd >= max(1, m).
    **
    **  e       (input) DATA TYPE array, dimension (lde, n)
    **          on entry, e contains an upper triangular matrix.
    **
    **  lde     (input) long int
    **          the leading dimension of the matrix e. lde >= max(1, n).
    **
    **  f       (input/ output) DATA TYPE array, dimension (ldf, n)
    **          on entry, f contains the right-hand-side of the second matrix
    **          equation in (1).
    **          on exit, if ijob = 0, f has been overwritten by the solution
    **          l.
    **
    **  ldf     (input) long int
    **          the leading dimension of the matrix f. ldf >= max(1, m).
    **
    **  scale   (output) BASE DATA TYPE
    **          on exit, 0 <= scale <= 1. if 0 < scale < 1, the solutions
    **          r and l (c and f on entry) will hold the solutions to a
    **          slightly perturbed system but the input matrices a, b, d and
    **          e have not been changed. if scale = 0, r and l will hold the
    **          solutions to the homogeneous system with c = f = 0.
    **          normally, scale = 1.
    **
    **  rdsum   (input/output) BASE DATA TYPE
    **          on entry, the sum of squares of computed contributions to
    **          the dif-estimate under computation by ctgsyl, where the
    **          scaling factor rdscal (see below) has been factored out.
    **          on exit, the corresponding sum of squares updated with the
    **          contributions from the current sub-system.
    **          if trans = 't' rdsum is not touched.
    **          note: rdsum only makes sense when xtgsy2 is called by
    **          ctgsyl.
    **
    **  rdscal  (input/output) BASE DATA TYPE
    **          on entry, scaling factor used to prevent overflow in rdsum.
    **          on exit, rdscal is updated w.r.t. the current contributions
    **          in rdsum.
    **          if trans = 't', rdscal is not touched.
    **          note: rdscal only makes sense when xtgsy2 is called by
    **          ctgsyl.
    **
    **  info    (output) long int
    **          on exit, if info is set to
    **            =0: successful exit
    **            <0: if info = -i, input argument number i is illegal.
    **            >0: the matrix pairs (a, d) and (b, e) have common or very
    **                close eigenvalues.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsy2(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        const float* d,
        const long int* ldd,
        const float* e,
        const long int* lde,
        float* f,
        const long int* ldf,
        float* scale,
        float* rdsum,
        float* rdscal,
        long int* pq,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgsy2(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* c,
        const long int* ldc,
        const float* d,
        const long int* ldd,
        const float* e,
        const long int* lde,
        float* f,
        const long int* ldf,
        float* scale,
        float* rdsum,
        float* rdscal,
        long int* pq,
        long int* info)
  */
  /*! fn
   inline void tgsy2(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        const double* d,
        const long int* ldd,
        const double* e,
        const long int* lde,
        double* f,
        const long int* ldf,
        double* scale,
        double* rdsum,
        double* rdscal,
        long int* pq,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgsy2(
        const char* trans,
        const long int* ijob,
        const long int* m,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* c,
        const long int* ldc,
        const double* d,
        const long int* ldd,
        const double* e,
        const long int* lde,
        double* f,
        const long int* ldf,
        double* scale,
        double* rdsum,
        double* rdscal,
        long int* pq,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgsy2.f)
  //    *  IWORK   (workspace) long int array, dimension (M+N+2)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSY2(NAME, T)\
inline void tgsy2(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    T* scale,\
    T* rdsum,\
    T* rdscal,\
    long int* pq,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*m)+(*n)+2);\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, rdsum, rdscal, w.getiw(), pq, info);\
}\
inline void tgsy2(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    T* scale,\
    T* rdsum,\
    T* rdscal,\
    long int* pq,\
    long int* info)\
{\
   workspace<T> w;\
   tgsy2(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, rdsum, rdscal, pq, info, w);\
}\

    LPP_TGSY2(stgsy2, float)
    LPP_TGSY2(dtgsy2, double)

#undef LPP_TGSY2


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgsy2(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       const std::complex<float>* d,
       const long int* ldd,
       const std::complex<float>* e,
       const long int* lde,
       std::complex<float>* f,
       const long int* ldf,
       float* scale,
       float* rdsum,
       float* rdscal,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgsy2(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* c,
       const long int* ldc,
       const std::complex<float>* d,
       const long int* ldd,
       const std::complex<float>* e,
       const long int* lde,
       std::complex<float>* f,
       const long int* ldf,
       float* scale,
       float* rdsum,
       float* rdscal,
       long int* info)
  */
  /*! fn
   inline void tgsy2(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       const std::complex<double>* d,
       const long int* ldd,
       const std::complex<double>* e,
       const long int* lde,
       std::complex<double>* f,
       const long int* ldf,
       double* scale,
       double* rdsum,
       double* rdscal,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgsy2(
       const char* trans,
       const long int* ijob,
       const long int* m,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* c,
       const long int* ldc,
       const std::complex<double>* d,
       const long int* ldd,
       const std::complex<double>* e,
       const long int* lde,
       std::complex<double>* f,
       const long int* ldf,
       double* scale,
       double* rdsum,
       double* rdscal,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgsy2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGSY2(NAME, T, TBASE)\
inline void tgsy2(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    TBASE* scale,\
    TBASE* rdsum,\
    TBASE* rdscal,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, rdsum, rdscal, info);\
}\
inline void tgsy2(\
    const char* trans,\
    const long int* ijob,\
    const long int* m,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* c,\
    const long int* ldc,\
    const T* d,\
    const long int* ldd,\
    const T* e,\
    const long int* lde,\
    T* f,\
    const long int* ldf,\
    TBASE* scale,\
    TBASE* rdsum,\
    TBASE* rdscal,\
    long int* info)\
{\
   workspace<T> w;\
   tgsy2(trans, ijob, m, n, a, lda, b, ldb, c, ldc, d, ldd, e, lde, f, ldf, scale, rdsum, rdscal, info, w);\
}\

    LPP_TGSY2(ctgsy2, std::complex<float>, float)
    LPP_TGSY2(ztgsy2, std::complex<double>, double)

#undef LPP_TGSY2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgsy2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
