#ifndef __PROJECT__LPP__FILE__TGEXC_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGEXC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgexc_itf.hh C++ interface to LAPACK (c,d,c,z)tgexc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgexc_itf.hh
    (excerpt adapted from xtgexc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgexc reorders the generalized schur decomposition of a DATA TYPE
    **  matrix pair (a,b), using an unitary equivalence transformation
    **  (a, b) := q * (a, b) * z', so that the diagonal block of (a, b) with
    **  row index ifst is moved to row ilst.
    **
    **  (a, b) must be in generalized schur canonical form, that is, a and
    **  b are both upper triangular.
    **
    **  optionally, the matrices q and z of generalized schur vectors are
    **  updated.
    **
    **         q(in) * a(in) * z(in)' = q(out) * a(out) * z(out)'
    **         q(in) * b(in) * z(in)' = q(out) * b(out) * z(out)'
    **
    **  arguments
    **  =========
    **
    **  wantq   (input) logical
    **          .true. : update the left transformation matrix q;
    **          .false.: do not update q.
    **
    **  wantz   (input) logical
    **          .true. : update the right transformation matrix z;
    **          .false.: do not update z.
    **
    **  n       (input) long int
    **          the order of the matrices a and b. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the upper triangular matrix a in the pair (a, b).
    **          on exit, the updated matrix a.
    **
    **  lda     (input)  long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,n)
    **          on entry, the upper triangular matrix b in the pair (a, b).
    **          on exit, the updated matrix b.
    **
    **  ldb     (input)  long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  q       (input/output) DATA TYPE array, dimension (ldz,n)
    **          on entry, if wantq = .true., the unitary matrix q.
    **          on exit, the updated matrix q.
    **          if wantq = .false., q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q. ldq >= 1;
    **          if wantq = .true., ldq >= n.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          on entry, if wantz = .true., the unitary matrix z.
    **          on exit, the updated matrix z.
    **          if wantz = .false., z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z. ldz >= 1;
    **          if wantz = .true., ldz >= n.
    **
    **  ifst    (input/output) long int
    **  ilst    (input/output) long int
    **          specify the reordering of the diagonal blocks of (a, b).
    **          the block with row index ifst is moved to row ilst, by a
    **          sequence of swapping between adjacent blocks.
    **
    **  info    (output) long int
    **           =0:  successful exit.
    **           <0:  if info = -i, the i-th argument had an illegal value.
    **           =1:  the transformed matrix pair (a, b) would be too far
    **                from generalized schur form; the problem is ill-
    **                conditioned. (a, b) may have been partially reordered,
    **                and ilst points to the first row of the current
    **                position of the block being moved.
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  [1] b. kagstrom; a direct method for reordering eigenvalues in the
    **      generalized BASE DATA TYPE schur form of a regular matrix pair (a, b), in
    **      m.s. moonen et al (eds), linear algebra for large scale and
    **      BASE DATA TYPE-time applications, kluwer academic publ. 1993, pp 195-218.
    **
    **  [2] b. kagstrom and p. poromaa; computing eigenspaces with specified
    **      eigenvalues of a regular matrix pair (a, b) and condition
    **      estimation: theory, algorithms and software, report
    **      uminf - 94.04, department of computing science, umea university,
    **      s-901 87 umea, sweden, 1994. also as lapack WORKing note 87.
    **      to appear in numerical algorithms, 1996.
    **
    **  [3] b. kagstrom and p. poromaa, lapack-style algorithms and software
    **      for solving the generalized sylvester equation and estimating the
    **      separation between regular matrix pairs, report uminf - 93.23,
    **      department of computing science, umea university, s-901 87 umea,
    **      sweden, december 1993, revised april 1994, also as lapack WORKing
    **      note 75. to appear in acm trans. on math. software, vol 22, no 1,
    **      1996.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgexc(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* ifst,
        long int* ilst,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgexc(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        long int* ifst,
        long int* ilst,
        long int* info)
  */
  /*! fn
   inline void tgexc(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* ifst,
        long int* ilst,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgexc(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        long int* ifst,
        long int* ilst,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgexc.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= 4*N + 16.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEXC(NAME, T)\
inline void tgexc(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* ifst,\
    long int* ilst,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, ifst, ilst, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, ifst, ilst, w.getw(), &w.neededsize(), info);\
}\
inline void tgexc(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* ifst,\
    long int* ilst,\
    long int* info)\
{\
   workspace<T> w;\
   tgexc(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, ifst, ilst, info, w);\
}\

    LPP_TGEXC(stgexc, float)
    LPP_TGEXC(dtgexc, double)

#undef LPP_TGEXC


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgexc(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* ifst,
       long int* ilst,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgexc(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       long int* ifst,
       long int* ilst,
       long int* info)
  */
  /*! fn
   inline void tgexc(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* ifst,
       long int* ilst,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgexc(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       long int* ifst,
       long int* ilst,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgexc.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEXC(NAME, T, TBASE)\
inline void tgexc(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* ifst,\
    long int* ilst,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, ifst, ilst, info);\
}\
inline void tgexc(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    long int* ifst,\
    long int* ilst,\
    long int* info)\
{\
   workspace<T> w;\
   tgexc(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, ifst, ilst, info, w);\
}\

    LPP_TGEXC(ctgexc, std::complex<float>,  float)
    LPP_TGEXC(ztgexc, std::complex<double>, double)

#undef LPP_TGEXC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgexc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
