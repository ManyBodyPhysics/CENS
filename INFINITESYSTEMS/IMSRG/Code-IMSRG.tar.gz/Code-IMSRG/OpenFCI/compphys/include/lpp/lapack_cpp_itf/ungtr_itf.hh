#ifndef __PROJECT__LPP__FILE__UNGTR_HH__INCLUDED
#define __PROJECT__LPP__FILE__UNGTR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ungtr_itf.hh C++ interface to LAPACK (c,d,c,z)ungtr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ungtr_itf.hh
    (excerpt adapted from xungtr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xungtr generates a DATA TYPE unitary matrix q which is defined as the
    **  product of n-1 elementary reflectors of order n, as returned by
    **  chetrd:
    **
    **  if uplo = 'u', q = h(n-1) . . . h(2) h(1),
    **
    **  if uplo = 'l', q = h(1) h(2) . . . h(n-1).
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u': upper triangle of a contains elementary reflectors
    **                 from chetrd;
    **          = 'l': lower triangle of a contains elementary reflectors
    **                 from chetrd.
    **
    **  n       (input) long int
    **          the order of the matrix q. n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the vectors which define the elementary reflectors,
    **          as returned by chetrd.
    **          on exit, the n-by-n unitary matrix q.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= n.
    **
    **  tau     (input) DATA TYPE array, dimension (n-1)
    **          tau(i) must contain the scalar factor of the elementary
    **          reflector h(i), as returned by chetrd.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ungtr(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* tau,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ungtr(
       const char* uplo,
       const long int* n,
       std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* tau,
       long int* info)
  */
  /*! fn
   inline void ungtr(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* tau,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ungtr(
       const char* uplo,
       const long int* n,
       std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* tau,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cungtr.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= N-1.
  //    *          For optimum performance LWORK >= (N-1)*NB, where NB is
  //    *          the optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_UNGTR(NAME, T, TBASE)\
inline void ungtr(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, tau, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(uplo, n, a, lda, tau, w.getw(), &w.neededsize(), info);\
}\
inline void ungtr(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   ungtr(uplo, n, a, lda, tau, info, w);\
}\

    LPP_UNGTR(cungtr, std::complex<float>,  float)
    LPP_UNGTR(zungtr, std::complex<double>, double)

#undef LPP_UNGTR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ungtr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
