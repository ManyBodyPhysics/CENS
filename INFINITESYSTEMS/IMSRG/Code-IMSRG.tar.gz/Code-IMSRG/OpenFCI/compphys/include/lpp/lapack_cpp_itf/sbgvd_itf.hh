#ifndef __PROJECT__LPP__FILE__SBGVD_HH__INCLUDED
#define __PROJECT__LPP__FILE__SBGVD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sbgvd_itf.hh C++ interface to LAPACK (s,d,c,z)sbgvd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sbgvd_itf.hh
    (excerpt adapted from xsbgvd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsbgvd computes all the eigenvalues, and optionally, the eigenvectors
    **  of a BASE DATA TYPE generalized symmetric-definite banded eigenproblem, of the
    **  form a*x=(lambda)*b*x.  here a and b are assumed to be symmetric and
    **  banded, and b is also positive definite.  if eigenvectors are
    **  desired, it uses a divide and conquer algorithm.
    **
    **  the divide and conquer algorithm makes very mild assumptions about
    **  floating point arithmetic. it will WORK on machines with a guard
    **  digit in add/subtract, or on those binary machines without guard
    **  digits which subtract like the cray x-mp, cray y-mp, cray c-90, or
    **  cray-2. it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangles of a and b are stored;
    **          = 'l':  lower triangles of a and b are stored.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ka      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  ka >= 0.
    **
    **  kb      (input) long int
    **          the number of superdiagonals of the matrix b if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kb >= 0.
    **
    **  ab      (input/output) BASE DATA TYPE array, dimension (ldab, n)
    **          on entry, the upper or lower triangle of the symmetric band
    **          matrix a, stored in the first ka+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(ka+1+i-j,j) = a(i,j) for max(1,j-ka)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+ka).
    **
    **          on exit, the contents of ab are destroyed.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= ka+1.
    **
    **  bb      (input/output) BASE DATA TYPE array, dimension (ldbb, n)
    **          on entry, the upper or lower triangle of the symmetric band
    **          matrix b, stored in the first kb+1 rows of the array.  the
    **          j-th column of b is stored in the j-th column of the array bb
    **          as follows:
    **          if uplo = 'u', bb(ka+1+i-j,j) = b(i,j) for max(1,j-kb)<=i<=j;
    **          if uplo = 'l', bb(1+i-j,j)    = b(i,j) for j<=i<=min(n,j+kb).
    **
    **          on exit, the factor s from the split cholesky factorization
    **          b = s**t*s, as returned by dpbstf.
    **
    **  ldbb    (input) long int
    **          the leading dimension of the array bb.  ldbb >= kb+1.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the eigenvalues in ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, n)
    **          if jobz = 'v', then if info = 0, z contains the matrix z of
    **          eigenvectors, with the i-th column of z holding the
    **          eigenvector associated with w(i).  the eigenvectors are
    **          normalized so z**t*b*z = i.
    **          if jobz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, and i is:
    **             <= n:  the algorithm failed to converge:
    **                    i off-diagonal elements of an intermediate
    **                    tridiagonal form did not converge to zero;
    **             > n:   if info = n + i, for 1 <= i <= n, then dpbstf
    **                    returned info = i: b is not positive definite.
    **                    the factorization of b could not be completed and
    **                    no eigenvalues or eigenvectors were computed.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     mark fahey, department of mathematics, univ. of kentucky, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sbgvd(
        const char* jobz,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        float* ab,
        const long int* ldab,
        float* bb,
        const long int* ldbb,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sbgvd(
        const char* jobz,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        float* ab,
        const long int* ldab,
        float* bb,
        const long int* ldbb,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* info)
  */
  /*! fn
   inline void sbgvd(
        const char* jobz,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        double* ab,
        const long int* ldab,
        double* bb,
        const long int* ldbb,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sbgvd(
        const char* jobz,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        double* ab,
        const long int* ldab,
        double* bb,
        const long int* ldbb,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssbgvd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          If N <= 1,               LWORK >= 1.
  //    *          If JOBZ = 'N' and N > 1, LWORK >= 3*N.
  //    *          If JOBZ = 'V' and N > 1, LWORK >= 1 + 5*N + 2*N**2.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if LIWORK > 0, IWORK(1) returns the optimal LIWORK.
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK.
  //    *          if jobz  = 'n' or n <= 1, lIWORK >= 1.
  //    *          if jobz  = 'v' and n > 1, lIWORK >= 3 + 5*n.
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SBGVD(NAME, T)\
inline void sbgvd(\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    T* bb,\
    const long int* ldbb,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobz, uplo, n, ka, kb, ab, ldab, bb, ldbb, ws, z, ldz, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizeiw(w.neededisize());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobz, uplo, n, ka, kb, ab, ldab, bb, ldbb, ws, z, ldz, w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void sbgvd(\
    const char* jobz,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    T* bb,\
    const long int* ldbb,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* info)\
{\
   workspace<T> w;\
   sbgvd(jobz, uplo, n, ka, kb, ab, ldab, bb, ldbb, ws, z, ldz, info, w);\
}\

    LPP_SBGVD(ssbgvd, float)
    LPP_SBGVD(dsbgvd, double)

#undef LPP_SBGVD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sbgvd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
