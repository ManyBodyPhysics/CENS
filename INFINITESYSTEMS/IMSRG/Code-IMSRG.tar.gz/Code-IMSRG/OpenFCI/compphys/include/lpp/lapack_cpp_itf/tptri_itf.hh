#ifndef __PROJECT__LPP__FILE__TPTRI_HH__INCLUDED
#define __PROJECT__LPP__FILE__TPTRI_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tptri_itf.hh C++ interface to LAPACK (c,d,c,z)tptri
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tptri_itf.hh
    (excerpt adapted from xtptri.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtptri computes the inverse of a DATA TYPE upper or lower triangular
    **  matrix a stored in packed format.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  a is upper triangular;
    **          = 'l':  a is lower triangular.
    **
    **  diag    (input) char
    **          = 'n':  a is non-unit triangular;
    **          = 'u':  a is unit triangular.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangular matrix a, stored
    **          columnwise in a linear array.  the j-th column of a is stored
    **          in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*((2*n-j)/2) = a(i,j) for j<=i<=n.
    **          see below for further details.
    **          on exit, the (triangular) inverse of the original matrix, in
    **          the same packed storage format.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, a(i,i) is exactly zero.  the triangular
    **                matrix is singular and its inverse can not be computed.
    **
    **  further details
    **  ===============
    **
    **  a triangular matrix a can be transferred to packed storage using one
    **  of the following program segments:
    **
    **  uplo = 'u':                      uplo = 'l':
    **
    **        jc = 1                           jc = 1
    **        do 2 j = 1, n                    do 2 j = 1, n
    **           do 1 i = 1, j                    do 1 i = j, n
    **              ap(jc+i-1) = a(i,j)              ap(jc+i-j) = a(i,j)
    **      1    continue                    1    continue
    **           jc = jc + j                      jc = jc + n - j + 1
    **      2 continue                       2 continue
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tptri(
        const char* uplo,
        const char* diag,
        const long int* n,
        float* ap,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tptri(
        const char* uplo,
        const char* diag,
        const long int* n,
        float* ap,
        long int* info)
  */
  /*! fn
   inline void tptri(
        const char* uplo,
        const char* diag,
        const long int* n,
        double* ap,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tptri(
        const char* uplo,
        const char* diag,
        const long int* n,
        double* ap,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stptri.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TPTRI(NAME, T)\
inline void tptri(\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    T* ap,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, diag, n, ap, info);\
}\
inline void tptri(\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    T* ap,\
    long int* info)\
{\
   workspace<T> w;\
   tptri(uplo, diag, n, ap, info, w);\
}\

    LPP_TPTRI(stptri, float)
    LPP_TPTRI(dtptri, double)

#undef LPP_TPTRI


  // The following macro provides the 4 functions 
  /*! fn
   inline void tptri(
       const char* uplo,
       const char* diag,
       const long int* n,
       std::complex<float>* ap,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tptri(
       const char* uplo,
       const char* diag,
       const long int* n,
       std::complex<float>* ap,
       long int* info)
  */
  /*! fn
   inline void tptri(
       const char* uplo,
       const char* diag,
       const long int* n,
       std::complex<double>* ap,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tptri(
       const char* uplo,
       const char* diag,
       const long int* n,
       std::complex<double>* ap,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctptri.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TPTRI(NAME, T, TBASE)\
inline void tptri(\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    T* ap,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, diag, n, ap, info);\
}\
inline void tptri(\
    const char* uplo,\
    const char* diag,\
    const long int* n,\
    T* ap,\
    long int* info)\
{\
   workspace<T> w;\
   tptri(uplo, diag, n, ap, info, w);\
}\

    LPP_TPTRI(ctptri, std::complex<float>,  float)
    LPP_TPTRI(ztptri, std::complex<double>, double)

#undef LPP_TPTRI



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tptri_itf.hh
// /////////////////////////////////////////////////////////////////////////////
