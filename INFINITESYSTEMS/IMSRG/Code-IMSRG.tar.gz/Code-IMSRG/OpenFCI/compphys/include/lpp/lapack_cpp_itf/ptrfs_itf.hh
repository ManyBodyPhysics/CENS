#ifndef __PROJECT__LPP__FILE__PTRFS_HH__INCLUDED
#define __PROJECT__LPP__FILE__PTRFS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ptrfs_itf.hh C++ interface to LAPACK (s,d,c,z)ptrfs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ptrfs_itf.hh
    (excerpt adapted from xptrfs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xptrfs improves the computed solution to a system of linear
    **  equations when the coefficient matrix is hermitian positive definite
    **  and tridiagonal, and provides error bounds and backward error
    **  estimates for the solution.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the superdiagonal or the subdiagonal of the
    **          tridiagonal matrix a is stored and the form of the
    **          factorization:
    **          = 'u':  e is the superdiagonal of a, and a = u**h*d*u;
    **          = 'l':  e is the subdiagonal of a, and a = l*d*l**h.
    **          (the two forms are equivalent if a is BASE DATA TYPE.)
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the n BASE DATA TYPE diagonal elements of the tridiagonal matrix a.
    **
    **  e       (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) off-diagonal elements of the tridiagonal matrix a
    **          (see uplo).
    **
    **  df      (input) BASE DATA TYPE array, dimension (n)
    **          the n diagonal elements of the diagonal matrix d from
    **          the factorization computed by cpttrf.
    **
    **  ef      (input) DATA TYPE array, dimension (n-1)
    **          the (n-1) off-diagonal elements of the unit bidiagonal
    **          factor u or l from the factorization computed by cpttrf
    **          (see uplo).
    **
    **  b       (input) DATA TYPE array, dimension (ldb,nrhs)
    **          the right hand side matrix b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (input/output) DATA TYPE array, dimension (ldx,nrhs)
    **          on entry, the solution matrix x, as computed by cpttrs.
    **          on exit, the improved solution matrix x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  internal parameters
    **  ===================
    **
    **  itmax is the maximum number of steps of iterative refinement.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ptrfs(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        const float* df,
        const float* ef,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ptrfs(
        const long int* n,
        const long int* nrhs,
        const float* d,
        const float* e,
        const float* df,
        const float* ef,
        const float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void ptrfs(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        const double* df,
        const double* ef,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ptrfs(
        const long int* n,
        const long int* nrhs,
        const double* d,
        const double* e,
        const double* df,
        const double* ef,
        const double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sptrfs.f)
  //    *  WORK    (workspace) float array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTRFS(NAME, T)\
inline void ptrfs(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    const T* df,\
    const T* ef,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(2*(*n));\
    F77NAME( NAME )(n, nrhs, d, e, df, ef, b, ldb, x, ldx, ferr, berr, w.getw(), info);\
}\
inline void ptrfs(\
    const long int* n,\
    const long int* nrhs,\
    const T* d,\
    const T* e,\
    const T* df,\
    const T* ef,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   ptrfs(n, nrhs, d, e, df, ef, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_PTRFS(sptrfs, float)
    LPP_PTRFS(dptrfs, double)

#undef LPP_PTRFS


  // The following macro provides the 4 functions 
  /*! fn
   inline void ptrfs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       const float* df,
       const std::complex<float>* ef,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ptrfs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const float* d,
       const std::complex<float>* e,
       const float* df,
       const std::complex<float>* ef,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void ptrfs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       const double* df,
       const std::complex<double>* ef,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ptrfs(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       const double* d,
       const std::complex<double>* e,
       const double* df,
       const std::complex<double>* ef,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cptrfs.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PTRFS(NAME, T, TBASE)\
inline void ptrfs(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    const TBASE* df,\
    const T* ef,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew((*n));\
    F77NAME( NAME )(uplo, n, nrhs, d, e, df, ef, b, ldb, x, ldx, ferr, berr, w.getw(), w.getrw(), info);\
}\
inline void ptrfs(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    const TBASE* d,\
    const T* e,\
    const TBASE* df,\
    const T* ef,\
    const T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   ptrfs(uplo, n, nrhs, d, e, df, ef, b, ldb, x, ldx, ferr, berr, info, w);\
}\

    LPP_PTRFS(cptrfs, std::complex<float>, float)
    LPP_PTRFS(zptrfs, std::complex<double>, double)

#undef LPP_PTRFS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ptrfs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
