#ifndef __PROJECT__LPP__FILE__LAGTS_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAGTS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lagts_itf.hh C++ interface to LAPACK (s,d,c,z)lagts
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lagts_itf.hh
    (excerpt adapted from xlagts.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlagts may be used to solve one of the systems of equations
    **
    **     (t - lambda*i)*x = y   or   (t - lambda*i)'*x = y,
    **
    **  where t is an n by n tridiagonal matrix, for x, following the
    **  factorization of (t - lambda*i) as
    **
    **     (t - lambda*i) = p*l*u ,
    **
    **  by routine dlagtf. the choice of equation to be solved is
    **  controlled by the argument job, and in each case there is an option
    **  to perturb zero or very small diagonal elements of u, this option
    **  being intended for use in applications such as inverse iteration.
    **
    **  arguments
    **  =========
    **
    **  job     (input) long int
    **          specifies the job to be performed by xlagts as follows:
    **          =  1: the equations  (t - lambda*i)x = y  are to be solved,
    **                but diagonal elements of u are not to be perturbed.
    **          = -1: the equations  (t - lambda*i)x = y  are to be solved
    **                and, if overflow would otherwise occur, the diagonal
    **                elements of u are to be perturbed. see argument tol
    **                below.
    **          =  2: the equations  (t - lambda*i)'x = y  are to be solved,
    **                but diagonal elements of u are not to be perturbed.
    **          = -2: the equations  (t - lambda*i)'x = y  are to be solved
    **                and, if overflow would otherwise occur, the diagonal
    **                elements of u are to be perturbed. see argument tol
    **                below.
    **
    **  n       (input) long int
    **          the order of the matrix t.
    **
    **  a       (input) BASE DATA TYPE array, dimension (n)
    **          on entry, a must contain the diagonal elements of u as
    **          returned from dlagtf.
    **
    **  b       (input) BASE DATA TYPE array, dimension (n-1)
    **          on entry, b must contain the first super-diagonal elements of
    **          u as returned from dlagtf.
    **
    **  c       (input) BASE DATA TYPE array, dimension (n-1)
    **          on entry, c must contain the sub-diagonal elements of l as
    **          returned from dlagtf.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n-2)
    **          on entry, d must contain the second super-diagonal elements
    **          of u as returned from dlagtf.
    **
    **  in      (input) long int array, dimension (n)
    **          on entry, in must contain details of the matrix p as returned
    **          from dlagtf.
    **
    **  y       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the right hand side vector y.
    **          on exit, y is overwritten by the solution vector x.
    **
    **  tol     (input/output) BASE DATA TYPE
    **          on entry, with  job .lt. 0, tol should be the minimum
    **          perturbation to be made to very small diagonal elements of u.
    **          tol should normally be chosen as about eps*norm(u), where eps
    **          is the relative machine precision, but if tol is supplied as
    **          non-positive, then it is reset to eps*max( abs( u(i,j) ) ).
    **          if  job .gt. 0  then tol is not referenced.
    **
    **          on exit, tol is changed as described above, only if tol is
    **          non-positive on entry. otherwise tol is unchanged.
    **
    **  info    (output) long int
    **          = 0   : successful exit
    **          .lt. 0: if info = -i, the i-th argument had an illegal value
    **          .gt. 0: overflow would occur when computing the info(th)
    **                  element of the solution vector x. this can only occur
    **                  when job is supplied as positive and either means
    **                  that a diagonal element of u is very small, or that
    **                  the elements of the right-hand side vector y are very
    **                  large.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lagts(
        const long int* job,
        const long int* n,
        const float* a,
        const float* b,
        const float* c,
        const float* d,
        const long int* in,
        float* y,
        float* tol,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lagts(
        const long int* job,
        const long int* n,
        const float* a,
        const float* b,
        const float* c,
        const float* d,
        const long int* in,
        float* y,
        float* tol,
        long int* info)
  */
  /*! fn
   inline void lagts(
        const long int* job,
        const long int* n,
        const double* a,
        const double* b,
        const double* c,
        const double* d,
        const long int* in,
        double* y,
        double* tol,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lagts(
        const long int* job,
        const long int* n,
        const double* a,
        const double* b,
        const double* c,
        const double* d,
        const long int* in,
        double* y,
        double* tol,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slagts.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAGTS(NAME, T)\
inline void lagts(\
    const long int* job,\
    const long int* n,\
    const T* a,\
    const T* b,\
    const T* c,\
    const T* d,\
    const long int* in,\
    T* y,\
    T* tol,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, n, a, b, c, d, in, y, tol, info);\
}\
inline void lagts(\
    const long int* job,\
    const long int* n,\
    const T* a,\
    const T* b,\
    const T* c,\
    const T* d,\
    const long int* in,\
    T* y,\
    T* tol,\
    long int* info)\
{\
   workspace<T> w;\
   lagts(job, n, a, b, c, d, in, y, tol, info, w);\
}\

    LPP_LAGTS(slagts, float)
    LPP_LAGTS(dlagts, double)

#undef LPP_LAGTS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lagts_itf.hh
// /////////////////////////////////////////////////////////////////////////////
