#ifndef __PROJECT__LPP__FILE__LAQPS_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAQPS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laqps_itf.hh C++ interface to LAPACK (c,d,c,z)laqps
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laqps_itf.hh
    (excerpt adapted from xlaqps.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaqps computes a step of qr factorization with column pivoting
    **  of a DATA TYPE m-by-n matrix a by using blas-3.  it tries to factorize
    **  nb columns from a starting from the row offset+1, and updates all
    **  of the matrix with blas-3 xgemm.
    **
    **  in some cases, due to catastrophic cancellations, it cannot
    **  factorize nb columns.  hence, the actual number of factorized
    **  columns is returned in kb.
    **
    **  block a(1:offset,1:n) is accordingly pivoted, but not factorized.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a. m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a. n >= 0
    **
    **  offset  (input) long int
    **          the number of rows of a that have been factorized in
    **          previous steps.
    **
    **  nb      (input) long int
    **          the number of columns to factorize.
    **
    **  kb      (output) long int
    **          the number of columns actually factorized.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the m-by-n matrix a.
    **          on exit, block a(offset+1:m,1:kb) is the triangular
    **          factor obtained and block a(1:offset,1:n) has been
    **          accordingly pivoted, but no factorized.
    **          the rest of the matrix, block a(offset+1:m,kb+1:n) has
    **          been updated.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a. lda >= max(1,m).
    **
    **  jpvt    (input/output) long int array, dimension (n)
    **          jpvt(i) = k <==> column k of the full matrix a has been
    **          permuted into position i in ap.
    **
    **  tau     (output) DATA TYPE array, dimension (kb)
    **          the scalar factors of the elementary reflectors.
    **
    **  vn1     (input/output) BASE DATA TYPE array, dimension (n)
    **          the vector with the partial column norms.
    **
    **  vn2     (input/output) BASE DATA TYPE array, dimension (n)
    **          the vector with the exact column norms.
    **
    **  auxv    (input/output) DATA TYPE array, dimension (nb)
    **          auxiliar vector.
    **
    **  f       (input/output) DATA TYPE array, dimension (ldf,nb)
    **          matrix f' = l*y'*a.
    **
    **  ldf     (input) long int
    **          the leading dimension of the array f. ldf >= max(1,n).
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    g. quintana-orti, depto. de informatica, universidad jaime i, spain
    **    x. sun, computer science dept., duke university, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laqps(
        const long int* m,
        const long int* n,
        const long int* offset,
        const long int* nb,
        long int* kb,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        float* vn1,
        float* vn2,
        float* auxv,
        const float* f,
        const long int* ldf,
        workspace<float> & w)
  */
  /*! fn
   inline void laqps(
        const long int* m,
        const long int* n,
        const long int* offset,
        const long int* nb,
        long int* kb,
        float* a,
        const long int* lda,
        long int* jpvt,
        float* tau,
        float* vn1,
        float* vn2,
        float* auxv,
        const float* f,
        const long int* ldf)
  */
  /*! fn
   inline void laqps(
        const long int* m,
        const long int* n,
        const long int* offset,
        const long int* nb,
        long int* kb,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        double* vn1,
        double* vn2,
        double* auxv,
        const double* f,
        const long int* ldf,
        workspace<double> & w)
  */
  /*! fn
   inline void laqps(
        const long int* m,
        const long int* n,
        const long int* offset,
        const long int* nb,
        long int* kb,
        double* a,
        const long int* lda,
        long int* jpvt,
        double* tau,
        double* vn1,
        double* vn2,
        double* auxv,
        const double* f,
        const long int* ldf)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaqps.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQPS(NAME, T)\
inline void laqps(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    T* vn1,\
    T* vn2,\
    T* auxv,\
    const T* f,\
    const long int* ldf,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, offset, nb, kb, a, lda, jpvt, tau, vn1, vn2, auxv, f, ldf);\
}\
inline void laqps(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    T* vn1,\
    T* vn2,\
    T* auxv,\
    const T* f,\
    const long int* ldf)\
{\
   workspace<T> w;\
   laqps(m, n, offset, nb, kb, a, lda, jpvt, tau, vn1, vn2, auxv, f, ldf, w);\
}\

    LPP_LAQPS(slaqps, float)
    LPP_LAQPS(dlaqps, double)

#undef LPP_LAQPS


  // The following macro provides the 4 functions 
  /*! fn
   inline void laqps(
       const long int* m,
       const long int* n,
       const long int* offset,
       const long int* nb,
       long int* kb,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       float* vn1,
       float* vn2,
       std::complex<float>* auxv,
       const std::complex<float>* f,
       const long int* ldf,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void laqps(
       const long int* m,
       const long int* n,
       const long int* offset,
       const long int* nb,
       long int* kb,
       std::complex<float>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<float>* tau,
       float* vn1,
       float* vn2,
       std::complex<float>* auxv,
       const std::complex<float>* f,
       const long int* ldf)
  */
  /*! fn
   inline void laqps(
       const long int* m,
       const long int* n,
       const long int* offset,
       const long int* nb,
       long int* kb,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       double* vn1,
       double* vn2,
       std::complex<double>* auxv,
       const std::complex<double>* f,
       const long int* ldf,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void laqps(
       const long int* m,
       const long int* n,
       const long int* offset,
       const long int* nb,
       long int* kb,
       std::complex<double>* a,
       const long int* lda,
       long int* jpvt,
       std::complex<double>* tau,
       double* vn1,
       double* vn2,
       std::complex<double>* auxv,
       const std::complex<double>* f,
       const long int* ldf)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from claqps.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAQPS(NAME, T, TBASE)\
inline void laqps(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    TBASE* vn1,\
    TBASE* vn2,\
    T* auxv,\
    const T* f,\
    const long int* ldf,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(m, n, offset, nb, kb, a, lda, jpvt, tau, vn1, vn2, auxv, f, ldf);\
}\
inline void laqps(\
    const long int* m,\
    const long int* n,\
    const long int* offset,\
    const long int* nb,\
    long int* kb,\
    T* a,\
    const long int* lda,\
    long int* jpvt,\
    T* tau,\
    TBASE* vn1,\
    TBASE* vn2,\
    T* auxv,\
    const T* f,\
    const long int* ldf)\
{\
   workspace<T> w;\
   laqps(m, n, offset, nb, kb, a, lda, jpvt, tau, vn1, vn2, auxv, f, ldf, w);\
}\

    LPP_LAQPS(claqps, std::complex<float>,  float)
    LPP_LAQPS(zlaqps, std::complex<double>, double)

#undef LPP_LAQPS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laqps_itf.hh
// /////////////////////////////////////////////////////////////////////////////
