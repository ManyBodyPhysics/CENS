#ifndef __PROJECT__LPP__FILE__LASD0_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD0_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd0_itf.hh C++ interface to LAPACK (s,d,c,z)lasd0
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd0_itf.hh
    (excerpt adapted from xlasd0.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  using a divide and conquer approach, xlasd0 computes the singular
    **  value decomposition (svd) of a BASE DATA TYPE upper bidiagonal n-by-m
    **  matrix b with diagonal d and offdiagonal e, where m = n + sqre.
    **  the algorithm computes orthogonal matrices u and vt such that
    **  b = u * s * vt. the singular values s are overwritten on d.
    **
    **  a related subroutine, dlasda, computes only the singular values,
    **  and optionally, the singular vectors in compact form.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         on entry, the row dimension of the upper bidiagonal matrix.
    **         this is also the dimension of the main diagonal array d.
    **
    **  sqre   (input) long int
    **         specifies the column dimension of the bidiagonal matrix.
    **         = 0: the bidiagonal matrix has column dimension m = n;
    **         = 1: the bidiagonal matrix has column dimension m = n+1;
    **
    **  d      (input/output) BASE DATA TYPE array, dimension (n)
    **         on entry d contains the main diagonal of the bidiagonal
    **         matrix.
    **         on exit d, if info = 0, contains its singular values.
    **
    **  e      (input) BASE DATA TYPE array, dimension (m-1)
    **         contains the subdiagonal entries of the bidiagonal matrix.
    **         on exit, e has been destroyed.
    **
    **  u      (output) BASE DATA TYPE array, dimension at least (ldq, n)
    **         on exit, u contains the left singular vectors.
    **
    **  ldu    (input) long int
    **         on entry, leading dimension of u.
    **
    **  vt     (output) BASE DATA TYPE array, dimension at least (ldvt, m)
    **         on exit, vt' contains the right singular vectors.
    **
    **  ldvt   (input) long int
    **         on entry, leading dimension of vt.
    **
    **  smlsiz (input) long int
    **         on entry, maximum size of the subproblems at the
    **         bottom of the computation tree.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd0(
        const long int* n,
        const long int* sqre,
        float* d,
        const float* e,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        const long int* smlsiz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd0(
        const long int* n,
        const long int* sqre,
        float* d,
        const float* e,
        float* u,
        const long int* ldu,
        float* vt,
        const long int* ldvt,
        const long int* smlsiz,
        long int* info)
  */
  /*! fn
   inline void lasd0(
        const long int* n,
        const long int* sqre,
        double* d,
        const double* e,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        const long int* smlsiz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd0(
        const long int* n,
        const long int* sqre,
        double* d,
        const double* e,
        double* u,
        const long int* ldu,
        double* vt,
        const long int* ldvt,
        const long int* smlsiz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd0.f)
  //    *  IWORK  (workspace) long int work array. (JTL)
  //    *         Dimension must be at least (8 * N)
  //    *
  //    *  WORK   (workspace) float work array. (JTL)
  //    *         Dimension must be at least (3 * sqre**2 + 2 * sqre)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD0(NAME, T)\
inline void lasd0(\
    const long int* n,\
    const long int* sqre,\
    T* d,\
    const T* e,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    const long int* smlsiz,\
    long int* info,\
    workspace<T> & w)\
{\
  w.resizeiw( ((3 * (*sqre) + 2) * (*sqre)))/*A VERIFIER*/;         \
    w.resizew(8**n)/*A VERIFIER*/;\
    F77NAME( NAME )(n, sqre, d, e, u, ldu, vt, ldvt, smlsiz, w.getiw(), w.getw(), info);\
}\
inline void lasd0(\
    const long int* n,\
    const long int* sqre,\
    T* d,\
    const T* e,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    const long int* ldvt,\
    const long int* smlsiz,\
    long int* info)\
{\
   workspace<T> w;\
   lasd0(n, sqre, d, e, u, ldu, vt, ldvt, smlsiz, info, w);\
}\

    LPP_LASD0(slasd0, float)
    LPP_LASD0(dlasd0, double)

#undef LPP_LASD0



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd0_itf.hh
// /////////////////////////////////////////////////////////////////////////////
