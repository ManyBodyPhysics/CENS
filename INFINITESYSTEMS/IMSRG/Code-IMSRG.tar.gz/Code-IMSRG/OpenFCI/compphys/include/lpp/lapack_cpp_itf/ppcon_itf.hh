#ifndef __PROJECT__LPP__FILE__PPCON_HH__INCLUDED
#define __PROJECT__LPP__FILE__PPCON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ppcon_itf.hh C++ interface to LAPACK (s,d,c,z)ppcon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ppcon_itf.hh
    (excerpt adapted from xppcon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xppcon estimates the reciprocal of the condition number (in the 
    **  1-norm) of a DATA TYPE hermitian positive definite packed matrix using
    **  the cholesky factorization a = u**h*u or a = l*l**h computed by
    **  cpptrf.
    **
    **  an estimate is obtained for norm(inv(a)), and the reciprocal of the
    **  condition number is computed as rcond = 1 / (anorm * norm(inv(a))).
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input) DATA TYPE array, dimension (n*(n+1)/2)
    **          the triangular factor u or l from the cholesky factorization
    **          a = u**h*u or a = l*l**h, packed columnwise in a linear
    **          array.  the j-th column of u or l is stored in the array ap
    **          as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = u(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2n-j)/2) = l(i,j) for j<=i<=n.
    **
    **  anorm   (input) BASE DATA TYPE
    **          the 1-norm (or infinity-norm) of the hermitian matrix a.
    **
    **  rcond   (output) BASE DATA TYPE
    **          the reciprocal of the condition number of the matrix a,
    **          computed as rcond = 1/(anorm * ainvnm), where ainvnm is an
    **          estimate of the 1-norm of inv(a) computed in this routine.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ppcon(
        const char* uplo,
        const long int* n,
        const float* ap,
        const float* anorm,
        float* rcond,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ppcon(
        const char* uplo,
        const long int* n,
        const float* ap,
        const float* anorm,
        float* rcond,
        long int* info)
  */
  /*! fn
   inline void ppcon(
        const char* uplo,
        const long int* n,
        const double* ap,
        const double* anorm,
        double* rcond,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ppcon(
        const char* uplo,
        const long int* n,
        const double* ap,
        const double* anorm,
        double* rcond,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sppcon.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PPCON(NAME, T)\
inline void ppcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const T* anorm,\
    T* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(3*(*n));\
    F77NAME( NAME )(uplo, n, ap, anorm, rcond, w.getw(), w.getiw(), info);\
}\
inline void ppcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const T* anorm,\
    T* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   ppcon(uplo, n, ap, anorm, rcond, info, w);\
}\

    LPP_PPCON(sppcon, float)
    LPP_PPCON(dppcon, double)

#undef LPP_PPCON


  // The following macro provides the 4 functions 
  /*! fn
   inline void ppcon(
       const char* uplo,
       const long int* n,
       const std::complex<float>* ap,
       const float* anorm,
       float* rcond,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ppcon(
       const char* uplo,
       const long int* n,
       const std::complex<float>* ap,
       const float* anorm,
       float* rcond,
       long int* info)
  */
  /*! fn
   inline void ppcon(
       const char* uplo,
       const long int* n,
       const std::complex<double>* ap,
       const double* anorm,
       double* rcond,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ppcon(
       const char* uplo,
       const long int* n,
       const std::complex<double>* ap,
       const double* anorm,
       double* rcond,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cppcon.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PPCON(NAME, T, TBASE)\
inline void ppcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(uplo, n, ap, anorm, rcond, w.getw(), w.getrw(), info);\
}\
inline void ppcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   ppcon(uplo, n, ap, anorm, rcond, info, w);\
}\

    LPP_PPCON(cppcon, std::complex<float>, float)
    LPP_PPCON(zppcon, std::complex<double>, double)

#undef LPP_PPCON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ppcon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
