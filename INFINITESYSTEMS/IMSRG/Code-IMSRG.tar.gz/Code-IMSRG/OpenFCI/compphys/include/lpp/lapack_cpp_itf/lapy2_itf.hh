#ifndef __PROJECT__LPP__FILE__LAPY2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAPY2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lapy2_itf.hh C++ interface to LAPACK (s,d,c,z)lapy2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lapy2_itf.hh
    (excerpt adapted from xlapy2.f file commentaries)
    
    DATA TYPE can mean float, double, complex<float>, complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlapy2 returns sqrt(x**2+y**2), taking care not to cause unnecessary
    **  overflow.
    **
    **  arguments
    **  =========
    **
    **  x       (input) BASE DATA TYPE
    **  y       (input) BASE DATA TYPE
    **          x and y specify the values x and y.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lapy2(
        const float* x,
        const float* y)
  */
  /*! fn
   inline void lapy2(
        const complex < float >* x,
        const complex < float >* y)
  */
  /*! fn
   inline void lapy2(
        const double* x,
        const double* y)
  */
  /*! fn
   inline void lapy2(
        const complex < double >* x,
        const complex < double >* y)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slapy2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAPY2(NAME, T)\
inline T lapy2(\
    const T* x,\
    const T* y)\
{\
    return F77NAME( NAME )(x, y);\
}\


    LPP_LAPY2(slapy2, float)
    LPP_LAPY2(dlapy2, double)

#undef LPP_LAPY2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lapy2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
