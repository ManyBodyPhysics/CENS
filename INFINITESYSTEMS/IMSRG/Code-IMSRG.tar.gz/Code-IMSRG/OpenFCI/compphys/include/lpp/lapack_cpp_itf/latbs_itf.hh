#ifndef __PROJECT__LPP__FILE__LATBS_HH__INCLUDED
#define __PROJECT__LPP__FILE__LATBS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : latbs_itf.hh C++ interface to LAPACK (c,d,c,z)latbs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file latbs_itf.hh
    (excerpt adapted from xlatbs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlatbs solves one of the triangular systems
    **
    **     a * x = s*b,  a**t * x = s*b,  or  a**h * x = s*b,
    **
    **  with scaling to prevent overflow, where a is an upper or lower
    **  triangular band matrix.  here a' denotes the transpose of a, x and b
    **  are n-element vectors, and s is a scaling factor, usually less than
    **  or equal to 1, chosen so that the components of x will be less than
    **  the overflow threshold.  if the unscaled problem will not cause
    **  overflow, the level 2 blas routine ctbsv is called.  if the matrix a
    **  is singular (a(j,j) = 0 for some j), then s is set to 0 and a
    **  non-trivial solution to a*x = 0 is returned.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the matrix a is upper or lower triangular.
    **          = 'u':  upper triangular
    **          = 'l':  lower triangular
    **
    **  trans   (input) char
    **          specifies the operation applied to a.
    **          = 'n':  solve a * x = s*b     (no transpose)
    **          = 't':  solve a**t * x = s*b  (transpose)
    **          = 'c':  solve a**h * x = s*b  (conjugate transpose)
    **
    **  diag    (input) char
    **          specifies whether or not the matrix a is unit triangular.
    **          = 'n':  non-unit triangular
    **          = 'u':  unit triangular
    **
    **  normin  (input) char
    **          specifies whether cnorm has been set or not.
    **          = 'y':  cnorm contains the column norms on entry
    **          = 'n':  cnorm is not set on entry.  on exit, the norms will
    **                  be computed and stored in cnorm.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of subdiagonals or superdiagonals in the
    **          triangular matrix a.  kd >= 0.
    **
    **  ab      (input) DATA TYPE array, dimension (ldab,n)
    **          the upper or lower triangular band matrix a, stored in the
    **          first kd+1 rows of the array. the j-th column of a is stored
    **          in the j-th column of the array ab as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= kd+1.
    **
    **  x       (input/output) DATA TYPE array, dimension (n)
    **          on entry, the right hand side b of the triangular system.
    **          on exit, x is overwritten by the solution vector x.
    **
    **  scale   (output) BASE DATA TYPE
    **          the scaling factor s for the triangular system
    **             a * x = s*b,  a**t * x = s*b,  or  a**h * x = s*b.
    **          if scale = 0, the matrix a is singular or badly scaled, and
    **          the vector x is an exact or approximate solution to a*x = 0.
    **
    **  cnorm   (input or output) BASE DATA TYPE array, dimension (n)
    **
    **          if normin = 'y', cnorm is an input argument and cnorm(j)
    **          contains the norm of the off-diagonal part of the j-th column
    **          of a.  if trans = 'n', cnorm(j) must be greater than or equal
    **          to the infinity-norm, and if trans = 't' or 'c', cnorm(j)
    **          must be greater than or equal to the 1-norm.
    **
    **          if normin = 'n', cnorm is an output argument and cnorm(j)
    **          returns the 1-norm of the offdiagonal part of the j-th column
    **          of a.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -k, the k-th argument had an illegal value
    **
    **  further details
    **  ======= =======
    **
    **  a rough bound on x is computed; if that is less than overflow, ctbsv
    **  is called, otherwise, specific code is used which checks for possible
    **  overflow or divide-by-zero at every operation.
    **
    **  a columnwise scheme is used for solving a*x = b.  the basic algorithm
    **  if a is lower triangular is
    **
    **       x[1:n] := b[1:n]
    **       for j = 1, ..., n
    **            x(j) := x(j) / a(j,j)
    **            x[j+1:n] := x[j+1:n] - x(j) * a[j+1:n,j]
    **       end
    **
    **  define bounds on the components of x after j iterations of the loop:
    **     m(j) = bound on x[1:j]
    **     g(j) = bound on x[j+1:n]
    **  initially, let m(0) = 0 and g(0) = max{x(i), i=1,...,n}.
    **
    **  then for iteration j+1 we have
    **     m(j+1) <= g(j) / | a(j+1,j+1) |
    **     g(j+1) <= g(j) + m(j+1) * | a[j+2:n,j+1] |
    **            <= g(j) ( 1 + cnorm(j+1) / | a(j+1,j+1) | )
    **
    **  where cnorm(j+1) is greater than or equal to the infinity-norm of
    **  column j+1 of a, not counting the diagonal.  hence
    **
    **     g(j) <= g(0) product ( 1 + cnorm(i) / | a(i,i) | )
    **                  1<=i<=j
    **  and
    **
    **     |x(j)| <= ( g(0) / |a(j,j)| ) product ( 1 + cnorm(i) / |a(i,i)| )
    **                                   1<=i< j
    **
    **  since |x(j)| <= m(j), we use the level 2 blas routine ctbsv if the
    **  reciprocal of the largest m(j), j=1,..,n, is larger than
    **  max(underflow, 1/overflow).
    **
    **  the bound on x(j) is also used to determine when a step in the
    **  columnwise method can be performed without fear of overflow.  if
    **  the computed bound is greater than a large constant, x is scaled to
    **  prevent overflow, but if the bound overflows, x is set to 0, x(j) to
    **  1, and scale to 0, and a non-trivial solution to a*x = 0 is found.
    **
    **  similarly, a row-wise scheme is used to solve a**t *x = b  or
    **  a**h *x = b.  the basic algorithm for a upper triangular is
    **
    **       for j = 1, ..., n
    **            x(j) := ( b(j) - a[1:j-1,j]' * x[1:j-1] ) / a(j,j)
    **       end
    **
    **  we simultaneously compute two bounds
    **       g(j) = bound on ( b(i) - a[1:i-1,i]' * x[1:i-1] ), 1<=i<=j
    **       m(j) = bound on x(i), 1<=i<=j
    **
    **  the initial values are g(0) = 0, m(0) = max{b(i), i=1,..,n}, and we
    **  add the constraint g(j) >= g(j-1) and m(j) >= m(j-1) for j >= 1.
    **  then the bound on x(j) is
    **
    **       m(j) <= m(j-1) * ( 1 + cnorm(j) ) / | a(j,j) |
    **
    **            <= m(0) * product ( ( 1 + cnorm(i) ) / |a(i,i)| )
    **                      1<=i<=j
    **
    **  and we can safely call ctbsv if 1/m(n) and 1/g(n) are both greater
    **  than max(underflow, 1/overflow).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void latbs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const char* normin,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* x,
        float* scale,
        float* cnorm,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void latbs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const char* normin,
        const long int* n,
        const long int* kd,
        const float* ab,
        const long int* ldab,
        float* x,
        float* scale,
        float* cnorm,
        long int* info)
  */
  /*! fn
   inline void latbs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const char* normin,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* x,
        double* scale,
        double* cnorm,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void latbs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const char* normin,
        const long int* n,
        const long int* kd,
        const double* ab,
        const long int* ldab,
        double* x,
        double* scale,
        double* cnorm,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slatbs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATBS(NAME, T)\
inline void latbs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const char* normin,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* x,\
    T* scale,\
    T* cnorm,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, trans, diag, normin, n, kd, ab, ldab, x, scale, cnorm, info);\
}\
inline void latbs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const char* normin,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* x,\
    T* scale,\
    T* cnorm,\
    long int* info)\
{\
   workspace<T> w;\
   latbs(uplo, trans, diag, normin, n, kd, ab, ldab, x, scale, cnorm, info, w);\
}\

    LPP_LATBS(slatbs, float)
    LPP_LATBS(dlatbs, double)

#undef LPP_LATBS


  // The following macro provides the 4 functions 
  /*! fn
   inline void latbs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const char* normin,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* x,
       float* scale,
       float* cnorm,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void latbs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const char* normin,
       const long int* n,
       const long int* kd,
       const std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* x,
       float* scale,
       float* cnorm,
       long int* info)
  */
  /*! fn
   inline void latbs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const char* normin,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* x,
       double* scale,
       double* cnorm,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void latbs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const char* normin,
       const long int* n,
       const long int* kd,
       const std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* x,
       double* scale,
       double* cnorm,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clatbs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATBS(NAME, T, TBASE)\
inline void latbs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const char* normin,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* x,\
    TBASE* scale,\
    TBASE* cnorm,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, trans, diag, normin, n, kd, ab, ldab, x, scale, cnorm, info);\
}\
inline void latbs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const char* normin,\
    const long int* n,\
    const long int* kd,\
    const T* ab,\
    const long int* ldab,\
    T* x,\
    TBASE* scale,\
    TBASE* cnorm,\
    long int* info)\
{\
   workspace<T> w;\
   latbs(uplo, trans, diag, normin, n, kd, ab, ldab, x, scale, cnorm, info, w);\
}\

    LPP_LATBS(clatbs, std::complex<float>,  float)
    LPP_LATBS(zlatbs, std::complex<double>, double)

#undef LPP_LATBS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of latbs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
