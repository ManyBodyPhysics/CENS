#ifndef __PROJECT__LPP__FILE__GGBAK_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGBAK_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggbak_itf.hh C++ interface to LAPACK (c,d,c,z)ggbak
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggbak_itf.hh
    (excerpt adapted from xggbak.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggbak forms the right or left eigenvectors of a DATA TYPE generalized
    **  eigenvalue problem a*x = lambda*b*x, by backward transformation on
    **  the computed eigenvectors of the balanced pair of matrices output by
    **  cggbal.
    **
    **  arguments
    **  =========
    **
    **  job     (input) char
    **          specifies the type of backward transformation required:
    **          = 'n':  do nothing, return immediately;
    **          = 'p':  do backward transformation for permutation only;
    **          = 's':  do backward transformation for scaling only;
    **          = 'b':  do backward transformations for both permutation and
    **                  scaling.
    **          job must be the same as the argument job supplied to cggbal.
    **
    **  side    (input) char
    **          = 'r':  v contains right eigenvectors;
    **          = 'l':  v contains left eigenvectors.
    **
    **  n       (input) long int
    **          the number of rows of the matrix v.  n >= 0.
    **
    **  ilo     (input) long int
    **  ihi     (input) long int
    **          the integers ilo and ihi determined by cggbal.
    **          1 <= ilo <= ihi <= n, if n > 0; ilo=1 and ihi=0, if n=0.
    **
    **  lscale  (input) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and/or scaling factors applied
    **          to the left side of a and b, as returned by cggbal.
    **
    **  rscale  (input) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and/or scaling factors applied
    **          to the right side of a and b, as returned by cggbal.
    **
    **  m       (input) long int
    **          the number of columns of the matrix v.  m >= 0.
    **
    **  v       (input/output) DATA TYPE array, dimension (ldv,m)
    **          on entry, the matrix of right or left eigenvectors to be
    **          transformed, as returned by ctgevc.
    **          on exit, v is overwritten by the transformed eigenvectors.
    **
    **  ldv     (input) long int
    **          the leading dimension of the matrix v. ldv >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  see r.c. ward, balancing the generalized eigenvalue problem,
    **                 siam j. sci. stat. comp. 2 (1981), 141-152.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggbak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* lscale,
        const float* rscale,
        const long int* m,
        float* v,
        const long int* ldv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggbak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const float* lscale,
        const float* rscale,
        const long int* m,
        float* v,
        const long int* ldv,
        long int* info)
  */
  /*! fn
   inline void ggbak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* lscale,
        const double* rscale,
        const long int* m,
        double* v,
        const long int* ldv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggbak(
        const char* job,
        const char* side,
        const long int* n,
        const long int* ilo,
        const long int* ihi,
        const double* lscale,
        const double* rscale,
        const long int* m,
        double* v,
        const long int* ldv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggbak.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGBAK(NAME, T)\
inline void ggbak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* lscale,\
    const T* rscale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, side, n, ilo, ihi, lscale, rscale, m, v, ldv, info);\
}\
inline void ggbak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const T* lscale,\
    const T* rscale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info)\
{\
   workspace<T> w;\
   ggbak(job, side, n, ilo, ihi, lscale, rscale, m, v, ldv, info, w);\
}\

    LPP_GGBAK(sggbak, float)
    LPP_GGBAK(dggbak, double)

#undef LPP_GGBAK


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggbak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const float* lscale,
       const float* rscale,
       const long int* m,
       std::complex<float>* v,
       const long int* ldv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggbak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const float* lscale,
       const float* rscale,
       const long int* m,
       std::complex<float>* v,
       const long int* ldv,
       long int* info)
  */
  /*! fn
   inline void ggbak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const double* lscale,
       const double* rscale,
       const long int* m,
       std::complex<double>* v,
       const long int* ldv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggbak(
       const char* job,
       const char* side,
       const long int* n,
       const long int* ilo,
       const long int* ihi,
       const double* lscale,
       const double* rscale,
       const long int* m,
       std::complex<double>* v,
       const long int* ldv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggbak.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGBAK(NAME, T, TBASE)\
inline void ggbak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const TBASE* lscale,\
    const TBASE* rscale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(job, side, n, ilo, ihi, lscale, rscale, m, v, ldv, info);\
}\
inline void ggbak(\
    const char* job,\
    const char* side,\
    const long int* n,\
    const long int* ilo,\
    const long int* ihi,\
    const TBASE* lscale,\
    const TBASE* rscale,\
    const long int* m,\
    T* v,\
    const long int* ldv,\
    long int* info)\
{\
   workspace<T> w;\
   ggbak(job, side, n, ilo, ihi, lscale, rscale, m, v, ldv, info, w);\
}\

    LPP_GGBAK(cggbak, std::complex<float>,  float)
    LPP_GGBAK(zggbak, std::complex<double>, double)

#undef LPP_GGBAK



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggbak_itf.hh
// /////////////////////////////////////////////////////////////////////////////
