#ifndef __PROJECT__LPP__FILE__TRTRS_HH__INCLUDED
#define __PROJECT__LPP__FILE__TRTRS_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : trtrs_itf.hh C++ interface to LAPACK (c,d,c,z)trtrs
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file trtrs_itf.hh
    (excerpt adapted from xtrtrs.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtrtrs solves a triangular system of the form
    **
    **     a * x = b,  a**t * x = b,  or  a**h * x = b,
    **
    **  where a is a triangular matrix of order n, and b is an n-by-nrhs
    **  matrix.  a check is made to verify that a is nonsingular.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  a is upper triangular;
    **          = 'l':  a is lower triangular.
    **
    **  trans   (input) char
    **          specifies the form of the system of equations:
    **          = 'n':  a * x = b     (no transpose)
    **          = 't':  a**t * x = b  (transpose)
    **          = 'c':  a**h * x = b  (conjugate transpose)
    **
    **  diag    (input) char
    **          = 'n':  a is non-unit triangular;
    **          = 'u':  a is unit triangular.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  a       (input) DATA TYPE array, dimension (lda,n)
    **          the triangular matrix a.  if uplo = 'u', the leading n-by-n
    **          upper triangular part of the array a contains the upper
    **          triangular matrix, and the strictly lower triangular part of
    **          a is not referenced.  if uplo = 'l', the leading n-by-n lower
    **          triangular part of the array a contains the lower triangular
    **          matrix, and the strictly upper triangular part of a is not
    **          referenced.  if diag = 'u', the diagonal elements of a are
    **          also not referenced and are assumed to be 1.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the right hand side matrix b.
    **          on exit, if info = 0, the solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, the i-th diagonal element of a is zero,
    **               indicating that the matrix is singular and the solutions
    **               x have not been computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void trtrs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void trtrs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void trtrs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void trtrs(
        const char* uplo,
        const char* trans,
        const char* diag,
        const long int* n,
        const long int* nrhs,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from strtrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRTRS(NAME, T)\
inline void trtrs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, trans, diag, n, nrhs, a, lda, b, ldb, info);\
}\
inline void trtrs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   trtrs(uplo, trans, diag, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_TRTRS(strtrs, float)
    LPP_TRTRS(dtrtrs, double)

#undef LPP_TRTRS


  // The following macro provides the 4 functions 
  /*! fn
   inline void trtrs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void trtrs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void trtrs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void trtrs(
       const char* uplo,
       const char* trans,
       const char* diag,
       const long int* n,
       const long int* nrhs,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctrtrs.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TRTRS(NAME, T, TBASE)\
inline void trtrs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, trans, diag, n, nrhs, a, lda, b, ldb, info);\
}\
inline void trtrs(\
    const char* uplo,\
    const char* trans,\
    const char* diag,\
    const long int* n,\
    const long int* nrhs,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   trtrs(uplo, trans, diag, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_TRTRS(ctrtrs, std::complex<float>,  float)
    LPP_TRTRS(ztrtrs, std::complex<double>, double)

#undef LPP_TRTRS



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of trtrs_itf.hh
// /////////////////////////////////////////////////////////////////////////////
