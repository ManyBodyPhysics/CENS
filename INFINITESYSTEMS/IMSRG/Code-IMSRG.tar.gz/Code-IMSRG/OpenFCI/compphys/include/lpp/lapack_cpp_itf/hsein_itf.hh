#ifndef __PROJECT__LPP__FILE__HSEIN_HH__INCLUDED
#define __PROJECT__LPP__FILE__HSEIN_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hsein_itf.hh C++ interface to LAPACK (s,d,c,z)hsein
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hsein_itf.hh
    (excerpt adapted from xhsein.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhsein uses inverse iteration to find specified right and/or left
    **  eigenvectors of a DATA TYPE upper hessenberg matrix h.
    **
    **  the right eigenvector x and the left eigenvector y of the matrix h
    **  corresponding to an eigenvalue w are defined by:
    **
    **               h * x = w * x,     y**h * h = w * y**h
    **
    **  where y**h denotes the conjugate transpose of the vector y.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'r': compute right eigenvectors only;
    **          = 'l': compute left eigenvectors only;
    **          = 'b': compute both right and left eigenvectors.
    **
    **  eigsrc  (input) char
    **          specifies the source of eigenvalues supplied in w:
    **          = 'q': the eigenvalues were found using chseqr; thus, if
    **                 h has zero subdiagonal elements, and so is
    **                 block-triangular, then the j-th eigenvalue can be
    **                 assumed to be an eigenvalue of the block containing
    **                 the j-th row/column.  this property allows xhsein to
    **                 perform inverse iteration on just one diagonal block.
    **          = 'n': no assumptions are made on the correspondence
    **                 between eigenvalues and diagonal blocks.  in this
    **                 case, xhsein must always perform inverse iteration
    **                 using the whole matrix h.
    **
    **  initv   (input) char
    **          = 'n': no initial vectors are supplied;
    **          = 'u': user-supplied initial vectors are stored in the arrays
    **                 vl and/or vr.
    **
    **  select  (input) logical array, dimension (n)
    **          specifies the eigenvectors to be computed. to select the
    **          eigenvector corresponding to the eigenvalue w(j),
    **          select(j) must be set to .true..
    **
    **  n       (input) long int
    **          the order of the matrix h.  n >= 0.
    **
    **  h       (input) DATA TYPE array, dimension (ldh,n)
    **          the upper hessenberg matrix h.
    **
    **  ldh     (input) long int
    **          the leading dimension of the array h.  ldh >= max(1,n).
    **
    **  w       (input/output) DATA TYPE array, dimension (n)
    **          on entry, the eigenvalues of h.
    **          on exit, the BASE DATA TYPE parts of w may have been altered since
    **          close eigenvalues are perturbed slightly in searching for
    **          independent eigenvectors.
    **
    **  vl      (input/output) DATA TYPE array, dimension (ldvl,mm)
    **          on entry, if initv = 'u' and side = 'l' or 'b', vl must
    **          contain starting vectors for the inverse iteration for the
    **          left eigenvectors; the starting vector for each eigenvector
    **          must be in the same column in which the eigenvector will be
    **          stored.
    **          on exit, if side = 'l' or 'b', the left eigenvectors
    **          specified by select will be stored consecutively in the
    **          columns of vl, in the same order as their eigenvalues.
    **          if side = 'r', vl is not referenced.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the array vl.
    **          ldvl >= max(1,n) if side = 'l' or 'b'; ldvl >= 1 otherwise.
    **
    **  vr      (input/output) DATA TYPE array, dimension (ldvr,mm)
    **          on entry, if initv = 'u' and side = 'r' or 'b', vr must
    **          contain starting vectors for the inverse iteration for the
    **          right eigenvectors; the starting vector for each eigenvector
    **          must be in the same column in which the eigenvector will be
    **          stored.
    **          on exit, if side = 'r' or 'b', the right eigenvectors
    **          specified by select will be stored consecutively in the
    **          columns of vr, in the same order as their eigenvalues.
    **          if side = 'l', vr is not referenced.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the array vr.
    **          ldvr >= max(1,n) if side = 'r' or 'b'; ldvr >= 1 otherwise.
    **
    **  mm      (input) long int
    **          the number of columns in the arrays vl and/or vr. mm >= m.
    **
    **  m       (output) long int
    **          the number of columns in the arrays vl and/or vr required to
    **          store the eigenvectors (= the number of .true. elements in
    **          select).
    **
    **
    **
    **  ifaill  (output) long int array, dimension (mm)
    **          if side = 'l' or 'b', ifaill(i) = j > 0 if the left
    **          eigenvector in the i-th column of vl (corresponding to the
    **          eigenvalue w(j)) failed to converge; ifaill(i) = 0 if the
    **          eigenvector converged satisfactorily.
    **          if side = 'r', ifaill is not referenced.
    **
    **  ifailr  (output) long int array, dimension (mm)
    **          if side = 'r' or 'b', ifailr(i) = j > 0 if the right
    **          eigenvector in the i-th column of vr (corresponding to the
    **          eigenvalue w(j)) failed to converge; ifailr(i) = 0 if the
    **          eigenvector converged satisfactorily.
    **          if side = 'l', ifailr is not referenced.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, i is the number of eigenvectors which
    **                failed to converge; see ifaill and ifailr for further
    **                details.
    **
    **  further details
    **  ===============
    **
    **  each eigenvector is normalized so that the element of largest
    **  magnitude has magnitude 1; here the magnitude of a DATA TYPE number
    **  (x,y) is taken to be |x|+|y|.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hsein(
        const char* side,
        const char* eigsrc,
        const char* initv,
        long int* select,
        const long int* n,
        const float* h,
        const long int* ldh,
        float* wr,
        const float* wi,
        float* vl,
        const long int* ldvl,
        float* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* ifaill,
        long int* ifailr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void hsein(
        const char* side,
        const char* eigsrc,
        const char* initv,
        long int* select,
        const long int* n,
        const float* h,
        const long int* ldh,
        float* wr,
        const float* wi,
        float* vl,
        const long int* ldvl,
        float* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* ifaill,
        long int* ifailr,
        long int* info)
  */
  /*! fn
   inline void hsein(
        const char* side,
        const char* eigsrc,
        const char* initv,
        long int* select,
        const long int* n,
        const double* h,
        const long int* ldh,
        double* wr,
        const double* wi,
        double* vl,
        const long int* ldvl,
        double* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* ifaill,
        long int* ifailr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void hsein(
        const char* side,
        const char* eigsrc,
        const char* initv,
        long int* select,
        const long int* n,
        const double* h,
        const long int* ldh,
        double* wr,
        const double* wi,
        double* vl,
        const long int* ldvl,
        double* vr,
        const long int* ldvr,
        const long int* mm,
        const long int* m,
        long int* ifaill,
        long int* ifailr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from shsein.f)
  //    *  WORK    (workspace) float array, dimension ((N+2)*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HSEIN(NAME, T)\
inline void hsein(\
    const char* side,\
    const char* eigsrc,\
    const char* initv,\
    long int* select,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    const T* wi,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* ifaill,\
    long int* ifailr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(((*n)+2)*(*n));\
    F77NAME( NAME )(side, eigsrc, initv, select, n, h, ldh, wr, wi, vl, ldvl, vr, ldvr, mm, m, w.getw(), ifaill, ifailr, info);\
}\
inline void hsein(\
    const char* side,\
    const char* eigsrc,\
    const char* initv,\
    long int* select,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    T* wr,\
    const T* wi,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* ifaill,\
    long int* ifailr,\
    long int* info)\
{\
   workspace<T> w;\
   hsein(side, eigsrc, initv, select, n, h, ldh, wr, wi, vl, ldvl, vr, ldvr, mm, m, ifaill, ifailr, info, w);\
}\

    LPP_HSEIN(shsein, float)
    LPP_HSEIN(dhsein, double)

#undef LPP_HSEIN


  // The following macro provides the 4 functions 
  /*! fn
   inline void hsein(
       const char* side,
       const char* eigsrc,
       const char* initv,
       const long int* select,
       const long int* n,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* ws,
       std::complex<float>* vl,
       const long int* ldvl,
       std::complex<float>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* ifaill,
       long int* ifailr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hsein(
       const char* side,
       const char* eigsrc,
       const char* initv,
       const long int* select,
       const long int* n,
       const std::complex<float>* h,
       const long int* ldh,
       std::complex<float>* ws,
       std::complex<float>* vl,
       const long int* ldvl,
       std::complex<float>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* ifaill,
       long int* ifailr,
       long int* info)
  */
  /*! fn
   inline void hsein(
       const char* side,
       const char* eigsrc,
       const char* initv,
       const long int* select,
       const long int* n,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* ws,
       std::complex<double>* vl,
       const long int* ldvl,
       std::complex<double>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* ifaill,
       long int* ifailr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hsein(
       const char* side,
       const char* eigsrc,
       const char* initv,
       const long int* select,
       const long int* n,
       const std::complex<double>* h,
       const long int* ldh,
       std::complex<double>* ws,
       std::complex<double>* vl,
       const long int* ldvl,
       std::complex<double>* vr,
       const long int* ldvr,
       const long int* mm,
       const long int* m,
       long int* ifaill,
       long int* ifailr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chsein.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HSEIN(NAME, T, TBASE)\
inline void hsein(\
    const char* side,\
    const char* eigsrc,\
    const char* initv,\
    const long int* select,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    T* ws,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* ifaill,\
    long int* ifailr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew((*n)*(*n));\
    F77NAME( NAME )(side, eigsrc, initv, select, n, h, ldh, ws, vl, ldvl, vr, ldvr, mm, m, w.getw(), w.getrw(), ifaill, ifailr, info);\
}\
inline void hsein(\
    const char* side,\
    const char* eigsrc,\
    const char* initv,\
    const long int* select,\
    const long int* n,\
    const T* h,\
    const long int* ldh,\
    T* ws,\
    T* vl,\
    const long int* ldvl,\
    T* vr,\
    const long int* ldvr,\
    const long int* mm,\
    const long int* m,\
    long int* ifaill,\
    long int* ifailr,\
    long int* info)\
{\
   workspace<T> w;\
   hsein(side, eigsrc, initv, select, n, h, ldh, ws, vl, ldvl, vr, ldvr, mm, m, info, ifaill, ifailr, w);\
}\

    LPP_HSEIN(chsein, std::complex<float>, float)
    LPP_HSEIN(zhsein, std::complex<double>, double)

#undef LPP_HSEIN



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hsein_itf.hh
// /////////////////////////////////////////////////////////////////////////////
