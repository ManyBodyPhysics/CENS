#ifndef __PROJECT__LPP__FILE__LATRZ_HH__INCLUDED
#define __PROJECT__LPP__FILE__LATRZ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : latrz_itf.hh C++ interface to LAPACK (s,d,c,z)latrz
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file latrz_itf.hh
    (excerpt adapted from xlatrz.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlatrz factors the m-by-(m+l) DATA TYPE upper trapezoidal matrix
    **  [ a1 a2 ] = [ a(1:m,1:m) a(1:m,n-l+1:n) ] as ( r  0 ) * z by means
    **  of unitary transformations, where  z is an (m+l)-by-(m+l) unitary
    **  matrix and, r and a1 are m-by-m upper triangular matrices.
    **
    **  arguments
    **  =========
    **
    **  m       (input) long int
    **          the number of rows of the matrix a.  m >= 0.
    **
    **  n       (input) long int
    **          the number of columns of the matrix a.  n >= 0.
    **
    **  l       (input) long int
    **          the number of columns of the matrix a containing the
    **          meaningful part of the householder vectors. n-m >= l >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the leading m-by-n upper trapezoidal part of the
    **          array a must contain the matrix to be factorized.
    **          on exit, the leading m-by-m upper triangular part of a
    **          contains the upper triangular matrix r, and elements n-l+1 to
    **          n of the first m rows of a, with the array tau, represent the
    **          unitary matrix z as a product of m elementary reflectors.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,m).
    **
    **  tau     (output) DATA TYPE array, dimension (m)
    **          the scalar factors of the elementary reflectors.
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    a. petitet, computer science dept., univ. of tenn., knoxville, usa
    **
    **  the factorization is obtained by householder's method.  the kth
    **  transformation matrix, z( k ), which is used to introduce zeros into
    **  the ( m - k + 1 )th row of a, is given in the form
    **
    **     z( k ) = ( i     0   ),
    **              ( 0  t( k ) )
    **
    **  where
    **
    **     t( k ) = i - tau*u( k )*u( k )',   u( k ) = (   1    ),
    **                                                 (   0    )
    **                                                 ( z( k ) )
    **
    **  tau is a scalar and z( k ) is an l element vector. tau and z( k )
    **  are chosen to annihilate the elements of the kth row of a2.
    **
    **  the scalar tau is returned in the kth element of tau and the vector
    **  u( k ) in the kth row of a2, such that the elements of z( k ) are
    **  in  a( k, l + 1 ), ..., a( k, n ). the elements of r are returned in
    **  the upper triangular part of a1.
    **
    **  z is given by
    **
    **     z =  z( 1 ) * z( 2 ) * ... * z( m ).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void latrz(
        const long int* m,
        const long int* n,
        const long int* l,
        float* a,
        const long int* lda,
        float* tau,
        workspace<float> & w)
  */
  /*! fn
   inline void latrz(
        const long int* m,
        const long int* n,
        const long int* l,
        float* a,
        const long int* lda,
        float* tau)
  */
  /*! fn
   inline void latrz(
        const long int* m,
        const long int* n,
        const long int* l,
        double* a,
        const long int* lda,
        double* tau,
        workspace<double> & w)
  */
  /*! fn
   inline void latrz(
        const long int* m,
        const long int* n,
        const long int* l,
        double* a,
        const long int* lda,
        double* tau)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slatrz.f)
  //    *  WORK    (workspace) float array, dimension (M)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATRZ(NAME, T)\
inline void latrz(\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    T* tau,\
    workspace<T> & w)\
{\
    w.resizew((*m));\
    F77NAME( NAME )(m, n, l, a, lda, tau, w.getw());\
}\
inline void latrz(\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    T* tau)             \
{\
   workspace<T> w;\
   latrz(m, n, l, a, lda, tau, w);\
}\

    LPP_LATRZ(slatrz, float)
    LPP_LATRZ(dlatrz, double)

#undef LPP_LATRZ


  // The following macro provides the 4 functions 
  /*! fn
   inline void latrz(
       const long int* m,
       const long int* n,
       const long int* l,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void latrz(
       const long int* m,
       const long int* n,
       const long int* l,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* tau)
  */
  /*! fn
   inline void latrz(
       const long int* m,
       const long int* n,
       const long int* l,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void latrz(
       const long int* m,
       const long int* n,
       const long int* l,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* tau)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clatrz.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (M)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATRZ(NAME, T, TBASE)\
inline void latrz(\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    T* tau,\
    workspace<T> & w)\
{\
    w.resizew((*m));\
    F77NAME( NAME )(m, n, l, a, lda, tau, w.getw());\
}\
inline void latrz(\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    T* a,\
    const long int* lda,\
    T* tau)             \
{\
   workspace<T> w;\
   latrz(m, n, l, a, lda, tau, w);\
}\

    LPP_LATRZ(clatrz, std::complex<float>, float)
    LPP_LATRZ(zlatrz, std::complex<double>, double)

#undef LPP_LATRZ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of latrz_itf.hh
// /////////////////////////////////////////////////////////////////////////////
