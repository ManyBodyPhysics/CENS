#ifndef __PROJECT__LPP__FILE__SYTRD_HH__INCLUDED
#define __PROJECT__LPP__FILE__SYTRD_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sytrd_itf.hh C++ interface to LAPACK (s,d,c,z)sytrd
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sytrd_itf.hh
    (excerpt adapted from xsytrd.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsytrd reduces a BASE DATA TYPE symmetric matrix a to BASE DATA TYPE symmetric
    **  tridiagonal form t by an orthogonal similarity transformation:
    **  q**t * a * q = t.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  a       (input/output) BASE DATA TYPE array, dimension (lda,n)
    **          on entry, the symmetric matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **          on exit, if uplo = 'u', the diagonal and first superdiagonal
    **          of a are overwritten by the corresponding elements of the
    **          tridiagonal matrix t, and the elements above the first
    **          superdiagonal, with the array tau, represent the orthogonal
    **          matrix q as a product of elementary reflectors; if uplo
    **          = 'l', the diagonal and first subdiagonal of a are over-
    **          written by the corresponding elements of the tridiagonal
    **          matrix t, and the elements below the first subdiagonal, with
    **          the array tau, represent the orthogonal matrix q as a product
    **          of elementary reflectors. see further details.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  d       (output) BASE DATA TYPE array, dimension (n)
    **          the diagonal elements of the tridiagonal matrix t:
    **          d(i) = a(i,i).
    **
    **  e       (output) BASE DATA TYPE array, dimension (n-1)
    **          the off-diagonal elements of the tridiagonal matrix t:
    **          e(i) = a(i,i+1) if uplo = 'u', e(i) = a(i+1,i) if uplo = 'l'.
    **
    **  tau     (output) BASE DATA TYPE array, dimension (n-1)
    **          the scalar factors of the elementary reflectors (see further
    **          details).
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
    **  further details
    **  ===============
    **
    **  if uplo = 'u', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(n-1) . . . h(2) h(1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a BASE DATA TYPE scalar, and v is a BASE DATA TYPE vector with
    **  v(i+1:n) = 0 and v(i) = 1; v(1:i-1) is stored on exit in
    **  a(1:i-1,i+1), and tau in tau(i).
    **
    **  if uplo = 'l', the matrix q is represented as a product of elementary
    **  reflectors
    **
    **     q = h(1) h(2) . . . h(n-1).
    **
    **  each h(i) has the form
    **
    **     h(i) = i - tau * v * v'
    **
    **  where tau is a BASE DATA TYPE scalar, and v is a BASE DATA TYPE vector with
    **  v(1:i) = 0 and v(i+1) = 1; v(i+2:n) is stored on exit in a(i+2:n,i),
    **  and tau in tau(i).
    **
    **  the contents of a on exit are illustrated by the following examples
    **  with n = 5:
    **
    **  if uplo = 'u':                       if uplo = 'l':
    **
    **    (  d   e   v2  v3  v4 )              (  d                  )
    **    (      d   e   v3  v4 )              (  e   d              )
    **    (          d   e   v4 )              (  v1  e   d          )
    **    (              d   e  )              (  v1  v2  e   d      )
    **    (                  d  )              (  v1  v2  v3  e   d  )
    **
    **  where d and e denote diagonal and off-diagonal elements of t, and vi
    **  denotes an element of the vector defining h(i).
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sytrd(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tau,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sytrd(
        const char* uplo,
        const long int* n,
        float* a,
        const long int* lda,
        const float* d,
        float* e,
        float* tau,
        long int* info)
  */
  /*! fn
   inline void sytrd(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tau,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sytrd(
        const char* uplo,
        const long int* n,
        double* a,
        const long int* lda,
        const double* d,
        double* e,
        double* tau,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssytrd.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= 1.
  //    *          For optimum performance LWORK >= N*NB, where NB is the
  //    *          optimal blocksize.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SYTRD(NAME, T)\
inline void sytrd(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tau,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, a, lda, d, e, tau, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(uplo, n, a, lda, d, e, tau, w.getw(), &w.neededsize(), info);\
}\
inline void sytrd(\
    const char* uplo,\
    const long int* n,\
    T* a,\
    const long int* lda,\
    const T* d,\
    T* e,\
    T* tau,\
    long int* info)\
{\
   workspace<T> w;\
   sytrd(uplo, n, a, lda, d, e, tau, info, w);\
}\

    LPP_SYTRD(ssytrd, float)
    LPP_SYTRD(dsytrd, double)

#undef LPP_SYTRD



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sytrd_itf.hh
// /////////////////////////////////////////////////////////////////////////////
