#ifndef __PROJECT__LPP__FILE__LAEXC_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAEXC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laexc_itf.hh C++ interface to LAPACK (s,d,c,z)laexc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laexc_itf.hh
    (excerpt adapted from xlaexc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaexc swaps adjacent diagonal blocks t11 and t22 of order 1 or 2 in
    **  an upper quasi-triangular matrix t by an orthogonal similarity
    **  transformation.
    **
    **  t must be in schur canonical form, that is, block upper triangular
    **  with 1-by-1 and 2-by-2 diagonal blocks; each 2-by-2 diagonal block
    **  has its diagonal elemnts equal and its off-diagonal elements of
    **  opposite sign.
    **
    **  arguments
    **  =========
    **
    **  wantq   (input) logical
    **          = .true. : accumulate the transformation in the matrix q;
    **          = .false.: do not accumulate the transformation.
    **
    **  n       (input) long int
    **          the order of the matrix t. n >= 0.
    **
    **  t       (input/output) BASE DATA TYPE array, dimension (ldt,n)
    **          on entry, the upper quasi-triangular matrix t, in schur
    **          canonical form.
    **          on exit, the updated matrix t, again in schur canonical form.
    **
    **  ldt     (input)  long int
    **          the leading dimension of the array t. ldt >= max(1,n).
    **
    **  q       (input/output) BASE DATA TYPE array, dimension (ldq,n)
    **          on entry, if wantq is .true., the orthogonal matrix q.
    **          on exit, if wantq is .true., the updated matrix q.
    **          if wantq is .false., q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.
    **          ldq >= 1; and if wantq is .true., ldq >= n.
    **
    **  j1      (input) long int
    **          the index of the first row of the first block t11.
    **
    **  n1      (input) long int
    **          the order of the first block t11. n1 = 0, 1 or 2.
    **
    **  n2      (input) long int
    **          the order of the second block t22. n2 = 0, 1 or 2.
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          = 1: the transformed matrix t would be too far from schur
    **               form; the blocks are not swapped and t and q are
    **               unchanged.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laexc(
        const long int* wantq,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laexc(
        const long int* wantq,
        const long int* n,
        const float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info)
  */
  /*! fn
   inline void laexc(
        const long int* wantq,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laexc(
        const long int* wantq,
        const long int* n,
        const double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaexc.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAEXC(NAME, T)\
inline void laexc(\
    const long int* wantq,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    const long int* j1,\
    const long int* n1,\
    const long int* n2,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew((*n));\
    F77NAME( NAME )(wantq, n, t, ldt, q, ldq, j1, n1, n2, w.getw(), info);\
}\
inline void laexc(\
    const long int* wantq,\
    const long int* n,\
    const T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    const long int* j1,\
    const long int* n1,\
    const long int* n2,\
    long int* info)\
{\
   workspace<T> w;\
   laexc(wantq, n, t, ldt, q, ldq, j1, n1, n2, info, w);\
}\

    LPP_LAEXC(slaexc, float)
    LPP_LAEXC(dlaexc, double)

#undef LPP_LAEXC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laexc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
