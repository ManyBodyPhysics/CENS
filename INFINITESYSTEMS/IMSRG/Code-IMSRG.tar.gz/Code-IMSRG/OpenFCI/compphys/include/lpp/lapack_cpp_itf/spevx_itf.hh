#ifndef __PROJECT__LPP__FILE__SPEVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__SPEVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : spevx_itf.hh C++ interface to LAPACK (s,d,c,z)spevx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file spevx_itf.hh
    (excerpt adapted from xspevx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xspevx computes selected eigenvalues and, optionally, eigenvectors
    **  of a BASE DATA TYPE symmetric matrix a in packed storage.  eigenvalues/vectors
    **  can be selected by specifying either a range of values or a range of
    **  indices for the desired eigenvalues.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  range   (input) char
    **          = 'a': all eigenvalues will be found;
    **          = 'v': all eigenvalues in the half-open interval (vl,vu]
    **                 will be found;
    **          = 'i': the il-th through iu-th eigenvalues will be found.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input/output) BASE DATA TYPE array, dimension (n*(n+1)/2)
    **          on entry, the upper or lower triangle of the symmetric matrix
    **          a, packed columnwise in a linear array.  the j-th column of a
    **          is stored in the array ap as follows:
    **          if uplo = 'u', ap(i + (j-1)*j/2) = a(i,j) for 1<=i<=j;
    **          if uplo = 'l', ap(i + (j-1)*(2*n-j)/2) = a(i,j) for j<=i<=n.
    **
    **          on exit, ap is overwritten by values generated during the
    **          reduction to tridiagonal form.  if uplo = 'u', the diagonal
    **          and first superdiagonal of the tridiagonal matrix t overwrite
    **          the corresponding elements of a, and if uplo = 'l', the
    **          diagonal and first subdiagonal of t overwrite the
    **          corresponding elements of a.
    **
    **  vl      (input) BASE DATA TYPE
    **  vu      (input) BASE DATA TYPE
    **          if range='v', the lower and upper bounds of the interval to
    **          be searched for eigenvalues. vl < vu.
    **          not referenced if range = 'a' or 'i'.
    **
    **  il      (input) long int
    **  iu      (input) long int
    **          if range='i', the indices (in ascending order) of the
    **          smallest and largest eigenvalues to be returned.
    **          1 <= il <= iu <= n, if n > 0; il = 1 and iu = 0 if n = 0.
    **          not referenced if range = 'a' or 'v'.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the absolute error tolerance for the eigenvalues.
    **          an approximate eigenvalue is accepted as converged
    **          when it is determined to lie in an interval [a,b]
    **          of width less than or equal to
    **
    **                  abstol + eps *   max( |a|,|b| ) ,
    **
    **          where eps is the machine precision.  if abstol is less than
    **          or equal to zero, then  eps*|t|  will be used in its place,
    **          where |t| is the 1-norm of the tridiagonal matrix obtained
    **          by reducing ap to tridiagonal form.
    **
    **          eigenvalues will be computed most accurately when abstol is
    **          set to twice the underflow threshold 2*dlamch('s'), not zero.
    **          if this routine returns with info>0, indicating that some
    **          eigenvectors did not converge, try setting abstol to
    **          2*dlamch('s').
    **
    **          see "computing small singular values of bidiagonal matrices
    **          with guaranteed high relative accuracy," by demmel and
    **          kahan, lapack WORKing note #3.
    **
    **  m       (output) long int
    **          the total number of eigenvalues found.  0 <= m <= n.
    **          if range = 'a', m = n, and if range = 'i', m = iu-il+1.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the selected eigenvalues in ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, max(1,m))
    **          if jobz = 'v', then if info = 0, the first m columns of z
    **          contain the orthonormal eigenvectors of the matrix a
    **          corresponding to the selected eigenvalues, with the i-th
    **          column of z holding the eigenvector associated with w(i).
    **          if an eigenvector fails to converge, then that column of z
    **          contains the latest approximation to the eigenvector, and the
    **          index of the eigenvector is returned in ifail.
    **          if jobz = 'n', then z is not referenced.
    **          note: the user must ensure that at least max(1,m) columns are
    **          supplied in the array z; if range = 'v', the exact value of m
    **          is not known in advance and an upper bound must be used.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **
    **
    **  ifail   (output) long int array, dimension (n)
    **          if jobz = 'v', then if info = 0, the first m elements of
    **          ifail are zero.  if info > 0, then ifail contains the
    **          indices of the eigenvectors that failed to converge.
    **          if jobz = 'n', then ifail is not referenced.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, then i eigenvectors failed to converge.
    **                their indices are stored in array ifail.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void spevx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        float* ap,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* ifail,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void spevx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        float* ap,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* ifail,
        long int* info)
  */
  /*! fn
   inline void spevx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        double* ap,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* ifail,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void spevx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        double* ap,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* ifail,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sspevx.f)
  //    *  WORK    (workspace) float array, dimension (8*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (5*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPEVX(NAME, T)\
inline void spevx(\
    const char* jobz,\
    const char* range,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(5*(*n));\
    w.resizew(8*(*n));\
    F77NAME( NAME )(jobz, range, uplo, n, ap, vl, vu, il, iu, abstol, m, ws, z, ldz,\
                    w.getw(), w.getiw(), ifail, info);                  \
}\
inline void spevx(\
    const char* jobz,\
    const char* range,\
    const char* uplo,\
    const long int* n,\
    T* ap,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* ifail,\
    long int* info)\
{\
   workspace<T> w;\
   spevx(jobz, range, uplo, n, ap, vl, vu, il, iu, abstol, m, ws, z, ldz,\
         ifail, info, w);                                               \
}\

    LPP_SPEVX(sspevx, float)
    LPP_SPEVX(dspevx, double)

#undef LPP_SPEVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of spevx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
