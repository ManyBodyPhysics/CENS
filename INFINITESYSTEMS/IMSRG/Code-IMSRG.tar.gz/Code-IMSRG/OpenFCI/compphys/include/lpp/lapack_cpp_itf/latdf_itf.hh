#ifndef __PROJECT__LPP__FILE__LATDF_HH__INCLUDED
#define __PROJECT__LPP__FILE__LATDF_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : latdf_itf.hh C++ interface to LAPACK (c,d,c,z)latdf
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file latdf_itf.hh
    (excerpt adapted from xlatdf.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlatdf computes the contribution to the reciprocal dif-estimate
    **  by solving for x in z * x = b, where b is chosen such that the norm
    **  of x is as large as possible. it is assumed that lu decomposition
    **  of z has been computed by cgetc2. on entry rhs = f holds the
    **  contribution from earlier solved sub-systems, and on return rhs = x.
    **
    **  the factorization of z returned by cgetc2 has the form
    **  z = p * l * u * q, where p and q are permutation matrices. l is lower
    **  triangular with unit diagonal elements and u is upper triangular.
    **
    **  arguments
    **  =========
    **
    **  ijob    (input) long int
    **          ijob = 2: first compute an approximative null-vector e
    **              of z using cgecon, e is normalized and solve for
    **              zx = +-e - f with the sign giving the greater value of
    **              2-norm(x).  about 5 times as expensive as default.
    **          ijob .ne. 2: local look ahead strategy where
    **              all entries of the r.h.s. b is choosen as either +1 or
    **              -1.  default.
    **
    **  n       (input) long int
    **          the number of columns of the matrix z.
    **
    **  z       (input) BASE DATA TYPE array, dimension (ldz, n)
    **          on entry, the lu part of the factorization of the n-by-n
    **          matrix z computed by cgetc2:  z = p * l * u * q
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  lda >= max(1, n).
    **
    **  rhs     (input/output) BASE DATA TYPE array, dimension (n).
    **          on entry, rhs contains contributions from other subsystems.
    **          on exit, rhs contains the solution of the subsystem with
    **          entries according to the value of ijob (see above).
    **
    **  rdsum   (input/output) BASE DATA TYPE
    **          on entry, the sum of squares of computed contributions to
    **          the dif-estimate under computation by ctgsyl, where the
    **          scaling factor rdscal (see below) has been factored out.
    **          on exit, the corresponding sum of squares updated with the
    **          contributions from the current sub-system.
    **          if trans = 't' rdsum is not touched.
    **          note: rdsum only makes sense when ctgsy2 is called by ctgsyl.
    **
    **  rdscal  (input/output) BASE DATA TYPE
    **          on entry, scaling factor used to prevent overflow in rdsum.
    **          on exit, rdscal is updated w.r.t. the current contributions
    **          in rdsum.
    **          if trans = 't', rdscal is not touched.
    **          note: rdscal only makes sense when ctgsy2 is called by
    **          ctgsyl.
    **
    **  ipiv    (input) long int array, dimension (n).
    **          the pivot indices; for 1 <= i <= n, row i of the
    **          matrix has been interchanged with row ipiv(i).
    **
    **  jpiv    (input) long int array, dimension (n).
    **          the pivot indices; for 1 <= j <= n, column j of the
    **          matrix has been interchanged with column jpiv(j).
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  this routine is a further developed implementation of algorithm
    **  bsolve in [1] using complete pivoting in the lu factorization.
    **
    **   [1]   bo kagstrom and lars westin,
    **         generalized schur methods with condition estimators for
    **         solving the generalized sylvester equation, ieee transactions
    **         on automatic control, vol. 34, no. 7, july 1989, pp 745-751.
    **
    **   [2]   peter poromaa,
    **         on efficient and robust estimators for the separation
    **         between two regular matrix pairs with applications in
    **         condition estimation. report uminf-95.05, department of
    **         computing science, umea university, s-901 87 umea, sweden,
    **         1995.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void latdf(
        const long int* ijob,
        const long int* n,
        const float* z,
        const long int* ldz,
        float* rhs,
        float* rdsum,
        float* rdscal,
        const long int* ipiv,
        const long int* jpiv,
        workspace<float> & w)
  */
  /*! fn
   inline void latdf(
        const long int* ijob,
        const long int* n,
        const float* z,
        const long int* ldz,
        float* rhs,
        float* rdsum,
        float* rdscal,
        const long int* ipiv,
        const long int* jpiv)
  */
  /*! fn
   inline void latdf(
        const long int* ijob,
        const long int* n,
        const double* z,
        const long int* ldz,
        double* rhs,
        double* rdsum,
        double* rdscal,
        const long int* ipiv,
        const long int* jpiv,
        workspace<double> & w)
  */
  /*! fn
   inline void latdf(
        const long int* ijob,
        const long int* n,
        const double* z,
        const long int* ldz,
        double* rhs,
        double* rdsum,
        double* rdscal,
        const long int* ipiv,
        const long int* jpiv)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slatdf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATDF(NAME, T)\
inline void latdf(\
    const long int* ijob,\
    const long int* n,\
    const T* z,\
    const long int* ldz,\
    T* rhs,\
    T* rdsum,\
    T* rdscal,\
    const long int* ipiv,\
    const long int* jpiv,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ijob, n, z, ldz, rhs, rdsum, rdscal, ipiv, jpiv);\
}\
inline void latdf(\
    const long int* ijob,\
    const long int* n,\
    const T* z,\
    const long int* ldz,\
    T* rhs,\
    T* rdsum,\
    T* rdscal,\
    const long int* ipiv,\
    const long int* jpiv)\
{\
   workspace<T> w;\
   latdf(ijob, n, z, ldz, rhs, rdsum, rdscal, ipiv, jpiv, w);\
}\

    LPP_LATDF(slatdf, float)
    LPP_LATDF(dlatdf, double)

#undef LPP_LATDF


  // The following macro provides the 4 functions 
  /*! fn
   inline void latdf(
       const long int* ijob,
       const long int* n,
       const std::complex<float>* z,
       const long int* ldz,
       std::complex<float>* rhs,
       float* rdsum,
       float* rdscal,
       const long int* ipiv,
       const long int* jpiv,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void latdf(
       const long int* ijob,
       const long int* n,
       const std::complex<float>* z,
       const long int* ldz,
       std::complex<float>* rhs,
       float* rdsum,
       float* rdscal,
       const long int* ipiv,
       const long int* jpiv)
  */
  /*! fn
   inline void latdf(
       const long int* ijob,
       const long int* n,
       const std::complex<double>* z,
       const long int* ldz,
       std::complex<double>* rhs,
       double* rdsum,
       double* rdscal,
       const long int* ipiv,
       const long int* jpiv,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void latdf(
       const long int* ijob,
       const long int* n,
       const std::complex<double>* z,
       const long int* ldz,
       std::complex<double>* rhs,
       double* rdsum,
       double* rdscal,
       const long int* ipiv,
       const long int* jpiv)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clatdf.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LATDF(NAME, T, TBASE)\
inline void latdf(\
    const long int* ijob,\
    const long int* n,\
    const T* z,\
    const long int* ldz,\
    T* rhs,\
    TBASE* rdsum,\
    TBASE* rdscal,\
    const long int* ipiv,\
    const long int* jpiv,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(ijob, n, z, ldz, rhs, rdsum, rdscal, ipiv, jpiv);\
}\
inline void latdf(\
    const long int* ijob,\
    const long int* n,\
    const T* z,\
    const long int* ldz,\
    T* rhs,\
    TBASE* rdsum,\
    TBASE* rdscal,\
    const long int* ipiv,\
    const long int* jpiv)\
{\
   workspace<T> w;\
   latdf(ijob, n, z, ldz, rhs, rdsum, rdscal, ipiv, jpiv, w);\
}\

    LPP_LATDF(clatdf, std::complex<float>,  float)
    LPP_LATDF(zlatdf, std::complex<double>, double)

#undef LPP_LATDF



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of latdf_itf.hh
// /////////////////////////////////////////////////////////////////////////////
