#ifndef __PROJECT__LPP__FILE__SBGVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__SBGVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sbgvx_itf.hh C++ interface to LAPACK (s,d,c,z)sbgvx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sbgvx_itf.hh
    (excerpt adapted from xsbgvx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsbgvx computes selected eigenvalues, and optionally, eigenvectors
    **  of a BASE DATA TYPE generalized symmetric-definite banded eigenproblem, of
    **  the form a*x=(lambda)*b*x.  here a and b are assumed to be symmetric
    **  and banded, and b is also positive definite.  eigenvalues and
    **  eigenvectors can be selected by specifying either all eigenvalues,
    **  a range of values or a range of indices for the desired eigenvalues.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  range   (input) char
    **          = 'a': all eigenvalues will be found.
    **          = 'v': all eigenvalues in the half-open interval (vl,vu]
    **                 will be found.
    **          = 'i': the il-th through iu-th eigenvalues will be found.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangles of a and b are stored;
    **          = 'l':  lower triangles of a and b are stored.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ka      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  ka >= 0.
    **
    **  kb      (input) long int
    **          the number of superdiagonals of the matrix b if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kb >= 0.
    **
    **  ab      (input/output) BASE DATA TYPE array, dimension (ldab, n)
    **          on entry, the upper or lower triangle of the symmetric band
    **          matrix a, stored in the first ka+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(ka+1+i-j,j) = a(i,j) for max(1,j-ka)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+ka).
    **
    **          on exit, the contents of ab are destroyed.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= ka+1.
    **
    **  bb      (input/output) BASE DATA TYPE array, dimension (ldbb, n)
    **          on entry, the upper or lower triangle of the symmetric band
    **          matrix b, stored in the first kb+1 rows of the array.  the
    **          j-th column of b is stored in the j-th column of the array bb
    **          as follows:
    **          if uplo = 'u', bb(ka+1+i-j,j) = b(i,j) for max(1,j-kb)<=i<=j;
    **          if uplo = 'l', bb(1+i-j,j)    = b(i,j) for j<=i<=min(n,j+kb).
    **
    **          on exit, the factor s from the split cholesky factorization
    **          b = s**t*s, as returned by dpbstf.
    **
    **  ldbb    (input) long int
    **          the leading dimension of the array bb.  ldbb >= kb+1.
    **
    **  q       (output) BASE DATA TYPE array, dimension (ldq, n)
    **          if jobz = 'v', the n-by-n matrix used in the reduction of
    **          a*x = (lambda)*b*x to standard form, i.e. c*x = (lambda)*x,
    **          and consequently c to tridiagonal form.
    **          if jobz = 'n', the array q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.  if jobz = 'n',
    **          ldq >= 1. if jobz = 'v', ldq >= max(1,n).
    **
    **  vl      (input) BASE DATA TYPE
    **  vu      (input) BASE DATA TYPE
    **          if range='v', the lower and upper bounds of the interval to
    **          be searched for eigenvalues. vl < vu.
    **          not referenced if range = 'a' or 'i'.
    **
    **  il      (input) long int
    **  iu      (input) long int
    **          if range='i', the indices (in ascending order) of the
    **          smallest and largest eigenvalues to be returned.
    **          1 <= il <= iu <= n, if n > 0; il = 1 and iu = 0 if n = 0.
    **          not referenced if range = 'a' or 'v'.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the absolute error tolerance for the eigenvalues.
    **          an approximate eigenvalue is accepted as converged
    **          when it is determined to lie in an interval [a,b]
    **          of width less than or equal to
    **
    **                  abstol + eps *   max( |a|,|b| ) ,
    **
    **          where eps is the machine precision.  if abstol is less than
    **          or equal to zero, then  eps*|t|  will be used in its place,
    **          where |t| is the 1-norm of the tridiagonal matrix obtained
    **          by reducing a to tridiagonal form.
    **
    **          eigenvalues will be computed most accurately when abstol is
    **          set to twice the underflow threshold 2*dlamch('s'), not zero.
    **          if this routine returns with info>0, indicating that some
    **          eigenvectors did not converge, try setting abstol to
    **          2*dlamch('s').
    **
    **  m       (output) long int
    **          the total number of eigenvalues found.  0 <= m <= n.
    **          if range = 'a', m = n, and if range = 'i', m = iu-il+1.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          if info = 0, the eigenvalues in ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, n)
    **          if jobz = 'v', then if info = 0, z contains the matrix z of
    **          eigenvectors, with the i-th column of z holding the
    **          eigenvector associated with w(i).  the eigenvectors are
    **          normalized so z**t*b*z = i.
    **          if jobz = 'n', then z is not referenced.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **
    **
    **  ifail   (input) long int array, dimension (m)
    **          if jobz = 'v', then if info = 0, the first m elements of
    **          ifail are zero.  if info > 0, then ifail contains the
    **          indices of the eigenvalues that failed to converge.
    **          if jobz = 'n', then ifail is not referenced.
    **
    **  info    (output) long int
    **          = 0 : successful exit
    **          < 0 : if info = -i, the i-th argument had an illegal value
    **          <= n: if info = i, then i eigenvectors failed to converge.
    **                  their indices are stored in ifail.
    **          > n : dpbstf returned an error code; i.e.,
    **                if info = n + i, for 1 <= i <= n, then the leading
    **                minor of order i of b is not positive definite.
    **                the factorization of b could not be completed and
    **                no eigenvalues or eigenvectors were computed.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     mark fahey, department of mathematics, univ. of kentucky, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sbgvx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        float* ab,
        const long int* ldab,
        float* bb,
        const long int* ldbb,
        float* q,
        const long int* ldq,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        const long int* ifail,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sbgvx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        float* ab,
        const long int* ldab,
        float* bb,
        const long int* ldbb,
        float* q,
        const long int* ldq,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        const long int* ifail,
        long int* info)
  */
  /*! fn
   inline void sbgvx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        double* ab,
        const long int* ldab,
        double* bb,
        const long int* ldbb,
        double* q,
        const long int* ldq,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        const long int* ifail,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sbgvx(
        const char* jobz,
        const char* range,
        const char* uplo,
        const long int* n,
        const long int* ka,
        const long int* kb,
        double* ab,
        const long int* ldab,
        double* bb,
        const long int* ldbb,
        double* q,
        const long int* ldq,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        const long int* ifail,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssbgvx.f)
  //    *  WORK    (workspace/output) float array, dimension (7N)
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (5N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SBGVX(NAME, T)\
inline void sbgvx(\
    const char* jobz,\
    const char* range,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    T* bb,\
    const long int* ldbb,\
    T* q,\
    const long int* ldq,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    const long int* ifail,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(5**n);\
    w.resizew(7*(*n));\
    F77NAME( NAME )(jobz, range, uplo, n, ka, kb, ab, ldab, bb, ldbb, q, ldq,\
                    vl, vu, il, iu, abstol, m, ws, z, ldz, w.getw(), w.getiw(), ifail, info); \
}\
inline void sbgvx(\
    const char* jobz,\
    const char* range,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    T* bb,\
    const long int* ldbb,\
    T* q,\
    const long int* ldq,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    const long int* ifail,\
    long int* info)\
{\
   workspace<T> w;\
   sbgvx(jobz, range, uplo, n, ka, kb, ab, ldab, bb, ldbb, q, ldq,\
         vl, vu, il, iu, abstol, m, ws, z, ldz, ifail, info, w);  \
}\

    LPP_SBGVX(ssbgvx, float)
    LPP_SBGVX(dsbgvx, double)

#undef LPP_SBGVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sbgvx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
