#ifndef __PROJECT__LPP__FILE__LAS2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAS2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : las2_itf.hh C++ interface to LAPACK (s,d,c,z)las2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file las2_itf.hh
    (excerpt adapted from xlas2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlas2  computes the singular values of the 2-by-2 matrix
    **     [  f   g  ]
    **     [  0   h  ].
    **  on return, ssmin is the smaller singular value and ssmax is the
    **  larger singular value.
    **
    **  arguments
    **  =========
    **
    **  f       (input) BASE DATA TYPE
    **          the (1,1) element of the 2-by-2 matrix.
    **
    **  g       (input) BASE DATA TYPE
    **          the (1,2) element of the 2-by-2 matrix.
    **
    **  h       (input) BASE DATA TYPE
    **          the (2,2) element of the 2-by-2 matrix.
    **
    **  ssmin   (output) BASE DATA TYPE
    **          the smaller singular value.
    **
    **  ssmax   (output) BASE DATA TYPE
    **          the larger singular value.
    **
    **  further details
    **  ===============
    **
    **  barring over/underflow, all output quantities are correct to within
    **  a few units in the last place (ulps), even in the absence of a guard
    **  digit in addition/subtraction.
    **
    **  in ieee arithmetic, the code WORKs correctly if one matrix element is
    **  infinite.
    **
    **  overflow will not occur unless the largest singular value itself
    **  overflows, or is within a few ulps of overflow. (on machines with
    **  partial overflow, like the cray, overflow may occur if the largest
    **  singular value is within a factor of 2 of overflow.)
    **
    **  underflow is harmless if underflow is gradual. otherwise, results
    **  may correspond to a matrix modified by perturbations of size near
    **  the underflow threshold.
    **
    **  ====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void las2(
        const float* f,
        const float* g,
        const float* h,
        float* ssmin,
        float* ssmax,
        workspace<float> & w)
  */
  /*! fn
   inline void las2(
        const float* f,
        const float* g,
        const float* h,
        float* ssmin,
        float* ssmax)
  */
  /*! fn
   inline void las2(
        const double* f,
        const double* g,
        const double* h,
        double* ssmin,
        double* ssmax,
        workspace<double> & w)
  */
  /*! fn
   inline void las2(
        const double* f,
        const double* g,
        const double* h,
        double* ssmin,
        double* ssmax)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slas2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAS2(NAME, T)\
inline void las2(\
    const T* f,\
    const T* g,\
    const T* h,\
    T* ssmin,\
    T* ssmax,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(f, g, h, ssmin, ssmax);\
}\
inline void las2(\
    const T* f,\
    const T* g,\
    const T* h,\
    T* ssmin,\
    T* ssmax)\
{\
   workspace<T> w;\
   las2(f, g, h, ssmin, ssmax, w);\
}\

    LPP_LAS2(slas2, float)
    LPP_LAS2(dlas2, double)

#undef LPP_LAS2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of las2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
