#ifndef __PROJECT__LPP__FILE__LASD9_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD9_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd9_itf.hh C++ interface to LAPACK (s,d,c,z)lasd9
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd9_itf.hh
    (excerpt adapted from xlasd9.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd9 finds the square roots of the roots of the secular equation,
    **  as defined by the values in dsigma and z.  it makes the
    **  appropriate calls to dlasd4, and stores, for each  element in d,
    **  the distance to its two nearest poles (elements in dsigma). it also
    **  updates the arrays vf and vl, the first and last components of all
    **  the right singular vectors of the original bidiagonal matrix.
    **
    **  xlasd9 is called from dlasd7.
    **
    **  arguments
    **  =========
    **
    **  icompq  (input) long int
    **          specifies whether singular vectors are to be computed in
    **          factored form in the calling routine:
    **
    **             icompq = 0             compute singular values only.
    **
    **             icompq = 1             compute singular vector matrices in
    **                                    factored form also.
    **  ldu    (input) long int
    **         on entry, leading dimension of difr. (jtl)
    **
    **  k       (input) long int
    **          the number of terms in the rational function to be solved by
    **          dlasd4.  k >= 1.
    **
    **  d       (output) BASE DATA TYPE array, dimension(k)
    **          d(i) contains the updated singular values.
    **
    **  dsigma  (input) BASE DATA TYPE array, dimension(k)
    **          the first k elements of this array contain the old roots
    **          of the deflated updating problem.  these are the poles
    **          of the secular equation.
    **
    **  z       (input) BASE DATA TYPE array, dimension (k)
    **          the first k elements of this array contain the components
    **          of the deflation-adjusted updating row vector.
    **
    **  vf      (input/output) BASE DATA TYPE array, dimension(k)
    **          on entry, vf contains  information passed through sbede8.f
    **          on exit, vf contains the first k components of the first
    **          components of all right singular vectors of the bidiagonal
    **          matrix.
    **
    **  vl      (input/output) BASE DATA TYPE array, dimension(k)
    **          on entry, vl contains  information passed through sbede8.f
    **          on exit, vl contains the first k components of the last
    **          components of all right singular vectors of the bidiagonal
    **          matrix.
    **
    **  difl    (output) BASE DATA TYPE array, dimension (k).
    **          on exit, difl(i) = d(i) - dsigma(i).
    **
    **  difr    (output) BASE DATA TYPE array,
    **                              dimension (ldu, 2) if icompq =1 and
    **                              dimension (k) if icompq = 0.
    **          on exit, difr(i, 1) = d(i) - dsigma(i+1), difr(k, 1) is not
    **          defined and will not be referenced.
    **
    **          if icompq = 1, difr(1:k, 2) is an array containing the
    **          normalizing factors for the right singular vector matrix.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd9(
        const long int* icompq,
        const long int* ldu,
        const long int* k,
        const float* d,
        const float* z,
        float* vf,
        float* vl,
        float* difl,
        float* difr,
        const float* dsigma,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd9(
        const long int* icompq,
        const long int* ldu,
        const long int* k,
        const float* d,
        const float* z,
        float* vf,
        float* vl,
        float* difl,
        float* difr,
        const float* dsigma,
        long int* info)
  */
  /*! fn
   inline void lasd9(
        const long int* icompq,
        const long int* ldu,
        const long int* k,
        const double* d,
        const double* z,
        double* vf,
        double* vl,
        double* difl,
        double* difr,
        const double* dsigma,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd9(
        const long int* icompq,
        const long int* ldu,
        const long int* k,
        const double* d,
        const double* z,
        double* vf,
        double* vl,
        double* difl,
        double* difr,
        const double* dsigma,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd9.f)
  //    *  WORK    (workspace) float array,
  //    *                                 dimension at least (3 * K)
  //    *          Workspace.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD9(NAME, T)\
inline void lasd9(\
    const long int* icompq,\
    const long int* ldu,\
    const long int* k,\
    const T* d,\
    const T* z,\
    T* vf,\
    T* vl,\
    T* difl,\
    T* difr,\
    const T* dsigma,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(3**k);\
    F77NAME( NAME )(icompq, ldu, k, d, z, vf, vl, difl, difr, dsigma, w.getw(), info);\
}\
inline void lasd9(\
    const long int* icompq,\
    const long int* ldu,\
    const long int* k,\
    const T* d,\
    const T* z,\
    T* vf,\
    T* vl,\
    T* difl,\
    T* difr,\
    const T* dsigma,\
    long int* info)\
{\
   workspace<T> w;\
   lasd9(icompq, ldu, k, d, z, vf, vl, difl, difr, dsigma, info, w);\
}\

    LPP_LASD9(slasd9, float)
    LPP_LASD9(dlasd9, double)

#undef LPP_LASD9



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd9_itf.hh
// /////////////////////////////////////////////////////////////////////////////
