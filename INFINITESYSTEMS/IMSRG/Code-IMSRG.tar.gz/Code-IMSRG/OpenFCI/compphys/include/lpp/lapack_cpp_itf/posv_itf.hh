#ifndef __PROJECT__LPP__FILE__POSV_HH__INCLUDED
#define __PROJECT__LPP__FILE__POSV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : posv_itf.hh C++ interface to LAPACK (c,d,c,z)posv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file posv_itf.hh
    (excerpt adapted from xposv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xposv computes the solution to a DATA TYPE system of linear equations
    **     a * x = b,
    **  where a is an n-by-n hermitian positive definite matrix and x and b
    **  are n-by-nrhs matrices.
    **
    **  the cholesky decomposition is used to factor a as
    **     a = u**h* u,  if uplo = 'u', or
    **     a = l * l**h,  if uplo = 'l',
    **  where u is an upper triangular matrix and  l is a lower triangular
    **  matrix.  the factored form of a is then used to solve the system of
    **  equations a * x = b.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the hermitian matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, if info = 0, the factor u or l from the cholesky
    **          factorization a = u**h*u or a = l*l**h.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if info = 0, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  if info = i, the leading minor of order i of a is not
    **                positive definite, so the factorization could not be
    **                completed, and the solution has not been computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void posv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void posv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void posv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void posv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sposv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POSV(NAME, T)\
inline void posv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, b, ldb, info);\
}\
inline void posv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   posv(uplo, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_POSV(sposv, float)
    LPP_POSV(dposv, double)

#undef LPP_POSV


  // The following macro provides the 4 functions 
  /*! fn
   inline void posv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void posv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void posv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void posv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cposv.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_POSV(NAME, T, TBASE)\
inline void posv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, b, ldb, info);\
}\
inline void posv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   posv(uplo, n, nrhs, a, lda, b, ldb, info, w);\
}\

    LPP_POSV(cposv, std::complex<float>,  float)
    LPP_POSV(zposv, std::complex<double>, double)

#undef LPP_POSV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of posv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
