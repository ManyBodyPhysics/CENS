#ifndef __PROJECT__LPP__FILE__TGEX2_HH__INCLUDED
#define __PROJECT__LPP__FILE__TGEX2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : tgex2_itf.hh C++ interface to LAPACK (c,d,c,z)tgex2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file tgex2_itf.hh
    (excerpt adapted from xtgex2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtgex2 swaps adjacent diagonal 1 by 1 blocks (a11,b11) and (a22,b22)
    **  in an upper triangular matrix pair (a, b) by an unitary equivalence
    **  transformation.
    **
    **  (a, b) must be in generalized schur canonical form, that is, a and
    **  b are both upper triangular.
    **
    **  optionally, the matrices q and z of generalized schur vectors are
    **  updated.
    **
    **         q(in) * a(in) * z(in)' = q(out) * a(out) * z(out)'
    **         q(in) * b(in) * z(in)' = q(out) * b(out) * z(out)'
    **
    **
    **  arguments
    **  =========
    **
    **  wantq   (input) logical
    **          .true. : update the left transformation matrix q;
    **          .false.: do not update q.
    **
    **  wantz   (input) logical
    **          .true. : update the right transformation matrix z;
    **          .false.: do not update z.
    **
    **  n       (input) long int
    **          the order of the matrices a and b. n >= 0.
    **
    **  a       (input/output) DATA TYPE arrays, dimensions (lda,n)
    **          on entry, the matrix a in the pair (a, b).
    **          on exit, the updated matrix a.
    **
    **  lda     (input)  long int
    **          the leading dimension of the array a. lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE arrays, dimensions (ldb,n)
    **          on entry, the matrix b in the pair (a, b).
    **          on exit, the updated matrix b.
    **
    **  ldb     (input)  long int
    **          the leading dimension of the array b. ldb >= max(1,n).
    **
    **  q       (input/output) DATA TYPE array, dimension (ldz,n)
    **          if wantq = .true, on entry, the unitary matrix q. on exit,
    **          the updated matrix q.
    **          not referenced if wantq = .false..
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q. ldq >= 1;
    **          if wantq = .true., ldq >= n.
    **
    **  z       (input/output) DATA TYPE array, dimension (ldz,n)
    **          if wantz = .true, on entry, the unitary matrix z. on exit,
    **          the updated matrix z.
    **          not referenced if wantz = .false..
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z. ldz >= 1;
    **          if wantz = .true., ldz >= n.
    **
    **  j1      (input) long int
    **          the index to the first block (a11, b11).
    **
    **  info    (output) long int
    **           =0:  successful exit.
    **           =1:  the transformed matrix pair (a, b) would be too far
    **                from generalized schur form; the problem is ill-
    **                conditioned. (a, b) may have been partially reordered,
    **                and ilst points to the first row of the current
    **                position of the block being moved.
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     bo kagstrom and peter poromaa, department of computing science,
    **     umea university, s-901 87 umea, sweden.
    **
    **  in the current code both weak and strong stability tests are
    **  performed. the user can omit the strong stability test by changing
    **  the internal logical parameter wands to .false.. see ref. [2] for
    **  details.
    **
    **  [1] b. kagstrom; a direct method for reordering eigenvalues in the
    **      generalized BASE DATA TYPE schur form of a regular matrix pair (a, b), in
    **      m.s. moonen et al (eds), linear algebra for large scale and
    **      BASE DATA TYPE-time applications, kluwer academic publ. 1993, pp 195-218.
    **
    **  [2] b. kagstrom and p. poromaa; computing eigenspaces with specified
    **      eigenvalues of a regular matrix pair (a, b) and condition
    **      estimation: theory, algorithms and software, report uminf-94.04,
    **      department of computing science, umea university, s-901 87 umea,
    **      sweden, 1994. also as lapack WORKing note 87. to appear in
    **      numerical algorithms, 1996.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void tgex2(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void tgex2(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const float* a,
        const long int* lda,
        float* b,
        const long int* ldb,
        const float* q,
        const long int* ldq,
        const float* z,
        const long int* ldz,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info)
  */
  /*! fn
   inline void tgex2(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void tgex2(
        const long int* wantq,
        const long int* wantz,
        const long int* n,
        const double* a,
        const long int* lda,
        double* b,
        const long int* ldb,
        const double* q,
        const long int* ldq,
        const double* z,
        const long int* ldz,
        const long int* j1,
        const long int* n1,
        const long int* n2,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from stgex2.f)
  //    *  WORK    (workspace) float array, dimension (LWORK).
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.
  //    *          LWORK >=  MAX( N*(N2+N1), (N2+N1)*(N2+N1)*2 )
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEX2(NAME, T)\
inline void tgex2(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    const long int* j1,\
    const long int* n1,\
    const long int* n2,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, j1, n1, n2, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, j1, n1, n2, w.getw(), &w.neededsize(), info);\
}\
inline void tgex2(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    const long int* j1,\
    const long int* n1,\
    const long int* n2,\
    long int* info)\
{\
   workspace<T> w;\
   tgex2(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, j1, n1, n2, info, w);\
}\

    LPP_TGEX2(stgex2, float)
    LPP_TGEX2(dtgex2, double)

#undef LPP_TGEX2


  // The following macro provides the 4 functions 
  /*! fn
   inline void tgex2(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       const long int* j1,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void tgex2(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       std::complex<float>* b,
       const long int* ldb,
       const std::complex<float>* q,
       const long int* ldq,
       const std::complex<float>* z,
       const long int* ldz,
       const long int* j1,
       long int* info)
  */
  /*! fn
   inline void tgex2(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       const long int* j1,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void tgex2(
       const long int* wantq,
       const long int* wantz,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       std::complex<double>* b,
       const long int* ldb,
       const std::complex<double>* q,
       const long int* ldq,
       const std::complex<double>* z,
       const long int* ldz,
       const long int* j1,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctgex2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TGEX2(NAME, T, TBASE)\
inline void tgex2(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    const long int* j1,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, j1, info);\
}\
inline void tgex2(\
    const long int* wantq,\
    const long int* wantz,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    T* b,\
    const long int* ldb,\
    const T* q,\
    const long int* ldq,\
    const T* z,\
    const long int* ldz,\
    const long int* j1,\
    long int* info)\
{\
   workspace<T> w;\
   tgex2(wantq, wantz, n, a, lda, b, ldb, q, ldq, z, ldz, j1, info, w);\
}\

    LPP_TGEX2(ctgex2, std::complex<float>,  float)
    LPP_TGEX2(ztgex2, std::complex<double>, double)

#undef LPP_TGEX2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of tgex2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
