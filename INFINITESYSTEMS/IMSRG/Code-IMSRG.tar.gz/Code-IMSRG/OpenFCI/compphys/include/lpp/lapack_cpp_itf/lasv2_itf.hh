#ifndef __PROJECT__LPP__FILE__LASV2_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASV2_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasv2_itf.hh C++ interface to LAPACK (s,d,c,z)lasv2
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasv2_itf.hh
    (excerpt adapted from xlasv2.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasv2 computes the singular value decomposition of a 2-by-2
    **  triangular matrix
    **     [  f   g  ]
    **     [  0   h  ].
    **  on return, abs(ssmax) is the larger singular value, abs(ssmin) is the
    **  smaller singular value, and (csl,snl) and (csr,snr) are the left and
    **  right singular vectors for abs(ssmax), giving the decomposition
    **
    **     [ csl  snl ] [  f   g  ] [ csr -snr ]  =  [ ssmax   0   ]
    **     [-snl  csl ] [  0   h  ] [ snr  csr ]     [  0    ssmin ].
    **
    **  arguments
    **  =========
    **
    **  f       (input) BASE DATA TYPE
    **          the (1,1) element of the 2-by-2 matrix.
    **
    **  g       (input) BASE DATA TYPE
    **          the (1,2) element of the 2-by-2 matrix.
    **
    **  h       (input) BASE DATA TYPE
    **          the (2,2) element of the 2-by-2 matrix.
    **
    **  ssmin   (output) BASE DATA TYPE
    **          abs(ssmin) is the smaller singular value.
    **
    **  ssmax   (output) BASE DATA TYPE
    **          abs(ssmax) is the larger singular value.
    **
    **  snl     (output) BASE DATA TYPE
    **  csl     (output) BASE DATA TYPE
    **          the vector (csl, snl) is a unit left singular vector for the
    **          singular value abs(ssmax).
    **
    **  snr     (output) BASE DATA TYPE
    **  csr     (output) BASE DATA TYPE
    **          the vector (csr, snr) is a unit right singular vector for the
    **          singular value abs(ssmax).
    **
    **  further details
    **  ===============
    **
    **  any input parameter may be aliased with any output parameter.
    **
    **  barring over/underflow and assuming a guard digit in subtraction, all
    **  output quantities are correct to within a few units in the last
    **  place (ulps).
    **
    **  in ieee arithmetic, the code WORKs correctly if one matrix element is
    **  infinite.
    **
    **  overflow will not occur unless the largest singular value itself
    **  overflows or is within a few ulps of overflow. (on machines with
    **  partial overflow, like the cray, overflow may occur if the largest
    **  singular value is within a factor of 2 of overflow.)
    **
    **  underflow is harmless if underflow is gradual. otherwise, results
    **  may correspond to a matrix modified by perturbations of size near
    **  the underflow threshold.
    **
    ** =====================================================================
    **
    **     .. parameters ..
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasv2(
        const float* f,
        const float* g,
        const float* h,
        float* ssmin,
        float* ssmax,
        float* snr,
        float* csr,
        float* snl,
        float* csl,
        workspace<float> & w)
  */
  /*! fn
   inline void lasv2(
        const float* f,
        const float* g,
        const float* h,
        float* ssmin,
        float* ssmax,
        float* snr,
        float* csr,
        float* snl,
        float* csl)
  */
  /*! fn
   inline void lasv2(
        const double* f,
        const double* g,
        const double* h,
        double* ssmin,
        double* ssmax,
        double* snr,
        double* csr,
        double* snl,
        double* csl,
        workspace<double> & w)
  */
  /*! fn
   inline void lasv2(
        const double* f,
        const double* g,
        const double* h,
        double* ssmin,
        double* ssmax,
        double* snr,
        double* csr,
        double* snl,
        double* csl)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasv2.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASV2(NAME, T)\
inline void lasv2(\
    const T* f,\
    const T* g,\
    const T* h,\
    T* ssmin,\
    T* ssmax,\
    T* snr,\
    T* csr,\
    T* snl,\
    T* csl,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(f, g, h, ssmin, ssmax, snr, csr, snl, csl);\
}\
inline void lasv2(\
    const T* f,\
    const T* g,\
    const T* h,\
    T* ssmin,\
    T* ssmax,\
    T* snr,\
    T* csr,\
    T* snl,\
    T* csl)\
{\
   workspace<T> w;\
   lasv2(f, g, h, ssmin, ssmax, snr, csr, snl, csl, w);\
}\

    LPP_LASV2(slasv2, float)
    LPP_LASV2(dlasv2, double)

#undef LPP_LASV2



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasv2_itf.hh
// /////////////////////////////////////////////////////////////////////////////
