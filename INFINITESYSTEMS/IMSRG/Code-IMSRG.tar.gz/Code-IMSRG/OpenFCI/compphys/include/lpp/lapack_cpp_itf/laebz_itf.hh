#ifndef __PROJECT__LPP__FILE__LAEBZ_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAEBZ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laebz_itf.hh C++ interface to LAPACK (s,d,c,z)laebz
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laebz_itf.hh
    (excerpt adapted from xlaebz.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaebz contains the iteration loops which compute and use the
    **  function n(w), which is the count of eigenvalues of a symmetric
    **  tridiagonal matrix t less than or equal to its argument  w.  it
    **  performs a choice of two types of loops:
    **
    **  ijob=1, followed by
    **  ijob=2: it takes as input a list of intervals and returns a list of
    **          sufficiently small intervals whose union contains the same
    **          eigenvalues as the union of the original intervals.
    **          the input intervals are (ab(j,1),ab(j,2)], j=1,...,minp.
    **          the output interval (ab(j,1),ab(j,2)] will contain
    **          eigenvalues nab(j,1)+1,...,nab(j,2), where 1 <= j <= mout.
    **
    **  ijob=3: it performs a binary search in each input interval
    **          (ab(j,1),ab(j,2)] for a point  w(j)  such that
    **          n(w(j))=nval(j), and uses  c(j)  as the starting point of
    **          the search.  if such a w(j) is found, then on output
    **          ab(j,1)=ab(j,2)=w.  if no such w(j) is found, then on output
    **          (ab(j,1),ab(j,2)] will be a small interval containing the
    **          point where n(w) jumps through nval(j), unless that point
    **          lies outside the initial interval.
    **
    **  note that the intervals are in all cases half-open intervals,
    **  i.e., of the form  (a,b] , which includes  b  but not  a .
    **
    **  to avoid underflow, the matrix should be scaled so that its largest
    **  element is no greater than  overflow**(1/2) * underflow**(1/4)
    **  in absolute value.  to assure the most accurate computation
    **  of small eigenvalues, the matrix should be scaled to be
    **  not much smaller than that, either.
    **
    **  see w. kahan "accurate eigenvalues of a symmetric tridiagonal
    **  matrix", report cs41, computer science dept., stanford
    **  university, july 21, 1966
    **
    **  note: the arguments are, in general, *not* checked for unreasonable
    **  values.
    **
    **  arguments
    **  =========
    **
    **  ijob    (input) long int
    **          specifies what is to be done:
    **          = 1:  compute nab for the initial intervals.
    **          = 2:  perform bisection iteration to find eigenvalues of t.
    **          = 3:  perform bisection iteration to invert n(w), i.e.,
    **                to find a point which has a specified number of
    **                eigenvalues of t to its left.
    **          other values will cause xlaebz to return with info=-1.
    **
    **  nitmax  (input) long int
    **          the maximum number of "levels" of bisection to be
    **          performed, i.e., an interval of width w will not be made
    **          smaller than 2^(-nitmax) * w.  if not all intervals
    **          have converged after nitmax iterations, then info is set
    **          to the number of non-converged intervals.
    **
    **  n       (input) long int
    **          the dimension n of the tridiagonal matrix t.  it must be at
    **          least 1.
    **
    **  mmax    (input) long int
    **          the maximum number of intervals.  if more than mmax intervals
    **          are generated, then xlaebz will quit with info=mmax+1.
    **
    **  minp    (input) long int
    **          the initial number of intervals.  it may not be greater than
    **          mmax.
    **
    **  nbmin   (input) long int
    **          the smallest number of intervals that should be processed
    **          using a vector loop.  if zero, then only the scalar loop
    **          will be used.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the minimum (absolute) width of an interval.  when an
    **          interval is narrower than abstol, or than reltol times the
    **          larger (in magnitude) endpoint, then it is considered to be
    **          sufficiently small, i.e., converged.  this must be at least
    **          zero.
    **
    **  reltol  (input) BASE DATA TYPE
    **          the minimum relative width of an interval.  when an interval
    **          is narrower than abstol, or than reltol times the larger (in
    **          magnitude) endpoint, then it is considered to be
    **          sufficiently small, i.e., converged.  note: this should
    **          always be at least radix*machine epsilon.
    **
    **  pivmin  (input) BASE DATA TYPE
    **          the minimum absolute value of a "pivot" in the sturm
    **          sequence loop.  this *must* be at least  max |e(j)**2| *
    **          safe_min  and at least safe_min, where safe_min is at least
    **          the smallest number that can divide one without overflow.
    **
    **  d       (input) BASE DATA TYPE array, dimension (n)
    **          the diagonal elements of the tridiagonal matrix t.
    **
    **  e       (input) BASE DATA TYPE array, dimension (n)
    **          the offdiagonal elements of the tridiagonal matrix t in
    **          positions 1 through n-1.  e(n) is arbitrary.
    **
    **  e2      (input) BASE DATA TYPE array, dimension (n)
    **          the squares of the offdiagonal elements of the tridiagonal
    **          matrix t.  e2(n) is ignored.
    **
    **  nval    (input/output) long int array, dimension (minp)
    **          if ijob=1 or 2, not referenced.
    **          if ijob=3, the desired values of n(w).  the elements of nval
    **          will be reordered to correspond with the intervals in ab.
    **          thus, nval(j) on output will not, in general be the same as
    **          nval(j) on input, but it will correspond with the interval
    **          (ab(j,1),ab(j,2)] on output.
    **
    **  ab      (input/output) BASE DATA TYPE array, dimension (mmax,2)
    **          the endpoints of the intervals.  ab(j,1) is  a(j), the left
    **          endpoint of the j-th interval, and ab(j,2) is b(j), the
    **          right endpoint of the j-th interval.  the input intervals
    **          will, in general, be modified, split, and reordered by the
    **          calculation.
    **
    **  c       (input/output) BASE DATA TYPE array, dimension (mmax)
    **          if ijob=1, ignored.
    **          if ijob=2, WORKspace.
    **          if ijob=3, then on input c(j) should be initialized to the
    **          first search point in the binary search.
    **
    **  mout    (output) long int
    **          if ijob=1, the number of eigenvalues in the intervals.
    **          if ijob=2 or 3, the number of intervals output.
    **          if ijob=3, mout will equal minp.
    **
    **  nab     (input/output) long int array, dimension (mmax,2)
    **          if ijob=1, then on output nab(i,j) will be set to n(ab(i,j)).
    **          if ijob=2, then on input, nab(i,j) should be set.  it must
    **             satisfy the condition:
    **             n(ab(i,1)) <= nab(i,1) <= nab(i,2) <= n(ab(i,2)),
    **             which means that in interval i only eigenvalues
    **             nab(i,1)+1,...,nab(i,2) will be considered.  usually,
    **             nab(i,j)=n(ab(i,j)), from a previous call to xlaebz with
    **             ijob=1.
    **             on output, nab(i,j) will contain
    **             max(na(k),min(nb(k),n(ab(i,j)))), where k is the index of
    **             the input interval that the output interval
    **             (ab(j,1),ab(j,2)] came from, and na(k) and nb(k) are the
    **             the input values of nab(k,1) and nab(k,2).
    **          if ijob=3, then on output, nab(i,j) contains n(ab(i,j)),
    **             unless n(w) > nval(i) for all search points  w , in which
    **             case nab(i,1) will not be modified, i.e., the output
    **             value will be the same as the input value (modulo
    **             reorderings -- see nval and ab), or unless n(w) < nval(i)
    **             for all search points  w , in which case nab(i,2) will
    **             not be modified.  normally, nab should be set to some
    **             distinctive value(s) before xlaebz is called.
    **
    **
    **
    **  info    (output) long int
    **          = 0:       all intervals converged.
    **          = 1--mmax: the last info intervals did not converge.
    **          = mmax+1:  more than mmax intervals were generated.
    **
    **  further details
    **  ===============
    **
    **      this routine is intended to be called only by other lapack
    **  routines, thus the interface is less user-friendly.  it is intended
    **  for two purposes:
    **
    **  (a) finding eigenvalues.  in this case, xlaebz should have one or
    **      more initial intervals set up in ab, and xlaebz should be called
    **      with ijob=1.  this sets up nab, and also counts the eigenvalues.
    **      intervals with no eigenvalues would usually be thrown out at
    **      this point.  also, if not all the eigenvalues in an interval i
    **      are desired, nab(i,1) can be increased or nab(i,2) decreased.
    **      for example, set nab(i,1)=nab(i,2)-1 to get the largest
    **      eigenvalue.  xlaebz is then called with ijob=2 and mmax
    **      no smaller than the value of mout returned by the call with
    **      ijob=1.  after this (ijob=2) call, eigenvalues nab(i,1)+1
    **      through nab(i,2) are approximately ab(i,1) (or ab(i,2)) to the
    **      tolerance specified by abstol and reltol.
    **
    **  (b) finding an interval (a',b'] containing eigenvalues w(f),...,w(l).
    **      in this case, start with a gershgorin interval  (a,b).  set up
    **      ab to contain 2 search intervals, both initially (a,b).  one
    **      nval element should contain  f-1  and the other should contain  l
    **      , while c should contain a and b, resp.  nab(i,1) should be -1
    **      and nab(i,2) should be n+1, to flag an error if the desired
    **      interval does not lie in (a,b).  xlaebz is then called with
    **      ijob=3.  on exit, if w(f-1) < w(f), then one of the intervals --
    **      j -- will have ab(j,1)=ab(j,2) and nab(j,1)=nab(j,2)=f-1, while
    **      if, to the specified tolerance, w(f-k)=...=w(f+r), k > 0 and r
    **      >= 0, then the interval will have  n(ab(j,1))=nab(j,1)=f-k and
    **      n(ab(j,2))=nab(j,2)=f+r.  the cases w(l) < w(l+1) and
    **      w(l-r)=...=w(l+k) are handled similarly.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laebz(
        const long int* ijob,
        const long int* nitmax,
        const long int* n,
        const long int* mmax,
        const long int* minp,
        const long int* nbmin,
        const float* abstol,
        const float* reltol,
        const float* pivmin,
        const float* d,
        const float* e,
        const float* e2,
        long int* nval,
        const float* ab,
        float* c,
        long int* mout,
        long int* nab,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laebz(
        const long int* ijob,
        const long int* nitmax,
        const long int* n,
        const long int* mmax,
        const long int* minp,
        const long int* nbmin,
        const float* abstol,
        const float* reltol,
        const float* pivmin,
        const float* d,
        const float* e,
        const float* e2,
        long int* nval,
        const float* ab,
        float* c,
        long int* mout,
        long int* nab,
        long int* info)
  */
  /*! fn
   inline void laebz(
        const long int* ijob,
        const long int* nitmax,
        const long int* n,
        const long int* mmax,
        const long int* minp,
        const long int* nbmin,
        const double* abstol,
        const double* reltol,
        const double* pivmin,
        const double* d,
        const double* e,
        const double* e2,
        long int* nval,
        const double* ab,
        double* c,
        long int* mout,
        long int* nab,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laebz(
        const long int* ijob,
        const long int* nitmax,
        const long int* n,
        const long int* mmax,
        const long int* minp,
        const long int* nbmin,
        const double* abstol,
        const double* reltol,
        const double* pivmin,
        const double* d,
        const double* e,
        const double* e2,
        long int* nval,
        const double* ab,
        double* c,
        long int* mout,
        long int* nab,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaebz.f)
  //    *  WORK    (workspace) float array, dimension (MMAX)
  //    *          Workspace.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (MMAX)
  //    *          Workspace.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAEBZ(NAME, T)\
inline void laebz(\
    const long int* ijob,\
    const long int* nitmax,\
    const long int* n,\
    const long int* mmax,\
    const long int* minp,\
    const long int* nbmin,\
    const T* abstol,\
    const T* reltol,\
    const T* pivmin,\
    const T* d,\
    const T* e,\
    const T* e2,\
    long int* nval,\
    const T* ab,\
    T* c,\
    long int* mout,\
    long int* nab,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*mmax);\
    w.resizew(*mmax);\
    F77NAME( NAME )(ijob, nitmax, n, mmax, minp, nbmin, abstol, reltol, pivmin, d, e, e2, nval, ab, c, mout, nab, w.getw(), w.getiw(), info);\
}\
inline void laebz(\
    const long int* ijob,\
    const long int* nitmax,\
    const long int* n,\
    const long int* mmax,\
    const long int* minp,\
    const long int* nbmin,\
    const T* abstol,\
    const T* reltol,\
    const T* pivmin,\
    const T* d,\
    const T* e,\
    const T* e2,\
    long int* nval,\
    const T* ab,\
    T* c,\
    long int* mout,\
    long int* nab,\
    long int* info)\
{\
   workspace<T> w;\
   laebz(ijob, nitmax, n, mmax, minp, nbmin, abstol, reltol, pivmin, d, e, e2, nval, ab, c, mout, nab, info, w);\
}\

    LPP_LAEBZ(slaebz, float)
    LPP_LAEBZ(dlaebz, double)

#undef LPP_LAEBZ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laebz_itf.hh
// /////////////////////////////////////////////////////////////////////////////
