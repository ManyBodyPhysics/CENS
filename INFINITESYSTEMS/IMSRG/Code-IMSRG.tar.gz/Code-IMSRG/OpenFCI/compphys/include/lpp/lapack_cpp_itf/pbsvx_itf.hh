#ifndef __PROJECT__LPP__FILE__PBSVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__PBSVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : pbsvx_itf.hh C++ interface to LAPACK (s,d,c,z)pbsvx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file pbsvx_itf.hh
    (excerpt adapted from xpbsvx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xpbsvx uses the cholesky factorization a = u**h*u or a = l*l**h to
    **  compute the solution to a DATA TYPE system of linear equations
    **     a * x = b,
    **  where a is an n-by-n hermitian positive definite band matrix and x
    **  and b are n-by-nrhs matrices.
    **
    **  error bounds on the solution and a condition estimate are also
    **  provided.
    **
    **  description
    **  ===========
    **
    **  the following steps are performed:
    **
    **  1. if fact = 'e', BASE DATA TYPE scaling factors are computed to equilibrate
    **     the system:
    **        diag(s) * a * diag(s) * inv(diag(s)) * x = diag(s) * b
    **     whether or not the system will be equilibrated depends on the
    **     scaling of the matrix a, but if equilibration is used, a is
    **     overwritten by diag(s)*a*diag(s) and b by diag(s)*b.
    **
    **  2. if fact = 'n' or 'e', the cholesky decomposition is used to
    **     factor the matrix a (after equilibration if fact = 'e') as
    **        a = u**h * u,  if uplo = 'u', or
    **        a = l * l**h,  if uplo = 'l',
    **     where u is an upper triangular band matrix, and l is a lower
    **     triangular band matrix.
    **
    **  3. if the leading i-by-i principal minor is not positive definite,
    **     then the routine returns with info = i. otherwise, the factored
    **     form of a is used to estimate the condition number of the matrix
    **     a.  if the reciprocal of the condition number is less than machine
    **     precision, info = n+1 is returned as a warning, but the routine
    **     still goes on to solve for x and compute error bounds as
    **     described below.
    **
    **  4. the system of equations is solved for x using the factored form
    **     of a.
    **
    **  5. iterative refinement is applied to improve the computed solution
    **     matrix and calculate error bounds and backward error estimates
    **     for it.
    **
    **  6. if equilibration was used, the matrix x is premultiplied by
    **     diag(s) so that it solves the original system before
    **     equilibration.
    **
    **  arguments
    **  =========
    **
    **  fact    (input) char
    **          specifies whether or not the factored form of the matrix a is
    **          supplied on entry, and if not, whether the matrix a should be
    **          equilibrated before it is factored.
    **          = 'f':  on entry, afb contains the factored form of a.
    **                  if equed = 'y', the matrix a has been equilibrated
    **                  with scaling factors given by s.  ab and afb will not
    **                  be modified.
    **          = 'n':  the matrix a will be copied to afb and factored.
    **          = 'e':  the matrix a will be equilibrated if necessary, then
    **                  copied to afb and factored.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  kd      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  kd >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right-hand sides, i.e., the number of columns
    **          of the matrices b and x.  nrhs >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the upper or lower triangle of the hermitian band
    **          matrix a, stored in the first kd+1 rows of the array, except
    **          if fact = 'f' and equed = 'y', then a must contain the
    **          equilibrated matrix diag(s)*a*diag(s).  the j-th column of a
    **          is stored in the j-th column of the array ab as follows:
    **          if uplo = 'u', ab(kd+1+i-j,j) = a(i,j) for max(1,j-kd)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+kd).
    **          see below for further details.
    **
    **          on exit, if fact = 'e' and equed = 'y', a is overwritten by
    **          diag(s)*a*diag(s).
    **
    **  ldab    (input) long int
    **          the leading dimension of the array a.  ldab >= kd+1.
    **
    **  afb     (input or output) DATA TYPE array, dimension (ldafb,n)
    **          if fact = 'f', then afb is an input argument and on entry
    **          contains the triangular factor u or l from the cholesky
    **          factorization a = u**h*u or a = l*l**h of the band matrix
    **          a, in the same storage format as a (see ab).  if equed = 'y',
    **          then afb is the factored form of the equilibrated matrix a.
    **
    **          if fact = 'n', then afb is an output argument and on exit
    **          returns the triangular factor u or l from the cholesky
    **          factorization a = u**h*u or a = l*l**h.
    **
    **          if fact = 'e', then afb is an output argument and on exit
    **          returns the triangular factor u or l from the cholesky
    **          factorization a = u**h*u or a = l*l**h of the equilibrated
    **          matrix a (see the description of a for the form of the
    **          equilibrated matrix).
    **
    **  ldafb   (input) long int
    **          the leading dimension of the array afb.  ldafb >= kd+1.
    **
    **  equed   (input or output) char
    **          specifies the form of equilibration that was done.
    **          = 'n':  no equilibration (always true if fact = 'n').
    **          = 'y':  equilibration was done, i.e., a has been replaced by
    **                  diag(s) * a * diag(s).
    **          equed is an input argument if fact = 'f'; otherwise, it is an
    **          output argument.
    **
    **  s       (input or output) BASE DATA TYPE array, dimension (n)
    **          the scale factors for a; not accessed if equed = 'n'.  s is
    **          an input argument if fact = 'f'; otherwise, s is an output
    **          argument.  if fact = 'f' and equed = 'y', each element of s
    **          must be positive.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if equed = 'n', b is not modified; if equed = 'y',
    **          b is overwritten by diag(s) * b.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **  x       (output) DATA TYPE array, dimension (ldx,nrhs)
    **          if info = 0 or info = n+1, the n-by-nrhs solution matrix x to
    **          the original system of equations.  note that if equed = 'y',
    **          a and b are modified on exit, and the solution to the
    **          equilibrated system is inv(diag(s))*x.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.  ldx >= max(1,n).
    **
    **  rcond   (output) BASE DATA TYPE
    **          the estimate of the reciprocal condition number of the matrix
    **          a after equilibration (if done).  if rcond is less than the
    **          machine precision (in particular, if rcond = 0), the matrix
    **          is singular to WORKing precision.  this condition is
    **          indicated by a return code of info > 0.
    **
    **  ferr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the estimated forward error bound for each solution vector
    **          x(j) (the j-th column of the solution matrix x).
    **          if xtrue is the true solution corresponding to x(j), ferr(j)
    **          is an estimated upper bound for the magnitude of the largest
    **          element in (x(j) - xtrue) divided by the magnitude of the
    **          largest element in x(j).  the estimate is as reliable as
    **          the estimate for rcond, and is almost always a slight
    **          overestimate of the true error.
    **
    **  berr    (output) BASE DATA TYPE array, dimension (nrhs)
    **          the componentwise relative backward error of each solution
    **          vector x(j) (i.e., the smallest relative change in
    **          any element of a or b that makes x(j) an exact solution).
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, and i is
    **                <= n:  the leading minor of order i of a is
    **                       not positive definite, so the factorization
    **                       could not be completed, and the solution has not
    **                       been computed. rcond = 0 is returned.
    **                = n+1: u is nonsingular, but rcond is less than machine
    **                       precision, meaning that the matrix is singular
    **                       to WORKing precision.  nevertheless, the
    **                       solution and error bounds are computed because
    **                       there are a number of situations where the
    **                       computed solution can be more accurate than the
    **                       value of rcond would suggest.
    **
    **  further details
    **  ===============
    **
    **  the band storage scheme is illustrated by the following example, when
    **  n = 6, kd = 2, and uplo = 'u':
    **
    **  two-dimensional storage of the hermitian matrix a:
    **
    **     a11  a12  a13
    **          a22  a23  a24
    **               a33  a34  a35
    **                    a44  a45  a46
    **                         a55  a56
    **     (aij=conjg(aji))         a66
    **
    **  band storage of the upper triangle of a:
    **
    **      *    *   a13  a24  a35  a46
    **      *   a12  a23  a34  a45  a56
    **     a11  a22  a33  a44  a55  a66
    **
    **  similarly, if uplo = 'l' the format of a is as follows:
    **
    **     a11  a22  a33  a44  a55  a66
    **     a21  a32  a43  a54  a65   *
    **     a31  a42  a53  a64   *    *
    **
    **  array elements marked * are not used by the routine.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void pbsvx(
        const char* fact,
        const char* uplo,
        const long int* n,
        const long int* kd,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        float* afb,
        const long int* ldafb,
        char* equed,
        const float* s,
        float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void pbsvx(
        const char* fact,
        const char* uplo,
        const long int* n,
        const long int* kd,
        const long int* nrhs,
        float* ab,
        const long int* ldab,
        float* afb,
        const long int* ldafb,
        char* equed,
        const float* s,
        float* b,
        const long int* ldb,
        float* x,
        const long int* ldx,
        float* rcond,
        float* ferr,
        float* berr,
        long int* info)
  */
  /*! fn
   inline void pbsvx(
        const char* fact,
        const char* uplo,
        const long int* n,
        const long int* kd,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        double* afb,
        const long int* ldafb,
        char* equed,
        const double* s,
        double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void pbsvx(
        const char* fact,
        const char* uplo,
        const long int* n,
        const long int* kd,
        const long int* nrhs,
        double* ab,
        const long int* ldab,
        double* afb,
        const long int* ldafb,
        char* equed,
        const double* s,
        double* b,
        const long int* ldb,
        double* x,
        const long int* ldx,
        double* rcond,
        double* ferr,
        double* berr,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from spbsvx.f)
  //    *  WORK    (workspace) float array, dimension (3*N)
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBSVX(NAME, T)\
inline void pbsvx(\
    const char* fact,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    char* equed,\
    const T* s,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw((*n));\
    w.resizew(3*(*n));\
    F77NAME( NAME )(fact, uplo, n, kd, nrhs, ab, ldab, afb, ldafb, equed, s, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getiw(), info);\
}\
inline void pbsvx(\
    const char* fact,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    char* equed,\
    const T* s,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    T* rcond,\
    T* ferr,\
    T* berr,\
    long int* info)\
{\
   workspace<T> w;\
   pbsvx(fact, uplo, n, kd, nrhs, ab, ldab, afb, ldafb, equed, s, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_PBSVX(spbsvx, float)
    LPP_PBSVX(dpbsvx, double)

#undef LPP_PBSVX


  // The following macro provides the 4 functions 
  /*! fn
   inline void pbsvx(
       const char* fact,
       const char* uplo,
       const long int* n,
       const long int* kd,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* afb,
       const long int* ldafb,
       char* equed,
       const float* s,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void pbsvx(
       const char* fact,
       const char* uplo,
       const long int* n,
       const long int* kd,
       const long int* nrhs,
       std::complex<float>* ab,
       const long int* ldab,
       std::complex<float>* afb,
       const long int* ldafb,
       char* equed,
       const float* s,
       std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* x,
       const long int* ldx,
       float* rcond,
       float* ferr,
       float* berr,
       long int* info)
  */
  /*! fn
   inline void pbsvx(
       const char* fact,
       const char* uplo,
       const long int* n,
       const long int* kd,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* afb,
       const long int* ldafb,
       char* equed,
       const double* s,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void pbsvx(
       const char* fact,
       const char* uplo,
       const long int* n,
       const long int* kd,
       const long int* nrhs,
       std::complex<double>* ab,
       const long int* ldab,
       std::complex<double>* afb,
       const long int* ldafb,
       char* equed,
       const double* s,
       std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* x,
       const long int* ldx,
       double* rcond,
       double* ferr,
       double* berr,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cpbsvx.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_PBSVX(NAME, T, TBASE)\
inline void pbsvx(\
    const char* fact,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    char* equed,\
    const TBASE* s,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    w.resizew(2*(*n));\
    F77NAME( NAME )(fact, uplo, n, kd, nrhs, ab, ldab, afb, ldafb, equed, s, b, ldb, x, ldx, rcond, ferr, berr, w.getw(), w.getrw(), info);\
}\
inline void pbsvx(\
    const char* fact,\
    const char* uplo,\
    const long int* n,\
    const long int* kd,\
    const long int* nrhs,\
    T* ab,\
    const long int* ldab,\
    T* afb,\
    const long int* ldafb,\
    char* equed,\
    const TBASE* s,\
    T* b,\
    const long int* ldb,\
    T* x,\
    const long int* ldx,\
    TBASE* rcond,\
    TBASE* ferr,\
    TBASE* berr,\
    long int* info)\
{\
   workspace<T> w;\
   pbsvx(fact, uplo, n, kd, nrhs, ab, ldab, afb, ldafb, equed, s, b, ldb, x, ldx, rcond, ferr, berr, info, w);\
}\

    LPP_PBSVX(cpbsvx, std::complex<float>, float)
    LPP_PBSVX(zpbsvx, std::complex<double>, double)

#undef LPP_PBSVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of pbsvx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
