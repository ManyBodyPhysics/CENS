#ifndef __PROJECT__LPP__FILE__GGEVX_HH__INCLUDED
#define __PROJECT__LPP__FILE__GGEVX_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : ggevx_itf.hh C++ interface to LAPACK (c,d,c,z)ggevx
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file ggevx_itf.hh
    (excerpt adapted from xggevx.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xggevx computes for a pair of n-by-n DATA TYPE nonsymmetric matrices
    **  (a,b) the generalized eigenvalues, and optionally, the left and/or
    **  right generalized eigenvectors.
    **
    **  optionally, it also computes a balancing transformation to improve
    **  the conditioning of the eigenvalues and eigenvectors (ilo, ihi,
    **  lscale, rscale, abnrm, and bbnrm), reciprocal condition numbers for
    **  the eigenvalues (rconde), and reciprocal condition numbers for the
    **  right eigenvectors (rcondv).
    **
    **  a generalized eigenvalue for a pair of matrices (a,b) is a scalar
    **  lambda or a ratio alpha/beta = lambda, such that a - lambda*b is
    **  singular. it is usually represented as the pair (alpha,beta), as
    **  there is a reasonable interpretation for beta=0, and even for both
    **  being zero.
    **
    **  the right eigenvector v(j) corresponding to the eigenvalue lambda(j)
    **  of (a,b) satisfies
    **                   a * v(j) = lambda(j) * b * v(j) .
    **  the left eigenvector u(j) corresponding to the eigenvalue lambda(j)
    **  of (a,b) satisfies
    **                   u(j)**h * a  = lambda(j) * u(j)**h * b.
    **  where u(j)**h is the conjugate-transpose of u(j).
    **
    **
    **  arguments
    **  =========
    **
    **  balanc  (input) char
    **          specifies the balance option to be performed:
    **          = 'n':  do not diagonally scale or permute;
    **          = 'p':  permute only;
    **          = 's':  scale only;
    **          = 'b':  both permute and scale.
    **          computed reciprocal condition numbers will be for the
    **          matrices after permuting and/or balancing. permuting does
    **          not change condition numbers (in exact arithmetic), but
    **          balancing does.
    **
    **  jobvl   (input) char
    **          = 'n':  do not compute the left generalized eigenvectors;
    **          = 'v':  compute the left generalized eigenvectors.
    **
    **  jobvr   (input) char
    **          = 'n':  do not compute the right generalized eigenvectors;
    **          = 'v':  compute the right generalized eigenvectors.
    **
    **  sense   (input) char
    **          determines which reciprocal condition numbers are computed.
    **          = 'n': none are computed;
    **          = 'e': computed for eigenvalues only;
    **          = 'v': computed for eigenvectors only;
    **          = 'b': computed for eigenvalues and eigenvectors.
    **
    **  n       (input) long int
    **          the order of the matrices a, b, vl, and vr.  n >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda, n)
    **          on entry, the matrix a in the pair (a,b).
    **          on exit, a has been overwritten. if jobvl='v' or jobvr='v'
    **          or both, then a contains the first part of the DATA TYPE schur
    **          form of the "balanced" versions of the input a and b.
    **
    **  lda     (input) long int
    **          the leading dimension of a.  lda >= max(1,n).
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb, n)
    **          on entry, the matrix b in the pair (a,b).
    **          on exit, b has been overwritten. if jobvl='v' or jobvr='v'
    **          or both, then b contains the second part of the DATA TYPE
    **          schur form of the "balanced" versions of the input a and b.
    **
    **  ldb     (input) long int
    **          the leading dimension of b.  ldb >= max(1,n).
    **
    **  alpha   (output) DATA TYPE array, dimension (n)
    **  beta    (output) DATA TYPE array, dimension (n)
    **          on exit, alpha(j)/beta(j), j=1,...,n, will be the generalized
    **          eigenvalues.
    **
    **          note: the quotient alpha(j)/beta(j) ) may easily over- or
    **          underflow, and beta(j) may even be zero.  thus, the user
    **          should avoid naively computing the ratio alpha/beta.
    **          however, alpha will be always less than and usually
    **          comparable with norm(a) in magnitude, and beta always less
    **          than and usually comparable with norm(b).
    **
    **  vl      (output) DATA TYPE array, dimension (ldvl,n)
    **          if jobvl = 'v', the left generalized eigenvectors u(j) are
    **          stored one after another in the columns of vl, in the same
    **          order as their eigenvalues.
    **          each eigenvector will be scaled so the largest component
    **          will have abs(BASE DATA TYPE part) + abs(imag. part) = 1.
    **          not referenced if jobvl = 'n'.
    **
    **  ldvl    (input) long int
    **          the leading dimension of the matrix vl. ldvl >= 1, and
    **          if jobvl = 'v', ldvl >= n.
    **
    **  vr      (output) DATA TYPE array, dimension (ldvr,n)
    **          if jobvr = 'v', the right generalized eigenvectors v(j) are
    **          stored one after another in the columns of vr, in the same
    **          order as their eigenvalues.
    **          each eigenvector will be scaled so the largest component
    **          will have abs(BASE DATA TYPE part) + abs(imag. part) = 1.
    **          not referenced if jobvr = 'n'.
    **
    **  ldvr    (input) long int
    **          the leading dimension of the matrix vr. ldvr >= 1, and
    **          if jobvr = 'v', ldvr >= n.
    **
    **  ilo,ihi (output) long int
    **          ilo and ihi are integer values such that on exit
    **          a(i,j) = 0 and b(i,j) = 0 if i > j and
    **          j = 1,...,ilo-1 or i = ihi+1,...,n.
    **          if balanc = 'n' or 's', ilo = 1 and ihi = n.
    **
    **  lscale  (output) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and scaling factors applied
    **          to the left side of a and b.  if pl(j) is the index of the
    **          row interchanged with row j, and dl(j) is the scaling
    **          factor applied to row j, then
    **            lscale(j) = pl(j)  for j = 1,...,ilo-1
    **                      = dl(j)  for j = ilo,...,ihi
    **                      = pl(j)  for j = ihi+1,...,n.
    **          the order in which the interchanges are made is n to ihi+1,
    **          then 1 to ilo-1.
    **
    **  rscale  (output) BASE DATA TYPE array, dimension (n)
    **          details of the permutations and scaling factors applied
    **          to the right side of a and b.  if pr(j) is the index of the
    **          column interchanged with column j, and dr(j) is the scaling
    **          factor applied to column j, then
    **            rscale(j) = pr(j)  for j = 1,...,ilo-1
    **                      = dr(j)  for j = ilo,...,ihi
    **                      = pr(j)  for j = ihi+1,...,n
    **          the order in which the interchanges are made is n to ihi+1,
    **          then 1 to ilo-1.
    **
    **  abnrm   (output) BASE DATA TYPE
    **          the one-norm of the balanced matrix a.
    **
    **  bbnrm   (output) BASE DATA TYPE
    **          the one-norm of the balanced matrix b.
    **
    **  rconde  (output) BASE DATA TYPE array, dimension (n)
    **          if sense = 'e' or 'b', the reciprocal condition numbers of
    **          the selected eigenvalues, stored in consecutive elements of
    **          the array.
    **          if sense = 'v', rconde is not referenced.
    **
    **  rcondv  (output) BASE DATA TYPE array, dimension (n)
    **          if job = 'v' or 'b', the estimated reciprocal condition
    **          numbers of the selected eigenvectors, stored in consecutive
    **          elements of the array. if the eigenvalues cannot be reordered
    **          to compute rcondv(j), rcondv(j) is set to 0; this can only
    **          occur when the true value would be very small anyway.
    **          if sense = 'e', rcondv is not referenced.
    **          not referenced if job = 'e'.
    **
    **
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          = 1,...,n:
    **                the qz iteration failed.  no eigenvectors have been
    **                calculated, but alpha(j) and beta(j) should be correct
    **                for j=info+1,...,n.
    **          > n:  =n+1: other than qz iteration failed in chgeqz.
    **                =n+2: error return from ctgevc.
    **
    **  further details
    **  ===============
    **
    **  balancing a matrix pair (a,b) includes, first, permuting rows and
    **  columns to isolate eigenvalues, second, applying diagonal similarity
    **  transformation to the rows and columns to make the rows and columns
    **  as close in norm as possible. the computed reciprocal condition
    **  numbers correspond to the balanced matrix. permuting rows and columns
    **  will not change the condition numbers (in exact arithmetic) but
    **  diagonal scaling will.  for further explanation of balancing, see
    **  section 4.11.1.2 of lapack users' guide.
    **
    **  an approximate error bound on the chordal distance between the i-th
    **  computed generalized eigenvalue w and the corresponding exact
    **  eigenvalue lambda is
    **
    **       chord(w, lambda) <= eps * norm(abnrm, bbnrm) / rconde(i)
    **
    **  an approximate error bound for the angle between the i-th computed
    **  eigenvector vl(i) or vr(i) is given by
    **
    **       eps * norm(abnrm, bbnrm) / dif(i).
    **
    **  for further explanation of the reciprocal condition numbers rconde
    **  and rcondv, see section 4.11 of lapack user's guide.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void ggevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        float* lscale,
        float* rscale,
        float* abnrm,
        float* bbnrm,
        float* rconde,
        float* rcondv,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void ggevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const float* a,
        const long int* lda,
        const float* b,
        const long int* ldb,
        float* alphar,
        float* alphai,
        float* beta,
        const float* vl,
        const long int* ldvl,
        const float* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        float* lscale,
        float* rscale,
        float* abnrm,
        float* bbnrm,
        float* rconde,
        float* rcondv,
        long int* info)
  */
  /*! fn
   inline void ggevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        double* lscale,
        double* rscale,
        double* abnrm,
        double* bbnrm,
        double* rconde,
        double* rcondv,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void ggevx(
        const char* balanc,
        const char* jobvl,
        const char* jobvr,
        const char* sense,
        const long int* n,
        const double* a,
        const long int* lda,
        const double* b,
        const long int* ldb,
        double* alphar,
        double* alphai,
        double* beta,
        const double* vl,
        const long int* ldvl,
        const double* vr,
        const long int* ldvr,
        long int* ilo,
        long int* ihi,
        double* lscale,
        double* rscale,
        double* abnrm,
        double* bbnrm,
        double* rconde,
        double* rcondv,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sggevx.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,6*N).
  //    *          If SENSE = 'E', LWORK >= 12*N.
  //    *          If SENSE = 'V' or 'B', LWORK >= 2*N*N+12*N+16.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N+6)
  //    *          If SENSE = 'E', IWORK is not referenced.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          If SENSE = 'N', BWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGEVX(NAME, T)\
inline void ggevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    T* lscale,\
    T* rscale,\
    T* abnrm,\
    T* bbnrm,\
    T* rconde,\
    T* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*n+6);\
    w.resizebw(*n);\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, w.getw(), w.query(), w.getiw(), w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, w.getw(), &w.neededsize(), w.getiw(), w.getbw(), info);\
}\
inline void ggevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alphar,\
    T* alphai,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    T* lscale,\
    T* rscale,\
    T* abnrm,\
    T* bbnrm,\
    T* rconde,\
    T* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   ggevx(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alphar, alphai, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, info, w);\
}\

    LPP_GGEVX(sggevx, float)
    LPP_GGEVX(dggevx, double)

#undef LPP_GGEVX


  // The following macro provides the 4 functions 
  /*! fn
   inline void ggevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       float* lscale,
       float* rscale,
       float* abnrm,
       float* bbnrm,
       float* rconde,
       float* rcondv,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void ggevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<float>* a,
       const long int* lda,
       const std::complex<float>* b,
       const long int* ldb,
       std::complex<float>* alpha,
       std::complex<float>* beta,
       const std::complex<float>* vl,
       const long int* ldvl,
       const std::complex<float>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       float* lscale,
       float* rscale,
       float* abnrm,
       float* bbnrm,
       float* rconde,
       float* rcondv,
       long int* info)
  */
  /*! fn
   inline void ggevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       double* lscale,
       double* rscale,
       double* abnrm,
       double* bbnrm,
       double* rconde,
       double* rcondv,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void ggevx(
       const char* balanc,
       const char* jobvl,
       const char* jobvr,
       const char* sense,
       const long int* n,
       const std::complex<double>* a,
       const long int* lda,
       const std::complex<double>* b,
       const long int* ldb,
       std::complex<double>* alpha,
       std::complex<double>* beta,
       const std::complex<double>* vl,
       const long int* ldvl,
       const std::complex<double>* vr,
       const long int* ldvr,
       long int* ilo,
       long int* ihi,
       double* lscale,
       double* rscale,
       double* abnrm,
       double* bbnrm,
       double* rconde,
       double* rcondv,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cggevx.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK. LWORK >= max(1,2*N).
  //    *          If SENSE = 'N' or 'E', LWORK >= 2*N.
  //    *          If SENSE = 'V' or 'B', LWORK >= 2*N*N+2*N.
  //    *
  //    *          If LWORK = -1, a workspace query is assumed.  The optimal
  //    *          size for the WORK array is calculated and stored in WORK(1),
  //    *          and no other work except argument checking is performed.
  //    *
  //    *  RWORK   (workspace) float array, dimension (6*N)
  //    *          Real workspace.
  //    *
  //    *  IWORK   (workspace) long int array, dimension (N+2)
  //    *          If SENSE = 'E', IWORK is not referenced.
  //    *
  //    *  BWORK   (workspace) LOGICAL array, dimension (N)
  //    *          If SENSE = 'N', BWORK is not referenced.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_GGEVX(NAME, T, TBASE)\
inline void ggevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    TBASE* lscale,\
    TBASE* rscale,\
    TBASE* abnrm,\
    TBASE* bbnrm,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(6**n);\
    w.resizeiw(*n+2);\
    w.resizebw(*n);\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, w.getw(), w.query(), w.getrw(), w.getiw(), w.getbw(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, w.getw(), &w.neededsize(), w.getrw(), w.getiw(), w.getbw(), info);\
}\
inline void ggevx(\
    const char* balanc,\
    const char* jobvl,\
    const char* jobvr,\
    const char* sense,\
    const long int* n,\
    const T* a,\
    const long int* lda,\
    const T* b,\
    const long int* ldb,\
    T* alpha,\
    T* beta,\
    const T* vl,\
    const long int* ldvl,\
    const T* vr,\
    const long int* ldvr,\
    long int* ilo,\
    long int* ihi,\
    TBASE* lscale,\
    TBASE* rscale,\
    TBASE* abnrm,\
    TBASE* bbnrm,\
    TBASE* rconde,\
    TBASE* rcondv,\
    long int* info)\
{\
   workspace<T> w;\
   ggevx(balanc, jobvl, jobvr, sense, n, a, lda, b, ldb, alpha, beta, vl, ldvl, vr, ldvr, ilo, ihi, lscale, rscale, abnrm, bbnrm, rconde, rcondv, info, w);\
}\

    LPP_GGEVX(cggevx, std::complex<float>,  float)
    LPP_GGEVX(zggevx, std::complex<double>, double)

#undef LPP_GGEVX



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of ggevx_itf.hh
// /////////////////////////////////////////////////////////////////////////////
