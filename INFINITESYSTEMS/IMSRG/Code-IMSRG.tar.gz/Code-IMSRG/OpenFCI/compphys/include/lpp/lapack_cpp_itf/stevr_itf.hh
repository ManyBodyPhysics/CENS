#ifndef __PROJECT__LPP__FILE__STEVR_HH__INCLUDED
#define __PROJECT__LPP__FILE__STEVR_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : stevr_itf.hh C++ interface to LAPACK (s,d,c,z)stevr
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file stevr_itf.hh
    (excerpt adapted from xstevr.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xstevr computes selected eigenvalues and, optionally, eigenvectors
    **  of a BASE DATA TYPE symmetric tridiagonal matrix t.  eigenvalues and
    **  eigenvectors can be selected by specifying either a range of values
    **  or a range of indices for the desired eigenvalues.
    **
    **  whenever possible, xstevr calls sstegr to compute the
    **  eigenspectrum using relatively robust representations.  dstegr
    **  computes eigenvalues by the dqds algorithm, while orthogonal
    **  eigenvectors are computed from various "good" l d l^t representations
    **  (also known as relatively robust representations). gram-schmidt
    **  orthogonalization is avoided as far as possible. more specifically,
    **  the various steps of the algorithm are as follows. for the i-th
    **  unreduced block of t,
    **     (a) compute t - sigma_i = l_i d_i l_i^t, such that l_i d_i l_i^t
    **          is a relatively robust representation,
    **     (b) compute the eigenvalues, lambda_j, of l_i d_i l_i^t to high
    **         relative accuracy by the dqds algorithm,
    **     (c) if there is a cluster of close eigenvalues, "choose" sigma_i
    **         close to the cluster, and go to step (a),
    **     (d) given the approximate eigenvalue lambda_j of l_i d_i l_i^t,
    **         compute the corresponding eigenvector by forming a
    **         rank-revealing twisted factorization.
    **  the desired accuracy of the output can be specified by the input
    **  parameter abstol.
    **
    **  for more details, see "a new o(n^2) algorithm for the symmetric
    **  tridiagonal eigenvalue/eigenvector problem", by inderjit dhillon,
    **  computer science division technical report no. ucb//csd-97-971,
    **  uc berkeley, may 1997.
    **
    **
    **  note 1 : xstevr calls sstegr when the full spectrum is requested
    **  on machines which conform to the ieee-754 floating point standard.
    **  xstevr calls sstebz and sstein on non-ieee machines and
    **  when partial spectrum requests are made.
    **
    **  normal execution of dstegr may create nans and infinities and
    **  hence may abort due to a floating point exception in environments
    **  which do not handle nans and infinities in the ieee standard default
    **  manner.
    **
    **  arguments
    **  =========
    **
    **  jobz    (input) char
    **          = 'n':  compute eigenvalues only;
    **          = 'v':  compute eigenvalues and eigenvectors.
    **
    **  range   (input) char
    **          = 'a': all eigenvalues will be found.
    **          = 'v': all eigenvalues in the half-open interval (vl,vu]
    **                 will be found.
    **          = 'i': the il-th through iu-th eigenvalues will be found.
    *********** for range = 'v' or 'i' and iu - il < n - 1, dstebz and
    *********** dstein are called
    **
    **  n       (input) long int
    **          the order of the matrix.  n >= 0.
    **
    **  d       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the n diagonal elements of the tridiagonal matrix
    **          a.
    **          on exit, d may be multiplied by a constant factor chosen
    **          to avoid over/underflow in computing the eigenvalues.
    **
    **  e       (input/output) BASE DATA TYPE array, dimension (n)
    **          on entry, the (n-1) subdiagonal elements of the tridiagonal
    **          matrix a in elements 1 to n-1 of e; e(n) need not be set.
    **          on exit, e may be multiplied by a constant factor chosen
    **          to avoid over/underflow in computing the eigenvalues.
    **
    **  vl      (input) BASE DATA TYPE
    **  vu      (input) BASE DATA TYPE
    **          if range='v', the lower and upper bounds of the interval to
    **          be searched for eigenvalues. vl < vu.
    **          not referenced if range = 'a' or 'i'.
    **
    **  il      (input) long int
    **  iu      (input) long int
    **          if range='i', the indices (in ascending order) of the
    **          smallest and largest eigenvalues to be returned.
    **          1 <= il <= iu <= n, if n > 0; il = 1 and iu = 0 if n = 0.
    **          not referenced if range = 'a' or 'v'.
    **
    **  abstol  (input) BASE DATA TYPE
    **          the absolute error tolerance for the eigenvalues.
    **          an approximate eigenvalue is accepted as converged
    **          when it is determined to lie in an interval [a,b]
    **          of width less than or equal to
    **
    **                  abstol + eps *   max( |a|,|b| ) ,
    **
    **          where eps is the machine precision.  if abstol is less than
    **          or equal to zero, then  eps*|t|  will be used in its place,
    **          where |t| is the 1-norm of the tridiagonal matrix obtained
    **          by reducing a to tridiagonal form.
    **
    **          see "computing small singular values of bidiagonal matrices
    **          with guaranteed high relative accuracy," by demmel and
    **          kahan, lapack WORKing note #3.
    **
    **          if high relative accuracy is important, set abstol to
    **          dlamch( 'safe minimum' ).  doing so will guarantee that
    **          eigenvalues are computed to high relative accuracy when
    **          possible in future releases.  the current code does not
    **          make any guarantees about high relative accuracy, but
    **          future releases will. see j. barlow and j. demmel,
    **          "computing accurate eigensystems of scaled diagonally
    **          dominant matrices", lapack WORKing note #7, for a discussion
    **          of which matrices define their eigenvalues to high relative
    **          accuracy.
    **
    **  m       (output) long int
    **          the total number of eigenvalues found.  0 <= m <= n.
    **          if range = 'a', m = n, and if range = 'i', m = iu-il+1.
    **
    **  w       (output) BASE DATA TYPE array, dimension (n)
    **          the first m elements contain the selected eigenvalues in
    **          ascending order.
    **
    **  z       (output) BASE DATA TYPE array, dimension (ldz, max(1,m) )
    **          if jobz = 'v', then if info = 0, the first m columns of z
    **          contain the orthonormal eigenvectors of the matrix a
    **          corresponding to the selected eigenvalues, with the i-th
    **          column of z holding the eigenvector associated with w(i).
    **          note: the user must ensure that at least max(1,m) columns are
    **          supplied in the array z; if range = 'v', the exact value of m
    **          is not known in advance and an upper bound must be used.
    **
    **  ldz     (input) long int
    **          the leading dimension of the array z.  ldz >= 1, and if
    **          jobz = 'v', ldz >= max(1,n).
    **
    **  isuppz  (output) long int array, dimension ( 2*max(1,m) )
    **          the support of the eigenvectors in z, i.e., the indices
    **          indicating the nonzero elements in z. the i-th eigenvector
    **          is nonzero only in elements isuppz( 2*i-1 ) through
    **          isuppz( 2*i ).
    *********** implemented only for range = 'a' or 'i' and iu - il = n - 1
    **
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **          > 0:  internal error
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     inderjit dhillon, ibm almaden, usa
    **     osni marques, lbnl/nersc, usa
    **     ken stanley, computer science division, university of
    **       california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void stevr(
        const char* jobz,
        const char* range,
        const long int* n,
        float* d,
        const float* e,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void stevr(
        const char* jobz,
        const char* range,
        const long int* n,
        float* d,
        const float* e,
        const float* vl,
        const float* vu,
        const long int* il,
        const long int* iu,
        const float* abstol,
        long int* m,
        float* ws,
        const float* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */
  /*! fn
   inline void stevr(
        const char* jobz,
        const char* range,
        const long int* n,
        double* d,
        const double* e,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void stevr(
        const char* jobz,
        const char* range,
        const long int* n,
        double* d,
        const double* e,
        const double* vl,
        const double* vu,
        const long int* il,
        const long int* iu,
        const double* abstol,
        long int* m,
        double* ws,
        const double* z,
        const long int* ldz,
        long int* isuppz,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sstevr.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal (and
  //    *          minimal) LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The dimension of the array WORK.  LWORK >= 20*N.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  //    *  IWORK   (workspace/output) long int array, dimension (LIWORK)
  //    *          On exit, if INFO = 0, IWORK(1) returns the optimal (and
  //    *          minimal) LIWORK.
  //    *  lIWORK  (input) long int
  //    *          the dimension of the array IWORK.  lIWORK >= 10*n.
  //    *
  //    *          if lIWORK = -1, then a WORKspace query is assumed; the
  //    *          routine only calculates the optimal size of the IWORK array,
  //    *          returns this value as the first entry of the IWORK array, and
  //    *          no error message related to lIWORK is issued by xerbla.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_STEVR(NAME, T)\
inline void stevr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, w.getw(), w.query(), w.getiw(), w.query(), info);\
    w.resizeiw(w.neededisize());\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, w.getw(), &w.neededsize(), w.getiw(), &w.neededisize(), info);\
}\
inline void stevr(\
    const char* jobz,\
    const char* range,\
    const long int* n,\
    T* d,\
    const T* e,\
    const T* vl,\
    const T* vu,\
    const long int* il,\
    const long int* iu,\
    const T* abstol,\
    long int* m,\
    T* ws,\
    const T* z,\
    const long int* ldz,\
    long int* isuppz,\
    long int* info)\
{\
   workspace<T> w;\
   stevr(jobz, range, n, d, e, vl, vu, il, iu, abstol, m, ws, z, ldz, isuppz, info, w);\
}\

    LPP_STEVR(sstevr, float)
    LPP_STEVR(dstevr, double)

#undef LPP_STEVR



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of stevr_itf.hh
// /////////////////////////////////////////////////////////////////////////////
