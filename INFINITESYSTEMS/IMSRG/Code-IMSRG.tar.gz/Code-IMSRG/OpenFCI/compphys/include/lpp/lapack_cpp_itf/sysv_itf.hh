#ifndef __PROJECT__LPP__FILE__SYSV_HH__INCLUDED
#define __PROJECT__LPP__FILE__SYSV_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : sysv_itf.hh C++ interface to LAPACK (c,d,c,z)sysv
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file sysv_itf.hh
    (excerpt adapted from xsysv.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xsysv computes the solution to a DATA TYPE system of linear equations
    **     a * x = b,
    **  where a is an n-by-n symmetric matrix and x and b are n-by-nrhs
    **  matrices.
    **
    **  the diagonal pivoting method is used to factor a as
    **     a = u * d * u**t,  if uplo = 'u', or
    **     a = l * d * l**t,  if uplo = 'l',
    **  where u (or l) is a product of permutation and unit upper (lower)
    **  triangular matrices, and d is symmetric and block diagonal with 
    **  1-by-1 and 2-by-2 diagonal blocks.  the factored form of a is then
    **  used to solve the system of equations a * x = b.
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the number of linear equations, i.e., the order of the
    **          matrix a.  n >= 0.
    **
    **  nrhs    (input) long int
    **          the number of right hand sides, i.e., the number of columns
    **          of the matrix b.  nrhs >= 0.
    **
    **  a       (input/output) DATA TYPE array, dimension (lda,n)
    **          on entry, the symmetric matrix a.  if uplo = 'u', the leading
    **          n-by-n upper triangular part of a contains the upper
    **          triangular part of the matrix a, and the strictly lower
    **          triangular part of a is not referenced.  if uplo = 'l', the
    **          leading n-by-n lower triangular part of a contains the lower
    **          triangular part of the matrix a, and the strictly upper
    **          triangular part of a is not referenced.
    **
    **          on exit, if info = 0, the block diagonal matrix d and the
    **          multipliers used to obtain the factor u or l from the
    **          factorization a = u*d*u**t or a = l*d*l**t as computed by
    **          csytrf.
    **
    **  lda     (input) long int
    **          the leading dimension of the array a.  lda >= max(1,n).
    **
    **  ipiv    (output) long int array, dimension (n)
    **          details of the interchanges and the block structure of d, as
    **          determined by csytrf.  if ipiv(k) > 0, then rows and columns
    **          k and ipiv(k) were interchanged, and d(k,k) is a 1-by-1
    **          diagonal block.  if uplo = 'u' and ipiv(k) = ipiv(k-1) < 0,
    **          then rows and columns k-1 and -ipiv(k) were interchanged and
    **          d(k-1:k,k-1:k) is a 2-by-2 diagonal block.  if uplo = 'l' and
    **          ipiv(k) = ipiv(k+1) < 0, then rows and columns k+1 and
    **          -ipiv(k) were interchanged and d(k:k+1,k:k+1) is a 2-by-2
    **          diagonal block.
    **
    **  b       (input/output) DATA TYPE array, dimension (ldb,nrhs)
    **          on entry, the n-by-nrhs right hand side matrix b.
    **          on exit, if info = 0, the n-by-nrhs solution matrix x.
    **
    **  ldb     (input) long int
    **          the leading dimension of the array b.  ldb >= max(1,n).
    **
    **
    **
    **  info    (output) long int
    **          = 0: successful exit
    **          < 0: if info = -i, the i-th argument had an illegal value
    **          > 0: if info = i, d(i,i) is exactly zero.  the factorization
    **               has been completed, but the block diagonal matrix d is
    **               exactly singular, so the solution could not be computed.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void sysv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void sysv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        float* a,
        const long int* lda,
        long int* ipiv,
        float* b,
        const long int* ldb,
        long int* info)
  */
  /*! fn
   inline void sysv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void sysv(
        const char* uplo,
        const long int* n,
        const long int* nrhs,
        double* a,
        const long int* lda,
        long int* ipiv,
        double* b,
        const long int* ldb,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ssysv.f)
  //    *  WORK    (workspace/output) float array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of WORK.  LWORK >= 1, and for best performance
  //    *          LWORK >= N*NB, where NB is the optimal blocksize for
  //    *          SSYTRF.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SYSV(NAME, T)\
inline void sysv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, ipiv, b, ldb, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, ipiv, b, ldb, w.getw(), &w.neededsize(), info);\
}\
inline void sysv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   sysv(uplo, n, nrhs, a, lda, ipiv, b, ldb, info, w);\
}\

    LPP_SYSV(ssysv, float)
    LPP_SYSV(dsysv, double)

#undef LPP_SYSV


  // The following macro provides the 4 functions 
  /*! fn
   inline void sysv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void sysv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<float>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<float>* b,
       const long int* ldb,
       long int* info)
  */
  /*! fn
   inline void sysv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void sysv(
       const char* uplo,
       const long int* n,
       const long int* nrhs,
       std::complex<double>* a,
       const long int* lda,
       long int* ipiv,
       std::complex<double>* b,
       const long int* ldb,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from csysv.f)
  //    *  WORK    (workspace/output) std::complex<float> array, dimension (LWORK)
  //    *          On exit, if INFO = 0, WORK(1) returns the optimal LWORK.
  //    *
  //    *  LWORK   (input) long int
  //    *          The length of WORK.  LWORK >= 1, and for best performance
  //    *          LWORK >= N*NB, where NB is the optimal blocksize for
  //    *          CSYTRF.
  //    *
  //    *          If LWORK = -1, then a workspace query is assumed; the routine
  //    *          only calculates the optimal size of the WORK array, returns
  //    *          this value as the first entry of the WORK array, and no error
  //    *          message related to LWORK is issued by XERBLA.
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SYSV(NAME, T, TBASE)\
inline void sysv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, ipiv, b, ldb, w.getw(), w.query(), info);\
    w.resizew(w.neededsize());\
    F77NAME( NAME )(uplo, n, nrhs, a, lda, ipiv, b, ldb, w.getw(), &w.neededsize(), info);\
}\
inline void sysv(\
    const char* uplo,\
    const long int* n,\
    const long int* nrhs,\
    T* a,\
    const long int* lda,\
    long int* ipiv,\
    T* b,\
    const long int* ldb,\
    long int* info)\
{\
   workspace<T> w;\
   sysv(uplo, n, nrhs, a, lda, ipiv, b, ldb, info, w);\
}\

    LPP_SYSV(csysv, std::complex<float>,  float)
    LPP_SYSV(zsysv, std::complex<double>, double)

#undef LPP_SYSV



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of sysv_itf.hh
// /////////////////////////////////////////////////////////////////////////////
