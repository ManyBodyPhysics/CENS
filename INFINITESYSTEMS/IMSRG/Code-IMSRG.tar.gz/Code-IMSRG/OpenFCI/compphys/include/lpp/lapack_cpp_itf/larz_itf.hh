#ifndef __PROJECT__LPP__FILE__LARZ_HH__INCLUDED
#define __PROJECT__LPP__FILE__LARZ_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : larz_itf.hh C++ interface to LAPACK (s,d,c,z)larz
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file larz_itf.hh
    (excerpt adapted from xlarz.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlarz applies a DATA TYPE elementary reflector h to a DATA TYPE
    **  m-by-n matrix c, from either the left or the right. h is represented
    **  in the form
    **
    **        h = i - tau * v * v'
    **
    **  where tau is a DATA TYPE scalar and v is a DATA TYPE vector.
    **
    **  if tau = 0, then h is taken to be the unit matrix.
    **
    **  to apply h' (the conjugate transpose of h), supply conjg(tau) instead
    **  tau.
    **
    **  h is a product of k elementary reflectors as returned by ctzrzf.
    **
    **  arguments
    **  =========
    **
    **  side    (input) char
    **          = 'l': form  h * c
    **          = 'r': form  c * h
    **
    **  m       (input) long int
    **          the number of rows of the matrix c.
    **
    **  n       (input) long int
    **          the number of columns of the matrix c.
    **
    **  l       (input) long int
    **          the number of entries of the vector v containing
    **          the meaningful part of the householder vectors.
    **          if side = 'l', m >= l >= 0, if side = 'r', n >= l >= 0.
    **
    **  v       (input) DATA TYPE array, dimension (1+(l-1)*abs(incv))
    **          the vector v in the representation of h as returned by
    **          ctzrzf. v is not used if tau = 0.
    **
    **  incv    (input) long int
    **          the increment between elements of v. incv <> 0.
    **
    **  tau     (input) DATA TYPE
    **          the value tau in the representation of h.
    **
    **  c       (input/output) DATA TYPE array, dimension (ldc,n)
    **          on entry, the m-by-n matrix c.
    **          on exit, c is overwritten by the matrix h * c if side = 'l',
    **          or c * h if side = 'r'.
    **
    **  ldc     (input) long int
    **          the leading dimension of the array c. ldc >= max(1,m).
    **
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **    a. petitet, computer science dept., univ. of tenn., knoxville, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void larz(
        const char* side,
        const long int* m,
        const long int* n,
        const long int* l,
        const float* v,
        const long int* incv,
        const float* tau,
        const float* c,
        const long int* ldc,
        workspace<float> & w)
  */
  /*! fn
   inline void larz(
        const char* side,
        const long int* m,
        const long int* n,
        const long int* l,
        const float* v,
        const long int* incv,
        const float* tau,
        const float* c,
        const long int* ldc)
  */
  /*! fn
   inline void larz(
        const char* side,
        const long int* m,
        const long int* n,
        const long int* l,
        const double* v,
        const long int* incv,
        const double* tau,
        const double* c,
        const long int* ldc,
        workspace<double> & w)
  */
  /*! fn
   inline void larz(
        const char* side,
        const long int* m,
        const long int* n,
        const long int* l,
        const double* v,
        const long int* incv,
        const double* tau,
        const double* c,
        const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slarz.f)
  //    *  WORK    (workspace) float array, dimension
  //    *                         (N) if SIDE = 'L'
  //    *                      or (M) if SIDE = 'R'
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZ(NAME, T)\
inline void larz(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
  w.resizew((lower(*side) == 'l')? *n : *m);                            \
    F77NAME( NAME )(side, m, n, l, v, incv, tau, c, ldc, w.getw());\
}\
inline void larz(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larz(side, m, n, l, v, incv, tau, c, ldc, w);\
}\

    LPP_LARZ(slarz, float)
    LPP_LARZ(dlarz, double)

#undef LPP_LARZ


  // The following macro provides the 4 functions 
  /*! fn
   inline void larz(
       const char* side,
       const long int* m,
       const long int* n,
       const long int* l,
       const std::complex<float>* v,
       const long int* incv,
       const std::complex<float>* tau,
       const std::complex<float>* c,
       const long int* ldc,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void larz(
       const char* side,
       const long int* m,
       const long int* n,
       const long int* l,
       const std::complex<float>* v,
       const long int* incv,
       const std::complex<float>* tau,
       const std::complex<float>* c,
       const long int* ldc)
  */
  /*! fn
   inline void larz(
       const char* side,
       const long int* m,
       const long int* n,
       const long int* l,
       const std::complex<double>* v,
       const long int* incv,
       const std::complex<double>* tau,
       const std::complex<double>* c,
       const long int* ldc,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void larz(
       const char* side,
       const long int* m,
       const long int* n,
       const long int* l,
       const std::complex<double>* v,
       const long int* incv,
       const std::complex<double>* tau,
       const std::complex<double>* c,
       const long int* ldc)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from clarz.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension
  //    *                         (N) if SIDE = 'L'
  //    *                      or (M) if SIDE = 'R'
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LARZ(NAME, T, TBASE)\
inline void larz(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc,\
    workspace<T> & w)\
{\
  w.resizew((lower(*side) == 'l')? *n : *m);                        \
  F77NAME( NAME )(side, m, n, l, v, incv, tau, c, ldc, w.getw());   \
}\
inline void larz(\
    const char* side,\
    const long int* m,\
    const long int* n,\
    const long int* l,\
    const T* v,\
    const long int* incv,\
    const T* tau,\
    const T* c,\
    const long int* ldc)                        \
{\
   workspace<T> w;\
   larz(side, m, n, l, v, incv, tau, c, ldc, w);\
}\

    LPP_LARZ(clarz, std::complex<float>, float)
    LPP_LARZ(zlarz, std::complex<double>, double)

#undef LPP_LARZ



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of larz_itf.hh
// /////////////////////////////////////////////////////////////////////////////
