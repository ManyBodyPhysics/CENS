#ifndef __PROJECT__LPP__FILE__SPCON_HH__INCLUDED
#define __PROJECT__LPP__FILE__SPCON_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : spcon_itf.hh C++ interface to LAPACK (s,d,c,z)spcon
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file spcon_itf.hh
    (excerpt adapted from xspcon.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xspcon estimates the reciprocal of the condition number (in the
    **  1-norm) of a DATA TYPE symmetric packed matrix a using the
    **  factorization a = u*d*u**t or a = l*d*l**t computed by csptrf.
    **
    **  an estimate is obtained for norm(inv(a)), and the reciprocal of the
    **  condition number is computed as rcond = 1 / (anorm * norm(inv(a))).
    **
    **  arguments
    **  =========
    **
    **  uplo    (input) char
    **          specifies whether the details of the factorization are stored
    **          as an upper or lower triangular matrix.
    **          = 'u':  upper triangular, form is a = u*d*u**t;
    **          = 'l':  lower triangular, form is a = l*d*l**t.
    **
    **  n       (input) long int
    **          the order of the matrix a.  n >= 0.
    **
    **  ap      (input) DATA TYPE array, dimension (n*(n+1)/2)
    **          the block diagonal matrix d and the multipliers used to
    **          obtain the factor u or l as computed by csptrf, stored as a
    **          packed triangular matrix.
    **
    **  ipiv    (input) long int array, dimension (n)
    **          details of the interchanges and the block structure of d
    **          as determined by csptrf.
    **
    **  anorm   (input) BASE DATA TYPE
    **          the 1-norm of the original matrix a.
    **
    **  rcond   (output) BASE DATA TYPE
    **          the reciprocal of the condition number of the matrix a,
    **          computed as rcond = 1/(anorm * ainvnm), where ainvnm is an
    **          estimate of the 1-norm of inv(a) computed in this routine.
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void spcon(
        const char* uplo,
        const long int* n,
        const float* ap,
        const long int* ipiv,
        const float* anorm,
        float* rcond,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void spcon(
        const char* uplo,
        const long int* n,
        const float* ap,
        const long int* ipiv,
        const float* anorm,
        float* rcond,
        long int* info)
  */
  /*! fn
   inline void spcon(
        const char* uplo,
        const long int* n,
        const double* ap,
        const long int* ipiv,
        const double* anorm,
        double* rcond,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void spcon(
        const char* uplo,
        const long int* n,
        const double* ap,
        const long int* ipiv,
        const double* anorm,
        double* rcond,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from sspcon.f)
  //    *  WORK    (workspace) float array, dimension (2*N)
  //    *
  //    *  IWORK    (workspace) long int array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPCON(NAME, T)\
inline void spcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const long int* ipiv,\
    const T* anorm,\
    T* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(*n);\
    w.resizew(2*(*n));\
    F77NAME( NAME )(uplo, n, ap, ipiv, anorm, rcond, w.getw(), w.getiw(), info);\
}\
inline void spcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const long int* ipiv,\
    const T* anorm,\
    T* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   spcon(uplo, n, ap, ipiv, anorm, rcond, info, w);\
}\

    LPP_SPCON(sspcon, float)
    LPP_SPCON(dspcon, double)

#undef LPP_SPCON


  // The following macro provides the 4 functions 
  /*! fn
   inline void spcon(
       const char* uplo,
       const long int* n,
       const std::complex<float>* ap,
       const long int* ipiv,
       const float* anorm,
       float* rcond,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void spcon(
       const char* uplo,
       const long int* n,
       const std::complex<float>* ap,
       const long int* ipiv,
       const float* anorm,
       float* rcond,
       long int* info)
  */
  /*! fn
   inline void spcon(
       const char* uplo,
       const long int* n,
       const std::complex<double>* ap,
       const long int* ipiv,
       const double* anorm,
       double* rcond,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void spcon(
       const char* uplo,
       const long int* n,
       const std::complex<double>* ap,
       const long int* ipiv,
       const double* anorm,
       double* rcond,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from cspcon.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (2*N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_SPCON(NAME, T, TBASE)\
inline void spcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const long int* ipiv,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizew(2*(*n));\
    F77NAME( NAME )(uplo, n, ap, ipiv, anorm, rcond, w.getw(), info);\
}\
inline void spcon(\
    const char* uplo,\
    const long int* n,\
    const T* ap,\
    const long int* ipiv,\
    const TBASE* anorm,\
    TBASE* rcond,\
    long int* info)\
{\
   workspace<T> w;\
   spcon(uplo, n, ap, ipiv, anorm, rcond, info, w);\
}\

    LPP_SPCON(cspcon, std::complex<float>, float)
    LPP_SPCON(zspcon, std::complex<double>, double)

#undef LPP_SPCON



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of spcon_itf.hh
// /////////////////////////////////////////////////////////////////////////////
