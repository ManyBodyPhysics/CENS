#ifndef __PROJECT__LPP__FILE__HBGST_HH__INCLUDED
#define __PROJECT__LPP__FILE__HBGST_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : hbgst_itf.hh C++ interface to LAPACK (s,d,c,z)hbgst
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file hbgst_itf.hh
    (excerpt adapted from xhbgst.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xhbgst reduces a DATA TYPE hermitian-definite banded generalized
    **  eigenproblem  a*x = lambda*b*x  to standard form  c*y = lambda*y,
    **  such that c has the same bandwidth as a.
    **
    **  b must have been previously factorized as s**h*s by cpbstf, using a
    **  split cholesky factorization. a is overwritten by c = x**h*a*x, where
    **  x = s**(-1)*q and q is a unitary matrix chosen to preserve the
    **  bandwidth of a.
    **
    **  arguments
    **  =========
    **
    **  vect    (input) char
    **          = 'n':  do not form the transformation matrix x;
    **          = 'v':  form x.
    **
    **  uplo    (input) char
    **          = 'u':  upper triangle of a is stored;
    **          = 'l':  lower triangle of a is stored.
    **
    **  n       (input) long int
    **          the order of the matrices a and b.  n >= 0.
    **
    **  ka      (input) long int
    **          the number of superdiagonals of the matrix a if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  ka >= 0.
    **
    **  kb      (input) long int
    **          the number of superdiagonals of the matrix b if uplo = 'u',
    **          or the number of subdiagonals if uplo = 'l'.  ka >= kb >= 0.
    **
    **  ab      (input/output) DATA TYPE array, dimension (ldab,n)
    **          on entry, the upper or lower triangle of the hermitian band
    **          matrix a, stored in the first ka+1 rows of the array.  the
    **          j-th column of a is stored in the j-th column of the array ab
    **          as follows:
    **          if uplo = 'u', ab(ka+1+i-j,j) = a(i,j) for max(1,j-ka)<=i<=j;
    **          if uplo = 'l', ab(1+i-j,j)    = a(i,j) for j<=i<=min(n,j+ka).
    **
    **          on exit, the transformed matrix x**h*a*x, stored in the same
    **          format as a.
    **
    **  ldab    (input) long int
    **          the leading dimension of the array ab.  ldab >= ka+1.
    **
    **  bb      (input) DATA TYPE array, dimension (ldbb,n)
    **          the banded factor s from the split cholesky factorization of
    **          b, as returned by cpbstf, stored in the first kb+1 rows of
    **          the array.
    **
    **  ldbb    (input) long int
    **          the leading dimension of the array bb.  ldbb >= kb+1.
    **
    **  x       (output) DATA TYPE array, dimension (ldx,n)
    **          if vect = 'v', the n-by-n matrix x.
    **          if vect = 'n', the array x is not referenced.
    **
    **  ldx     (input) long int
    **          the leading dimension of the array x.
    **          ldx >= max(1,n) if vect = 'v'; ldx >= 1 otherwise.
    **
    **
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void hbgst(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* ka,
       const long int* kb,
       std::complex<float>* ab,
       const long int* ldab,
       const std::complex<float>* bb,
       const long int* ldbb,
       std::complex<float>* x,
       const long int* ldx,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void hbgst(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* ka,
       const long int* kb,
       std::complex<float>* ab,
       const long int* ldab,
       const std::complex<float>* bb,
       const long int* ldbb,
       std::complex<float>* x,
       const long int* ldx,
       long int* info)
  */
  /*! fn
   inline void hbgst(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* ka,
       const long int* kb,
       std::complex<double>* ab,
       const long int* ldab,
       const std::complex<double>* bb,
       const long int* ldbb,
       std::complex<double>* x,
       const long int* ldx,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void hbgst(
       const char* vect,
       const char* uplo,
       const long int* n,
       const long int* ka,
       const long int* kb,
       std::complex<double>* ab,
       const long int* ldab,
       const std::complex<double>* bb,
       const long int* ldbb,
       std::complex<double>* x,
       const long int* ldx,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from chbgst.f)
  //    *  WORK    (workspace) std::complex<float> array, dimension (N)
  //    *
  //    *  RWORK   (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_HBGST(NAME, T, TBASE)\
inline void hbgst(\
    const char* vect,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    const T* bb,\
    const long int* ldbb,\
    T* x,\
    const long int* ldx,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw(*n);\
    w.resizew(*n);\
    F77NAME( NAME )(vect, uplo, n, ka, kb, ab, ldab, bb, ldbb, x, ldx, w.getw(), w.getrw(), info);\
}\
inline void hbgst(\
    const char* vect,\
    const char* uplo,\
    const long int* n,\
    const long int* ka,\
    const long int* kb,\
    T* ab,\
    const long int* ldab,\
    const T* bb,\
    const long int* ldbb,\
    T* x,\
    const long int* ldx,\
    long int* info)\
{\
   workspace<T> w;\
   hbgst(vect, uplo, n, ka, kb, ab, ldab, bb, ldbb, x, ldx, info, w);\
}\

    LPP_HBGST(chbgst, std::complex<float>, float)
    LPP_HBGST(zhbgst, std::complex<double>, double)

#undef LPP_HBGST



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of hbgst_itf.hh
// /////////////////////////////////////////////////////////////////////////////
