#ifndef __PROJECT__LPP__FILE__LAEDA_HH__INCLUDED
#define __PROJECT__LPP__FILE__LAEDA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : laeda_itf.hh C++ interface to LAPACK (s,d,c,z)laeda
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file laeda_itf.hh
    (excerpt adapted from xlaeda.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlaeda computes the z vector corresponding to the merge step in the
    **  curlvlth step of the merge process with tlvls steps for the curpbmth
    **  problem.
    **
    **  arguments
    **  =========
    **
    **  n      (input) long int
    **         the dimension of the symmetric tridiagonal matrix.  n >= 0.
    **
    **  tlvls  (input) long int
    **         the total number of merging levels in the overall divide and
    **         conquer tree.
    **
    **  curlvl (input) long int
    **         the current level in the overall merge routine,
    **         0 <= curlvl <= tlvls.
    **
    **  curpbm (input) long int
    **         the current problem in the current level in the overall
    **         merge routine (counting from upper left to lower right).
    **
    **  prmptr (input) long int array, dimension (n lg n)
    **         contains a list of pointers which indicate where in perm a
    **         level's permutation is stored.  prmptr(i+1) - prmptr(i)
    **         indicates the size of the permutation and incidentally the
    **         size of the full, non-deflated problem.
    **
    **  perm   (input) long int array, dimension (n lg n)
    **         contains the permutations (from deflation and sorting) to be
    **         applied to each eigenblock.
    **
    **  givptr (input) long int array, dimension (n lg n)
    **         contains a list of pointers which indicate where in givcol a
    **         level's givens rotations are stored.  givptr(i+1) - givptr(i)
    **         indicates the number of givens rotations.
    **
    **  givcol (input) long int array, dimension (2, n lg n)
    **         each pair of numbers indicates a pair of columns to take place
    **         in a givens rotation.
    **
    **  givnum (input) BASE DATA TYPE array, dimension (2, n lg n)
    **         each number indicates the s value to be used in the
    **         corresponding givens rotation.
    **
    **  q      (input) BASE DATA TYPE array, dimension (n**2)
    **         contains the square eigenblocks from previous levels, the
    **         starting positions for blocks are given by qptr.
    **
    **  qptr   (input) long int array, dimension (n+2)
    **         contains a list of pointers which indicate where in q an
    **         eigenblock is stored.  sqrt( qptr(i+1) - qptr(i) ) indicates
    **         the size of the block.
    **
    **  z      (output) BASE DATA TYPE array, dimension (n)
    **         on output this vector contains the updating vector (the last
    **         row of the first sub-eigenvector matrix and the first row of
    **         the second sub-eigenvector matrix).
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     jeff rutter, computer science division, university of california
    **     at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void laeda(
        const long int* n,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const float* givnum,
        const float* q,
        const long int* qptr,
        float* z,
        float* ztemp,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void laeda(
        const long int* n,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const float* givnum,
        const float* q,
        const long int* qptr,
        float* z,
        float* ztemp,
        long int* info)
  */
  /*! fn
   inline void laeda(
        const long int* n,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const double* givnum,
        const double* q,
        const long int* qptr,
        double* z,
        double* ztemp,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void laeda(
        const long int* n,
        const long int* tlvls,
        const long int* curlvl,
        const long int* curpbm,
        const long int* prmptr,
        const long int* perm,
        const long int* givptr,
        const long int* givcol,
        const double* givnum,
        const double* q,
        const long int* qptr,
        double* z,
        double* ztemp,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slaeda.f)
  //    *  ZTEMP  (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LAEDA(NAME, T)\
inline void laeda(\
    const long int* n,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const T* givnum,\
    const T* q,\
    const long int* qptr,\
    T* z,\
    T* ztemp,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(n, tlvls, curlvl, curpbm, prmptr, perm, givptr, givcol, givnum, q, qptr, z, ztemp, info);\
}\
inline void laeda(\
    const long int* n,\
    const long int* tlvls,\
    const long int* curlvl,\
    const long int* curpbm,\
    const long int* prmptr,\
    const long int* perm,\
    const long int* givptr,\
    const long int* givcol,\
    const T* givnum,\
    const T* q,\
    const long int* qptr,\
    T* z,\
    T* ztemp,\
    long int* info)\
{\
   workspace<T> w;\
   laeda(n, tlvls, curlvl, curpbm, prmptr, perm, givptr, givcol, givnum, q, qptr, z, ztemp, info, w);\
}\

    LPP_LAEDA(slaeda, float)
    LPP_LAEDA(dlaeda, double)

#undef LPP_LAEDA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of laeda_itf.hh
// /////////////////////////////////////////////////////////////////////////////
