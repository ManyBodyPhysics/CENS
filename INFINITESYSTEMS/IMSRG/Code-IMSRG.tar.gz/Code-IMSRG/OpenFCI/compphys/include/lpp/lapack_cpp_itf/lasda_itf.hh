#ifndef __PROJECT__LPP__FILE__LASDA_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASDA_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasda_itf.hh C++ interface to LAPACK (s,d,c,z)lasda
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasda_itf.hh
    (excerpt adapted from xlasda.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  using a divide and conquer approach, xlasda computes the singular
    **  value decomposition (svd) of a BASE DATA TYPE upper bidiagonal n-by-m matrix
    **  b with diagonal d and offdiagonal e, where m = n + sqre. the
    **  algorithm computes the singular values in the svd b = u * s * vt.
    **  the orthogonal matrices u and vt are optionally computed in
    **  compact form.
    **
    **  a related subroutine, dlasd0, computes the singular values and
    **  the singular vectors in explicit form.
    **
    **  arguments
    **  =========
    **
    **  icompq (input) long int
    **         specifies whether singular vectors are to be computed
    **         in compact form, as follows
    **         = 0: compute singular values only.
    **         = 1: compute singular vectors of upper bidiagonal
    **              matrix in compact form.
    **
    **  smlsiz (input) long int
    **         the maximum size of the subproblems at the bottom of the
    **         computation tree.
    **
    **  n      (input) long int
    **         the row dimension of the upper bidiagonal matrix. this is
    **         also the dimension of the main diagonal array d.
    **
    **  sqre   (input) long int
    **         specifies the column dimension of the bidiagonal matrix.
    **         = 0: the bidiagonal matrix has column dimension m = n;
    **         = 1: the bidiagonal matrix has column dimension m = n + 1.
    **
    **  d      (input/output) BASE DATA TYPE array, dimension ( n )
    **         on entry d contains the main diagonal of the bidiagonal
    **         matrix. on exit d, if info = 0, contains its singular values.
    **
    **  e      (input) BASE DATA TYPE array, dimension ( m-1 )
    **         contains the subdiagonal entries of the bidiagonal matrix.
    **         on exit, e has been destroyed.
    **
    **  u      (output) BASE DATA TYPE array,
    **         dimension ( ldu, smlsiz ) if icompq = 1, and not referenced
    **         if icompq = 0. if icompq = 1, on exit, u contains the left
    **         singular vector matrices of all subproblems at the bottom
    **         level.
    **
    **  ldu    (input) long int, ldu = > n.
    **         the leading dimension of arrays u, vt, difl, difr, poles,
    **         givnum, and z.
    **
    **  vt     (output) BASE DATA TYPE array,
    **         dimension ( ldu, smlsiz+1 ) if icompq = 1, and not referenced
    **         if icompq = 0. if icompq = 1, on exit, vt' contains the right
    **         singular vector matrices of all subproblems at the bottom
    **         level.
    **
    **  k      (output) long int array,
    **         dimension ( n ) if icompq = 1 and dimension 1 if icompq = 0.
    **         if icompq = 1, on exit, k(i) is the dimension of the i-th
    **         secular equation on the computation tree.
    **
    **  difl   (output) BASE DATA TYPE array, dimension ( ldu, nlvl ),
    **         where nlvl = floor(log_2 (n/smlsiz))).
    **
    **  difr   (output) BASE DATA TYPE array,
    **                  dimension ( ldu, 2 * nlvl ) if icompq = 1 and
    **                  dimension ( n ) if icompq = 0.
    **         if icompq = 1, on exit, difl(1:n, i) and difr(1:n, 2 * i - 1)
    **         record distances between singular values on the i-th
    **         level and singular values on the (i -1)-th level, and
    **         difr(1:n, 2 * i ) contains the normalizing factors for
    **         the right singular vector matrix. see dlasd8 for details.
    **
    **  z      (output) BASE DATA TYPE array,
    **                  dimension ( ldu, nlvl ) if icompq = 1 and
    **                  dimension ( n ) if icompq = 0.
    **         the first k elements of z(1, i) contain the components of
    **         the deflation-adjusted updating row vector for subproblems
    **         on the i-th level.
    **
    **  poles  (output) BASE DATA TYPE array,
    **         dimension ( ldu, 2 * nlvl ) if icompq = 1, and not referenced
    **         if icompq = 0. if icompq = 1, on exit, poles(1, 2*i - 1) and
    **         poles(1, 2*i) contain  the new and old singular values
    **         involved in the secular equations on the i-th level.
    **
    **  givptr (output) long int array,
    **         dimension ( n ) if icompq = 1, and not referenced if
    **         icompq = 0. if icompq = 1, on exit, givptr( i ) records
    **         the number of givens rotations performed on the i-th
    **         problem on the computation tree.
    **
    **  givcol (output) long int array,
    **         dimension ( ldgcol, 2 * nlvl ) if icompq = 1, and not
    **         referenced if icompq = 0. if icompq = 1, on exit, for each i,
    **         givcol(1, 2 *i - 1) and givcol(1, 2 *i) record the locations
    **         of givens rotations performed on the i-th level on the
    **         computation tree.
    **
    **  ldgcol (input) long int, ldgcol = > n.
    **         the leading dimension of arrays givcol and perm.
    **
    **  perm   (output) long int array,
    **         dimension ( ldgcol, nlvl ) if icompq = 1, and not referenced
    **         if icompq = 0. if icompq = 1, on exit, perm(1, i) records
    **         permutations done on the i-th level of the computation tree.
    **
    **  givnum (output) BASE DATA TYPE array,
    **         dimension ( ldu,  2 * nlvl ) if icompq = 1, and not
    **         referenced if icompq = 0. if icompq = 1, on exit, for each i,
    **         givnum(1, 2 *i - 1) and givnum(1, 2 *i) record the c- and s-
    **         values of givens rotations performed on the i-th level on
    **         the computation tree.
    **
    **  c      (output) BASE DATA TYPE array,
    **         dimension ( n ) if icompq = 1, and dimension 1 if icompq = 0.
    **         if icompq = 1 and the i-th subproblem is not square, on exit,
    **         c( i ) contains the c-value of a givens rotation related to
    **         the right null space of the i-th subproblem.
    **
    **  s      (output) BASE DATA TYPE array, dimension ( n ) if
    **         icompq = 1, and dimension 1 if icompq = 0. if icompq = 1
    **         and the i-th subproblem is not square, on exit, s( i )
    **         contains the s-value of a givens rotation related to
    **         the right null space of the i-th subproblem.
    **
    **
    **
    **  info   (output) long int
    **          = 0:  successful exit.
    **          < 0:  if info = -i, the i-th argument had an illegal value.
    **          > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasda(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* sqre,
        float* d,
        const float* e,
        float* u,
        const long int* ldu,
        float* vt,
        long int* k,
        float* difl,
        float* difr,
        const float* z,
        float* poles,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        long int* perm,
        float* givnum,
        const float* c,
        const float* s,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasda(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* sqre,
        float* d,
        const float* e,
        float* u,
        const long int* ldu,
        float* vt,
        long int* k,
        float* difl,
        float* difr,
        const float* z,
        float* poles,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        long int* perm,
        float* givnum,
        const float* c,
        const float* s,
        long int* info)
  */
  /*! fn
   inline void lasda(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* sqre,
        double* d,
        const double* e,
        double* u,
        const long int* ldu,
        double* vt,
        long int* k,
        double* difl,
        double* difr,
        const double* z,
        double* poles,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        long int* perm,
        double* givnum,
        const double* c,
        const double* s,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasda(
        const long int* icompq,
        const long int* smlsiz,
        const long int* n,
        const long int* sqre,
        double* d,
        const double* e,
        double* u,
        const long int* ldu,
        double* vt,
        long int* k,
        double* difl,
        double* difr,
        const double* z,
        double* poles,
        long int* givptr,
        long int* givcol,
        const long int* ldgcol,
        long int* perm,
        double* givnum,
        const double* c,
        const double* s,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasda.f)
  //    *  WORK   (workspace) float array, dimension
  //    *         (6 * N + (SMLSIZ + 1)*(SMLSIZ + 1)).
  //    *
  //    *  IWORK  (workspace) long int array.
  //    *         Dimension must be at least (7 * N).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASDA(NAME, T)\
inline void lasda(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* sqre,\
    T* d,\
    const T* e,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    long int* k,\
    T* difl,\
    T* difr,\
    const T* z,\
    T* poles,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    long int* perm,\
    T* givnum,\
    const T* c,\
    const T* s,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizeiw(7**n);\
    w.resizew((6 * *n + (*smlsiz + 1)*(*smlsiz + 1)));\
    F77NAME( NAME )(icompq, smlsiz, n, sqre, d, e, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, w.getw(), w.getiw(), info);\
}\
inline void lasda(\
    const long int* icompq,\
    const long int* smlsiz,\
    const long int* n,\
    const long int* sqre,\
    T* d,\
    const T* e,\
    T* u,\
    const long int* ldu,\
    T* vt,\
    long int* k,\
    T* difl,\
    T* difr,\
    const T* z,\
    T* poles,\
    long int* givptr,\
    long int* givcol,\
    const long int* ldgcol,\
    long int* perm,\
    T* givnum,\
    const T* c,\
    const T* s,\
    long int* info)\
{\
   workspace<T> w;\
   lasda(icompq, smlsiz, n, sqre, d, e, u, ldu, vt, k, difl, difr, z, poles, givptr, givcol, ldgcol, perm, givnum, c, s, info, w);\
}\

    LPP_LASDA(slasda, float)
    LPP_LASDA(dlasda, double)

#undef LPP_LASDA



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasda_itf.hh
// /////////////////////////////////////////////////////////////////////////////
