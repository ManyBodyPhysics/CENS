#ifndef __PROJECT__LPP__FILE__TREXC_HH__INCLUDED
#define __PROJECT__LPP__FILE__TREXC_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : trexc_itf.hh C++ interface to LAPACK (s,d,c,z)trexc
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file trexc_itf.hh
    (excerpt adapted from xtrexc.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xtrexc reorders the schur factorization of a DATA TYPE matrix
    **  a = q*t*q**h, so that the diagonal element of t with row index ifst
    **  is moved to row ilst.
    **
    **  the schur form t is reordered by a unitary similarity transformation
    **  z**h*t*z, and optionally the matrix q of schur vectors is updated by
    **  postmultplying it with z.
    **
    **  arguments
    **  =========
    **
    **  compq   (input) char
    **          = 'v':  update the matrix q of schur vectors;
    **          = 'n':  do not update q.
    **
    **  n       (input) long int
    **          the order of the matrix t. n >= 0.
    **
    **  t       (input/output) DATA TYPE array, dimension (ldt,n)
    **          on entry, the upper triangular matrix t.
    **          on exit, the reordered upper triangular matrix.
    **
    **  ldt     (input) long int
    **          the leading dimension of the array t. ldt >= max(1,n).
    **
    **  q       (input/output) DATA TYPE array, dimension (ldq,n)
    **          on entry, if compq = 'v', the matrix q of schur vectors.
    **          on exit, if compq = 'v', q has been postmultiplied by the
    **          unitary transformation matrix z which reorders t.
    **          if compq = 'n', q is not referenced.
    **
    **  ldq     (input) long int
    **          the leading dimension of the array q.  ldq >= max(1,n).
    **
    **  ifst    (input) long int
    **  ilst    (input) long int
    **          specify the reordering of the diagonal elements of t:
    **          the element with row index ifst is moved to row ilst by a
    **          sequence of transpositions between adjacent elements.
    **          1 <= ifst <= n; 1 <= ilst <= n.
    **
    **  info    (output) long int
    **          = 0:  successful exit
    **          < 0:  if info = -i, the i-th argument had an illegal value
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void trexc(
        const char* compq,
        const long int* n,
        float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        long int* ifst,
        long int* ilst,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void trexc(
        const char* compq,
        const long int* n,
        float* t,
        const long int* ldt,
        const float* q,
        const long int* ldq,
        long int* ifst,
        long int* ilst,
        long int* info)
  */
  /*! fn
   inline void trexc(
        const char* compq,
        const long int* n,
        double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        long int* ifst,
        long int* ilst,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void trexc(
        const char* compq,
        const long int* n,
        double* t,
        const long int* ldt,
        const double* q,
        const long int* ldq,
        long int* ifst,
        long int* ilst,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from strexc.f)
  //    *  WORK    (workspace) float array, dimension (N)
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_TREXC(NAME, T)\
inline void trexc(\
    const char* compq,\
    const long int* n,\
    T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    long int* ifst,\
    long int* ilst,\
    long int* info,\
    workspace<T> & w)\
{\
    w.resizerw((*n));\
    F77NAME( NAME )(compq, n, t, ldt, q, ldq, ifst, ilst, w.getrw(), info);\
}\
inline void trexc(\
    const char* compq,\
    const long int* n,\
    T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    long int* ifst,\
    long int* ilst,\
    long int* info)\
{\
   workspace<T> w;\
   trexc(compq, n, t, ldt, q, ldq, ifst, ilst, info, w);\
}\

    LPP_TREXC(strexc, float)
    LPP_TREXC(dtrexc, double)

#undef LPP_TREXC


  // The following macro provides the 4 functions 
  /*! fn
   inline void trexc(
       const char* compq,
       const long int* n,
       std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* q,
       const long int* ldq,
       const long int* ifst,
       const long int* ilst,
       long int* info,
       workspace<complex<float> > & w)
  */
  /*! fn
   inline void trexc(
       const char* compq,
       const long int* n,
       std::complex<float>* t,
       const long int* ldt,
       const std::complex<float>* q,
       const long int* ldq,
       const long int* ifst,
       const long int* ilst,
       long int* info)
  */
  /*! fn
   inline void trexc(
       const char* compq,
       const long int* n,
       std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* q,
       const long int* ldq,
       const long int* ifst,
       const long int* ilst,
       long int* info,
       workspace<complex<double> > & w)
  */
  /*! fn
   inline void trexc(
       const char* compq,
       const long int* n,
       std::complex<double>* t,
       const long int* ldt,
       const std::complex<double>* q,
       const long int* ldq,
       const long int* ifst,
       const long int* ilst,
       long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from ctrexc.f)
  /////////////////////////////////////////////////////////////////////////

#define LPP_TREXC(NAME, T, TBASE)\
inline void trexc(\
    const char* compq,\
    const long int* n,\
    T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    const long int* ifst,\
    const long int* ilst,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(compq, n, t, ldt, q, ldq, ifst, ilst, info);\
}\
inline void trexc(\
    const char* compq,\
    const long int* n,\
    T* t,\
    const long int* ldt,\
    const T* q,\
    const long int* ldq,\
    const long int* ifst,\
    const long int* ilst,\
    long int* info)\
{\
   workspace<T> w;\
   trexc(compq, n, t, ldt, q, ldq, ifst, ilst, info, w);\
}\

    LPP_TREXC(ctrexc, std::complex<float>, float)
    LPP_TREXC(ztrexc, std::complex<double>, double)

#undef LPP_TREXC



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of trexc_itf.hh
// /////////////////////////////////////////////////////////////////////////////
