#ifndef __PROJECT__LPP__FILE__LASD3_HH__INCLUDED
#define __PROJECT__LPP__FILE__LASD3_HH__INCLUDED

////////////////////////////////////////////////////////////////////////////////
//  Copyright (c) 2005 for LASMEA UMR 6602 du CNRS.                  
//  All rights reserved.                                             
//                                                                   
//  This file is part of the LPP C++ Library.  This library is       
//  free software; you can redistribute it and/or modify it under    
//  the terms of the GNU Lesser General Public License as published  
//  by the Free Software Foundation; either version 2.1, or (at      
//  your option) any later version.                                  
//                                                                   
//  This library is distributed in the hope that it will be useful,  
//  but WITHOUT ANY WARRANTY; without even the implied warranty of   
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
//  GNU Lesser General Public License for more details.              
//                                                                   
//  You should have received a copy of the GNU Lesser General        
//  Public License along with this library; see the file COPYING.    
//  If not, send mail to the developers of LPP                       
//                                                                   
//  As a special exception, you may use this file as part of a free  
//  software library without restriction.  Specifically, if other    
//  files instantiate templates or use macros or inline functions    
//  from this file, or you compile this file and link it with other  
//  files to produce an executable, this file does not by itself     
//  cause the resulting executable to be covered by the GNU Lesser   
//  General Public License.  This exception does not however         
//  invalidate any other reasons why the executable file might be    
//  covered by the GNU Lesser General Public License.                
//                                                                   
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//  what        : lasd3_itf.hh C++ interface to LAPACK (s,d,c,z)lasd3
//  who         : contributed by Jean-Thierry LAPRESTE 
//  when        : Thu Dec 15 07:00:44 2005                           
//  where       : tested with g++ 3.x,4.x                            
//  from        :                                                    
//  to          :                                                    
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/*! \file lasd3_itf.hh
    (excerpt adapted from xlasd3.f file commentaries)
    
    DATA TYPE can mean float, double, std::complex<float>, std::complex<double>
    
    BASE TYPE can mean respectively float, double, float, double
    
    In some cases only two of these types types are available
    the two real or the two std::complex ones.
    CAPITALIZED PARAMETERS are FORTRAN parameters who are not used directly
    in the C++ calls, but through the workspace parameter,
    their use is transparent for the caller (see lapackworkspace.hh)

    *
    **  purpose
    **  =======
    **
    **  xlasd3 finds all the square roots of the roots of the secular
    **  equation, as defined by the values in d and z.  it makes the
    **  appropriate calls to dlasd4 and then updates the singular
    **  vectors by matrix multiplication.
    **
    **  this code makes very mild assumptions about floating point
    **  arithmetic. it will WORK on machines with a guard digit in
    **  add/subtract, or on those binary machines without guard digits
    **  which subtract like the cray xmp, cray ymp, cray c 90, or cray 2.
    **  it could conceivably fail on hexadecimal or decimal machines
    **  without guard digits, but we know of none.
    **
    **  xlasd3 is called from dlasd1.
    **
    **  arguments
    **  =========
    **
    **  nl     (input) long int
    **         the row dimension of the upper block.  nl >= 1.
    **
    **  nr     (input) long int
    **         the row dimension of the lower block.  nr >= 1.
    **
    **  sqre   (input) long int
    **         = 0: the lower block is an nr-by-nr square matrix.
    **         = 1: the lower block is an nr-by-(nr+1) rectangular matrix.
    **
    **         the bidiagonal matrix has n = nl + nr + 1 rows and
    **         m = n + sqre >= n columns.
    **
    **  k      (input) long int
    **         the size of the secular equation, 1 =< k = < n.
    **
    **  d      (output) BASE DATA TYPE array, dimension(k)
    **         on exit the square roots of the roots of the secular equation,
    **         in ascending order.
    **
    **
    **  ldq    (input) long int
    **         the leading dimension of the array q.  ldq >= k.
    **
    **  dsigma (input) BASE DATA TYPE array, dimension(k)
    **         the first k elements of this array contain the old roots
    **         of the deflated updating problem.  these are the poles
    **         of the secular equation.
    **
    **  u      (input) BASE DATA TYPE array, dimension (ldu, n)
    **         the last n - k columns of this matrix contain the deflated
    **         left singular vectors.
    **
    **  ldu    (input) long int
    **         the leading dimension of the array u.  ldu >= n.
    **
    **  u2     (input) BASE DATA TYPE array, dimension (ldu2, n)
    **         the first k columns of this matrix contain the non-deflated
    **         left singular vectors for the split problem.
    **
    **  ldu2   (input) long int
    **         the leading dimension of the array u2.  ldu2 >= n.
    **
    **  vt     (input) BASE DATA TYPE array, dimension (ldvt, m)
    **         the last m - k columns of vt' contain the deflated
    **         right singular vectors.
    **
    **  ldvt   (input) long int
    **         the leading dimension of the array vt.  ldvt >= n.
    **
    **  vt2    (input) BASE DATA TYPE array, dimension (ldvt2, n)
    **         the first k columns of vt2' contain the non-deflated
    **         right singular vectors for the split problem.
    **
    **  ldvt2  (input) long int
    **         the leading dimension of the array vt2.  ldvt2 >= n.
    **
    **  idxc   (input) long int array, dimension ( n )
    **         the permutation used to arrange the columns of u (and rows of
    **         vt) into three groups:  the first group contains non-zero
    **         entries only at and above (or before) nl +1; the second
    **         contains non-zero entries only at and below (or after) nl+2;
    **         and the third is dense. the first column of u and the row of
    **         vt are treated separately, however.
    **
    **         the rows of the singular vectors found by dlasd4
    **         must be likewise permuted before the matrix multiplies can
    **         take place.
    **
    **  ctot   (input) long int array, dimension ( 4 )
    **         a count of the total number of the various types of columns
    **         in u (or rows in vt), as described in idxc. the fourth column
    **         type is any column which has been deflated.
    **
    **  z      (input) BASE DATA TYPE array, dimension (k)
    **         the first k elements of this array contain the components
    **         of the deflation-adjusted updating row vector.
    **
    **  info   (output) long int
    **         = 0:  successful exit.
    **         < 0:  if info = -i, the i-th argument had an illegal value.
    **         > 0:  if info = 1, an singular value did not converge
    **
    **  further details
    **  ===============
    **
    **  based on contributions by
    **     ming gu and huan ren, computer science division, university of
    **     california at berkeley, usa
    **
**/
/////////////////////////////////////////////////////////////////////////////////


// /////////////////////////////////////////////////////////////////////////////
//  Beginning of lpp namespace
// /////////////////////////////////////////////////////////////////////////////
namespace lpp
{
  
  // /////////////////////////////////////////////////////////////////////////////
  //  macros interfaces to FORTRAN calls
  // /////////////////////////////////////////////////////////////////////////////




  // The following macro provides the 4 functions 
  /*! fn
   inline void lasd3(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        const long int* k,
        float* d,
        const float* q,
        const long int* ldq,
        const float* dsigma,
        const float* u,
        const long int* ldu,
        const float* u2,
        const long int* ldu2,
        const float* vt,
        const long int* ldvt,
        const float* vt2,
        const long int* ldvt2,
        const long int* idxc,
        const long int* ctot,
        const float* z,
        long int* info,
        workspace<float> & w)
  */
  /*! fn
   inline void lasd3(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        const long int* k,
        float* d,
        const float* q,
        const long int* ldq,
        const float* dsigma,
        const float* u,
        const long int* ldu,
        const float* u2,
        const long int* ldu2,
        const float* vt,
        const long int* ldvt,
        const float* vt2,
        const long int* ldvt2,
        const long int* idxc,
        const long int* ctot,
        const float* z,
        long int* info)
  */
  /*! fn
   inline void lasd3(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        const long int* k,
        double* d,
        const double* q,
        const long int* ldq,
        const double* dsigma,
        const double* u,
        const long int* ldu,
        const double* u2,
        const long int* ldu2,
        const double* vt,
        const long int* ldvt,
        const double* vt2,
        const long int* ldvt2,
        const long int* idxc,
        const long int* ctot,
        const double* z,
        long int* info,
        workspace<double> & w)
  */
  /*! fn
   inline void lasd3(
        const long int* nl,
        const long int* nr,
        const long int* sqre,
        const long int* k,
        double* d,
        const double* q,
        const long int* ldq,
        const double* dsigma,
        const double* u,
        const long int* ldu,
        const double* u2,
        const long int* ldu2,
        const double* vt,
        const long int* ldvt,
        const double* vt2,
        const long int* ldvt2,
        const long int* idxc,
        const long int* ctot,
        const double* z,
        long int* info)
  */


  /////////////////////////////////////////////////////////////////////////
  // (excerpt adapted from slasd3.f)
  //    *  Q      (workspace) float array,
  //    *                     dimension at least (LDQ,K).
  //    *
  /////////////////////////////////////////////////////////////////////////

#define LPP_LASD3(NAME, T)\
inline void lasd3(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    const long int* k,\
    T* d,\
    const T* q,\
    const long int* ldq,\
    const T* dsigma,\
    const T* u,\
    const long int* ldu,\
    const T* u2,\
    const long int* ldu2,\
    const T* vt,\
    const long int* ldvt,\
    const T* vt2,\
    const long int* ldvt2,\
    const long int* idxc,\
    const long int* ctot,\
    const T* z,\
    long int* info,\
    workspace<T> & w)\
{\
    F77NAME( NAME )(nl, nr, sqre, k, d, q, ldq, dsigma, u, ldu, u2, ldu2, vt, ldvt, vt2, ldvt2, idxc, ctot, z, info);\
}\
inline void lasd3(\
    const long int* nl,\
    const long int* nr,\
    const long int* sqre,\
    const long int* k,\
    T* d,\
    const T* q,\
    const long int* ldq,\
    const T* dsigma,\
    const T* u,\
    const long int* ldu,\
    const T* u2,\
    const long int* ldu2,\
    const T* vt,\
    const long int* ldvt,\
    const T* vt2,\
    const long int* ldvt2,\
    const long int* idxc,\
    const long int* ctot,\
    const T* z,\
    long int* info)\
{\
   workspace<T> w;\
   lasd3(nl, nr, sqre, k, d, q, ldq, dsigma, u, ldu, u2, ldu2, vt, ldvt, vt2, ldvt2, idxc, ctot, z, info, w);\
}\

    LPP_LASD3(slasd3, float)
    LPP_LASD3(dlasd3, double)

#undef LPP_LASD3



}
#endif

// /////////////////////////////////////////////////////////////////////////////
// End of lasd3_itf.hh
// /////////////////////////////////////////////////////////////////////////////
